<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.1">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting keepoldvectorfont="yes"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="1" fill="3" visible="no" active="no"/>
<layer number="3" name="Route3" color="4" fill="3" visible="no" active="no"/>
<layer number="4" name="Route4" color="1" fill="4" visible="no" active="no"/>
<layer number="5" name="Route5" color="4" fill="4" visible="no" active="no"/>
<layer number="6" name="Route6" color="1" fill="8" visible="no" active="no"/>
<layer number="7" name="Route7" color="4" fill="8" visible="no" active="no"/>
<layer number="8" name="Route8" color="1" fill="2" visible="no" active="no"/>
<layer number="9" name="Route9" color="4" fill="2" visible="no" active="no"/>
<layer number="10" name="Route10" color="1" fill="7" visible="no" active="no"/>
<layer number="11" name="Route11" color="4" fill="7" visible="no" active="no"/>
<layer number="12" name="Route12" color="1" fill="5" visible="no" active="no"/>
<layer number="13" name="Route13" color="4" fill="5" visible="no" active="no"/>
<layer number="14" name="Route14" color="1" fill="6" visible="no" active="no"/>
<layer number="15" name="Route15" color="4" fill="6" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="14" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="13" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="14" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="13" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="11" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="9" visible="no" active="no"/>
<layer number="54" name="bGND_GNDA" color="1" fill="9" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="57" name="tCAD" color="7" fill="1" visible="no" active="no"/>
<layer number="59" name="tCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="60" name="bCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="yes" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="yes" active="yes"/>
<layer number="90" name="Modules" color="7" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="7" fill="1" visible="no" active="no"/>
<layer number="100" name="Muster" color="7" fill="1" visible="yes" active="yes"/>
<layer number="101" name="Patch_Top" color="12" fill="4" visible="yes" active="yes"/>
<layer number="102" name="Mittellin" color="7" fill="1" visible="yes" active="yes"/>
<layer number="103" name="Stiffner" color="7" fill="1" visible="yes" active="yes"/>
<layer number="104" name="Name" color="7" fill="1" visible="yes" active="yes"/>
<layer number="105" name="Beschreib" color="7" fill="1" visible="yes" active="yes"/>
<layer number="106" name="BGA-Top" color="7" fill="1" visible="yes" active="yes"/>
<layer number="107" name="BD-Top" color="7" fill="1" visible="yes" active="yes"/>
<layer number="108" name="tBridges" color="7" fill="1" visible="yes" active="yes"/>
<layer number="109" name="tBPL" color="7" fill="1" visible="yes" active="yes"/>
<layer number="110" name="bBPL" color="7" fill="1" visible="yes" active="yes"/>
<layer number="111" name="MPL" color="7" fill="1" visible="yes" active="yes"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="113" name="ReferenceLS" color="7" fill="1" visible="no" active="no"/>
<layer number="114" name="FRNTMAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="115" name="FRNTMAAT2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="116" name="Patch_BOT" color="9" fill="4" visible="yes" active="yes"/>
<layer number="117" name="BACKMAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="118" name="Rect_Pads" color="7" fill="1" visible="no" active="no"/>
<layer number="119" name="KAP_TEKEN" color="7" fill="1" visible="yes" active="yes"/>
<layer number="120" name="KAP_MAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="121" name="sName" color="7" fill="1" visible="yes" active="yes"/>
<layer number="122" name="_bPlace" color="7" fill="1" visible="yes" active="yes"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="no" active="yes"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="no" active="yes"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="129" name="Mask" color="7" fill="1" visible="yes" active="yes"/>
<layer number="130" name="SMDSTROOK" color="7" fill="1" visible="yes" active="yes"/>
<layer number="131" name="tAdjust" color="7" fill="1" visible="no" active="yes"/>
<layer number="132" name="bAdjust" color="7" fill="1" visible="no" active="yes"/>
<layer number="133" name="bottom_silk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="134" name="silk_top" color="7" fill="1" visible="yes" active="yes"/>
<layer number="135" name="silk_bottom" color="7" fill="1" visible="yes" active="yes"/>
<layer number="136" name="silktop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="137" name="silkbottom" color="7" fill="1" visible="yes" active="yes"/>
<layer number="138" name="EEE" color="7" fill="1" visible="yes" active="yes"/>
<layer number="139" name="_tKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="140" name="mbKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="141" name="ASSEMBLY_TOP" color="7" fill="1" visible="yes" active="yes"/>
<layer number="142" name="mbRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="143" name="PLACE_BOUND_TOP" color="7" fill="1" visible="yes" active="yes"/>
<layer number="144" name="Drill_legend" color="7" fill="1" visible="yes" active="yes"/>
<layer number="145" name="DrillLegend_01-16" color="7" fill="1" visible="yes" active="yes"/>
<layer number="146" name="DrillLegend_01-20" color="7" fill="1" visible="yes" active="yes"/>
<layer number="147" name="PIN_NUMBER" color="7" fill="1" visible="yes" active="yes"/>
<layer number="148" name="DrillLegend_01-20" color="7" fill="1" visible="yes" active="yes"/>
<layer number="149" name="DrillLegend_02-15" color="7" fill="1" visible="yes" active="yes"/>
<layer number="150" name="Notes" color="7" fill="1" visible="yes" active="yes"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="yes" active="yes"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="153" name="FabDoc1" color="6" fill="1" visible="no" active="no"/>
<layer number="154" name="FabDoc2" color="2" fill="1" visible="no" active="no"/>
<layer number="155" name="FabDoc3" color="7" fill="15" visible="no" active="no"/>
<layer number="166" name="AntennaArea" color="7" fill="1" visible="yes" active="yes"/>
<layer number="168" name="4mmHeightArea" color="7" fill="1" visible="yes" active="yes"/>
<layer number="191" name="mNets" color="7" fill="1" visible="yes" active="yes"/>
<layer number="192" name="mBusses" color="7" fill="1" visible="yes" active="yes"/>
<layer number="193" name="mPins" color="7" fill="1" visible="yes" active="yes"/>
<layer number="194" name="mSymbols" color="7" fill="1" visible="yes" active="yes"/>
<layer number="195" name="mNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="196" name="mValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="199" name="Contour" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="yes" active="yes"/>
<layer number="201" name="201bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="202" name="202bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="203" name="203bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="204" name="204bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="205" name="205bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="206" name="206bmp" color="7" fill="10" visible="yes" active="yes"/>
<layer number="207" name="207bmp" color="8" fill="10" visible="yes" active="yes"/>
<layer number="208" name="208bmp" color="9" fill="10" visible="yes" active="yes"/>
<layer number="209" name="209bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="210" name="210bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="211" name="211bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="212" name="212bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="213" name="213bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="214" name="214bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="215" name="215bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="216" name="216bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="217" name="217bmp" color="18" fill="1" visible="no" active="no"/>
<layer number="218" name="218bmp" color="19" fill="1" visible="no" active="no"/>
<layer number="219" name="219bmp" color="20" fill="1" visible="no" active="no"/>
<layer number="220" name="220bmp" color="21" fill="1" visible="no" active="no"/>
<layer number="221" name="221bmp" color="22" fill="1" visible="no" active="no"/>
<layer number="222" name="222bmp" color="23" fill="1" visible="no" active="no"/>
<layer number="223" name="223bmp" color="24" fill="1" visible="no" active="no"/>
<layer number="224" name="224bmp" color="25" fill="1" visible="no" active="no"/>
<layer number="225" name="225bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="226" name="226bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="227" name="227bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="228" name="228bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="229" name="229bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="230" name="230bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="231" name="Eagle3D_PG1" color="7" fill="1" visible="no" active="no"/>
<layer number="232" name="Eagle3D_PG2" color="7" fill="1" visible="no" active="no"/>
<layer number="233" name="Eagle3D_PG3" color="7" fill="1" visible="no" active="no"/>
<layer number="248" name="Housing" color="7" fill="1" visible="yes" active="yes"/>
<layer number="249" name="Edge" color="7" fill="1" visible="yes" active="yes"/>
<layer number="250" name="Descript" color="7" fill="1" visible="yes" active="yes"/>
<layer number="251" name="SMDround" color="7" fill="1" visible="yes" active="yes"/>
<layer number="254" name="cooling" color="7" fill="1" visible="yes" active="yes"/>
<layer number="255" name="routoute" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="microbuilder">
<description>&lt;h2&gt;&lt;b&gt;microBuilder.eu&lt;/b&gt; Eagle Footprint Library&lt;/h2&gt;

&lt;p&gt;Footprints for common components used in our projects and products.  This is the same library that we use internally, and it is regularly updated.  The newest version can always be found at &lt;b&gt;www.microBuilder.eu&lt;/b&gt;.  If you find this library useful, please feel free to purchase something from our online store. Please also note that all holes are optimised for metric drill bits!&lt;/p&gt;

&lt;h3&gt;Obligatory Warning&lt;/h3&gt;
&lt;p&gt;While it probably goes without saying, there are no guarantees that the footprints or schematic symbols in this library are flawless, and we make no promises of fitness for production, prototyping or any other purpose. These libraries are provided for information puposes only, and are used at your own discretion.  While we make every effort to produce accurate footprints, and many of the items found in this library have be proven in production, we can't make any promises of suitability for a specific purpose. If you do find any errors, though, please feel free to contact us at www.microbuilder.eu to let us know about it so that we can update the library accordingly!&lt;/p&gt;

&lt;h3&gt;License&lt;/h3&gt;
&lt;p&gt;This work is placed in the public domain, and may be freely used for commercial and non-commercial work with the following conditions:&lt;/p&gt;
&lt;p&gt;THIS SOFTWARE IS PROVIDED ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
&lt;/p&gt;</description>
<packages>
<package name="_0402">
<description>&lt;b&gt; 0402&lt;/b&gt;</description>
<wire x1="-0.245" y1="0.174" x2="0.245" y2="0.174" width="0.1016" layer="51"/>
<wire x1="0.245" y1="-0.174" x2="-0.245" y2="-0.174" width="0.1016" layer="51"/>
<wire x1="-1.0573" y1="0.5557" x2="1.0573" y2="0.5557" width="0.2032" layer="21"/>
<wire x1="1.0573" y1="0.5557" x2="1.0573" y2="-0.5556" width="0.2032" layer="21"/>
<wire x1="1.0573" y1="-0.5556" x2="-1.0573" y2="-0.5557" width="0.2032" layer="21"/>
<wire x1="-1.0573" y1="-0.5557" x2="-1.0573" y2="0.5557" width="0.2032" layer="21"/>
<smd name="1" x="-0.508" y="0" dx="0.6" dy="0.6" layer="1"/>
<smd name="2" x="0.508" y="0" dx="0.6" dy="0.6" layer="1"/>
<text x="-0.9525" y="0.7939" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-0.9525" y="-1.3336" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-0.0794" y1="-0.2381" x2="0.0794" y2="0.2381" layer="35"/>
<rectangle x1="0.25" y1="-0.25" x2="0.5" y2="0.25" layer="51"/>
<rectangle x1="-0.5" y1="-0.25" x2="-0.25" y2="0.25" layer="51"/>
</package>
<package name="_0402MP">
<description>&lt;b&gt;0402 MicroPitch&lt;p&gt;</description>
<wire x1="-0.245" y1="0.174" x2="0.245" y2="0.174" width="0.1016" layer="51"/>
<wire x1="0.245" y1="-0.174" x2="-0.245" y2="-0.174" width="0.1016" layer="51"/>
<wire x1="0" y1="0.127" x2="0" y2="-0.127" width="0.2032" layer="21"/>
<smd name="1" x="-0.508" y="0" dx="0.5" dy="0.5" layer="1"/>
<smd name="2" x="0.508" y="0" dx="0.5" dy="0.5" layer="1"/>
<text x="-0.635" y="0.4763" size="0.6096" layer="25" ratio="18">&gt;NAME</text>
<text x="-0.635" y="-0.7938" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-0.1" y1="-0.2" x2="0.1" y2="0.2" layer="35"/>
<rectangle x1="-0.5" y1="-0.25" x2="-0.254" y2="0.25" layer="51"/>
<rectangle x1="0.2588" y1="-0.25" x2="0.5" y2="0.25" layer="51"/>
</package>
<package name="_0603">
<description>&lt;b&gt;0603&lt;/b&gt;</description>
<wire x1="-0.432" y1="-0.306" x2="0.432" y2="-0.306" width="0.1016" layer="51"/>
<wire x1="0.432" y1="0.306" x2="-0.432" y2="0.306" width="0.1016" layer="51"/>
<wire x1="-1.4605" y1="0.635" x2="1.4605" y2="0.635" width="0.2032" layer="21"/>
<wire x1="1.4605" y1="0.635" x2="1.4605" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="1.4605" y1="-0.635" x2="-1.4605" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-1.4605" y1="-0.635" x2="-1.4605" y2="0.635" width="0.2032" layer="21"/>
<smd name="1" x="-0.762" y="0" dx="0.9" dy="0.8" layer="1"/>
<smd name="2" x="0.762" y="0" dx="0.9" dy="0.8" layer="1"/>
<text x="-1.27" y="0.9525" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.27" y="-1.4923" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="0.4318" y1="-0.4" x2="0.8382" y2="0.4" layer="51"/>
<rectangle x1="-0.8382" y1="-0.4" x2="-0.4318" y2="0.4" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="_0603MP">
<description>&lt;b&gt;0603 MicroPitch&lt;/b&gt;</description>
<wire x1="-0.432" y1="-0.306" x2="0.432" y2="-0.306" width="0.1016" layer="51"/>
<wire x1="0.432" y1="0.306" x2="-0.432" y2="0.306" width="0.1016" layer="51"/>
<wire x1="0" y1="0.254" x2="0" y2="-0.254" width="0.2032" layer="21"/>
<smd name="1" x="-0.762" y="0" dx="0.8" dy="0.8" layer="1"/>
<smd name="2" x="0.762" y="0" dx="0.8" dy="0.8" layer="1"/>
<text x="-0.9525" y="0.635" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-0.9525" y="-0.9525" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="0.4318" y1="-0.4" x2="0.8" y2="0.4" layer="51"/>
<rectangle x1="-0.8" y1="-0.4" x2="-0.4318" y2="0.4" layer="51"/>
<rectangle x1="-0.1999" y1="-0.25" x2="0.1999" y2="0.25" layer="35"/>
</package>
<package name="_0805">
<description>&lt;b&gt;0805&lt;/b&gt;</description>
<wire x1="-0.41" y1="0.585" x2="0.41" y2="0.585" width="0.1016" layer="51"/>
<wire x1="-0.41" y1="-0.585" x2="0.41" y2="-0.585" width="0.1016" layer="51"/>
<wire x1="-1.905" y1="0.889" x2="1.905" y2="0.889" width="0.2032" layer="21"/>
<wire x1="1.905" y1="0.889" x2="1.905" y2="-0.889" width="0.2032" layer="21"/>
<wire x1="1.905" y1="-0.889" x2="-1.905" y2="-0.889" width="0.2032" layer="21"/>
<wire x1="-1.905" y1="-0.889" x2="-1.905" y2="0.889" width="0.2032" layer="21"/>
<smd name="1" x="-1.016" y="0" dx="1.2" dy="1.3" layer="1"/>
<smd name="2" x="1.016" y="0" dx="1.2" dy="1.3" layer="1"/>
<text x="-1.5875" y="1.27" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.5874" y="-1.651" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="0.4064" y1="-0.65" x2="1.0564" y2="0.65" layer="51"/>
<rectangle x1="-1.0668" y1="-0.65" x2="-0.4168" y2="0.65" layer="51"/>
<rectangle x1="-0.1999" y1="-0.5001" x2="0.1999" y2="0.5001" layer="35"/>
</package>
<package name="_0805MP">
<description>&lt;b&gt;0805 MicroPitch&lt;/b&gt;</description>
<wire x1="-0.51" y1="0.535" x2="0.51" y2="0.535" width="0.1016" layer="51"/>
<wire x1="-0.51" y1="-0.535" x2="0.51" y2="-0.535" width="0.1016" layer="51"/>
<wire x1="0" y1="0.508" x2="0" y2="-0.508" width="0.2032" layer="21"/>
<smd name="1" x="-1.016" y="0" dx="1.2" dy="1.3" layer="1"/>
<smd name="2" x="1.016" y="0" dx="1.2" dy="1.3" layer="1"/>
<text x="-1.5875" y="0.9525" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.5875" y="-1.27" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="0.4064" y1="-0.65" x2="1" y2="0.65" layer="51"/>
<rectangle x1="-1" y1="-0.65" x2="-0.4168" y2="0.65" layer="51"/>
<rectangle x1="-0.1999" y1="-0.5001" x2="0.1999" y2="0.5001" layer="35"/>
</package>
<package name="2012">
<wire x1="-1.662" y1="1.245" x2="1.662" y2="1.245" width="0.2032" layer="51"/>
<wire x1="-1.637" y1="-1.245" x2="1.687" y2="-1.245" width="0.2032" layer="51"/>
<wire x1="-3.473" y1="1.483" x2="3.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="3.473" y1="1.483" x2="3.473" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="3.473" y1="-1.483" x2="-3.473" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-3.473" y1="-1.483" x2="-3.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-3.302" y1="1.524" x2="3.302" y2="1.524" width="0.2032" layer="21"/>
<wire x1="3.302" y1="1.524" x2="3.302" y2="-1.524" width="0.2032" layer="21"/>
<wire x1="3.302" y1="-1.524" x2="-3.302" y2="-1.524" width="0.2032" layer="21"/>
<wire x1="-3.302" y1="-1.524" x2="-3.302" y2="1.524" width="0.2032" layer="21"/>
<smd name="1" x="-2.2" y="0" dx="1.8" dy="2.7" layer="1"/>
<smd name="2" x="2.2" y="0" dx="1.8" dy="2.7" layer="1"/>
<text x="-2.54" y="1.8415" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-2.667" y="-2.159" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-2.4892" y1="-1.3208" x2="-1.6393" y2="1.3292" layer="51"/>
<rectangle x1="1.651" y1="-1.3208" x2="2.5009" y2="1.3292" layer="51"/>
</package>
<package name="2512">
<description>&lt;b&gt;RESISTOR 2512 (Metric 6432)&lt;/b&gt;</description>
<wire x1="-2.362" y1="1.473" x2="2.387" y2="1.473" width="0.2032" layer="51"/>
<wire x1="-2.362" y1="-1.473" x2="2.387" y2="-1.473" width="0.2032" layer="51"/>
<wire x1="-3.973" y1="1.983" x2="3.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="3.973" y1="1.983" x2="3.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="3.973" y1="-1.983" x2="-3.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="-3.973" y1="-1.983" x2="-3.973" y2="1.983" width="0.0508" layer="39"/>
<smd name="1" x="-2.8" y="0" dx="1.8" dy="3.2" layer="1"/>
<smd name="2" x="2.8" y="0" dx="1.8" dy="3.2" layer="1"/>
<text x="-3.683" y="1.905" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-3.556" y="-2.286" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-3.2004" y1="-1.5494" x2="-2.3505" y2="1.5507" layer="51"/>
<rectangle x1="2.3622" y1="-1.5494" x2="3.2121" y2="1.5507" layer="51"/>
<rectangle x1="-0.5001" y1="-1" x2="0.5001" y2="1" layer="35"/>
</package>
<package name="0603-MINI">
<description>0603-Mini
&lt;p&gt;Mini footprint for dense boards&lt;/p&gt;</description>
<wire x1="-1.346" y1="0.583" x2="1.346" y2="0.583" width="0.0508" layer="39"/>
<wire x1="1.346" y1="0.583" x2="1.346" y2="-0.583" width="0.0508" layer="39"/>
<wire x1="1.346" y1="-0.583" x2="-1.346" y2="-0.583" width="0.0508" layer="39"/>
<wire x1="-1.346" y1="-0.583" x2="-1.346" y2="0.583" width="0.0508" layer="39"/>
<wire x1="-1.45" y1="-0.7" x2="-1.45" y2="0.7" width="0.2032" layer="21"/>
<wire x1="-1.45" y1="0.7" x2="1.45" y2="0.7" width="0.2032" layer="21"/>
<wire x1="1.45" y1="0.7" x2="1.45" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="1.45" y1="-0.7" x2="-1.45" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.75" y="0" dx="0.9" dy="0.9" layer="1"/>
<smd name="2" x="0.75" y="0" dx="0.9" dy="0.9" layer="1"/>
<text x="1.524" y="-0.0635" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="1.524" y="-0.635" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
</package>
<package name="0805_NOTHERMALS">
<wire x1="-1.873" y1="0.883" x2="1.873" y2="0.883" width="0.0508" layer="39"/>
<wire x1="1.873" y1="-0.883" x2="-1.873" y2="-0.883" width="0.0508" layer="39"/>
<wire x1="-1.873" y1="-0.883" x2="-1.873" y2="0.883" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<wire x1="1.873" y1="0.883" x2="1.873" y2="-0.883" width="0.0508" layer="39"/>
<wire x1="1.85" y1="1" x2="1.85" y2="-1" width="0.2032" layer="21"/>
<wire x1="1.85" y1="-1" x2="-1.85" y2="-1" width="0.2032" layer="21"/>
<wire x1="-1.85" y1="-1" x2="-1.85" y2="1" width="0.2032" layer="21"/>
<wire x1="-1.85" y1="1" x2="1.85" y2="1" width="0.2032" layer="21"/>
<smd name="1" x="-0.95" y="0" dx="1.3" dy="1.5" layer="1" thermals="no"/>
<smd name="2" x="0.95" y="0" dx="1.3" dy="1.5" layer="1" thermals="no"/>
<text x="2.032" y="-0.127" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="2.032" y="-0.762" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
</package>
<package name="0805-NO">
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<smd name="1" x="-0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="2.032" y="-0.127" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="2.032" y="-0.762" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<wire x1="0" y1="0.508" x2="0" y2="-0.508" width="0.3048" layer="21"/>
</package>
<package name="0805_10MGAP">
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<smd name="1" x="-1.05" y="0" dx="1.2" dy="1.5" layer="1"/>
<smd name="2" x="1.05" y="0" dx="1.2" dy="1.5" layer="1"/>
<text x="2.032" y="-0.127" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="2.032" y="-0.762" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<wire x1="0" y1="0.508" x2="0" y2="-0.508" width="0.3048" layer="21"/>
</package>
<package name="CHIPLED_0805_NOOUTLINE">
<wire x1="-0.35" y1="0.925" x2="0.35" y2="0.925" width="0.1016" layer="51" curve="162.394521"/>
<wire x1="-0.35" y1="-0.925" x2="0.35" y2="-0.925" width="0.1016" layer="51" curve="-162.394521"/>
<wire x1="0.575" y1="0.525" x2="0.575" y2="-0.525" width="0.1016" layer="51"/>
<wire x1="-0.575" y1="-0.5" x2="-0.575" y2="0.925" width="0.1016" layer="51"/>
<circle x="-0.45" y="0.85" radius="0.103" width="0.0762" layer="51"/>
<smd name="C" x="0" y="1.05" dx="1.2" dy="1.2" layer="1"/>
<smd name="A" x="0" y="-1.05" dx="1.2" dy="1.2" layer="1"/>
<text x="-1.016" y="-1.778" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.397" y="-1.778" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<text x="-0.1" y="-1.4" size="0.254" layer="51">A</text>
<text x="-0.1" y="1.2" size="0.254" layer="51">C</text>
<rectangle x1="0.3" y1="0.5" x2="0.625" y2="1" layer="51"/>
<rectangle x1="-0.325" y1="0.5" x2="-0.175" y2="0.75" layer="51"/>
<rectangle x1="0.175" y1="0.5" x2="0.325" y2="0.75" layer="51"/>
<rectangle x1="-0.2" y1="0.5" x2="0.2" y2="0.675" layer="51"/>
<rectangle x1="0.3" y1="-1" x2="0.625" y2="-0.5" layer="51"/>
<rectangle x1="-0.625" y1="-1" x2="-0.3" y2="-0.5" layer="51"/>
<rectangle x1="0.175" y1="-0.75" x2="0.325" y2="-0.5" layer="51"/>
<rectangle x1="-0.325" y1="-0.75" x2="-0.175" y2="-0.5" layer="51"/>
<rectangle x1="-0.2" y1="-0.675" x2="0.2" y2="-0.5" layer="51"/>
<rectangle x1="-0.6" y1="0.5" x2="-0.3" y2="0.762" layer="51"/>
<rectangle x1="-0.625" y1="0.925" x2="-0.3" y2="1" layer="51"/>
<rectangle x1="-0.4445" y1="0.1405" x2="0.4445" y2="0.331" layer="21"/>
<polygon width="0.1524" layer="21">
<vertex x="0" y="0.254"/>
<vertex x="-0.381" y="-0.254"/>
<vertex x="0.381" y="-0.254"/>
</polygon>
</package>
<package name="CHIPLED_1206">
<description>&lt;b&gt;CHIPLED 1206&lt;/b&gt;</description>
<wire x1="-0.4" y1="1.6" x2="0.4" y2="1.6" width="0.1016" layer="51" curve="172.619069"/>
<wire x1="-0.8" y1="-0.95" x2="-0.8" y2="0.95" width="0.1016" layer="51"/>
<wire x1="0.8" y1="0.95" x2="0.8" y2="-0.95" width="0.1016" layer="51"/>
<wire x1="-0.6" y1="0.446" x2="0" y2="0.446" width="0.2032" layer="21"/>
<wire x1="0" y1="0.446" x2="0.6" y2="0.446" width="0.2032" layer="21"/>
<wire x1="0" y1="0.446" x2="-0.6" y2="-0.154" width="0.2032" layer="21"/>
<wire x1="-0.6" y1="-0.154" x2="0.6" y2="-0.154" width="0.2032" layer="21"/>
<wire x1="0.6" y1="-0.154" x2="0" y2="0.446" width="0.2032" layer="21"/>
<wire x1="1" y1="2.4985" x2="-1" y2="2.4985" width="0.2032" layer="21"/>
<wire x1="-1" y1="2.4985" x2="-1" y2="-2.4985" width="0.2032" layer="21"/>
<wire x1="-1" y1="-2.4985" x2="1" y2="-2.4985" width="0.2032" layer="21"/>
<wire x1="1" y1="-2.4985" x2="1" y2="2.4985" width="0.2032" layer="21"/>
<circle x="-0.55" y="1.425" radius="0.1" width="0.0762" layer="51"/>
<smd name="C" x="0" y="1.496" dx="1.5" dy="1.5" layer="1"/>
<smd name="A" x="0" y="-1.496" dx="1.5" dy="1.5" layer="1"/>
<text x="-1.27" y="-2.286" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.651" y="-2.286" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<text x="-0.1" y="-2.23" size="0.4064" layer="51">A</text>
<text x="-0.1" y="1.86" size="0.4064" layer="51">C</text>
<rectangle x1="-0.85" y1="1.525" x2="-0.35" y2="1.65" layer="51"/>
<rectangle x1="-0.85" y1="1.225" x2="-0.625" y2="1.55" layer="51"/>
<rectangle x1="-0.45" y1="1.225" x2="-0.325" y2="1.45" layer="51"/>
<rectangle x1="-0.65" y1="1.225" x2="-0.225" y2="1.35" layer="51"/>
<rectangle x1="0.35" y1="1.3" x2="0.85" y2="1.65" layer="51"/>
<rectangle x1="0.25" y1="1.225" x2="0.85" y2="1.35" layer="51"/>
<rectangle x1="-0.85" y1="0.95" x2="0.85" y2="1.25" layer="51"/>
<rectangle x1="-0.85" y1="-1.65" x2="0.85" y2="-0.95" layer="51"/>
</package>
<package name="CHIPLED_0805">
<description>&lt;b&gt;CHIPLED 0805&lt;/b&gt;</description>
<wire x1="-0.35" y1="0.925" x2="0.35" y2="0.925" width="0.1016" layer="51" curve="162.394521"/>
<wire x1="-0.35" y1="-0.925" x2="0.35" y2="-0.925" width="0.1016" layer="51" curve="-162.394521"/>
<wire x1="0.575" y1="0.525" x2="0.575" y2="-0.525" width="0.1016" layer="51"/>
<wire x1="-0.575" y1="-0.5" x2="-0.575" y2="0.925" width="0.1016" layer="51"/>
<wire x1="-0.4" y1="0.2" x2="0" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0" y1="0.2" x2="0.4" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0" y1="0.2" x2="-0.4" y2="-0.2" width="0.2032" layer="21"/>
<wire x1="-0.4" y1="-0.2" x2="0.4" y2="-0.2" width="0.2032" layer="21"/>
<wire x1="0.4" y1="-0.2" x2="0" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0.85" y1="-1.9" x2="-0.85" y2="-1.9" width="0.2032" layer="21"/>
<wire x1="-0.85" y1="-1.9" x2="-0.85" y2="1.9" width="0.2032" layer="21"/>
<wire x1="-0.85" y1="1.9" x2="0.85" y2="1.9" width="0.2032" layer="21"/>
<wire x1="0.85" y1="1.9" x2="0.85" y2="-1.9" width="0.2032" layer="21"/>
<circle x="-0.45" y="0.85" radius="0.103" width="0.0762" layer="51"/>
<smd name="C" x="0" y="1.05" dx="1.2" dy="1.2" layer="1"/>
<smd name="A" x="0" y="-1.05" dx="1.2" dy="1.2" layer="1"/>
<text x="-1.016" y="-1.778" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.397" y="-1.778" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<text x="-0.1" y="-1.4" size="0.254" layer="51">A</text>
<text x="-0.1" y="1.2" size="0.254" layer="51">C</text>
<rectangle x1="0.3" y1="0.5" x2="0.625" y2="1" layer="51"/>
<rectangle x1="-0.325" y1="0.5" x2="-0.175" y2="0.75" layer="51"/>
<rectangle x1="0.175" y1="0.5" x2="0.325" y2="0.75" layer="51"/>
<rectangle x1="-0.2" y1="0.5" x2="0.2" y2="0.675" layer="51"/>
<rectangle x1="0.3" y1="-1" x2="0.625" y2="-0.5" layer="51"/>
<rectangle x1="-0.625" y1="-1" x2="-0.3" y2="-0.5" layer="51"/>
<rectangle x1="0.175" y1="-0.75" x2="0.325" y2="-0.5" layer="51"/>
<rectangle x1="-0.325" y1="-0.75" x2="-0.175" y2="-0.5" layer="51"/>
<rectangle x1="-0.2" y1="-0.675" x2="0.2" y2="-0.5" layer="51"/>
<rectangle x1="-0.6" y1="0.5" x2="-0.3" y2="0.762" layer="51"/>
<rectangle x1="-0.625" y1="0.925" x2="-0.3" y2="1" layer="51"/>
</package>
<package name="CHIPLED_0603">
<description>&lt;b&gt;CHIPLED 0603&lt;/b&gt;</description>
<wire x1="-0.3" y1="0.8" x2="0.3" y2="0.8" width="0.1016" layer="51" curve="170.055574"/>
<wire x1="-0.275" y1="-0.825" x2="0.275" y2="-0.825" width="0.0508" layer="51" curve="-180"/>
<wire x1="-0.4" y1="0.375" x2="-0.4" y2="-0.35" width="0.1016" layer="51"/>
<wire x1="0.4" y1="0.35" x2="0.4" y2="-0.35" width="0.1016" layer="51"/>
<wire x1="-0.65" y1="-1.4" x2="-0.65" y2="1.4" width="0.2032" layer="21"/>
<wire x1="0.65" y1="1.4" x2="0.65" y2="-1.4" width="0.2032" layer="21"/>
<wire x1="-0.65" y1="1.4" x2="0.65" y2="1.4" width="0.2032" layer="21"/>
<wire x1="-0.65" y1="-1.4" x2="0.65" y2="-1.4" width="0.2032" layer="21"/>
<wire x1="-0.4" y1="0.2" x2="0" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0" y1="0.2" x2="0.4" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0" y1="0.2" x2="-0.4" y2="-0.2" width="0.2032" layer="21"/>
<wire x1="-0.4" y1="-0.2" x2="0.4" y2="-0.2" width="0.2032" layer="21"/>
<wire x1="0.4" y1="-0.2" x2="0" y2="0.2" width="0.2032" layer="21"/>
<circle x="-0.35" y="0.625" radius="0.075" width="0.0508" layer="51"/>
<smd name="C" x="0" y="0.75" dx="0.8" dy="0.8" layer="1"/>
<smd name="A" x="0" y="-0.75" dx="0.8" dy="0.8" layer="1"/>
<text x="-0.762" y="-1.27" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.27" y="-1.27" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<rectangle x1="-0.45" y1="0.7" x2="-0.25" y2="0.85" layer="51"/>
<rectangle x1="-0.275" y1="0.55" x2="-0.225" y2="0.6" layer="51"/>
<rectangle x1="-0.45" y1="0.35" x2="-0.4" y2="0.725" layer="51"/>
<rectangle x1="0.25" y1="0.55" x2="0.45" y2="0.85" layer="51"/>
<rectangle x1="-0.45" y1="0.35" x2="0.45" y2="0.575" layer="51"/>
<rectangle x1="-0.45" y1="-0.85" x2="-0.25" y2="-0.35" layer="51"/>
<rectangle x1="0.25" y1="-0.85" x2="0.45" y2="-0.35" layer="51"/>
<rectangle x1="-0.275" y1="-0.575" x2="0.275" y2="-0.35" layer="51"/>
<rectangle x1="-0.275" y1="-0.65" x2="-0.175" y2="-0.55" layer="51"/>
<rectangle x1="0.175" y1="-0.65" x2="0.275" y2="-0.55" layer="51"/>
</package>
<package name="CHIPLED_0603_NOOUTLINE">
<wire x1="-0.3" y1="0.8" x2="0.3" y2="0.8" width="0.1016" layer="51" curve="170.055574"/>
<wire x1="-0.275" y1="-0.825" x2="0.275" y2="-0.825" width="0.0508" layer="51" curve="-180"/>
<wire x1="-0.4" y1="0.375" x2="-0.4" y2="-0.35" width="0.1016" layer="51"/>
<wire x1="0.4" y1="0.35" x2="0.4" y2="-0.35" width="0.1016" layer="51"/>
<circle x="-0.35" y="0.625" radius="0.075" width="0.0508" layer="51"/>
<smd name="C" x="0" y="0.75" dx="0.8" dy="0.8" layer="1"/>
<smd name="A" x="0" y="-0.75" dx="0.8" dy="0.8" layer="1"/>
<text x="-0.762" y="-1.27" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.27" y="-1.27" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<rectangle x1="-0.45" y1="0.7" x2="-0.25" y2="0.85" layer="51"/>
<rectangle x1="-0.275" y1="0.55" x2="-0.225" y2="0.6" layer="51"/>
<rectangle x1="-0.45" y1="0.35" x2="-0.4" y2="0.725" layer="51"/>
<rectangle x1="0.25" y1="0.55" x2="0.45" y2="0.85" layer="51"/>
<rectangle x1="-0.45" y1="0.35" x2="0.45" y2="0.575" layer="51"/>
<rectangle x1="-0.45" y1="-0.85" x2="-0.25" y2="-0.35" layer="51"/>
<rectangle x1="0.25" y1="-0.85" x2="0.45" y2="-0.35" layer="51"/>
<rectangle x1="-0.275" y1="-0.575" x2="0.275" y2="-0.35" layer="51"/>
<rectangle x1="-0.275" y1="-0.65" x2="-0.175" y2="-0.55" layer="51"/>
<rectangle x1="0.175" y1="-0.65" x2="0.275" y2="-0.55" layer="51"/>
<rectangle x1="-0.381" y1="0.1397" x2="0.381" y2="0.2667" layer="21"/>
<polygon width="0.1524" layer="21">
<vertex x="0" y="0.1397"/>
<vertex x="-0.254" y="-0.1778"/>
<vertex x="0.254" y="-0.1778"/>
</polygon>
</package>
<package name="CREE_XLAMP_XPE2">
<description>&lt;p&gt;Source: http://www.cree.com/~/media/Files/Cree/LED%20Components%20and%20Modules/XLamp/Data%20and%20Binning/XLampXPE2.pdf&lt;/p&gt;</description>
<smd name="CATHODE" x="-1.4" y="0" dx="0.5" dy="3.3" layer="1" cream="no"/>
<smd name="ANODE" x="1.4" y="0" dx="0.5" dy="3.3" layer="1" cream="no"/>
<smd name="THERMAL" x="0" y="0" dx="1.3" dy="3.3" layer="1" cream="no"/>
<rectangle x1="-2.05" y1="-0.25" x2="-1.15" y2="0.25" layer="1"/>
<rectangle x1="-2.1" y1="-0.3" x2="-1.15" y2="0.3" layer="29"/>
<rectangle x1="1.15" y1="-0.25" x2="2.05" y2="0.25" layer="1" rot="R180"/>
<rectangle x1="1.15" y1="-0.3" x2="2.1" y2="0.3" layer="29" rot="R180"/>
<rectangle x1="-0.6" y1="-1.6" x2="0.6" y2="1.6" layer="31"/>
<rectangle x1="-2" y1="-0.2" x2="-1.2" y2="0.2" layer="31"/>
<rectangle x1="-1.6" y1="0.2" x2="-1.2" y2="1.6" layer="31"/>
<rectangle x1="-1.6" y1="-1.6" x2="-1.2" y2="-0.2" layer="31"/>
<rectangle x1="1.2" y1="-0.2" x2="2" y2="0.2" layer="31"/>
<rectangle x1="1.2" y1="0.2" x2="1.6" y2="1.6" layer="31"/>
<rectangle x1="1.2" y1="-1.6" x2="1.6" y2="-0.2" layer="31"/>
<wire x1="-1.725" y1="1.725" x2="1.725" y2="1.725" width="0.127" layer="51"/>
<wire x1="1.725" y1="1.725" x2="1.725" y2="-1.725" width="0.127" layer="51"/>
<wire x1="1.725" y1="-1.725" x2="-1.725" y2="-1.725" width="0.127" layer="51"/>
<wire x1="-1.725" y1="-1.725" x2="-1.725" y2="1.725" width="0.127" layer="51"/>
<circle x="0" y="0" radius="1.48660625" width="0.127" layer="51"/>
<rectangle x1="-1.5" y1="-1.5" x2="-1.3" y2="-1.3" layer="51"/>
<wire x1="-0.6" y1="-1.7" x2="-0.6" y2="-0.7" width="0.127" layer="51"/>
<wire x1="-0.6" y1="-0.7" x2="0.7" y2="-0.7" width="0.127" layer="51"/>
<wire x1="0.7" y1="-0.7" x2="0.7" y2="0.7" width="0.127" layer="51"/>
<wire x1="0.7" y1="0.7" x2="0" y2="0.7" width="0.127" layer="51"/>
<wire x1="0" y1="0.7" x2="0" y2="1.7" width="0.127" layer="51"/>
<polygon width="0.1524" layer="21">
<vertex x="2.346" y="1.2"/>
<vertex x="2.954" y="0.719"/>
<vertex x="2.954" y="1.681"/>
</polygon>
<rectangle x1="2.1" y1="0.6" x2="2.4" y2="1.8" layer="21"/>
<wire x1="-1.8" y1="1.8" x2="1.8" y2="1.8" width="0.127" layer="21"/>
<wire x1="1.8" y1="1.8" x2="1.8" y2="0.4" width="0.127" layer="21"/>
<wire x1="-1.8" y1="1.8" x2="-1.8" y2="0.4" width="0.127" layer="21"/>
<wire x1="-1.8" y1="-0.4" x2="-1.8" y2="-1.8" width="0.127" layer="21"/>
<wire x1="-1.8" y1="-1.8" x2="1.8" y2="-1.8" width="0.127" layer="21"/>
<wire x1="1.8" y1="-1.8" x2="1.8" y2="-0.4" width="0.127" layer="21"/>
<text x="-1.862" y="2.027" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.762" y="-2.435" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-0.5" y1="-0.5" x2="0.5" y2="0.5" layer="51"/>
</package>
<package name="CREE_XLAMP_XTE">
<smd name="CATHODE" x="-1.4" y="0" dx="0.5" dy="3.3" layer="1" cream="no"/>
<smd name="ANODE" x="1.4" y="0" dx="0.5" dy="3.3" layer="1" cream="no"/>
<smd name="THERMAL" x="0" y="0" dx="1.3" dy="3.3" layer="1" cream="no"/>
<rectangle x1="-2.05" y1="-0.25" x2="-1.15" y2="0.25" layer="1"/>
<rectangle x1="-2.1" y1="-0.3" x2="-1.15" y2="0.3" layer="29"/>
<rectangle x1="1.15" y1="-0.25" x2="2.05" y2="0.25" layer="1" rot="R180"/>
<rectangle x1="1.15" y1="-0.3" x2="2.1" y2="0.3" layer="29" rot="R180"/>
<rectangle x1="-0.6" y1="-1.6" x2="0.6" y2="1.6" layer="31"/>
<rectangle x1="-2" y1="-0.2" x2="-1.2" y2="0.2" layer="31"/>
<rectangle x1="-1.6" y1="0.2" x2="-1.2" y2="1.6" layer="31"/>
<rectangle x1="-1.6" y1="-1.6" x2="-1.2" y2="-0.2" layer="31"/>
<rectangle x1="1.2" y1="-0.2" x2="2" y2="0.2" layer="31"/>
<rectangle x1="1.2" y1="0.2" x2="1.6" y2="1.6" layer="31"/>
<rectangle x1="1.2" y1="-1.6" x2="1.6" y2="-0.2" layer="31"/>
<wire x1="-1.725" y1="1.725" x2="1.725" y2="1.725" width="0.127" layer="51"/>
<wire x1="1.725" y1="1.725" x2="1.725" y2="-1.725" width="0.127" layer="51"/>
<wire x1="1.725" y1="-1.725" x2="-1.725" y2="-1.725" width="0.127" layer="51"/>
<wire x1="-1.725" y1="-1.725" x2="-1.725" y2="1.725" width="0.127" layer="51"/>
<rectangle x1="-1.5" y1="-1.5" x2="-1.3" y2="-1.3" layer="51"/>
<polygon width="0.1524" layer="21">
<vertex x="2.346" y="1.2"/>
<vertex x="2.954" y="0.719"/>
<vertex x="2.954" y="1.681"/>
</polygon>
<rectangle x1="2.1" y1="0.6" x2="2.4" y2="1.8" layer="21"/>
<wire x1="-1.8" y1="1.8" x2="1.8" y2="1.8" width="0.127" layer="21"/>
<wire x1="1.8" y1="1.8" x2="1.8" y2="0.4" width="0.127" layer="21"/>
<wire x1="-1.8" y1="1.8" x2="-1.8" y2="0.4" width="0.127" layer="21"/>
<wire x1="-1.8" y1="-0.4" x2="-1.8" y2="-1.8" width="0.127" layer="21"/>
<wire x1="-1.8" y1="-1.8" x2="1.8" y2="-1.8" width="0.127" layer="21"/>
<wire x1="1.8" y1="-1.8" x2="1.8" y2="-0.4" width="0.127" layer="21"/>
<text x="-1.862" y="2.027" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.762" y="-2.435" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-0.5" y1="-0.5" x2="0.5" y2="0.5" layer="51"/>
<circle x="0" y="0" radius="1.5811375" width="0.127" layer="51"/>
<circle x="0" y="0" radius="1.3928375" width="0.127" layer="51"/>
<wire x1="1.2" y1="0.125" x2="1.45" y2="0.125" width="0.1" layer="51"/>
<wire x1="1.45" y1="0.125" x2="1.45" y2="0.375" width="0.1" layer="51"/>
<wire x1="1.45" y1="0.375" x2="1.7" y2="0.375" width="0.1" layer="51"/>
<wire x1="1.7" y1="0.375" x2="1.7" y2="0.125" width="0.1" layer="51"/>
<wire x1="1.7" y1="0.125" x2="1.95" y2="0.125" width="0.1" layer="51"/>
<wire x1="1.95" y1="0.125" x2="1.95" y2="-0.125" width="0.1" layer="51"/>
<wire x1="1.95" y1="-0.125" x2="1.7" y2="-0.125" width="0.1" layer="51"/>
<wire x1="1.7" y1="-0.125" x2="1.7" y2="-0.375" width="0.1" layer="51"/>
<wire x1="1.7" y1="-0.375" x2="1.45" y2="-0.375" width="0.1" layer="51"/>
<wire x1="1.45" y1="-0.375" x2="1.45" y2="-0.125" width="0.1" layer="51"/>
<wire x1="1.45" y1="-0.125" x2="1.2" y2="-0.125" width="0.1" layer="51"/>
<wire x1="1.2" y1="-0.125" x2="1.2" y2="0.125" width="0.1" layer="51"/>
</package>
<package name="EVERLIGHT_45-21">
<wire x1="-1.35" y1="1" x2="1.35" y2="1" width="0.127" layer="51"/>
<wire x1="1.35" y1="1" x2="1.35" y2="0.7" width="0.127" layer="51"/>
<wire x1="1.35" y1="0.7" x2="1.35" y2="-0.55" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.55" x2="1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.7" x2="1.35" y2="-1" width="0.127" layer="51"/>
<wire x1="1.35" y1="-1" x2="0.9" y2="-1" width="0.127" layer="51"/>
<wire x1="0.9" y1="-1" x2="-1.35" y2="-1" width="0.127" layer="51"/>
<wire x1="-1.35" y1="-1" x2="-1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="-1.35" y1="-0.7" x2="-1.35" y2="0.7" width="0.127" layer="51"/>
<wire x1="-1.35" y1="0.7" x2="-1.35" y2="1" width="0.127" layer="51"/>
<wire x1="1.35" y1="0.7" x2="1.5" y2="0.7" width="0.127" layer="51"/>
<wire x1="1.5" y1="0.7" x2="1.5" y2="-0.7" width="0.127" layer="51"/>
<wire x1="1.5" y1="-0.7" x2="1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.7" x2="1.35" y2="-0.55" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.55" x2="1.35" y2="0.7" width="0.127" layer="51"/>
<wire x1="-1.35" y1="0.7" x2="-1.5" y2="0.7" width="0.127" layer="51"/>
<wire x1="-1.5" y1="0.7" x2="-1.5" y2="-0.7" width="0.127" layer="51"/>
<wire x1="-1.5" y1="-0.7" x2="-1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="-1.15" y1="0.45" x2="-1.15" y2="0.5" width="0.127" layer="51"/>
<wire x1="-1.15" y1="0.5" x2="-0.85" y2="0.8" width="0.127" layer="51" curve="-90"/>
<wire x1="-0.85" y1="0.8" x2="0.8" y2="0.8" width="0.127" layer="51"/>
<wire x1="0.8" y1="0.8" x2="1.15" y2="0.45" width="0.127" layer="51" curve="-90"/>
<wire x1="1.15" y1="0.45" x2="1.15" y2="-0.5" width="0.127" layer="51"/>
<wire x1="1.15" y1="-0.5" x2="0.85" y2="-0.8" width="0.127" layer="51" curve="-90"/>
<wire x1="0.85" y1="-0.8" x2="-0.85" y2="-0.8" width="0.127" layer="51"/>
<wire x1="-0.85" y1="-0.8" x2="-1.15" y2="-0.5" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.15" y1="-0.5" x2="-1.15" y2="0.45" width="0.127" layer="51"/>
<smd name="A" x="-1.45" y="0" dx="1.4" dy="1.4" layer="1"/>
<smd name="K" x="1.45" y="0" dx="1.4" dy="1.4" layer="1"/>
<wire x1="0.9" y1="-1" x2="1.35" y2="-0.55" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.55" x2="1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.7" x2="1.1" y2="-0.95" width="0.127" layer="51"/>
<wire x1="1.1" y1="-0.95" x2="1.2" y2="-0.95" width="0.127" layer="51"/>
<wire x1="1.2" y1="-0.95" x2="1.3" y2="-0.85" width="0.127" layer="51"/>
<text x="-1.375" y="1.25" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.375" y="-1.633" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<wire x1="-1.45" y1="0.85" x2="-1.45" y2="1.1" width="0.127" layer="21"/>
<wire x1="-1.45" y1="1.1" x2="1.45" y2="1.1" width="0.127" layer="21"/>
<wire x1="1.45" y1="1.1" x2="1.45" y2="0.9" width="0.127" layer="21"/>
<wire x1="1.45" y1="0.9" x2="1.45" y2="0.85" width="0.127" layer="21"/>
<wire x1="-1.45" y1="-0.85" x2="-1.45" y2="-1.1" width="0.127" layer="21"/>
<wire x1="-1.45" y1="-1.1" x2="1.45" y2="-1.1" width="0.127" layer="21"/>
<wire x1="1.45" y1="-1.1" x2="1.45" y2="-0.85" width="0.127" layer="21"/>
<polygon width="0.1524" layer="21">
<vertex x="0.254" y="0"/>
<vertex x="-0.354" y="0.481"/>
<vertex x="-0.354" y="-0.481"/>
</polygon>
<rectangle x1="0.2" y1="-0.6" x2="0.5" y2="0.6" layer="21" rot="R180"/>
</package>
<package name="PLCC2_REVMOUNT">
<description>&lt;p&gt;PLCC2 - Reverse Mount&lt;/p&gt;
&lt;p&gt;Source: http://catalog.osram-os.com/media/_en/Graphics/00042122_0.pdf&lt;/p&gt;</description>
<smd name="K" x="-2.4" y="0" dx="1.2" dy="2.6" layer="1"/>
<smd name="A" x="2.4" y="0" dx="1.2" dy="2.6" layer="1"/>
<hole x="0" y="0" drill="2.5"/>
<wire x1="-1.7" y1="1.15" x2="-1.7" y2="1.3" width="0.127" layer="51"/>
<wire x1="-1.7" y1="1.3" x2="-1.5" y2="1.5" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.5" y1="1.5" x2="-0.95" y2="1.5" width="0.127" layer="51"/>
<wire x1="-0.95" y1="1.5" x2="1.5" y2="1.5" width="0.127" layer="51"/>
<wire x1="1.5" y1="1.5" x2="1.7" y2="1.3" width="0.127" layer="51" curve="-90"/>
<wire x1="1.7" y1="1.3" x2="1.7" y2="1.2" width="0.127" layer="51"/>
<wire x1="1.7" y1="1.2" x2="1.7" y2="1.15" width="0.127" layer="51"/>
<wire x1="1.7" y1="1.15" x2="2.7" y2="1.15" width="0.127" layer="51"/>
<wire x1="2.7" y1="1.15" x2="2.7" y2="-1.15" width="0.127" layer="51"/>
<wire x1="2.7" y1="-1.15" x2="1.7" y2="-1.15" width="0.127" layer="51"/>
<wire x1="1.7" y1="-1.15" x2="1.7" y2="-1.2" width="0.127" layer="51"/>
<wire x1="1.7" y1="-1.2" x2="1.7" y2="-1.25" width="0.127" layer="51"/>
<wire x1="1.7" y1="-1.25" x2="1.45" y2="-1.5" width="0.127" layer="51" curve="-90"/>
<wire x1="1.45" y1="-1.5" x2="-1.45" y2="-1.5" width="0.127" layer="51"/>
<wire x1="-1.45" y1="-1.5" x2="-1.7" y2="-1.25" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.7" y1="-1.25" x2="-1.7" y2="-1.15" width="0.127" layer="51"/>
<wire x1="-1.7" y1="-1.15" x2="-2.65" y2="-1.15" width="0.127" layer="51"/>
<wire x1="-2.65" y1="-1.15" x2="-2.65" y2="1.15" width="0.127" layer="51"/>
<wire x1="-2.65" y1="1.15" x2="-1.7" y2="1.15" width="0.127" layer="51"/>
<wire x1="-1.7" y1="1.15" x2="-1.7" y2="0.75" width="0.127" layer="51"/>
<wire x1="-1.7" y1="0.75" x2="-1.7" y2="0.65" width="0.127" layer="51"/>
<wire x1="-1.7" y1="0.65" x2="-1.7" y2="-0.65" width="0.127" layer="51"/>
<wire x1="-1.7" y1="-0.65" x2="-1.7" y2="-1.15" width="0.127" layer="51"/>
<wire x1="-1.7" y1="-0.65" x2="-1.75" y2="-0.65" width="0.127" layer="51"/>
<wire x1="-1.75" y1="-0.65" x2="-1.85" y2="-0.55" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.85" y1="-0.55" x2="-1.85" y2="0.5" width="0.127" layer="51"/>
<wire x1="-1.85" y1="0.5" x2="-1.7" y2="0.65" width="0.127" layer="51" curve="-90"/>
<wire x1="1.7" y1="-1.2" x2="1.7" y2="-0.65" width="0.127" layer="51"/>
<wire x1="1.7" y1="-0.65" x2="1.7" y2="0.65" width="0.127" layer="51"/>
<wire x1="1.7" y1="0.65" x2="1.7" y2="1.2" width="0.127" layer="51"/>
<wire x1="1.7" y1="0.65" x2="1.75" y2="0.65" width="0.127" layer="51"/>
<wire x1="1.75" y1="0.65" x2="1.85" y2="0.55" width="0.127" layer="51" curve="-90"/>
<wire x1="1.85" y1="0.55" x2="1.85" y2="-0.5" width="0.127" layer="51"/>
<wire x1="1.85" y1="-0.5" x2="1.7" y2="-0.65" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.7" y1="0.75" x2="-0.95" y2="1.5" width="0.127" layer="51"/>
<circle x="0" y="0" radius="1.220653125" width="0.127" layer="51"/>
<wire x1="0" y1="0.8" x2="0.8" y2="0" width="0.127" layer="51" style="shortdash" curve="-90"/>
<wire x1="0.8" y1="0" x2="0" y2="-0.8" width="0.127" layer="51" style="shortdash" curve="-90"/>
<wire x1="0" y1="-0.8" x2="-0.8" y2="0" width="0.127" layer="51" style="shortdash" curve="-90"/>
<wire x1="-0.8" y1="0" x2="0" y2="0.8" width="0.127" layer="51" style="shortdash" curve="-90"/>
<wire x1="-1.75" y1="1.45" x2="-1.6" y2="1.6" width="0.127" layer="21" curve="-90"/>
<wire x1="-1.6" y1="1.6" x2="1.6" y2="1.6" width="0.127" layer="21"/>
<wire x1="1.6" y1="1.6" x2="1.75" y2="1.45" width="0.127" layer="21" curve="-90"/>
<wire x1="-1.75" y1="-1.45" x2="-1.55" y2="-1.6" width="0.127" layer="21" curve="90"/>
<wire x1="-1.55" y1="-1.6" x2="1.55" y2="-1.6" width="0.127" layer="21"/>
<wire x1="1.55" y1="-1.6" x2="1.75" y2="-1.45" width="0.127" layer="21" curve="90"/>
<text x="-1.79" y="1.84" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.74" y="-2.16" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="0603-NO">
<wire x1="-1.473" y1="0.729" x2="1.473" y2="0.729" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.729" x2="1.473" y2="-0.729" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.729" x2="-1.473" y2="-0.729" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.729" x2="-1.473" y2="0.729" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="1.778" y="-0.127" size="0.8128" layer="25" font="vector" ratio="18">&gt;NAME</text>
<text x="1.778" y="-0.762" size="0.4064" layer="27" font="vector" ratio="10">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="_1206">
<wire x1="0.9525" y1="-0.8128" x2="-0.9652" y2="-0.8128" width="0.1016" layer="51"/>
<wire x1="0.9525" y1="0.8128" x2="-0.9652" y2="0.8128" width="0.1016" layer="51"/>
<wire x1="-2.286" y1="1.143" x2="2.286" y2="1.143" width="0.2032" layer="21"/>
<wire x1="2.286" y1="1.143" x2="2.286" y2="-1.143" width="0.2032" layer="21"/>
<wire x1="2.286" y1="-1.143" x2="-2.286" y2="-1.143" width="0.2032" layer="21"/>
<wire x1="-2.286" y1="-1.143" x2="-2.286" y2="1.143" width="0.2032" layer="21"/>
<smd name="2" x="1.27" y="0" dx="1.4" dy="1.8" layer="1"/>
<smd name="1" x="-1.27" y="0" dx="1.4" dy="1.8" layer="1"/>
<rectangle x1="-1.6891" y1="-0.8763" x2="-0.9525" y2="0.8763" layer="51"/>
<rectangle x1="0.9525" y1="-0.8763" x2="1.6891" y2="0.8763" layer="51"/>
<rectangle x1="-0.3" y1="-0.7" x2="0.3" y2="0.7" layer="35"/>
<text x="-2.2225" y="1.5113" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-2.2225" y="-1.8288" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="_1206MP">
<wire x1="1.0525" y1="-0.7128" x2="-1.0652" y2="-0.7128" width="0.1016" layer="51"/>
<wire x1="1.0525" y1="0.7128" x2="-1.0652" y2="0.7128" width="0.1016" layer="51"/>
<wire x1="-0.635" y1="0.635" x2="0.635" y2="0.635" width="0.2032" layer="21"/>
<wire x1="-0.635" y1="-0.635" x2="0.635" y2="-0.635" width="0.2032" layer="21"/>
<smd name="2" x="1.524" y="0" dx="1.3" dy="1.6" layer="1"/>
<smd name="1" x="-1.524" y="0" dx="1.3" dy="1.6" layer="1"/>
<text x="-2.2225" y="1.1113" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-2.2225" y="-1.4288" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-1.6" y1="-0.8" x2="-0.9" y2="0.8" layer="51"/>
<rectangle x1="-0.3" y1="-0.7" x2="0.3" y2="0.7" layer="35"/>
<rectangle x1="0.9001" y1="-0.8" x2="1.6" y2="0.8" layer="51" rot="R180"/>
</package>
<package name="SOT23-5">
<description>&lt;b&gt;Small Outline Transistor&lt;/b&gt; - 5 Pin</description>
<wire x1="1.4224" y1="0.8104" x2="1.4224" y2="-0.8104" width="0.2032" layer="51"/>
<wire x1="1.4224" y1="-0.8104" x2="-1.4224" y2="-0.8104" width="0.2032" layer="51"/>
<wire x1="-1.4224" y1="-0.8104" x2="-1.4224" y2="0.8104" width="0.2032" layer="51"/>
<wire x1="-1.4224" y1="0.8104" x2="1.4224" y2="0.8104" width="0.2032" layer="51"/>
<wire x1="-1.65" y1="0.8" x2="-1.65" y2="-0.8" width="0.2032" layer="21"/>
<wire x1="1.65" y1="0.8" x2="1.65" y2="-0.8" width="0.2032" layer="21"/>
<smd name="1" x="-0.95" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="2" x="0" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="3" x="0.95" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="4" x="0.95" y="1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="5" x="-0.95" y="1.3001" dx="0.55" dy="1.2" layer="1"/>
<text x="1.978" y="0" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="1.978" y="-0.635" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-1.2" y1="-1.5" x2="-0.7" y2="-0.85" layer="51"/>
<rectangle x1="-0.25" y1="-1.5" x2="0.25" y2="-0.85" layer="51"/>
<rectangle x1="0.7" y1="-1.5" x2="1.2" y2="-0.85" layer="51"/>
<rectangle x1="0.7" y1="0.85" x2="1.2" y2="1.5" layer="51"/>
<rectangle x1="-1.2" y1="0.85" x2="-0.7" y2="1.5" layer="51"/>
<wire x1="-0.4" y1="1.05" x2="0.4" y2="1.05" width="0.2032" layer="21"/>
</package>
<package name="SMADIODE">
<description>&lt;b&gt;SMA Surface Mount Diode&lt;/b&gt;</description>
<wire x1="-2.15" y1="1.3" x2="2.15" y2="1.3" width="0.2032" layer="51"/>
<wire x1="2.15" y1="1.3" x2="2.15" y2="-1.3" width="0.2032" layer="51"/>
<wire x1="2.15" y1="-1.3" x2="-2.15" y2="-1.3" width="0.2032" layer="51"/>
<wire x1="-2.15" y1="-1.3" x2="-2.15" y2="1.3" width="0.2032" layer="51"/>
<wire x1="-3.889" y1="-1.146" x2="-3.889" y2="1.6" width="0.2032" layer="21"/>
<wire x1="-3.889" y1="1.6" x2="3.916" y2="1.6" width="0.2032" layer="21"/>
<wire x1="3.916" y1="1.6" x2="3.916" y2="1.394" width="0.2032" layer="21"/>
<wire x1="3.916" y1="1.394" x2="3.916" y2="-1.6" width="0.2032" layer="21"/>
<wire x1="3.916" y1="-1.6" x2="-3.889" y2="-1.6" width="0.2032" layer="21"/>
<wire x1="-3.889" y1="-1.6" x2="-3.889" y2="-1.146" width="0.2032" layer="21"/>
<wire x1="0.254" y1="0.762" x2="0.254" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="0.254" y1="-0.762" x2="-0.508" y2="0" width="0.2032" layer="21"/>
<wire x1="-0.508" y1="0" x2="0.254" y2="0.762" width="0.2032" layer="21"/>
<wire x1="-0.508" y1="0.762" x2="-0.508" y2="0" width="0.2032" layer="21"/>
<wire x1="-0.508" y1="0" x2="-0.508" y2="-0.762" width="0.2032" layer="21"/>
<smd name="C" x="-2.3495" y="0" dx="2.54" dy="2.54" layer="1"/>
<smd name="A" x="2.3495" y="0" dx="2.54" dy="2.54" layer="1" rot="R180"/>
<text x="-2.54" y="1.905" size="0.8128" layer="25" font="vector" ratio="18">&gt;NAME</text>
<text x="-2.54" y="-2.286" size="0.4064" layer="27" font="vector" ratio="10">&gt;VALUE</text>
<rectangle x1="-2.825" y1="-1.1" x2="-2.175" y2="1.1" layer="51"/>
<rectangle x1="2.175" y1="-1.1" x2="2.825" y2="1.1" layer="51" rot="R180"/>
<rectangle x1="-1.75" y1="-1.225" x2="-1.075" y2="1.225" layer="51"/>
</package>
<package name="DO-1N4148">
<wire x1="-2.54" y1="0.762" x2="2.54" y2="0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0.762" x2="2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="-0.762" x2="-2.54" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="-0.762" x2="-2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0" x2="2.794" y2="0" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.794" y2="0" width="0.2032" layer="21"/>
<wire x1="1.905" y1="0.635" x2="1.905" y2="-0.635" width="0.2032" layer="21"/>
<pad name="A" x="-3.81" y="0" drill="0.9"/>
<pad name="C" x="3.81" y="0" drill="0.9"/>
<text x="-2.286" y="1.143" size="0.8128" layer="25" ratio="18">&gt;Name</text>
<text x="-2.286" y="-0.381" size="0.8128" layer="21">&gt;Value</text>
</package>
<package name="SOT23-R">
<description>&lt;b&gt;SOT23&lt;/b&gt; - Reflow soldering</description>
<wire x1="1.5724" y1="0.6604" x2="1.5724" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="1.5724" y1="-0.6604" x2="-1.5724" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="-1.5724" y1="-0.6604" x2="-1.5724" y2="0.6604" width="0.1524" layer="51"/>
<wire x1="-1.5724" y1="0.6604" x2="1.5724" y2="0.6604" width="0.2032" layer="51"/>
<wire x1="-1.5724" y1="-0.6524" x2="-1.5724" y2="0.6604" width="0.2032" layer="21"/>
<wire x1="-1.5724" y1="0.6604" x2="-0.5636" y2="0.6604" width="0.2032" layer="21"/>
<wire x1="1.5724" y1="0.6604" x2="1.5724" y2="-0.6524" width="0.2032" layer="21"/>
<wire x1="0.5636" y1="0.6604" x2="1.5724" y2="0.6604" width="0.2032" layer="21"/>
<wire x1="0.3724" y1="-0.6604" x2="-0.3864" y2="-0.6604" width="0.2032" layer="21"/>
<smd name="3" x="0" y="1" dx="0.635" dy="1.016" layer="1"/>
<smd name="2" x="0.95" y="-1" dx="0.635" dy="1.016" layer="1"/>
<smd name="1" x="-0.95" y="-1" dx="0.635" dy="1.016" layer="1"/>
<text x="1.778" y="-0.127" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="1.778" y="-0.635" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-0.2286" y1="0.7112" x2="0.2286" y2="1.2954" layer="51"/>
<rectangle x1="0.7112" y1="-1.2954" x2="1.1684" y2="-0.7112" layer="51"/>
<rectangle x1="-1.1684" y1="-1.2954" x2="-0.7112" y2="-0.7112" layer="51"/>
</package>
<package name="SOD-523">
<description>SOD-523 (0.8x1.2mm)

&lt;p&gt;Source: http://www.rohm.com/products/databook/di/pdf/rb751s-40.pdf&lt;/p&gt;</description>
<smd name="K" x="0" y="0.75" dx="0.8" dy="0.6" layer="1"/>
<smd name="A" x="0" y="-0.75" dx="0.8" dy="0.6" layer="1"/>
<text x="0.716" y="0.016" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="0.716" y="-0.724" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<wire x1="0.4254" y1="0.6" x2="0.4254" y2="-0.6" width="0.127" layer="21"/>
<wire x1="0.4" y1="-0.6" x2="-0.4" y2="-0.6" width="0.127" layer="51"/>
<wire x1="-0.4254" y1="-0.6" x2="-0.4254" y2="0.6" width="0.127" layer="21"/>
<wire x1="-0.4" y1="0.6" x2="0.4" y2="0.6" width="0.127" layer="51"/>
<wire x1="0" y1="0.05" x2="0.25" y2="-0.2" width="0.127" layer="21"/>
<wire x1="0.25" y1="-0.2" x2="-0.25" y2="-0.2" width="0.127" layer="21"/>
<wire x1="-0.25" y1="-0.2" x2="0" y2="0.05" width="0.127" layer="21"/>
<rectangle x1="-0.1" y1="0.45" x2="0.1" y2="0.85" layer="51" rot="R270"/>
<rectangle x1="-0.1" y1="-0.85" x2="0.1" y2="-0.45" layer="51" rot="R270"/>
<rectangle x1="-0.1" y1="-0.2254" x2="0.1" y2="0.5746" layer="21" rot="R270"/>
<polygon width="0.0508" layer="21">
<vertex x="0" y="0.05"/>
<vertex x="0.25" y="-0.2"/>
<vertex x="-0.25" y="-0.2"/>
</polygon>
</package>
<package name="SOD-323">
<description>&lt;b&gt;SOD323&lt;/b&gt; (2.5x1.2mm)</description>
<smd name="C" x="-1.27" y="0" dx="1.35" dy="0.8" layer="1"/>
<smd name="A" x="1.27" y="0" dx="1.35" dy="0.8" layer="1"/>
<text x="-1.1" y="1" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.1" y="-1.792" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<wire x1="-1" y1="0.7" x2="1" y2="0.7" width="0.2032" layer="21"/>
<wire x1="1" y1="0.7" x2="1" y2="-0.7" width="0.2032" layer="51"/>
<wire x1="1" y1="-0.7" x2="-1" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="-1" y1="-0.7" x2="-1" y2="0.7" width="0.2032" layer="51"/>
<wire x1="-0.25" y1="0" x2="0.35" y2="0.4" width="0.2032" layer="21"/>
<wire x1="0.35" y1="0.4" x2="0.35" y2="-0.4" width="0.2032" layer="21"/>
<wire x1="0.35" y1="-0.4" x2="-0.25" y2="0" width="0.2032" layer="21"/>
<rectangle x1="-0.45" y1="-0.5" x2="-0.25" y2="0.5" layer="21"/>
<polygon width="0.2032" layer="21">
<vertex x="-0.1" y="0"/>
<vertex x="0.2" y="0.2"/>
<vertex x="0.2" y="-0.2"/>
</polygon>
</package>
<package name="SOD-123">
<description>&lt;b&gt;SOD-123&lt;/b&gt;
&lt;p&gt;Source: http://www.diodes.com/datasheets/ds30139.pdf&lt;/p&gt;</description>
<smd name="C" x="-1.85" y="0" dx="1.4" dy="1.4" layer="1" rot="R90"/>
<smd name="A" x="1.85" y="0" dx="1.4" dy="1.4" layer="1" rot="R90"/>
<text x="-1.27" y="1.016" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.27" y="-1.778" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<wire x1="-0.873" y1="0.7" x2="0.873" y2="0.7" width="0.2032" layer="21"/>
<wire x1="0.873" y1="0.7" x2="0.873" y2="-0.7" width="0.2032" layer="51"/>
<wire x1="0.873" y1="-0.7" x2="-0.873" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="-0.873" y1="-0.7" x2="-0.873" y2="0.7" width="0.2032" layer="51"/>
<wire x1="-0.3" y1="0" x2="0.3" y2="0.4" width="0.2032" layer="21"/>
<wire x1="0.3" y1="0.4" x2="0.3" y2="-0.4" width="0.2032" layer="21"/>
<wire x1="0.3" y1="-0.4" x2="-0.3" y2="0" width="0.2032" layer="21"/>
<rectangle x1="-1.723" y1="-0.45" x2="-0.973" y2="0.4" layer="51"/>
<rectangle x1="0.973" y1="-0.45" x2="1.723" y2="0.4" layer="51"/>
<rectangle x1="-0.5" y1="-0.5" x2="-0.3" y2="0.5" layer="21"/>
<polygon width="0.2032" layer="21">
<vertex x="-0.1" y="0"/>
<vertex x="0.2" y="0.2"/>
<vertex x="0.2" y="-0.2"/>
</polygon>
</package>
<package name="SOT23-WIDE">
<wire x1="1.5724" y1="0.6604" x2="1.5724" y2="-0.6604" width="0.2032" layer="51"/>
<wire x1="1.5724" y1="-0.6604" x2="-1.5724" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="-1.5724" y1="-0.6604" x2="-1.5724" y2="0.6604" width="0.2032" layer="51"/>
<wire x1="-1.5724" y1="0.6604" x2="1.5724" y2="0.6604" width="0.2032" layer="51"/>
<wire x1="-1.6724" y1="-0.6524" x2="-1.6724" y2="0.6604" width="0.2032" layer="21"/>
<wire x1="-1.6724" y1="0.6604" x2="-0.7136" y2="0.6604" width="0.2032" layer="21"/>
<wire x1="1.6724" y1="0.6604" x2="1.6724" y2="-0.6524" width="0.2032" layer="21"/>
<wire x1="0.7136" y1="0.6604" x2="1.6724" y2="0.6604" width="0.2032" layer="21"/>
<wire x1="0.2224" y1="-0.6604" x2="-0.2364" y2="-0.6604" width="0.2032" layer="21"/>
<smd name="3" x="0" y="1" dx="1" dy="1.2" layer="1"/>
<smd name="2" x="0.95" y="-1" dx="1" dy="1.2" layer="1"/>
<smd name="1" x="-0.95" y="-1" dx="1" dy="1.2" layer="1"/>
<text x="1.905" y="0" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="1.905" y="-0.635" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-0.2286" y1="0.7112" x2="0.2286" y2="1.2954" layer="51"/>
<rectangle x1="0.7112" y1="-1.2954" x2="1.1684" y2="-0.7112" layer="51"/>
<rectangle x1="-1.1684" y1="-1.2954" x2="-0.7112" y2="-0.7112" layer="51"/>
</package>
<package name="POWERDI-5">
<smd name="A1" x="-0.92" y="-2.84" dx="1.39" dy="1.4" layer="1"/>
<smd name="A2" x="0.92" y="-2.84" dx="1.39" dy="1.4" layer="1"/>
<smd name="C" x="0" y="1.142" dx="3.36" dy="4.86" layer="1"/>
<wire x1="-2" y1="3.25" x2="2" y2="3.25" width="0.127" layer="51"/>
<wire x1="2" y1="3.25" x2="2" y2="-3.25" width="0.127" layer="51"/>
<wire x1="2" y1="-3.25" x2="-2" y2="-3.25" width="0.127" layer="51"/>
<wire x1="-2" y1="-3.25" x2="-2" y2="3.25" width="0.127" layer="51"/>
<wire x1="-1.8" y1="-3" x2="-2.1" y2="-3" width="0.127" layer="21"/>
<wire x1="-2.1" y1="-3" x2="-2.1" y2="3" width="0.127" layer="21"/>
<wire x1="-2.1" y1="3" x2="-1.9" y2="3" width="0.127" layer="21"/>
<wire x1="1.9" y1="3.1" x2="2.1" y2="3.1" width="0.127" layer="21"/>
<wire x1="2.1" y1="3.1" x2="2.1" y2="-3" width="0.127" layer="21"/>
<wire x1="2.1" y1="-3" x2="1.8" y2="-3" width="0.127" layer="21"/>
<text x="-2.34" y="-2.99" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="2.66" y="-3.04" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<polygon width="0.3048" layer="51">
<vertex x="-1.5" y="-0.6"/>
<vertex x="0" y="1.9"/>
<vertex x="1.5" y="-0.6"/>
</polygon>
<rectangle x1="-1.6" y1="2" x2="1.6" y2="2.4" layer="51"/>
</package>
<package name="TQFP44">
<wire x1="-4.8" y1="4.4" x2="-4.4" y2="4.8" width="0.2032" layer="21"/>
<wire x1="-4.4" y1="4.8" x2="4.4" y2="4.8" width="0.2032" layer="21"/>
<wire x1="4.4" y1="4.8" x2="4.8" y2="4.4" width="0.2032" layer="21"/>
<wire x1="4.8" y1="4.4" x2="4.8" y2="-4.4" width="0.2032" layer="21"/>
<wire x1="4.8" y1="-4.4" x2="4.4" y2="-4.8" width="0.2032" layer="21"/>
<wire x1="4.4" y1="-4.8" x2="-4.4" y2="-4.8" width="0.2032" layer="21"/>
<wire x1="-4.4" y1="-4.8" x2="-4.8" y2="-4.4" width="0.2032" layer="21"/>
<wire x1="-4.8" y1="-4.4" x2="-4.8" y2="4.4" width="0.2032" layer="21"/>
<circle x="-4" y="4" radius="0.2827" width="0.254" layer="21"/>
<smd name="1" x="-5.8" y="4" dx="1.5" dy="0.5" layer="1"/>
<smd name="2" x="-5.8" y="3.2" dx="1.5" dy="0.5" layer="1"/>
<smd name="3" x="-5.8" y="2.4" dx="1.5" dy="0.5" layer="1"/>
<smd name="4" x="-5.8" y="1.6" dx="1.5" dy="0.5" layer="1"/>
<smd name="5" x="-5.8" y="0.8" dx="1.5" dy="0.5" layer="1"/>
<smd name="6" x="-5.8" y="0" dx="1.5" dy="0.5" layer="1"/>
<smd name="7" x="-5.8" y="-0.8" dx="1.5" dy="0.5" layer="1"/>
<smd name="8" x="-5.8" y="-1.6" dx="1.5" dy="0.5" layer="1"/>
<smd name="9" x="-5.8" y="-2.4" dx="1.5" dy="0.5" layer="1"/>
<smd name="10" x="-5.8" y="-3.2" dx="1.5" dy="0.5" layer="1"/>
<smd name="11" x="-5.8" y="-4" dx="1.5" dy="0.5" layer="1"/>
<smd name="12" x="-4" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="13" x="-3.2" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="14" x="-2.4" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="15" x="-1.6" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="16" x="-0.8" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="17" x="0" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="18" x="0.8" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="19" x="1.6" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="20" x="2.4" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="21" x="3.2" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="22" x="4" y="-5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="23" x="5.8" y="-4" dx="1.5" dy="0.5" layer="1"/>
<smd name="24" x="5.8" y="-3.2" dx="1.5" dy="0.5" layer="1"/>
<smd name="25" x="5.8" y="-2.4" dx="1.5" dy="0.5" layer="1"/>
<smd name="26" x="5.8" y="-1.6" dx="1.5" dy="0.5" layer="1"/>
<smd name="27" x="5.8" y="-0.8" dx="1.5" dy="0.5" layer="1"/>
<smd name="28" x="5.8" y="0" dx="1.5" dy="0.5" layer="1"/>
<smd name="29" x="5.8" y="0.8" dx="1.5" dy="0.5" layer="1"/>
<smd name="30" x="5.8" y="1.6" dx="1.5" dy="0.5" layer="1"/>
<smd name="31" x="5.8" y="2.4" dx="1.5" dy="0.5" layer="1"/>
<smd name="32" x="5.8" y="3.2" dx="1.5" dy="0.5" layer="1"/>
<smd name="33" x="5.8" y="4" dx="1.5" dy="0.5" layer="1"/>
<smd name="34" x="4" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="35" x="3.2" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="36" x="2.4" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="37" x="1.6" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="38" x="0.8" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="39" x="0" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="40" x="-0.8" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="41" x="-1.6" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="42" x="-2.4" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="43" x="-3.2" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<smd name="44" x="-4" y="5.8" dx="0.5" dy="1.5" layer="1"/>
<text x="-3.81" y="6.985" size="1.778" layer="25">&gt;NAME</text>
<text x="-4.445" y="-8.7551" size="1.778" layer="27">&gt;VALUE</text>
<rectangle x1="-6.1001" y1="3.8001" x2="-4.95" y2="4.1999" layer="51"/>
<rectangle x1="-6.1001" y1="3" x2="-4.95" y2="3.4" layer="51"/>
<rectangle x1="-6.1001" y1="2.1999" x2="-4.95" y2="2.5999" layer="51"/>
<rectangle x1="-6.1001" y1="1.4" x2="-4.95" y2="1.8001" layer="51"/>
<rectangle x1="-6.1001" y1="0.5999" x2="-4.95" y2="1" layer="51"/>
<rectangle x1="-6.1001" y1="-0.1999" x2="-4.95" y2="0.1999" layer="51"/>
<rectangle x1="-6.1001" y1="-1" x2="-4.95" y2="-0.5999" layer="51"/>
<rectangle x1="-6.1001" y1="-1.8001" x2="-4.95" y2="-1.4" layer="51"/>
<rectangle x1="-6.1001" y1="-2.5999" x2="-4.95" y2="-2.1999" layer="51"/>
<rectangle x1="-6.1001" y1="-3.4" x2="-4.95" y2="-3" layer="51"/>
<rectangle x1="-6.1001" y1="-4.1999" x2="-4.95" y2="-3.8001" layer="51"/>
<rectangle x1="-4.1999" y1="-6.1001" x2="-3.8001" y2="-4.95" layer="51"/>
<rectangle x1="-3.4" y1="-6.1001" x2="-3" y2="-4.95" layer="51"/>
<rectangle x1="-2.5999" y1="-6.1001" x2="-2.1999" y2="-4.95" layer="51"/>
<rectangle x1="-1.8001" y1="-6.1001" x2="-1.4" y2="-4.95" layer="51"/>
<rectangle x1="-1" y1="-6.1001" x2="-0.5999" y2="-4.95" layer="51"/>
<rectangle x1="-0.1999" y1="-6.1001" x2="0.1999" y2="-4.95" layer="51"/>
<rectangle x1="0.5999" y1="-6.1001" x2="1" y2="-4.95" layer="51"/>
<rectangle x1="1.4" y1="-6.1001" x2="1.8001" y2="-4.95" layer="51"/>
<rectangle x1="2.1999" y1="-6.1001" x2="2.5999" y2="-4.95" layer="51"/>
<rectangle x1="3" y1="-6.1001" x2="3.4" y2="-4.95" layer="51"/>
<rectangle x1="3.8001" y1="-6.1001" x2="4.1999" y2="-4.95" layer="51"/>
<rectangle x1="4.95" y1="-4.1999" x2="6.1001" y2="-3.8001" layer="51"/>
<rectangle x1="4.95" y1="-3.4" x2="6.1001" y2="-3" layer="51"/>
<rectangle x1="4.95" y1="-2.5999" x2="6.1001" y2="-2.1999" layer="51"/>
<rectangle x1="4.95" y1="-1.8001" x2="6.1001" y2="-1.4" layer="51"/>
<rectangle x1="4.95" y1="-1" x2="6.1001" y2="-0.5999" layer="51"/>
<rectangle x1="4.95" y1="-0.1999" x2="6.1001" y2="0.1999" layer="51"/>
<rectangle x1="4.95" y1="0.5999" x2="6.1001" y2="1" layer="51"/>
<rectangle x1="4.95" y1="1.4" x2="6.1001" y2="1.8001" layer="51"/>
<rectangle x1="4.95" y1="2.1999" x2="6.1001" y2="2.5999" layer="51"/>
<rectangle x1="4.95" y1="3" x2="6.1001" y2="3.4" layer="51"/>
<rectangle x1="4.95" y1="3.8001" x2="6.1001" y2="4.1999" layer="51"/>
<rectangle x1="3.8001" y1="4.95" x2="4.1999" y2="6.1001" layer="51"/>
<rectangle x1="3" y1="4.95" x2="3.4" y2="6.1001" layer="51"/>
<rectangle x1="2.1999" y1="4.95" x2="2.5999" y2="6.1001" layer="51"/>
<rectangle x1="1.4" y1="4.95" x2="1.8001" y2="6.1001" layer="51"/>
<rectangle x1="0.5999" y1="4.95" x2="1" y2="6.1001" layer="51"/>
<rectangle x1="-0.1999" y1="4.95" x2="0.1999" y2="6.1001" layer="51"/>
<rectangle x1="-1" y1="4.95" x2="-0.5999" y2="6.1001" layer="51"/>
<rectangle x1="-1.8001" y1="4.95" x2="-1.4" y2="6.1001" layer="51"/>
<rectangle x1="-2.5999" y1="4.95" x2="-2.1999" y2="6.1001" layer="51"/>
<rectangle x1="-3.4" y1="4.95" x2="-3" y2="6.1001" layer="51"/>
<rectangle x1="-4.1999" y1="4.95" x2="-3.8001" y2="6.1001" layer="51"/>
</package>
<package name="TQFN44_7MM">
<description>&lt;p&gt;&lt;b&gt;Source: &lt;/b&gt;http://datasheets.maxim-ic.com/en/ds/MAX9744.pdf&lt;/p&gt;</description>
<wire x1="-3.5" y1="3.5" x2="3.5" y2="3.5" width="0.127" layer="51"/>
<wire x1="3.5" y1="3.5" x2="3.5" y2="-3.5" width="0.127" layer="51"/>
<wire x1="3.5" y1="-3.5" x2="-3.5" y2="-3.5" width="0.127" layer="51"/>
<wire x1="-3.5" y1="-3.5" x2="-3.5" y2="3.5" width="0.127" layer="51"/>
<smd name="1" x="-2.5" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="2" x="-2" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="3" x="-1.5" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="4" x="-1" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="5" x="-0.5" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="6" x="0" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="7" x="0.5" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="8" x="1" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="9" x="1.5" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="10" x="2" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="11" x="2.5" y="-3.475" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="12" x="3.475" y="-2.5" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="13" x="3.475" y="-2" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="14" x="3.475" y="-1.5" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="15" x="3.475" y="-1" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="16" x="3.475" y="-0.5" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="17" x="3.475" y="0" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="18" x="3.475" y="0.5" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="19" x="3.475" y="1" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="20" x="3.475" y="1.5" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="21" x="3.475" y="2" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="22" x="3.475" y="2.5" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="23" x="2.5" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="24" x="2" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="25" x="1.5" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="26" x="1" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="27" x="0.5" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="28" x="0" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="29" x="-0.5" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="30" x="-1" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="31" x="-1.5" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="32" x="-2" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="33" x="-2.5" y="3.475" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="34" x="-3.475" y="2.5" dx="0.8" dy="0.25" layer="1"/>
<smd name="35" x="-3.475" y="2" dx="0.8" dy="0.25" layer="1"/>
<smd name="36" x="-3.475" y="1.5" dx="0.8" dy="0.25" layer="1"/>
<smd name="37" x="-3.475" y="1" dx="0.8" dy="0.25" layer="1"/>
<smd name="38" x="-3.475" y="0.5" dx="0.8" dy="0.25" layer="1"/>
<smd name="39" x="-3.475" y="0" dx="0.8" dy="0.25" layer="1"/>
<smd name="40" x="-3.475" y="-0.5" dx="0.8" dy="0.25" layer="1"/>
<smd name="41" x="-3.475" y="-1" dx="0.8" dy="0.25" layer="1"/>
<smd name="42" x="-3.475" y="-1.5" dx="0.8" dy="0.25" layer="1"/>
<smd name="43" x="-3.475" y="-2" dx="0.8" dy="0.25" layer="1"/>
<smd name="44" x="-3.475" y="-2.5" dx="0.8" dy="0.25" layer="1"/>
<rectangle x1="-3.5" y1="2.375" x2="-2.95" y2="2.625" layer="51"/>
<rectangle x1="-3.5" y1="1.875" x2="-2.95" y2="2.125" layer="51"/>
<rectangle x1="-3.5" y1="1.375" x2="-2.95" y2="1.625" layer="51"/>
<rectangle x1="-3.5" y1="0.875" x2="-2.95" y2="1.125" layer="51"/>
<rectangle x1="-3.5" y1="0.375" x2="-2.95" y2="0.625" layer="51"/>
<rectangle x1="-3.5" y1="-0.125" x2="-2.95" y2="0.125" layer="51"/>
<rectangle x1="-3.5" y1="-0.625" x2="-2.95" y2="-0.375" layer="51"/>
<rectangle x1="-3.5" y1="-1.125" x2="-2.95" y2="-0.875" layer="51"/>
<rectangle x1="-3.5" y1="-1.625" x2="-2.95" y2="-1.375" layer="51"/>
<rectangle x1="-3.5" y1="-2.125" x2="-2.95" y2="-1.875" layer="51"/>
<rectangle x1="-3.5" y1="-2.625" x2="-2.95" y2="-2.375" layer="51"/>
<rectangle x1="-2.775" y1="-3.35" x2="-2.225" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="-2.275" y1="-3.35" x2="-1.725" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="-1.775" y1="-3.35" x2="-1.225" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="-1.275" y1="-3.35" x2="-0.725" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="-0.775" y1="-3.35" x2="-0.225" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="-0.275" y1="-3.35" x2="0.275" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="0.225" y1="-3.35" x2="0.775" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="0.725" y1="-3.35" x2="1.275" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="1.225" y1="-3.35" x2="1.775" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="1.725" y1="-3.35" x2="2.275" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="2.225" y1="-3.35" x2="2.775" y2="-3.1" layer="51" rot="R90"/>
<rectangle x1="2.95" y1="-2.625" x2="3.5" y2="-2.375" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="-2.125" x2="3.5" y2="-1.875" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="-1.625" x2="3.5" y2="-1.375" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="-1.125" x2="3.5" y2="-0.875" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="-0.625" x2="3.5" y2="-0.375" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="-0.125" x2="3.5" y2="0.125" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="0.375" x2="3.5" y2="0.625" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="0.875" x2="3.5" y2="1.125" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="1.375" x2="3.5" y2="1.625" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="1.875" x2="3.5" y2="2.125" layer="51" rot="R180"/>
<rectangle x1="2.95" y1="2.375" x2="3.5" y2="2.625" layer="51" rot="R180"/>
<rectangle x1="2.225" y1="3.1" x2="2.775" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="1.725" y1="3.1" x2="2.275" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="1.225" y1="3.1" x2="1.775" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="0.725" y1="3.1" x2="1.275" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="0.225" y1="3.1" x2="0.775" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="-0.275" y1="3.1" x2="0.275" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="-0.775" y1="3.1" x2="-0.225" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="-1.275" y1="3.1" x2="-0.725" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="-1.775" y1="3.1" x2="-1.225" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="-2.275" y1="3.1" x2="-1.725" y2="3.35" layer="51" rot="R270"/>
<rectangle x1="-2.775" y1="3.1" x2="-2.225" y2="3.35" layer="51" rot="R270"/>
<text x="-2.6" y="4.4" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<circle x="-3.878" y="-3.932" radius="0.127" width="0.4064" layer="21"/>
<text x="-3" y="-4.7" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<wire x1="-2.8" y1="3.6" x2="-3.6" y2="3.6" width="0.127" layer="21"/>
<wire x1="-3.6" y1="3.6" x2="-3.6" y2="2.8" width="0.127" layer="21"/>
<wire x1="2.8" y1="3.6" x2="3.6" y2="3.6" width="0.127" layer="21"/>
<wire x1="3.6" y1="3.6" x2="3.6" y2="2.8" width="0.127" layer="21"/>
<wire x1="-3.6" y1="-2.8" x2="-3.6" y2="-3.6" width="0.127" layer="21"/>
<wire x1="-3.6" y1="-3.6" x2="-2.8" y2="-3.6" width="0.127" layer="21"/>
<wire x1="3.6" y1="-2.8" x2="3.6" y2="-3.6" width="0.127" layer="21"/>
<wire x1="3.6" y1="-3.6" x2="2.8" y2="-3.6" width="0.127" layer="21"/>
<smd name="THERMAL" x="0" y="0" dx="4.7" dy="4.7" layer="1" cream="no"/>
<rectangle x1="-2" y1="0.5" x2="-1" y2="2" layer="31"/>
<rectangle x1="-0.5" y1="0.5" x2="0.5" y2="2" layer="31"/>
<rectangle x1="1" y1="0.5" x2="2" y2="2" layer="31"/>
<rectangle x1="1" y1="-2" x2="2" y2="-0.5" layer="31"/>
<rectangle x1="-0.5" y1="-2" x2="0.5" y2="-0.5" layer="31"/>
<rectangle x1="-2" y1="-2" x2="-1" y2="-0.5" layer="31"/>
</package>
<package name="U.FL">
<wire x1="1.3" y1="0.7" x2="1.3" y2="2.1" width="0.2032" layer="21"/>
<wire x1="1.3" y1="2.1" x2="-1.3" y2="2.1" width="0.2032" layer="21"/>
<wire x1="-1.3" y1="-2.1" x2="1.3" y2="-2.1" width="0.2032" layer="21"/>
<wire x1="1.3" y1="-2.1" x2="1.3" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="-1.3" y1="0.7" x2="-1.3" y2="2.1" width="0.2032" layer="21"/>
<wire x1="-1.3" y1="-2.1" x2="-1.3" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="1.4" y1="0.7" x2="1.4" y2="2" width="0.2032" layer="21"/>
<wire x1="1.4" y1="-2" x2="1.4" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="1.5" y1="0.7" x2="1.5" y2="2.1" width="0.2032" layer="21"/>
<wire x1="1.5" y1="-2.1" x2="1.5" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="1.5" y1="2.1" x2="1.3" y2="2.1" width="0.2032" layer="21"/>
<wire x1="1.5" y1="0.7" x2="1.3" y2="0.7" width="0.2032" layer="21"/>
<wire x1="1.5" y1="-0.7" x2="1.3" y2="-0.7" width="0.2032" layer="21"/>
<wire x1="1.5" y1="-2.1" x2="1.3" y2="-2.1" width="0.2032" layer="21"/>
<smd name="1" x="0" y="1.375" dx="2.2" dy="1.05" layer="1"/>
<smd name="2" x="0" y="-1.375" dx="2.2" dy="1.05" layer="1"/>
<smd name="3" x="1.525" y="0" dx="0.8" dy="1" layer="1"/>
<rectangle x1="-0.889" y1="-0.8255" x2="0.889" y2="0.8255" layer="41"/>
<text x="-1.27" y="2.54" size="1.016" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.27" y="-3.175" size="0.8128" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="JSTPH2">
<description>2-Pin JST PH Series Right-Angle Connector (+/- for batteries)</description>
<wire x1="-4" y1="3" x2="4" y2="3" width="0.2032" layer="51"/>
<wire x1="4" y1="3" x2="4" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="-4" y1="-4.5" x2="-4" y2="3" width="0.2032" layer="51"/>
<wire x1="3.2" y1="-2" x2="-3.2" y2="-2" width="0.2032" layer="51"/>
<wire x1="-3.2" y1="-2" x2="-3.2" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="-3.2" y1="-4.5" x2="-4" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="4" y1="-4.5" x2="3.2" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="3.2" y1="-4.5" x2="3.2" y2="-2" width="0.2032" layer="51"/>
<wire x1="-2.25" y1="3" x2="2.25" y2="3" width="0.2032" layer="21"/>
<wire x1="4" y1="-0.5" x2="4" y2="-4.5" width="0.2032" layer="21"/>
<wire x1="4" y1="-4.5" x2="3.15" y2="-4.5" width="0.2032" layer="21"/>
<wire x1="3.15" y1="-4.5" x2="3.15" y2="-2" width="0.2032" layer="21"/>
<wire x1="3.15" y1="-2" x2="1.75" y2="-2" width="0.2032" layer="21"/>
<wire x1="-1.75" y1="-2" x2="-3.15" y2="-2" width="0.2032" layer="21"/>
<wire x1="-3.15" y1="-2" x2="-3.15" y2="-4.5" width="0.2032" layer="21"/>
<wire x1="-3.15" y1="-4.5" x2="-4" y2="-4.5" width="0.2032" layer="21"/>
<wire x1="-4" y1="-4.5" x2="-4" y2="-0.5" width="0.2032" layer="21"/>
<smd name="1" x="-1" y="-3.7" dx="1" dy="4.6" layer="1"/>
<smd name="2" x="1" y="-3.7" dx="1" dy="4.6" layer="1"/>
<smd name="NC1" x="-3.4" y="1.5" dx="3.4" dy="1.6" layer="1" rot="R90"/>
<smd name="NC2" x="3.4" y="1.5" dx="3.4" dy="1.6" layer="1" rot="R90"/>
<text x="-2.2225" y="1.9685" size="0.8128" layer="25" ratio="18">&gt;Name</text>
<text x="-2.2225" y="1.27" size="0.4064" layer="27" ratio="10">&gt;Value</text>
</package>
<package name="JSTSH2">
<wire x1="2" y1="2.125" x2="-2" y2="2.125" width="0.127" layer="20"/>
<wire x1="-2" y1="2.125" x2="-2" y2="-2.125" width="0.127" layer="20"/>
<wire x1="-2" y1="-2.125" x2="2" y2="-2.125" width="0.127" layer="20"/>
<wire x1="2" y1="-2.125" x2="2" y2="2.125" width="0.127" layer="20"/>
<wire x1="-0.889" y1="2.159" x2="0.889" y2="2.159" width="0.2032" layer="21"/>
<wire x1="-2.032" y1="-0.127" x2="-2.032" y2="-2.159" width="0.2032" layer="21"/>
<wire x1="-2.032" y1="-2.159" x2="-1.143" y2="-2.159" width="0.2032" layer="21"/>
<wire x1="2.032" y1="-0.127" x2="2.032" y2="-2.159" width="0.2032" layer="21"/>
<wire x1="2.032" y1="-2.159" x2="1.143" y2="-2.159" width="0.2032" layer="21"/>
<smd name="NC2" x="1.8" y="1.125" dx="1.2" dy="2" layer="1" rot="R180"/>
<smd name="NC1" x="-1.8" y="1.125" dx="1.2" dy="2" layer="1" rot="R180"/>
<smd name="2" x="0.5" y="-2.55" dx="1.35" dy="0.5" layer="1" rot="R270"/>
<smd name="1" x="-0.5" y="-2.55" dx="1.35" dy="0.5" layer="1" rot="R270"/>
<text x="-1.063" y="-2.404" size="1.4224" layer="21" ratio="12" rot="R180">-</text>
<text x="2.683" y="-2.404" size="1.4224" layer="21" ratio="12" rot="R180">+</text>
<text x="2.794" y="1.397" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="2.794" y="0.635" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="JSTPH2_NOTHERMALS">
<wire x1="-4" y1="3" x2="4" y2="3" width="0.2032" layer="51"/>
<wire x1="4" y1="3" x2="4" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="-4" y1="-4.5" x2="-4" y2="3" width="0.2032" layer="51"/>
<wire x1="3.2" y1="-2" x2="-3.2" y2="-2" width="0.2032" layer="51"/>
<wire x1="-3.2" y1="-2" x2="-3.2" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="-3.2" y1="-4.5" x2="-4" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="4" y1="-4.5" x2="3.2" y2="-4.5" width="0.2032" layer="51"/>
<wire x1="3.2" y1="-4.5" x2="3.2" y2="-2" width="0.2032" layer="51"/>
<wire x1="-2.25" y1="3" x2="2.25" y2="3" width="0.2032" layer="21"/>
<wire x1="4" y1="-0.5" x2="4" y2="-4.5" width="0.2032" layer="21"/>
<wire x1="4" y1="-4.5" x2="3.15" y2="-4.5" width="0.2032" layer="21"/>
<wire x1="3.15" y1="-4.5" x2="3.15" y2="-2" width="0.2032" layer="21"/>
<wire x1="3.15" y1="-2" x2="1.75" y2="-2" width="0.2032" layer="21"/>
<wire x1="-1.75" y1="-2" x2="-3.15" y2="-2" width="0.2032" layer="21"/>
<wire x1="-3.15" y1="-2" x2="-3.15" y2="-4.5" width="0.2032" layer="21"/>
<wire x1="-3.15" y1="-4.5" x2="-4" y2="-4.5" width="0.2032" layer="21"/>
<wire x1="-4" y1="-4.5" x2="-4" y2="-0.5" width="0.2032" layer="21"/>
<smd name="1" x="-1" y="-3.7" dx="1" dy="4.6" layer="1" thermals="no"/>
<smd name="2" x="1" y="-3.7" dx="1" dy="4.6" layer="1" thermals="no"/>
<smd name="NC1" x="-3.4" y="1.5" dx="3.4" dy="1.6" layer="1" rot="R90"/>
<smd name="NC2" x="3.4" y="1.5" dx="3.4" dy="1.6" layer="1" rot="R90"/>
<text x="-2.2225" y="1.9685" size="0.8128" layer="25" ratio="18">&gt;Name</text>
<text x="-2.2225" y="1.27" size="0.4064" layer="27" ratio="10">&gt;Value</text>
</package>
</packages>
<symbols>
<symbol name="CAPACITOR">
<wire x1="0" y1="0.762" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="0" y1="2.54" x2="0" y2="1.778" width="0.1524" layer="94"/>
<text x="-2.29" y="1.25" size="1.27" layer="95" font="vector" rot="R90" align="center">&gt;NAME</text>
<text x="2.3" y="1.25" size="1.27" layer="96" font="vector" rot="R90" align="center">&gt;VALUE</text>
<rectangle x1="-1.27" y1="0.508" x2="1.27" y2="1.016" layer="94"/>
<rectangle x1="-1.27" y1="1.524" x2="1.27" y2="2.032" layer="94"/>
<pin name="1" x="0" y="5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="GND">
<wire x1="-1.27" y1="0" x2="1.27" y2="0" width="0.254" layer="94"/>
<text x="-1.524" y="-2.54" size="1.27" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
<symbol name="RESISTOR">
<wire x1="-2.54" y1="1.27" x2="2.54" y2="1.27" width="0.254" layer="94"/>
<wire x1="2.54" y1="1.27" x2="2.54" y2="-1.27" width="0.254" layer="94"/>
<wire x1="2.54" y1="-1.27" x2="-2.54" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-1.27" x2="-2.54" y2="1.27" width="0.254" layer="94"/>
<text x="0" y="2.54" size="1.27" layer="95" font="vector" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.016" layer="96" font="vector" ratio="15" align="center">&gt;VALUE</text>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="VBUS">
<text x="-1.524" y="1.016" size="1.27" layer="96">&gt;VALUE</text>
<pin name="VBUS" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
<wire x1="-1.27" y1="-1.27" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="1.27" y2="-1.27" width="0.254" layer="94"/>
</symbol>
<symbol name="VBAT">
<text x="-1.524" y="1.016" size="1.27" layer="96">&gt;VALUE</text>
<pin name="VBAT" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
<wire x1="-1.27" y1="-1.27" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="1.27" y2="-1.27" width="0.254" layer="94"/>
</symbol>
<symbol name="LED">
<wire x1="-2.54" y1="1.27" x2="-2.54" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-1.27" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-2.54" y2="1.27" width="0.254" layer="94"/>
<wire x1="0" y1="1.27" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-0.635" y1="1.27" x2="0.635" y2="2.54" width="0.254" layer="94"/>
<wire x1="-1.905" y1="1.27" x2="-0.635" y2="2.54" width="0.254" layer="94"/>
<wire x1="-0.9525" y1="2.8575" x2="-0.3175" y2="2.2225" width="0.254" layer="94"/>
<wire x1="-0.3175" y1="2.2225" x2="0" y2="3.175" width="0.254" layer="94"/>
<wire x1="0" y1="3.175" x2="-0.9525" y2="2.8575" width="0.254" layer="94"/>
<wire x1="0.3175" y1="2.8575" x2="0.9525" y2="2.2225" width="0.254" layer="94"/>
<wire x1="1.27" y1="3.175" x2="0.3175" y2="2.8575" width="0.254" layer="94"/>
<wire x1="0.9525" y1="2.2225" x2="1.27" y2="3.175" width="0.254" layer="94"/>
<text x="-1.27" y="4.445" size="1.27" layer="95" align="center">&gt;NAME</text>
<text x="-1.27" y="-2.794" size="1.27" layer="96" align="center">&gt;VALUE</text>
<pin name="A" x="-5.08" y="0" visible="off" length="short" direction="pas"/>
<pin name="C" x="2.54" y="0" visible="off" length="short" direction="pas" rot="R180"/>
</symbol>
<symbol name="VREG_SOT23-5">
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<text x="-7.62" y="6.096" size="1.27" layer="95">&gt;NAME</text>
<text x="-7.62" y="-7.62" size="1.27" layer="95">&gt;VALUE</text>
<pin name="IN" x="-10.16" y="2.54" length="short" direction="pwr"/>
<pin name="OUT" x="10.16" y="2.54" length="short" direction="sup" rot="R180"/>
<pin name="EN" x="-10.16" y="0" length="short" direction="in"/>
<pin name="GND" x="-10.16" y="-2.54" length="short" direction="pwr"/>
<pin name="P4" x="10.16" y="-2.54" length="short" rot="R180"/>
</symbol>
<symbol name="DIODE-SCHOTTKY">
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-1.27" y1="-1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="-1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="1.27" y2="-1.27" width="0.254" layer="94"/>
<text x="0" y="2.54" size="1.27" layer="95" align="center">&gt;NAME</text>
<text x="0" y="-2.5" size="1.27" layer="96" align="center">&gt;VALUE</text>
<pin name="A" x="-2.54" y="0" visible="off" length="short" direction="pas"/>
<pin name="C" x="2.54" y="0" visible="off" length="short" direction="pas" rot="R180"/>
<wire x1="1.27" y1="-1.27" x2="1.778" y2="-1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="1.27" x2="0.762" y2="1.27" width="0.254" layer="94"/>
</symbol>
<symbol name="ATMEGA32U4">
<wire x1="-17.78" y1="45.72" x2="20.32" y2="45.72" width="0.254" layer="94"/>
<wire x1="20.32" y1="45.72" x2="20.32" y2="-33.02" width="0.254" layer="94"/>
<wire x1="20.32" y1="-33.02" x2="-17.78" y2="-33.02" width="0.254" layer="94"/>
<wire x1="-17.78" y1="-33.02" x2="-17.78" y2="45.72" width="0.254" layer="94"/>
<text x="-17.78" y="-38.1" size="1.778" layer="95">&gt;NAME</text>
<text x="-5.08" y="45.72" size="1.778" layer="96">&gt;VALUE</text>
<pin name="XTAL2" x="-22.86" y="-10.16" length="middle"/>
<pin name="XTAL1" x="-22.86" y="-2.54" length="middle"/>
<pin name="GND" x="-22.86" y="-22.86" length="middle"/>
<pin name="VCC" x="-22.86" y="30.48" length="middle"/>
<pin name="UVCC" x="-22.86" y="25.4" length="middle"/>
<pin name="UGND" x="-22.86" y="-17.78" length="middle"/>
<pin name="D-" x="-22.86" y="15.24" length="middle"/>
<pin name="AVCC" x="-22.86" y="22.86" length="middle"/>
<pin name="PB3(PDO/MISO)" x="25.4" y="0" length="middle" rot="R180"/>
<pin name="PB2(PDI/MOSI)" x="25.4" y="-2.54" length="middle" rot="R180"/>
<pin name="PB1(SCK)" x="25.4" y="-5.08" length="middle" rot="R180"/>
<pin name="PB0(SS)" x="25.4" y="-7.62" length="middle" rot="R180"/>
<pin name="PD7(OC4D/ADC10/T0)" x="25.4" y="-12.7" length="middle" rot="R180"/>
<pin name="PD6(T1/ADC9/!OC4D)" x="25.4" y="-15.24" length="middle" rot="R180"/>
<pin name="PD5(XCK/CTS)" x="25.4" y="-17.78" length="middle" rot="R180"/>
<pin name="PD4(ICP1/ADC8)" x="25.4" y="-20.32" length="middle" rot="R180"/>
<pin name="PD3(INT3/TXD1)" x="25.4" y="-22.86" length="middle" rot="R180"/>
<pin name="PD2(INT2/RXD1)" x="25.4" y="-25.4" length="middle" rot="R180"/>
<pin name="PD1(INT1/SDA)" x="25.4" y="-27.94" length="middle" rot="R180"/>
<pin name="PD0(INT0/OC0B/SCL)" x="25.4" y="-30.48" length="middle" rot="R180"/>
<pin name="PC7(ICP3/CLK0/OC4A)" x="25.4" y="15.24" length="middle" rot="R180"/>
<pin name="PC6(OC3A/!OC4A)" x="25.4" y="17.78" length="middle" rot="R180"/>
<pin name="PB4(ADC11)" x="25.4" y="2.54" length="middle" rot="R180"/>
<pin name="PB6(OC1B/OC4B/ADC13)" x="25.4" y="7.62" length="middle" rot="R180"/>
<pin name="PB5(OC1A/ADC12/!OC4B)" x="25.4" y="5.08" length="middle" rot="R180"/>
<pin name="PB7(OC0A/OC1C/RTS)" x="25.4" y="10.16" length="middle" rot="R180"/>
<pin name="/RESET" x="-22.86" y="43.18" length="middle" function="dot"/>
<pin name="D+" x="-22.86" y="12.7" length="middle"/>
<pin name="UCAP" x="-22.86" y="7.62" length="middle"/>
<pin name="PE2(!HWB)" x="25.4" y="25.4" length="middle" rot="R180"/>
<pin name="PF0(ADC0)" x="25.4" y="43.18" length="middle" rot="R180"/>
<pin name="PF1(ADC1)" x="25.4" y="40.64" length="middle" rot="R180"/>
<pin name="PF4(ADC4/TCK)" x="25.4" y="38.1" length="middle" rot="R180"/>
<pin name="PF5(ADC5/TMS)" x="25.4" y="35.56" length="middle" rot="R180"/>
<pin name="PF6(ADC6/TDO)" x="25.4" y="33.02" length="middle" rot="R180"/>
<pin name="PF7(ADC7(TDI)" x="25.4" y="30.48" length="middle" rot="R180"/>
<pin name="PE6(INT.6/AIN0)" x="25.4" y="22.86" length="middle" rot="R180"/>
<pin name="VBUS" x="-22.86" y="38.1" length="middle"/>
<pin name="GND1" x="-22.86" y="-25.4" length="middle"/>
<pin name="AVCC1" x="-22.86" y="20.32" length="middle"/>
<pin name="VCC1" x="-22.86" y="27.94" length="middle"/>
<pin name="AREF" x="-22.86" y="2.54" length="middle"/>
<pin name="GND2" x="-22.86" y="-27.94" length="middle"/>
<pin name="GND3" x="-22.86" y="-30.48" length="middle"/>
</symbol>
<symbol name="MCP73831/2">
<pin name="VDD" x="-12.7" y="2.54" length="short" direction="pwr"/>
<pin name="STAT" x="-12.7" y="-2.54" length="short" direction="out"/>
<pin name="VBAT" x="12.7" y="2.54" length="short" direction="pwr" rot="R180"/>
<pin name="PROG" x="12.7" y="0" length="short" direction="in" rot="R180"/>
<pin name="VSS" x="12.7" y="-2.54" length="short" direction="pwr" rot="R180"/>
<wire x1="-10.16" y1="5.08" x2="10.16" y2="5.08" width="0.254" layer="94" style="shortdash"/>
<wire x1="10.16" y1="5.08" x2="10.16" y2="-5.08" width="0.254" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="-10.16" y2="-5.08" width="0.254" layer="94" style="shortdash"/>
<wire x1="-10.16" y1="-5.08" x2="-10.16" y2="5.08" width="0.254" layer="94"/>
<text x="-5.715" y="8.255" size="1.27" layer="94">MCP73831/2</text>
<text x="-6.35" y="6.35" size="1.27" layer="94">LIPO Charger</text>
<text x="-8.255" y="-9.525" size="1.27" layer="94">Temp:</text>
<text x="0" y="-9.525" size="1.27" layer="94">-40-85°C</text>
<text x="-8.255" y="-7.62" size="1.27" layer="94">VDD:</text>
<text x="0" y="-7.62" size="1.27" layer="94">3.75-6V</text>
<wire x1="10.16" y1="-10.16" x2="-10.16" y2="-10.16" width="0.254" layer="94"/>
<wire x1="-10.16" y1="10.16" x2="10.16" y2="10.16" width="0.254" layer="94"/>
<wire x1="-10.16" y1="10.16" x2="-10.16" y2="5.08" width="0.254" layer="94"/>
<wire x1="-10.16" y1="-5.08" x2="-10.16" y2="-10.16" width="0.254" layer="94"/>
<wire x1="10.16" y1="10.16" x2="10.16" y2="5.08" width="0.254" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="10.16" y2="-10.16" width="0.254" layer="94"/>
<text x="-10.16" y="11.43" size="1.27" layer="95">&gt;NAME</text>
<text x="-10.16" y="-12.7" size="1.27" layer="95">&gt;VALUE</text>
</symbol>
<symbol name="DIODE-ZENER">
<wire x1="-1.27" y1="-1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="-1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="1.27" y2="-1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="1.27" x2="1.778" y2="1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="-1.27" x2="0.762" y2="-1.27" width="0.254" layer="94"/>
<text x="-2.54" y="3.0226" size="1.27" layer="95">&gt;NAME</text>
<text x="-2.54" y="-4.8514" size="1.27" layer="96">&gt;VALUE</text>
<pin name="A" x="-2.54" y="0" visible="off" length="short" direction="pas"/>
<pin name="C" x="2.54" y="0" visible="off" length="short" direction="pas" rot="R180"/>
</symbol>
<symbol name="U.FL">
<wire x1="0" y1="-2.54" x2="0" y2="-7.62" width="0.254" layer="94"/>
<circle x="0" y="0" radius="1.1359" width="0.254" layer="94"/>
<circle x="0" y="0" radius="2.54" width="0.254" layer="94"/>
<pin name="GND@0" x="-2.54" y="-5.08" visible="off" length="short" direction="pas"/>
<pin name="SIGNAL" x="5.08" y="0" visible="off" length="middle" direction="pas" rot="R180"/>
<pin name="GND@1" x="-2.54" y="-7.62" visible="off" length="short" direction="pas"/>
<text x="-2.54" y="3.302" size="1.27" layer="95">&gt;NAME</text>
<text x="-2.54" y="-10.16" size="1.27" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="PINHD2">
<wire x1="-6.35" y1="-2.54" x2="1.27" y2="-2.54" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="1.27" y2="5.08" width="0.4064" layer="94"/>
<wire x1="1.27" y1="5.08" x2="-6.35" y2="5.08" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="5.08" x2="-6.35" y2="-2.54" width="0.4064" layer="94"/>
<text x="-6.35" y="5.715" size="1.778" layer="95">&gt;NAME</text>
<text x="-6.35" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="CAP_CERAMIC" prefix="C" uservalue="yes">
<description>&lt;p&gt;&lt;b&gt;Ceramic Capacitors&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;For new designs, use the packages preceded by an '_' character since they are more reliable:&lt;/p&gt;
&lt;p&gt;The following footprints should be used on most boards:&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;&lt;b&gt;_0402&lt;/b&gt; - Standard footprint for regular board layouts&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_0603&lt;/b&gt; - Standard footprint for regular board layouts&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_0805&lt;/b&gt; - Standard footprint for regular board layouts&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_1206&lt;/b&gt; - Standard footprint for regular board layouts&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;For extremely tight-pitch boards where space is at a premium, the following 'micro-pitch' footprints can be used (smaller pads, no silkscreen outline, etc.):&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;&lt;b&gt;_0402MP&lt;/b&gt; - Micro-pitch footprint for very dense/compact boards&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_0603MP&lt;/b&gt; - Micro-pitch footprint for very dense/compact boards&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_0805MP&lt;/b&gt; - Micro-pitch footprint for very dense/compact boards&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_1206MP&lt;/b&gt; - Micro-pitch footprint for very dense/compact boards&lt;/li&gt;
&lt;/ul&gt;</description>
<gates>
<gate name="G$1" symbol="CAPACITOR" x="0" y="-2.54"/>
</gates>
<devices>
<device name="0603MINI" package="0603-MINI">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805-NOTHERMALS" package="0805_NOTHERMALS">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0402" package="_0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0402MP" package="_0402MP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0603" package="_0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0603MP" package="_0603MP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0805" package="_0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0805MP" package="_0805MP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805-NOOUTLINE" package="0805-NO">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805_10MGAP" package="0805_10MGAP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0603_NO" package="0603-NO">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_1206" package="_1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_1206MP" package="_1206MP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="GND">
<description>&lt;b&gt;GND&lt;/b&gt;</description>
<gates>
<gate name="G$1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="RESISTOR" prefix="R" uservalue="yes">
<description>&lt;p&gt;&lt;b&gt;Resistors&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;For new designs, use the packages preceded by an '_' character since they are more reliable:&lt;/p&gt;
&lt;p&gt;The following footprints should be used on most boards:&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;&lt;b&gt;_0402&lt;/b&gt; - Standard footprint for regular board layouts&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_0603&lt;/b&gt; - Standard footprint for regular board layouts&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_0805&lt;/b&gt; - Standard footprint for regular board layouts&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_1206&lt;/b&gt; - Standard footprint for regular board layouts&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;For extremely tight-pitch boards where space is at a premium, the following 'micro-pitch' footprints can be used (smaller pads, no silkscreen outline, etc.):&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;&lt;b&gt;_0402MP&lt;/b&gt; - Micro-pitch footprint for very dense/compact boards&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_0603MP&lt;/b&gt; - Micro-pitch footprint for very dense/compact boards&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_0805MP&lt;/b&gt; - Micro-pitch footprint for very dense/compact boards&lt;/li&gt;
&lt;li&gt;&lt;b&gt;_1206MP&lt;/b&gt; - Micro-pitch footprint for very dense/compact boards&lt;/li&gt;
&lt;/ul&gt;</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="0603MINI" package="0603-MINI">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="2012" package="2012">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805_NOTHERMALS" package="0805_NOTHERMALS">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="2512" package="2512">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0402" package="_0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0402MP" package="_0402MP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0603" package="_0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0603MP" package="_0603MP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0805" package="_0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0805MP" package="_0805MP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805_NOOUTLINE" package="0805-NO">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_0603_NOOUT" package="0603-NO">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_1206" package="_1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_1206MP" package="_1206MP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VBUS">
<description>&lt;p&gt;VBUS Supply Symbole&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="VBUS" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VBAT">
<description>VBAT Supply Sumbol</description>
<gates>
<gate name="G$1" symbol="VBAT" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="LED" prefix="D" uservalue="yes">
<description>&lt;p&gt;&lt;b&gt;LED&lt;/b&gt;&lt;/p&gt;
&lt;b&gt;0603&lt;/b&gt; - 0603 Surface Mount Package
&lt;hr&gt;
&lt;p&gt;&lt;b&gt;&lt;u&gt;2mA:&lt;/u&gt;&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Green LED - Low Power (3.9mcd, 2ma, 1.7Vf) - Digikey: 475-2709-2-ND&lt;/li&gt;
&lt;li&gt;Orange LED - Low Power (9.8mcd, 2ma, 1.8Vf) - Digikey: 475-1194-2-ND&lt;/li&gt;
&lt;li&gt;Red LED - Low Power (5mcd, 2ma, 1.8Vf) - Digikey: 475-1195-2-ND&lt;/li&gt;
&lt;li&gt;Yellow LED - Low Power (7mcd, 2ma, 1.8Vf) - Digikey: 475-1196-2-ND&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;&lt;b&gt;&lt;u&gt;5mA:&lt;/u&gt;&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Blue LED - Low Power (17mcd, 5ma, 2.9Vf) - Digikey: LNJ937W8CRACT-ND&lt;/li&gt;
&lt;/ul&gt;
&lt;b&gt;0805&lt;/b&gt; - 0805 Surface Mount Package
&lt;hr&gt;
&lt;p&gt;&lt;b&gt;&lt;u&gt;2mA:&lt;/u&gt;&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Red LED (8.8mcd, 2mA, 1.8Vf, Clear) - Low Power [Digikey: 475-2510-1-ND]&lt;/li&gt;
&lt;li&gt;Green LED (5mcd, 2mA, 1.8Vf, Clear) - Low Power [Digikey: 475-2730-1-ND]&lt;/li&gt;
&lt;li&gt;Yellow LED (11.3mcd, 2mA, 1.8Vf, Clear) - Low Power [Digikey: 475-2555-1-ND]&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;&lt;b&gt;&lt;u&gt;20mA:&lt;/u&gt;&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Red LED (104mcd, 20mA, Diffused) - LS R976 [Digikey: 475-1278-6-ND]&lt;/li&gt;
&lt;li&gt;Red LED (12mcd, 20mA, 2.0Vf, Clear) - APT2012EC [Digikey: 754-1128-1-ND]&lt;/li&gt;
&lt;li&gt;Green LED (15mcd, 20mA, 2.2Vf, Clear) - APT2012GC [Digikey: 754-1131-1-ND]&lt;/li&gt;
&lt;li&gt;Orange LED (160mcd, 20mA, 2.1Vf, Clear) - APT2012SECK [Digikey: 754-1130-1-ND]&lt;/li&gt;
&lt;/ul&gt;
&lt;li&gt;&lt;b&gt;1206&lt;/b&gt; - 1206 Surface Mount Package
&lt;hr&gt;
&lt;ul&gt;
&lt;li&gt;Green LED (26mcd, 20mA, Diffused) - LG N971  [Digikey: 475-1407-6-ND]&lt;/li&gt;
&lt;li&gt;Red LED (15mcd, 20mA, Diffused) - LH N974 [Digikey: 475-1416-6-ND]&lt;/li&gt;
&lt;/ul&gt;

&lt;li&gt;&lt;b&gt;Cree&lt;/b&gt; - Cree High-Power Surface Mount LEDs
&lt;hr&gt;
&lt;ul&gt;
&lt;li&gt;XPEBWT-L1-0000-00D50 - White 111lm 350mA 2.9Vf 6200K 110°&lt;/li&gt;
&lt;li&gt;XTEAWT-00-0000-00000LEE3 - White 114lm 350mA 2.85Vf 5000K 115°&lt;/li&gt;
&lt;/ul&gt;

&lt;li&gt;&lt;b&gt;Everlight&lt;/b&gt; - Everlight 45-21 Series Surface Mount LEDs
&lt;hr&gt;
&lt;ul&gt;
&lt;li&gt;45-21/QK2C-B2832AC2CB2/2T - Warm White 2000mcd 20mA 3.25Vf 3050K 120°&lt;/li&gt;
&lt;li&gt;45-21/LK2C-B38452C4CB2/2T - Nuetral White 2000mcd 20mA 3.25Vf 4150K 120°&lt;/li&gt;
&lt;li&gt;45-21/LK2C-B50634C6CB2/2T - Cold White 2200mcd 20mA 3.25Vf 5650K 120°&lt;/li&gt;
&lt;/ul&gt;

&lt;li&gt;&lt;b&gt;PLCC2 Reverse Mount&lt;/b&gt;
&lt;hr&gt;
&lt;ul&gt;
&lt;li&gt;LS T77K-J1L2-1-0-2-R18-Z - Red 11.25mcd 2mA 1.8Vf 630nm 120°&lt;/li&gt;
&lt;li&gt;LO T77K-L1M2-24-Z - Orange 19.6mcd 2mA 1.8Vf 606nm 120°&lt;/li&gt;
&lt;li&gt;LY T77K-K2M1-26-Z - Yellow 15.7mcd 2mA 1.8Vf 587nm 120°&lt;/li&gt;
&lt;/ul&gt;</description>
<gates>
<gate name="G$1" symbol="LED" x="0" y="0"/>
</gates>
<devices>
<device name="1206" package="CHIPLED_1206">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805" package="CHIPLED_0805">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0603" package="CHIPLED_0603">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0603_NOOUTLINE" package="CHIPLED_0603_NOOUTLINE">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805_NOOUTLINE" package="CHIPLED_0805_NOOUTLINE">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="XPE2" package="CREE_XLAMP_XPE2">
<connects>
<connect gate="G$1" pin="A" pad="ANODE"/>
<connect gate="G$1" pin="C" pad="CATHODE"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="XTE" package="CREE_XLAMP_XTE">
<connects>
<connect gate="G$1" pin="A" pad="ANODE"/>
<connect gate="G$1" pin="C" pad="CATHODE"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="EV45-21" package="EVERLIGHT_45-21">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PLCC2_REV" package="PLCC2_REVMOUNT">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VREG_SOT23-5" prefix="U" uservalue="yes">
<description>&lt;p&gt;&lt;b&gt;SOT23-5 Fixed Voltage Regulators&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;&lt;/p&gt;
&lt;table width="700"&gt;
&lt;tr bgcolor="#EEEEEE" &gt;
&lt;td&gt;&lt;b&gt;Part&lt;/b&gt;&lt;/td&gt;
&lt;td&gt;&lt;b&gt;Current Out&lt;/b&gt;&lt;/td&gt;
&lt;td&gt;&lt;b&gt;V Out&lt;/b&gt;&lt;/td&gt;
&lt;td&gt;&lt;b&gt;V In&lt;/b&gt;&lt;/td&gt;
&lt;td&gt;&lt;b&gt;V Dropout&lt;/b&gt;&lt;/td&gt;
&lt;td&gt;&lt;b&gt;θJA (°C/W)&lt;/b&gt;&lt;/td&gt;
&lt;td&gt;&lt;b&gt;TJ (°C)&lt;/b&gt;&lt;/td&gt;
&lt;td&gt;&lt;b&gt;Digikey Part No.&lt;/b&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;ADP121&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.4-5.5V&lt;/td&gt;
  &lt;td&gt;0.09V @ 150mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;ADP121-AUJZ33R7CT-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;ADP121&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.0V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.1-5.5V&lt;/td&gt;
  &lt;td&gt;0.09V @ 150mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;ADP121-AUJZ30R7CT-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;ADP122&lt;/td&gt;
  &lt;td&gt;&lt;strong&gt;300mA&lt;/strong&gt;&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.4-5.5V&lt;/td&gt;
  &lt;td&gt;0.085V @ 300mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;ADP122AUJZ-3.3-R7CT-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;ADP1712&lt;/td&gt;
  &lt;td&gt;&lt;strong&gt;300mA&lt;/strong&gt;&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.5-5.5V&lt;/td&gt;
  &lt;td&gt;0.17V @ 300mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;ADP1712AUJZ-3.3-R7TR-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;AP7311 (&lt;b&gt;Low Cost&lt;/b&gt;)&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.5-6V&lt;/td&gt;
  &lt;td&gt;0.15V @ 150mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;AP7311-33WG-7DICT-ND&lt;/td&gt;
&lt;/tr&gt;

&lt;tr&gt;
  &lt;td&gt;LD39015M18R&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;1.8V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;1.9V-5.5V&lt;/td&gt;
  &lt;td&gt;0.08V @ 100mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;497-6977-1-ND&lt;/td&gt;
&lt;/tr&gt;

&lt;tr&gt;
  &lt;td&gt;LP2985A-33DBVR&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.3-16V&lt;/td&gt;
  &lt;td&gt;0.28V @ 150mA&lt;/td&gt;
  &lt;td&gt;206&lt;/td&gt;
  &lt;td&gt;150&lt;/td&gt;
  &lt;td&gt;296-18479-1-ND&lt;/td&gt;
&lt;/tr&gt;

&lt;tr&gt;
  &lt;td&gt;MCP1824T-3302E/OT&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;300mA&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.5V-6V&lt;/td&gt;
  &lt;td&gt;0.2V @ 300mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;MCP1824T-3302E/OTCT-ND&lt;/td&gt;
&lt;/tr&gt;

&lt;tr&gt;
  &lt;td&gt;MIC5205-2.5YM5 TR&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;2.5V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;2.7-16V&lt;/td&gt;
  &lt;td&gt;0.165V @ 150mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;576-1257-2-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;MIC5205-3.0YM5 TR&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.0V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.2V-16V&lt;/td&gt;
  &lt;td&gt;0.165V @ 150mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;576-1258-2-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;MIC5205-3.3YM5 TR&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.5V-16V&lt;/td&gt;
  &lt;td&gt;0.165V @ 150mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;576-1259-2-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;TPS780330220&lt;/td&gt;
  &lt;td&gt;150mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V+2.2V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.6-5.5V&lt;/td&gt;
  &lt;td&gt;250mV Max&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;296-23332-1-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;TDA3663/N1,135&lt;/td&gt;
  &lt;td&gt;100mA&lt;/td&gt;
  &lt;td&gt;&lt;b&gt;3.3V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;3.5-&lt;b&gt;45V&lt;/b&gt;&lt;/td&gt;
  &lt;td&gt;0.18V @ 50mA&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;--&lt;/td&gt;
  &lt;td&gt;568-5343-1-ND&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
  &lt;td&gt;&lt;/td&gt;
&lt;/tr&gt;

&lt;/table&gt;
&lt;p&gt;Max operating temp can be calculated using θJA, TJ (max junction temperature), and power in watts.  Set the "Maximum Ambient Temperature" until it reaches TJ ("Max Junction Temperature"), which is the absolute limit for safe use of the regulator: &lt;a href="http://www.daycounter.com/Calculators/Heat-Sink-Temperature-Calculator.phtml"&gt;Heat Sink Temperature Calculator&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;For example, With 12V source into a 3.3V LP2985 and a 30mA load, we are dissipating (12V-3.3V) * 0.03A = 0.261W.  With a θJA of 206 °C/W, a TJ of 150°C, and 261mW we can safely use the chip without a heat sink up to 75°C (=147.1°C Junction Temperature).&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="VREG_SOT23-5" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT23-5">
<connects>
<connect gate="G$1" pin="EN" pad="3"/>
<connect gate="G$1" pin="GND" pad="2"/>
<connect gate="G$1" pin="IN" pad="1"/>
<connect gate="G$1" pin="OUT" pad="5"/>
<connect gate="G$1" pin="P4" pad="4"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="DIODE-SCHOTTKY" prefix="D" uservalue="yes">
<gates>
<gate name="G$1" symbol="DIODE-SCHOTTKY" x="0" y="0"/>
</gates>
<devices>
<device name="SMA" package="SMADIODE">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="DO-1N4148" package="DO-1N4148">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SOT23_REFLOW" package="SOT23-R">
<connects>
<connect gate="G$1" pin="A" pad="1"/>
<connect gate="G$1" pin="C" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SOD-523" package="SOD-523">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SOD-323" package="SOD-323">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SOD-123" package="SOD-123">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SOT23_WIDE" package="SOT23-WIDE">
<connects>
<connect gate="G$1" pin="A" pad="1"/>
<connect gate="G$1" pin="C" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="POWERDI" package="POWERDI-5">
<connects>
<connect gate="G$1" pin="A" pad="A1 A2"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="ATMEGA32U4" prefix="IC">
<description>&lt;p&gt;http://www.ladyada.net/library/eagle&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="ATMEGA32U4" x="0" y="-5.08"/>
</gates>
<devices>
<device name="-AU" package="TQFP44">
<connects>
<connect gate="G$1" pin="/RESET" pad="13"/>
<connect gate="G$1" pin="AREF" pad="42"/>
<connect gate="G$1" pin="AVCC" pad="24"/>
<connect gate="G$1" pin="AVCC1" pad="44"/>
<connect gate="G$1" pin="D+" pad="4"/>
<connect gate="G$1" pin="D-" pad="3"/>
<connect gate="G$1" pin="GND" pad="15"/>
<connect gate="G$1" pin="GND1" pad="23"/>
<connect gate="G$1" pin="GND2" pad="35"/>
<connect gate="G$1" pin="GND3" pad="43"/>
<connect gate="G$1" pin="PB0(SS)" pad="8"/>
<connect gate="G$1" pin="PB1(SCK)" pad="9"/>
<connect gate="G$1" pin="PB2(PDI/MOSI)" pad="10"/>
<connect gate="G$1" pin="PB3(PDO/MISO)" pad="11"/>
<connect gate="G$1" pin="PB4(ADC11)" pad="28"/>
<connect gate="G$1" pin="PB5(OC1A/ADC12/!OC4B)" pad="29"/>
<connect gate="G$1" pin="PB6(OC1B/OC4B/ADC13)" pad="30"/>
<connect gate="G$1" pin="PB7(OC0A/OC1C/RTS)" pad="12"/>
<connect gate="G$1" pin="PC6(OC3A/!OC4A)" pad="31"/>
<connect gate="G$1" pin="PC7(ICP3/CLK0/OC4A)" pad="32"/>
<connect gate="G$1" pin="PD0(INT0/OC0B/SCL)" pad="18"/>
<connect gate="G$1" pin="PD1(INT1/SDA)" pad="19"/>
<connect gate="G$1" pin="PD2(INT2/RXD1)" pad="20"/>
<connect gate="G$1" pin="PD3(INT3/TXD1)" pad="21"/>
<connect gate="G$1" pin="PD4(ICP1/ADC8)" pad="25"/>
<connect gate="G$1" pin="PD5(XCK/CTS)" pad="22"/>
<connect gate="G$1" pin="PD6(T1/ADC9/!OC4D)" pad="26"/>
<connect gate="G$1" pin="PD7(OC4D/ADC10/T0)" pad="27"/>
<connect gate="G$1" pin="PE2(!HWB)" pad="33"/>
<connect gate="G$1" pin="PE6(INT.6/AIN0)" pad="1"/>
<connect gate="G$1" pin="PF0(ADC0)" pad="41"/>
<connect gate="G$1" pin="PF1(ADC1)" pad="40"/>
<connect gate="G$1" pin="PF4(ADC4/TCK)" pad="39"/>
<connect gate="G$1" pin="PF5(ADC5/TMS)" pad="38"/>
<connect gate="G$1" pin="PF6(ADC6/TDO)" pad="37"/>
<connect gate="G$1" pin="PF7(ADC7(TDI)" pad="36"/>
<connect gate="G$1" pin="UCAP" pad="6"/>
<connect gate="G$1" pin="UGND" pad="5"/>
<connect gate="G$1" pin="UVCC" pad="2"/>
<connect gate="G$1" pin="VBUS" pad="7"/>
<connect gate="G$1" pin="VCC" pad="14"/>
<connect gate="G$1" pin="VCC1" pad="34"/>
<connect gate="G$1" pin="XTAL1" pad="17"/>
<connect gate="G$1" pin="XTAL2" pad="16"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-MU" package="TQFN44_7MM">
<connects>
<connect gate="G$1" pin="/RESET" pad="13"/>
<connect gate="G$1" pin="AREF" pad="42"/>
<connect gate="G$1" pin="AVCC" pad="24"/>
<connect gate="G$1" pin="AVCC1" pad="44"/>
<connect gate="G$1" pin="D+" pad="4"/>
<connect gate="G$1" pin="D-" pad="3"/>
<connect gate="G$1" pin="GND" pad="15"/>
<connect gate="G$1" pin="GND1" pad="23"/>
<connect gate="G$1" pin="GND2" pad="35"/>
<connect gate="G$1" pin="GND3" pad="43"/>
<connect gate="G$1" pin="PB0(SS)" pad="8"/>
<connect gate="G$1" pin="PB1(SCK)" pad="9"/>
<connect gate="G$1" pin="PB2(PDI/MOSI)" pad="10"/>
<connect gate="G$1" pin="PB3(PDO/MISO)" pad="11"/>
<connect gate="G$1" pin="PB4(ADC11)" pad="28"/>
<connect gate="G$1" pin="PB5(OC1A/ADC12/!OC4B)" pad="29"/>
<connect gate="G$1" pin="PB6(OC1B/OC4B/ADC13)" pad="30"/>
<connect gate="G$1" pin="PB7(OC0A/OC1C/RTS)" pad="12"/>
<connect gate="G$1" pin="PC6(OC3A/!OC4A)" pad="31"/>
<connect gate="G$1" pin="PC7(ICP3/CLK0/OC4A)" pad="32"/>
<connect gate="G$1" pin="PD0(INT0/OC0B/SCL)" pad="18"/>
<connect gate="G$1" pin="PD1(INT1/SDA)" pad="19"/>
<connect gate="G$1" pin="PD2(INT2/RXD1)" pad="20"/>
<connect gate="G$1" pin="PD3(INT3/TXD1)" pad="21"/>
<connect gate="G$1" pin="PD4(ICP1/ADC8)" pad="25"/>
<connect gate="G$1" pin="PD5(XCK/CTS)" pad="22"/>
<connect gate="G$1" pin="PD6(T1/ADC9/!OC4D)" pad="26"/>
<connect gate="G$1" pin="PD7(OC4D/ADC10/T0)" pad="27"/>
<connect gate="G$1" pin="PE2(!HWB)" pad="33"/>
<connect gate="G$1" pin="PE6(INT.6/AIN0)" pad="1"/>
<connect gate="G$1" pin="PF0(ADC0)" pad="41"/>
<connect gate="G$1" pin="PF1(ADC1)" pad="40"/>
<connect gate="G$1" pin="PF4(ADC4/TCK)" pad="39"/>
<connect gate="G$1" pin="PF5(ADC5/TMS)" pad="38"/>
<connect gate="G$1" pin="PF6(ADC6/TDO)" pad="37"/>
<connect gate="G$1" pin="PF7(ADC7(TDI)" pad="36"/>
<connect gate="G$1" pin="UCAP" pad="6"/>
<connect gate="G$1" pin="UGND" pad="5"/>
<connect gate="G$1" pin="UVCC" pad="2"/>
<connect gate="G$1" pin="VBUS" pad="7"/>
<connect gate="G$1" pin="VCC" pad="14"/>
<connect gate="G$1" pin="VCC1" pad="34"/>
<connect gate="G$1" pin="XTAL1" pad="17"/>
<connect gate="G$1" pin="XTAL2" pad="16"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="MCP73831/2" prefix="U" uservalue="yes">
<description>&lt;p&gt;&lt;b&gt;MCP73831/2 LIPO Charger&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;
&lt;ul&gt;
&lt;li&gt;VDD: 3.75 - 6V&lt;/li&gt;
&lt;li&gt;Temp -40 - 85°C&lt;/li&gt;
&lt;li&gt;Programmable Charge Rate: 15-500mA&lt;/li&gt;
&lt;/ul&gt;
&lt;/p&gt;
&lt;p&gt;&lt;b&gt;NOTE:&lt;/b&gt; STAT is a tri-state logic output on the MCP73831 and an open-drain output on the MCP73832.&lt;/p&gt;
&lt;p&gt;SOT23-5 with 4.2V output and tri-state logic on STAT = MCP73831T-2ACI/OT&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="MCP73831/2" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT23-5">
<connects>
<connect gate="G$1" pin="PROG" pad="5"/>
<connect gate="G$1" pin="STAT" pad="1"/>
<connect gate="G$1" pin="VBAT" pad="3"/>
<connect gate="G$1" pin="VDD" pad="4"/>
<connect gate="G$1" pin="VSS" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="DIODE-ZENER" prefix="D" uservalue="yes">
<description>&lt;b&gt;Zener Diode&lt;/b&gt;
&lt;p&gt;&lt;b&gt;SMA:&lt;/b&gt;
&lt;ul&gt;
&lt;li&gt;30V 1W Zener Diode, 1.2Vf - Digikey: SMAZ30-FDICT-ND&lt;/li&gt;
&lt;/ul&gt;
&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="DIODE-ZENER" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SMADIODE">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SOD123" package="SOD-123">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SOD323" package="SOD-323">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="ANTENNA_U.FL" prefix="X" uservalue="yes">
<description>&lt;p&gt;U.FL Antenna Connector&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="U.FL" x="0" y="0"/>
</gates>
<devices>
<device name="" package="U.FL">
<connects>
<connect gate="G$1" pin="GND@0" pad="1"/>
<connect gate="G$1" pin="GND@1" pad="2"/>
<connect gate="G$1" pin="SIGNAL" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CON_JST_PH_2PIN" prefix="X" uservalue="yes">
<description>JST 2-Pin Right-Angle Connector
&lt;ul&gt;
&lt;li&gt;PH-Series - 4UConnector: 17311&lt;/li&gt;
&lt;li&gt;SH-Series - 4UConnector: 07278&lt;/li&gt;
&lt;/ul&gt;</description>
<gates>
<gate name="G$1" symbol="PINHD2" x="2.54" y="0"/>
</gates>
<devices>
<device name="" package="JSTPH2">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SH2" package="JSTSH2">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PH2_NOTHERMALS" package="JSTPH2_NOTHERMALS">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="supply1">
<packages>
</packages>
<symbols>
<symbol name="GND">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
<symbol name="+3V3">
<wire x1="1.27" y1="-1.905" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="-1.905" width="0.254" layer="94"/>
<text x="-2.54" y="-5.08" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="+3V3" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND" prefix="GND">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+3V3" prefix="+3V3">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="G$1" symbol="+3V3" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="rcl">
<description>&lt;b&gt;Resistors, Capacitors, Inductors&lt;/b&gt;&lt;p&gt;
Based on the previous libraries:
&lt;ul&gt;
&lt;li&gt;r.lbr
&lt;li&gt;cap.lbr 
&lt;li&gt;cap-fe.lbr
&lt;li&gt;captant.lbr
&lt;li&gt;polcap.lbr
&lt;li&gt;ipc-smd.lbr
&lt;/ul&gt;
All SMD packages are defined according to the IPC specifications and  CECC&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;&lt;p&gt;
&lt;p&gt;
for Electrolyt Capacitors see also :&lt;p&gt;
www.bccomponents.com &lt;p&gt;
www.panasonic.com&lt;p&gt;
www.kemet.com&lt;p&gt;
http://www.secc.co.jp/pdf/os_e/2004/e_os_all.pdf &lt;b&gt;(SANYO)&lt;/b&gt;
&lt;p&gt;
for trimmer refence see : &lt;u&gt;www.electrospec-inc.com/cross_references/trimpotcrossref.asp&lt;/u&gt;&lt;p&gt;

&lt;table border=0 cellspacing=0 cellpadding=0 width="100%" cellpaddding=0&gt;
&lt;tr valign="top"&gt;

&lt;! &lt;td width="10"&gt;&amp;nbsp;&lt;/td&gt;
&lt;td width="90%"&gt;

&lt;b&gt;&lt;font color="#0000FF" size="4"&gt;TRIM-POT CROSS REFERENCE&lt;/font&gt;&lt;/b&gt;
&lt;P&gt;
&lt;TABLE BORDER=0 CELLSPACING=1 CELLPADDING=2&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;RECTANGULAR MULTI-TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;BOURNS&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;BI&amp;nbsp;TECH&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;DALE-VISHAY&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;PHILIPS/MEPCO&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;MURATA&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;PANASONIC&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;SPECTROL&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;B&gt;
      &lt;FONT SIZE=3 FACE=ARIAL color="#FF0000"&gt;MILSPEC&lt;/FONT&gt;
      &lt;/B&gt;
    &lt;/TD&gt;&lt;TD&gt;&amp;nbsp;&lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3 &gt;
      3005P&lt;BR&gt;
      3006P&lt;BR&gt;
      3006W&lt;BR&gt;
      3006Y&lt;BR&gt;
      3009P&lt;BR&gt;
      3009W&lt;BR&gt;
      3009Y&lt;BR&gt;
      3057J&lt;BR&gt;
      3057L&lt;BR&gt;
      3057P&lt;BR&gt;
      3057Y&lt;BR&gt;
      3059J&lt;BR&gt;
      3059L&lt;BR&gt;
      3059P&lt;BR&gt;
      3059Y&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      89P&lt;BR&gt;
      89W&lt;BR&gt;
      89X&lt;BR&gt;
      89PH&lt;BR&gt;
      76P&lt;BR&gt;
      89XH&lt;BR&gt;
      78SLT&lt;BR&gt;
      78L&amp;nbsp;ALT&lt;BR&gt;
      56P&amp;nbsp;ALT&lt;BR&gt;
      78P&amp;nbsp;ALT&lt;BR&gt;
      T8S&lt;BR&gt;
      78L&lt;BR&gt;
      56P&lt;BR&gt;
      78P&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      T18/784&lt;BR&gt;
      783&lt;BR&gt;
      781&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      2199&lt;BR&gt;
      1697/1897&lt;BR&gt;
      1680/1880&lt;BR&gt;
      2187&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      8035EKP/CT20/RJ-20P&lt;BR&gt;
      -&lt;BR&gt;
      RJ-20X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      1211L&lt;BR&gt;
      8012EKQ&amp;nbsp;ALT&lt;BR&gt;
      8012EKR&amp;nbsp;ALT&lt;BR&gt;
      1211P&lt;BR&gt;
      8012EKJ&lt;BR&gt;
      8012EKL&lt;BR&gt;
      8012EKQ&lt;BR&gt;
      8012EKR&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      2101P&lt;BR&gt;
      2101W&lt;BR&gt;
      2101Y&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      2102L&lt;BR&gt;
      2102S&lt;BR&gt;
      2102Y&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      EVMCOG&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      43P&lt;BR&gt;
      43W&lt;BR&gt;
      43Y&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      40L&lt;BR&gt;
      40P&lt;BR&gt;
      40Y&lt;BR&gt;
      70Y-T602&lt;BR&gt;
      70L&lt;BR&gt;
      70P&lt;BR&gt;
      70Y&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      RT/RTR12&lt;BR&gt;
      RT/RTR12&lt;BR&gt;
      RT/RTR12&lt;BR&gt;
      -&lt;BR&gt;
      RJ/RJR12&lt;BR&gt;
      RJ/RJR12&lt;BR&gt;
      RJ/RJR12&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;&amp;nbsp;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;
      &lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;SQUARE MULTI-TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
   &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BOURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BI&amp;nbsp;TECH&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;DALE-VISHAY&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PHILIPS/MEPCO&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;MURATA&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PANASONIC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;SPECTROL&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;MILSPEC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      3250L&lt;BR&gt;
      3250P&lt;BR&gt;
      3250W&lt;BR&gt;
      3250X&lt;BR&gt;
      3252P&lt;BR&gt;
      3252W&lt;BR&gt;
      3252X&lt;BR&gt;
      3260P&lt;BR&gt;
      3260W&lt;BR&gt;
      3260X&lt;BR&gt;
      3262P&lt;BR&gt;
      3262W&lt;BR&gt;
      3262X&lt;BR&gt;
      3266P&lt;BR&gt;
      3266W&lt;BR&gt;
      3266X&lt;BR&gt;
      3290H&lt;BR&gt;
      3290P&lt;BR&gt;
      3290W&lt;BR&gt;
      3292P&lt;BR&gt;
      3292W&lt;BR&gt;
      3292X&lt;BR&gt;
      3296P&lt;BR&gt;
      3296W&lt;BR&gt;
      3296X&lt;BR&gt;
      3296Y&lt;BR&gt;
      3296Z&lt;BR&gt;
      3299P&lt;BR&gt;
      3299W&lt;BR&gt;
      3299X&lt;BR&gt;
      3299Y&lt;BR&gt;
      3299Z&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      66P&amp;nbsp;ALT&lt;BR&gt;
      66W&amp;nbsp;ALT&lt;BR&gt;
      66X&amp;nbsp;ALT&lt;BR&gt;
      66P&amp;nbsp;ALT&lt;BR&gt;
      66W&amp;nbsp;ALT&lt;BR&gt;
      66X&amp;nbsp;ALT&lt;BR&gt;
      -&lt;BR&gt;
      64W&amp;nbsp;ALT&lt;BR&gt;
      -&lt;BR&gt;
      64P&amp;nbsp;ALT&lt;BR&gt;
      64W&amp;nbsp;ALT&lt;BR&gt;
      64X&amp;nbsp;ALT&lt;BR&gt;
      64P&lt;BR&gt;
      64W&lt;BR&gt;
      64X&lt;BR&gt;
      66X&amp;nbsp;ALT&lt;BR&gt;
      66P&amp;nbsp;ALT&lt;BR&gt;
      66W&amp;nbsp;ALT&lt;BR&gt;
      66P&lt;BR&gt;
      66W&lt;BR&gt;
      66X&lt;BR&gt;
      67P&lt;BR&gt;
      67W&lt;BR&gt;
      67X&lt;BR&gt;
      67Y&lt;BR&gt;
      67Z&lt;BR&gt;
      68P&lt;BR&gt;
      68W&lt;BR&gt;
      68X&lt;BR&gt;
      67Y&amp;nbsp;ALT&lt;BR&gt;
      67Z&amp;nbsp;ALT&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      5050&lt;BR&gt;
      5091&lt;BR&gt;
      5080&lt;BR&gt;
      5087&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      T63YB&lt;BR&gt;
      T63XB&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      5887&lt;BR&gt;
      5891&lt;BR&gt;
      5880&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      T93Z&lt;BR&gt;
      T93YA&lt;BR&gt;
      T93XA&lt;BR&gt;
      T93YB&lt;BR&gt;
      T93XB&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      8026EKP&lt;BR&gt;
      8026EKW&lt;BR&gt;
      8026EKM&lt;BR&gt;
      8026EKP&lt;BR&gt;
      8026EKB&lt;BR&gt;
      8026EKM&lt;BR&gt;
      1309X&lt;BR&gt;
      1309P&lt;BR&gt;
      1309W&lt;BR&gt;
      8024EKP&lt;BR&gt;
      8024EKW&lt;BR&gt;
      8024EKN&lt;BR&gt;
      RJ-9P/CT9P&lt;BR&gt;
      RJ-9W&lt;BR&gt;
      RJ-9X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      3103P&lt;BR&gt;
      3103Y&lt;BR&gt;
      3103Z&lt;BR&gt;
      3103P&lt;BR&gt;
      3103Y&lt;BR&gt;
      3103Z&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      3105P/3106P&lt;BR&gt;
      3105W/3106W&lt;BR&gt;
      3105X/3106X&lt;BR&gt;
      3105Y/3106Y&lt;BR&gt;
      3105Z/3105Z&lt;BR&gt;
      3102P&lt;BR&gt;
      3102W&lt;BR&gt;
      3102X&lt;BR&gt;
      3102Y&lt;BR&gt;
      3102Z&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMCBG&lt;BR&gt;
      EVMCCG&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      55-1-X&lt;BR&gt;
      55-4-X&lt;BR&gt;
      55-3-X&lt;BR&gt;
      55-2-X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      50-2-X&lt;BR&gt;
      50-4-X&lt;BR&gt;
      50-3-X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      64P&lt;BR&gt;
      64W&lt;BR&gt;
      64X&lt;BR&gt;
      64Y&lt;BR&gt;
      64Z&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      RT/RTR22&lt;BR&gt;
      RT/RTR22&lt;BR&gt;
      RT/RTR22&lt;BR&gt;
      RT/RTR22&lt;BR&gt;
      RJ/RJR22&lt;BR&gt;
      RJ/RJR22&lt;BR&gt;
      RJ/RJR22&lt;BR&gt;
      RT/RTR26&lt;BR&gt;
      RT/RTR26&lt;BR&gt;
      RT/RTR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RJ/RJR26&lt;BR&gt;
      RT/RTR24&lt;BR&gt;
      RT/RTR24&lt;BR&gt;
      RT/RTR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      RJ/RJR24&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;&amp;nbsp;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=8&gt;
      &lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;SINGLE TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BOURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BI&amp;nbsp;TECH&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;DALE-VISHAY&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PHILIPS/MEPCO&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;MURATA&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PANASONIC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;SPECTROL&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD ALIGN=CENTER&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;MILSPEC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      3323P&lt;BR&gt;
      3323S&lt;BR&gt;
      3323W&lt;BR&gt;
      3329H&lt;BR&gt;
      3329P&lt;BR&gt;
      3329W&lt;BR&gt;
      3339H&lt;BR&gt;
      3339P&lt;BR&gt;
      3339W&lt;BR&gt;
      3352E&lt;BR&gt;
      3352H&lt;BR&gt;
      3352K&lt;BR&gt;
      3352P&lt;BR&gt;
      3352T&lt;BR&gt;
      3352V&lt;BR&gt;
      3352W&lt;BR&gt;
      3362H&lt;BR&gt;
      3362M&lt;BR&gt;
      3362P&lt;BR&gt;
      3362R&lt;BR&gt;
      3362S&lt;BR&gt;
      3362U&lt;BR&gt;
      3362W&lt;BR&gt;
      3362X&lt;BR&gt;
      3386B&lt;BR&gt;
      3386C&lt;BR&gt;
      3386F&lt;BR&gt;
      3386H&lt;BR&gt;
      3386K&lt;BR&gt;
      3386M&lt;BR&gt;
      3386P&lt;BR&gt;
      3386S&lt;BR&gt;
      3386W&lt;BR&gt;
      3386X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      25P&lt;BR&gt;
      25S&lt;BR&gt;
      25RX&lt;BR&gt;
      82P&lt;BR&gt;
      82M&lt;BR&gt;
      82PA&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      91E&lt;BR&gt;
      91X&lt;BR&gt;
      91T&lt;BR&gt;
      91B&lt;BR&gt;
      91A&lt;BR&gt;
      91V&lt;BR&gt;
      91W&lt;BR&gt;
      25W&lt;BR&gt;
      25V&lt;BR&gt;
      25P&lt;BR&gt;
      -&lt;BR&gt;
      25S&lt;BR&gt;
      25U&lt;BR&gt;
      25RX&lt;BR&gt;
      25X&lt;BR&gt;
      72XW&lt;BR&gt;
      72XL&lt;BR&gt;
      72PM&lt;BR&gt;
      72RX&lt;BR&gt;
      -&lt;BR&gt;
      72PX&lt;BR&gt;
      72P&lt;BR&gt;
      72RXW&lt;BR&gt;
      72RXL&lt;BR&gt;
      72X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      T7YB&lt;BR&gt;
      T7YA&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      TXD&lt;BR&gt;
      TYA&lt;BR&gt;
      TYP&lt;BR&gt;
      -&lt;BR&gt;
      TYD&lt;BR&gt;
      TX&lt;BR&gt;
      -&lt;BR&gt;
      150SX&lt;BR&gt;
      100SX&lt;BR&gt;
      102T&lt;BR&gt;
      101S&lt;BR&gt;
      190T&lt;BR&gt;
      150TX&lt;BR&gt;
      101&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      101SX&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      ET6P&lt;BR&gt;
      ET6S&lt;BR&gt;
      ET6X&lt;BR&gt;
      RJ-6W/8014EMW&lt;BR&gt;
      RJ-6P/8014EMP&lt;BR&gt;
      RJ-6X/8014EMX&lt;BR&gt;
      TM7W&lt;BR&gt;
      TM7P&lt;BR&gt;
      TM7X&lt;BR&gt;
      -&lt;BR&gt;
      8017SMS&lt;BR&gt;
      -&lt;BR&gt;
      8017SMB&lt;BR&gt;
      8017SMA&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      CT-6W&lt;BR&gt;
      CT-6H&lt;BR&gt;
      CT-6P&lt;BR&gt;
      CT-6R&lt;BR&gt;
      -&lt;BR&gt;
      CT-6V&lt;BR&gt;
      CT-6X&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      8038EKV&lt;BR&gt;
      -&lt;BR&gt;
      8038EKX&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      8038EKP&lt;BR&gt;
      8038EKZ&lt;BR&gt;
      8038EKW&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      3321H&lt;BR&gt;
      3321P&lt;BR&gt;
      3321N&lt;BR&gt;
      1102H&lt;BR&gt;
      1102P&lt;BR&gt;
      1102T&lt;BR&gt;
      RVA0911V304A&lt;BR&gt;
      -&lt;BR&gt;
      RVA0911H413A&lt;BR&gt;
      RVG0707V100A&lt;BR&gt;
      RVA0607V(H)306A&lt;BR&gt;
      RVA1214H213A&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      3104B&lt;BR&gt;
      3104C&lt;BR&gt;
      3104F&lt;BR&gt;
      3104H&lt;BR&gt;
      -&lt;BR&gt;
      3104M&lt;BR&gt;
      3104P&lt;BR&gt;
      3104S&lt;BR&gt;
      3104W&lt;BR&gt;
      3104X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      EVMQ0G&lt;BR&gt;
      EVMQIG&lt;BR&gt;
      EVMQ3G&lt;BR&gt;
      EVMS0G&lt;BR&gt;
      EVMQ0G&lt;BR&gt;
      EVMG0G&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMK4GA00B&lt;BR&gt;
      EVM30GA00B&lt;BR&gt;
      EVMK0GA00B&lt;BR&gt;
      EVM38GA00B&lt;BR&gt;
      EVMB6&lt;BR&gt;
      EVLQ0&lt;BR&gt;
      -&lt;BR&gt;
      EVMMSG&lt;BR&gt;
      EVMMBG&lt;BR&gt;
      EVMMAG&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMMCS&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMM1&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMM0&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      EVMM3&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      62-3-1&lt;BR&gt;
      62-1-2&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      67R&lt;BR&gt;
      -&lt;BR&gt;
      67P&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      67X&lt;BR&gt;
      63V&lt;BR&gt;
      63S&lt;BR&gt;
      63M&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      63H&lt;BR&gt;
      63P&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      63X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      RJ/RJR50&lt;BR&gt;
      RJ/RJR50&lt;BR&gt;
      RJ/RJR50&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
&lt;/TABLE&gt;
&lt;P&gt;&amp;nbsp;&lt;P&gt;
&lt;TABLE BORDER=0 CELLSPACING=1 CELLPADDING=3&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=7&gt;
      &lt;FONT color="#0000FF" SIZE=4 FACE=ARIAL&gt;&lt;B&gt;SMD TRIM-POT CROSS REFERENCE&lt;/B&gt;&lt;/FONT&gt;
      &lt;P&gt;
      &lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;MULTI-TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BOURNS&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BI&amp;nbsp;TECH&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;DALE-VISHAY&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PHILIPS/MEPCO&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PANASONIC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;TOCOS&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;AUX/KYOCERA&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      3224G&lt;BR&gt;
      3224J&lt;BR&gt;
      3224W&lt;BR&gt;
      3269P&lt;BR&gt;
      3269W&lt;BR&gt;
      3269X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      44G&lt;BR&gt;
      44J&lt;BR&gt;
      44W&lt;BR&gt;
      84P&lt;BR&gt;
      84W&lt;BR&gt;
      84X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      ST63Z&lt;BR&gt;
      ST63Y&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      ST5P&lt;BR&gt;
      ST5W&lt;BR&gt;
      ST5X&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=7&gt;&amp;nbsp;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD COLSPAN=7&gt;
      &lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;SINGLE TURN&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BOURNS&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;BI&amp;nbsp;TECH&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;DALE-VISHAY&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PHILIPS/MEPCO&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;PANASONIC&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;TOCOS&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD&gt;
      &lt;FONT SIZE=3 FACE=ARIAL&gt;&lt;B&gt;AUX/KYOCERA&lt;/B&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
  &lt;TR&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      3314G&lt;BR&gt;
      3314J&lt;BR&gt;
      3364A/B&lt;BR&gt;
      3364C/D&lt;BR&gt;
      3364W/X&lt;BR&gt;
      3313G&lt;BR&gt;
      3313J&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      23B&lt;BR&gt;
      23A&lt;BR&gt;
      21X&lt;BR&gt;
      21W&lt;BR&gt;
      -&lt;BR&gt;
      22B&lt;BR&gt;
      22A&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      ST5YL/ST53YL&lt;BR&gt;
      ST5YJ/5T53YJ&lt;BR&gt;
      ST-23A&lt;BR&gt;
      ST-22B&lt;BR&gt;
      ST-22&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      ST-4B&lt;BR&gt;
      ST-4A&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      ST-3B&lt;BR&gt;
      ST-3A&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      EVM-6YS&lt;BR&gt;
      EVM-1E&lt;BR&gt;
      EVM-1G&lt;BR&gt;
      EVM-1D&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      G4B&lt;BR&gt;
      G4A&lt;BR&gt;
      TR04-3S1&lt;BR&gt;
      TRG04-2S1&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
    &lt;TD BGCOLOR="#cccccc" ALIGN=CENTER&gt;&lt;FONT FACE=ARIAL SIZE=3&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;
      DVR-43A&lt;BR&gt;
      CVR-42C&lt;BR&gt;
      CVR-42A/C&lt;BR&gt;
      -&lt;BR&gt;
      -&lt;BR&gt;&lt;/FONT&gt;
    &lt;/TD&gt;
  &lt;/TR&gt;
&lt;/TABLE&gt;
&lt;P&gt;
&lt;FONT SIZE=4 FACE=ARIAL&gt;&lt;B&gt;ALT =&amp;nbsp;ALTERNATE&lt;/B&gt;&lt;/FONT&gt;
&lt;P&gt;

&amp;nbsp;
&lt;P&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;/table&gt;</description>
<packages>
<package name="C0402">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-0.245" y1="0.224" x2="0.245" y2="0.224" width="0.1524" layer="51"/>
<wire x1="0.245" y1="-0.224" x2="-0.245" y2="-0.224" width="0.1524" layer="51"/>
<wire x1="-1.473" y1="0.483" x2="1.473" y2="0.483" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.483" x2="1.473" y2="-0.483" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.483" x2="-1.473" y2="-0.483" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.483" x2="-1.473" y2="0.483" width="0.0508" layer="39"/>
<smd name="1" x="-0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<smd name="2" x="0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.554" y1="-0.3048" x2="-0.254" y2="0.2951" layer="51"/>
<rectangle x1="0.2588" y1="-0.3048" x2="0.5588" y2="0.2951" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C0504">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.473" y1="0.983" x2="1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.983" x2="1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.983" x2="-1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.983" x2="-1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.294" y1="0.559" x2="0.294" y2="0.559" width="0.1016" layer="51"/>
<wire x1="-0.294" y1="-0.559" x2="0.294" y2="-0.559" width="0.1016" layer="51"/>
<smd name="1" x="-0.7" y="0" dx="1" dy="1.3" layer="1"/>
<smd name="2" x="0.7" y="0" dx="1" dy="1.3" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.6604" y1="-0.6223" x2="-0.2804" y2="0.6276" layer="51"/>
<rectangle x1="0.2794" y1="-0.6223" x2="0.6594" y2="0.6276" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C0603">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.473" y1="0.983" x2="1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.983" x2="1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.983" x2="-1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.983" x2="-1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C0805">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;</description>
<wire x1="-1.973" y1="0.983" x2="1.973" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.973" y1="-0.983" x2="-1.973" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.973" y1="-0.983" x2="-1.973" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<wire x1="1.973" y1="0.983" x2="1.973" y2="-0.983" width="0.0508" layer="39"/>
<smd name="1" x="-0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C1005">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-0.245" y1="0.224" x2="0.245" y2="0.224" width="0.1524" layer="51"/>
<wire x1="0.245" y1="-0.224" x2="-0.245" y2="-0.224" width="0.1524" layer="51"/>
<wire x1="-1.473" y1="0.483" x2="1.473" y2="0.483" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.483" x2="1.473" y2="-0.483" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.483" x2="-1.473" y2="-0.483" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.483" x2="-1.473" y2="0.483" width="0.0508" layer="39"/>
<smd name="1" x="-0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<smd name="2" x="0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.554" y1="-0.3048" x2="-0.254" y2="0.2951" layer="51"/>
<rectangle x1="0.2588" y1="-0.3048" x2="0.5588" y2="0.2951" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C1206">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.473" y1="0.983" x2="2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-0.983" x2="-2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-0.983" x2="-2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="0.983" x2="2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="C1210">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.473" y1="1.483" x2="2.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-1.483" x2="-2.473" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-1.483" x2="-2.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="1.2446" x2="0.9652" y2="1.2446" width="0.1016" layer="51"/>
<wire x1="-0.9652" y1="-1.2446" x2="0.9652" y2="-1.2446" width="0.1016" layer="51"/>
<wire x1="2.473" y1="1.483" x2="2.473" y2="-1.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-1.2954" x2="-0.9517" y2="1.3045" layer="51"/>
<rectangle x1="0.9517" y1="-1.3045" x2="1.7018" y2="1.2954" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="C1310">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.473" y1="0.983" x2="1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.983" x2="1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.983" x2="-1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.983" x2="-1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.294" y1="0.559" x2="0.294" y2="0.559" width="0.1016" layer="51"/>
<wire x1="-0.294" y1="-0.559" x2="0.294" y2="-0.559" width="0.1016" layer="51"/>
<smd name="1" x="-0.7" y="0" dx="1" dy="1.3" layer="1"/>
<smd name="2" x="0.7" y="0" dx="1" dy="1.3" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.6604" y1="-0.6223" x2="-0.2804" y2="0.6276" layer="51"/>
<rectangle x1="0.2794" y1="-0.6223" x2="0.6594" y2="0.6276" layer="51"/>
<rectangle x1="-0.1001" y1="-0.3" x2="0.1001" y2="0.3" layer="35"/>
</package>
<package name="C1608">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.473" y1="0.983" x2="1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.983" x2="1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.983" x2="-1.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.983" x2="-1.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C1812">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.973" y1="1.983" x2="2.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="2.973" y1="-1.983" x2="-2.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="-2.973" y1="-1.983" x2="-2.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="-1.4732" y1="1.6002" x2="1.4732" y2="1.6002" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-1.6002" x2="1.4732" y2="-1.6002" width="0.1016" layer="51"/>
<wire x1="2.973" y1="1.983" x2="2.973" y2="-1.983" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<text x="-1.905" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.81" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.3876" y1="-1.651" x2="-1.4376" y2="1.649" layer="51"/>
<rectangle x1="1.4478" y1="-1.651" x2="2.3978" y2="1.649" layer="51"/>
<rectangle x1="-0.3" y1="-0.4001" x2="0.3" y2="0.4001" layer="35"/>
</package>
<package name="C1825">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.973" y1="3.483" x2="2.973" y2="3.483" width="0.0508" layer="39"/>
<wire x1="2.973" y1="-3.483" x2="-2.973" y2="-3.483" width="0.0508" layer="39"/>
<wire x1="-2.973" y1="-3.483" x2="-2.973" y2="3.483" width="0.0508" layer="39"/>
<wire x1="-1.4986" y1="3.2766" x2="1.4732" y2="3.2766" width="0.1016" layer="51"/>
<wire x1="-1.4732" y1="-3.2766" x2="1.4986" y2="-3.2766" width="0.1016" layer="51"/>
<wire x1="2.973" y1="3.483" x2="2.973" y2="-3.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<text x="-1.905" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.413" y1="-3.3528" x2="-1.463" y2="3.3472" layer="51"/>
<rectangle x1="1.4478" y1="-3.3528" x2="2.3978" y2="3.3472" layer="51"/>
<rectangle x1="-0.7" y1="-0.7" x2="0.7" y2="0.7" layer="35"/>
</package>
<package name="C2012">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.973" y1="0.983" x2="1.973" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.973" y1="0.983" x2="1.973" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.973" y1="-0.983" x2="-1.973" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.973" y1="-0.983" x2="-1.973" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C3216">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.473" y1="0.983" x2="2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-0.983" x2="-2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-0.983" x2="-2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="0.983" x2="2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.3" y1="-0.5001" x2="0.3" y2="0.5001" layer="35"/>
</package>
<package name="C3225">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.473" y1="1.483" x2="2.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-1.483" x2="-2.473" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-1.483" x2="-2.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="1.2446" x2="0.9652" y2="1.2446" width="0.1016" layer="51"/>
<wire x1="-0.9652" y1="-1.2446" x2="0.9652" y2="-1.2446" width="0.1016" layer="51"/>
<wire x1="2.473" y1="1.483" x2="2.473" y2="-1.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-1.2954" x2="-0.9517" y2="1.3045" layer="51"/>
<rectangle x1="0.9517" y1="-1.3045" x2="1.7018" y2="1.2954" layer="51"/>
<rectangle x1="-0.1999" y1="-0.5001" x2="0.1999" y2="0.5001" layer="35"/>
</package>
<package name="C4532">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.973" y1="1.983" x2="2.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="2.973" y1="-1.983" x2="-2.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="-2.973" y1="-1.983" x2="-2.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="-1.4732" y1="1.6002" x2="1.4732" y2="1.6002" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-1.6002" x2="1.4732" y2="-1.6002" width="0.1016" layer="51"/>
<wire x1="2.973" y1="1.983" x2="2.973" y2="-1.983" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<text x="-1.905" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.81" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.3876" y1="-1.651" x2="-1.4376" y2="1.649" layer="51"/>
<rectangle x1="1.4478" y1="-1.651" x2="2.3978" y2="1.649" layer="51"/>
<rectangle x1="-0.4001" y1="-0.7" x2="0.4001" y2="0.7" layer="35"/>
</package>
<package name="C4564">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.973" y1="3.483" x2="2.973" y2="3.483" width="0.0508" layer="39"/>
<wire x1="2.973" y1="-3.483" x2="-2.973" y2="-3.483" width="0.0508" layer="39"/>
<wire x1="-2.973" y1="-3.483" x2="-2.973" y2="3.483" width="0.0508" layer="39"/>
<wire x1="-1.4986" y1="3.2766" x2="1.4732" y2="3.2766" width="0.1016" layer="51"/>
<wire x1="-1.4732" y1="-3.2766" x2="1.4986" y2="-3.2766" width="0.1016" layer="51"/>
<wire x1="2.973" y1="3.483" x2="2.973" y2="-3.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<text x="-1.905" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.413" y1="-3.3528" x2="-1.463" y2="3.3472" layer="51"/>
<rectangle x1="1.4478" y1="-3.3528" x2="2.3978" y2="3.3472" layer="51"/>
<rectangle x1="-0.5001" y1="-1" x2="0.5001" y2="1" layer="35"/>
</package>
<package name="C025-024X044">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 2.4 x 4.4 mm</description>
<wire x1="-2.159" y1="-0.635" x2="-2.159" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.159" y1="0.635" x2="-1.651" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.159" y1="-0.635" x2="-1.651" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="1.651" y1="1.143" x2="-1.651" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-0.635" x2="2.159" y2="0.635" width="0.1524" layer="21"/>
<wire x1="1.651" y1="-1.143" x2="-1.651" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="1.651" y1="1.143" x2="2.159" y2="0.635" width="0.1524" layer="21" curve="-90"/>
<wire x1="1.651" y1="-1.143" x2="2.159" y2="-0.635" width="0.1524" layer="21" curve="90"/>
<wire x1="-0.3048" y1="0.762" x2="-0.3048" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0.762" x2="0.3302" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="1.27" y1="0" x2="0.3302" y2="0" width="0.1524" layer="51"/>
<wire x1="-1.27" y1="0" x2="-0.3048" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-1.778" y="1.397" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.778" y="-2.667" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-025X050">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 2.5 x 5 mm</description>
<wire x1="-2.159" y1="1.27" x2="2.159" y2="1.27" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.27" x2="-2.159" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.016" x2="-2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.27" x2="2.413" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.016" x2="-2.159" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.27" x2="2.413" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.016" x2="-2.159" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="1.524" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-030X050">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 3 x 5 mm</description>
<wire x1="-2.159" y1="1.524" x2="2.159" y2="1.524" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.524" x2="-2.159" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.27" x2="2.413" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.27" x2="-2.413" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.524" x2="2.413" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.27" x2="-2.159" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.524" x2="2.413" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.27" x2="-2.159" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="1.905" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.048" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-040X050">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 4 x 5 mm</description>
<wire x1="-2.159" y1="1.905" x2="2.159" y2="1.905" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.905" x2="-2.159" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.651" x2="2.413" y2="-1.651" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.651" x2="-2.413" y2="-1.651" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.905" x2="2.413" y2="1.651" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.651" x2="-2.159" y2="1.905" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.905" x2="2.413" y2="-1.651" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.651" x2="-2.159" y2="-1.905" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="2.159" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.429" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-050X050">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 5 x 5 mm</description>
<wire x1="-2.159" y1="2.286" x2="2.159" y2="2.286" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-2.286" x2="-2.159" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="2.413" y1="2.032" x2="2.413" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="2.032" x2="-2.413" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="2.159" y1="2.286" x2="2.413" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="2.032" x2="-2.159" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-2.286" x2="2.413" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-2.032" x2="-2.159" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="2.54" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.81" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025-060X050">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm, outline 6 x 5 mm</description>
<wire x1="-2.159" y1="2.794" x2="2.159" y2="2.794" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-2.794" x2="-2.159" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="2.413" y1="2.54" x2="2.413" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="2.54" x2="-2.413" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="2.159" y1="2.794" x2="2.413" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="2.54" x2="-2.159" y2="2.794" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-2.794" x2="2.413" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-2.54" x2="-2.159" y2="-2.794" width="0.1524" layer="21" curve="90"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="3.048" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.032" y="-2.413" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-024X070">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 mm + 5 mm, outline 2.4 x 7 mm</description>
<wire x1="-2.159" y1="-0.635" x2="-2.159" y2="0.635" width="0.1524" layer="51"/>
<wire x1="-2.159" y1="0.635" x2="-1.651" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.159" y1="-0.635" x2="-1.651" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="1.651" y1="1.143" x2="-1.651" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-0.635" x2="2.159" y2="0.635" width="0.1524" layer="51"/>
<wire x1="1.651" y1="-1.143" x2="-1.651" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="1.651" y1="1.143" x2="2.159" y2="0.635" width="0.1524" layer="21" curve="-90"/>
<wire x1="-4.191" y1="-1.143" x2="-3.9624" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-4.191" y1="1.143" x2="-3.9624" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-4.699" y1="-0.635" x2="-4.191" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="1.651" y1="-1.143" x2="2.159" y2="-0.635" width="0.1524" layer="21" curve="90"/>
<wire x1="-4.699" y1="0.635" x2="-4.191" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-4.699" y1="-0.635" x2="-4.699" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="1.143" x2="-2.5654" y2="1.143" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.143" x2="-2.5654" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="-0.3048" y1="0.762" x2="-0.3048" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0.762" x2="0.3302" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="1.27" y1="0" x2="0.3302" y2="0" width="0.1524" layer="51"/>
<wire x1="-1.27" y1="0" x2="-0.3048" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.81" y="1.397" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.81" y="-2.667" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-025X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 + 5 mm, outline 2.5 x 7.5 mm</description>
<wire x1="-2.159" y1="1.27" x2="2.159" y2="1.27" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.27" x2="-2.159" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.016" x2="-2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.27" x2="2.413" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.016" x2="-2.159" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.27" x2="2.413" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.016" x2="-2.159" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="4.953" y1="1.016" x2="4.953" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="4.699" y1="1.27" x2="4.953" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.699" y1="-1.27" x2="4.953" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="2.794" y1="1.27" x2="4.699" y2="1.27" width="0.1524" layer="21"/>
<wire x1="4.699" y1="-1.27" x2="2.794" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.016" x2="2.413" y2="0.762" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-0.762" x2="2.413" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="2.413" y1="0.254" x2="2.413" y2="-0.254" width="0.1524" layer="21"/>
<wire x1="1.778" y1="0" x2="2.286" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="2.794" y2="0" width="0.1524" layer="21"/>
<wire x1="2.794" y1="0" x2="3.302" y2="0" width="0.1524" layer="51"/>
<wire x1="0.762" y1="0" x2="0.381" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.159" y="1.651" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.159" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-035X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 + 5 mm, outline 3.5 x 7.5 mm</description>
<wire x1="-2.159" y1="1.778" x2="2.159" y2="1.778" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-1.778" x2="-2.159" y2="-1.778" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="1.524" x2="-2.413" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="2.159" y1="1.778" x2="2.413" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="1.524" x2="-2.159" y2="1.778" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-1.778" x2="2.413" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-1.524" x2="-2.159" y2="-1.778" width="0.1524" layer="21" curve="90"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="4.953" y1="1.524" x2="4.953" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="4.699" y1="1.778" x2="4.953" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.699" y1="-1.778" x2="4.953" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="2.794" y1="1.778" x2="4.699" y2="1.778" width="0.1524" layer="21"/>
<wire x1="4.699" y1="-1.778" x2="2.794" y2="-1.778" width="0.1524" layer="21"/>
<wire x1="2.413" y1="1.524" x2="2.413" y2="1.016" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.016" x2="2.413" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="2.413" y1="0.508" x2="2.413" y2="-0.508" width="0.1524" layer="21"/>
<wire x1="0.381" y1="0" x2="0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="2.794" y2="0" width="0.1524" layer="21"/>
<wire x1="2.794" y1="0" x2="3.302" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="1.778" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="2.159" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.302" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-045X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 + 5 mm, outline 4.5 x 7.5 mm</description>
<wire x1="-2.159" y1="2.286" x2="2.159" y2="2.286" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-2.286" x2="-2.159" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="2.032" x2="-2.413" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="2.159" y1="2.286" x2="2.413" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="2.032" x2="-2.159" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-2.286" x2="2.413" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-2.032" x2="-2.159" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="4.953" y1="2.032" x2="4.953" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="4.699" y1="2.286" x2="4.953" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.699" y1="-2.286" x2="4.953" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="2.794" y1="2.286" x2="4.699" y2="2.286" width="0.1524" layer="21"/>
<wire x1="4.699" y1="-2.286" x2="2.794" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="2.413" y1="2.032" x2="2.413" y2="1.397" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-1.397" x2="2.413" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="2.413" y1="0.762" x2="2.413" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="2.286" y1="0" x2="2.794" y2="0" width="0.1524" layer="21"/>
<wire x1="2.794" y1="0" x2="3.302" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="1.778" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="2.667" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.286" y="-3.81" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C025_050-055X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 2.5 + 5 mm, outline 5.5 x 7.5 mm</description>
<wire x1="-2.159" y1="2.794" x2="2.159" y2="2.794" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-2.794" x2="-2.159" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="-2.413" y1="2.54" x2="-2.413" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="2.159" y1="2.794" x2="2.413" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.413" y1="2.54" x2="-2.159" y2="2.794" width="0.1524" layer="21" curve="-90"/>
<wire x1="2.159" y1="-2.794" x2="2.413" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-2.413" y1="-2.54" x2="-2.159" y2="-2.794" width="0.1524" layer="21" curve="90"/>
<wire x1="0.381" y1="0" x2="0.254" y2="0" width="0.1524" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="0.762" width="0.254" layer="21"/>
<wire x1="0.254" y1="0" x2="0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0.762" x2="-0.254" y2="0" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.254" y2="-0.762" width="0.254" layer="21"/>
<wire x1="-0.254" y1="0" x2="-0.381" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.381" y1="0" x2="-0.762" y2="0" width="0.1524" layer="51"/>
<wire x1="4.953" y1="2.54" x2="4.953" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="4.699" y1="2.794" x2="4.953" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.699" y1="-2.794" x2="4.953" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="2.794" y1="2.794" x2="4.699" y2="2.794" width="0.1524" layer="21"/>
<wire x1="4.699" y1="-2.794" x2="2.794" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="2.413" y1="2.54" x2="2.413" y2="2.032" width="0.1524" layer="21"/>
<wire x1="2.413" y1="-2.032" x2="2.413" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="2.413" y1="0.762" x2="2.413" y2="-0.762" width="0.1524" layer="21"/>
<wire x1="1.778" y1="0" x2="2.286" y2="0" width="0.1524" layer="51"/>
<wire x1="2.286" y1="0" x2="2.794" y2="0" width="0.1524" layer="21"/>
<wire x1="2.794" y1="0" x2="3.302" y2="0" width="0.1524" layer="51"/>
<wire x1="0.381" y1="0" x2="0.762" y2="0" width="0.1524" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128" shape="octagon"/>
<pad name="3" x="3.81" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.286" y="3.175" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.032" y="-2.286" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-024X044">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 2.4 x 4.4 mm</description>
<wire x1="-2.159" y1="-0.635" x2="-2.159" y2="0.635" width="0.1524" layer="51"/>
<wire x1="-2.159" y1="0.635" x2="-1.651" y2="1.143" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.159" y1="-0.635" x2="-1.651" y2="-1.143" width="0.1524" layer="21" curve="90"/>
<wire x1="1.651" y1="1.143" x2="-1.651" y2="1.143" width="0.1524" layer="21"/>
<wire x1="2.159" y1="-0.635" x2="2.159" y2="0.635" width="0.1524" layer="51"/>
<wire x1="1.651" y1="-1.143" x2="-1.651" y2="-1.143" width="0.1524" layer="21"/>
<wire x1="1.651" y1="1.143" x2="2.159" y2="0.635" width="0.1524" layer="21" curve="-90"/>
<wire x1="1.651" y1="-1.143" x2="2.159" y2="-0.635" width="0.1524" layer="21" curve="90"/>
<wire x1="-0.3048" y1="0.762" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0.762" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="1.27" y1="0" x2="0.3302" y2="0" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="0" x2="-0.3048" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-2.159" y="1.397" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.159" y="-2.667" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="2.159" y1="-0.381" x2="2.54" y2="0.381" layer="51"/>
<rectangle x1="-2.54" y1="-0.381" x2="-2.159" y2="0.381" layer="51"/>
</package>
<package name="C050-025X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 2.5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="1.016" x2="-3.683" y2="-1.016" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.27" x2="3.429" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-1.016" x2="3.683" y2="1.016" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.27" x2="-3.429" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.27" x2="3.683" y2="1.016" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-1.27" x2="3.683" y2="-1.016" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-1.016" x2="-3.429" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="1.016" x2="-3.429" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="1.651" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.794" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-045X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 4.5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="2.032" x2="-3.683" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-2.286" x2="3.429" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-2.032" x2="3.683" y2="2.032" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.286" x2="-3.429" y2="2.286" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.286" x2="3.683" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-2.286" x2="3.683" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-2.032" x2="-3.429" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="2.032" x2="-3.429" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.556" y="2.667" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.556" y="-3.81" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-030X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 3 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="1.27" x2="-3.683" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.524" x2="3.429" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-1.27" x2="3.683" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.524" x2="-3.429" y2="1.524" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.524" x2="3.683" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-1.524" x2="3.683" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-1.27" x2="-3.429" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="1.27" x2="-3.429" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.556" y="1.905" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.556" y="-3.048" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-050X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="2.286" x2="-3.683" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-2.54" x2="3.429" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-2.286" x2="3.683" y2="2.286" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.54" x2="-3.429" y2="2.54" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.54" x2="3.683" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-2.54" x2="3.683" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-2.286" x2="-3.429" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="2.286" x2="-3.429" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.175" y="-2.159" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-055X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 5.5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="2.54" x2="-3.683" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-2.794" x2="3.429" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-2.54" x2="3.683" y2="2.54" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.794" x2="-3.429" y2="2.794" width="0.1524" layer="21"/>
<wire x1="3.429" y1="2.794" x2="3.683" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-2.794" x2="3.683" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-2.54" x2="-3.429" y2="-2.794" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="2.54" x2="-3.429" y2="2.794" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="3.175" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.302" y="-2.286" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-075X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 7.5 x 7.5 mm</description>
<wire x1="-1.524" y1="0" x2="-0.4572" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.4572" y1="0" x2="-0.4572" y2="0.762" width="0.4064" layer="21"/>
<wire x1="-0.4572" y1="0" x2="-0.4572" y2="-0.762" width="0.4064" layer="21"/>
<wire x1="0.4318" y1="0.762" x2="0.4318" y2="0" width="0.4064" layer="21"/>
<wire x1="0.4318" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.4318" y1="0" x2="0.4318" y2="-0.762" width="0.4064" layer="21"/>
<wire x1="-3.683" y1="3.429" x2="-3.683" y2="-3.429" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-3.683" x2="3.429" y2="-3.683" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-3.429" x2="3.683" y2="3.429" width="0.1524" layer="21"/>
<wire x1="3.429" y1="3.683" x2="-3.429" y2="3.683" width="0.1524" layer="21"/>
<wire x1="3.429" y1="3.683" x2="3.683" y2="3.429" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-3.683" x2="3.683" y2="-3.429" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-3.429" x2="-3.429" y2="-3.683" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="3.429" x2="-3.429" y2="3.683" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.429" y="4.064" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.175" y="-2.921" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050H075X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Horizontal, grid 5 mm, outline 7.5 x 7.5 mm</description>
<wire x1="-3.683" y1="7.112" x2="-3.683" y2="0.508" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="0.508" x2="-3.302" y2="0.508" width="0.1524" layer="21"/>
<wire x1="-3.302" y1="0.508" x2="-1.778" y2="0.508" width="0.1524" layer="51"/>
<wire x1="-1.778" y1="0.508" x2="1.778" y2="0.508" width="0.1524" layer="21"/>
<wire x1="1.778" y1="0.508" x2="3.302" y2="0.508" width="0.1524" layer="51"/>
<wire x1="3.302" y1="0.508" x2="3.683" y2="0.508" width="0.1524" layer="21"/>
<wire x1="3.683" y1="0.508" x2="3.683" y2="7.112" width="0.1524" layer="21"/>
<wire x1="3.175" y1="7.62" x2="-3.175" y2="7.62" width="0.1524" layer="21"/>
<wire x1="-0.3048" y1="2.413" x2="-0.3048" y2="1.778" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="1.778" x2="-0.3048" y2="1.143" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="1.778" x2="-1.651" y2="1.778" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="2.413" x2="0.3302" y2="1.778" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="1.778" x2="0.3302" y2="1.143" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="1.778" x2="1.651" y2="1.778" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="7.112" x2="-3.175" y2="7.62" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.175" y1="7.62" x2="3.683" y2="7.112" width="0.1524" layer="21" curve="-90"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="0.254" width="0.508" layer="51"/>
<wire x1="2.54" y1="0" x2="2.54" y2="0.254" width="0.508" layer="51"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.302" y="8.001" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.175" y="3.175" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-2.794" y1="0.127" x2="-2.286" y2="0.508" layer="51"/>
<rectangle x1="2.286" y1="0.127" x2="2.794" y2="0.508" layer="51"/>
</package>
<package name="C075-032X103">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 7.5 mm, outline 3.2 x 10.3 mm</description>
<wire x1="4.826" y1="1.524" x2="-4.826" y2="1.524" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-4.826" y1="-1.524" x2="4.826" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-1.27" x2="5.08" y2="1.27" width="0.1524" layer="21"/>
<wire x1="4.826" y1="1.524" x2="5.08" y2="1.27" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.826" y1="-1.524" x2="5.08" y2="-1.27" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.08" y1="-1.27" x2="-4.826" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.08" y1="1.27" x2="-4.826" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="0.508" y1="0" x2="2.54" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0" x2="-0.508" y2="0" width="0.1524" layer="21"/>
<wire x1="-0.508" y1="0.889" x2="-0.508" y2="0" width="0.4064" layer="21"/>
<wire x1="-0.508" y1="0" x2="-0.508" y2="-0.889" width="0.4064" layer="21"/>
<wire x1="0.508" y1="0.889" x2="0.508" y2="0" width="0.4064" layer="21"/>
<wire x1="0.508" y1="0" x2="0.508" y2="-0.889" width="0.4064" layer="21"/>
<pad name="1" x="-3.81" y="0" drill="0.9144" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.9144" shape="octagon"/>
<text x="-4.826" y="1.905" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-4.826" y="-3.048" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C075-042X103">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 7.5 mm, outline 4.2 x 10.3 mm</description>
<wire x1="4.826" y1="2.032" x2="-4.826" y2="2.032" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="1.778" x2="-5.08" y2="-1.778" width="0.1524" layer="21"/>
<wire x1="-4.826" y1="-2.032" x2="4.826" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-1.778" x2="5.08" y2="1.778" width="0.1524" layer="21"/>
<wire x1="4.826" y1="2.032" x2="5.08" y2="1.778" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.826" y1="-2.032" x2="5.08" y2="-1.778" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.08" y1="-1.778" x2="-4.826" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.08" y1="1.778" x2="-4.826" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="-1.27" y1="0" x2="2.667" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.667" y1="0" x2="-2.159" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.159" y1="1.27" x2="-2.159" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.159" y1="0" x2="-2.159" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="0" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-1.27" width="0.4064" layer="21"/>
<pad name="1" x="-3.81" y="0" drill="0.9144" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.9144" shape="octagon"/>
<text x="-4.699" y="2.413" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-0.635" y="-1.651" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C075-052X106">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 7.5 mm, outline 5.2 x 10.6 mm</description>
<wire x1="4.953" y1="2.54" x2="-4.953" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-5.207" y1="2.286" x2="-5.207" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="-4.953" y1="-2.54" x2="4.953" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="5.207" y1="-2.286" x2="5.207" y2="2.286" width="0.1524" layer="21"/>
<wire x1="4.953" y1="2.54" x2="5.207" y2="2.286" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.953" y1="-2.54" x2="5.207" y2="-2.286" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.207" y1="-2.286" x2="-4.953" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.207" y1="2.286" x2="-4.953" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="-1.27" y1="0" x2="2.667" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.667" y1="0" x2="-2.159" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.159" y1="1.27" x2="-2.159" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.159" y1="0" x2="-2.159" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="0" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-1.27" width="0.4064" layer="21"/>
<pad name="1" x="-3.81" y="0" drill="0.9144" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.9144" shape="octagon"/>
<text x="-4.826" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-0.635" y="-2.032" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C102-043X133">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 10.2 mm, outline 4.3 x 13.3 mm</description>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.286" y1="1.27" x2="-2.286" y2="0" width="0.4064" layer="21"/>
<wire x1="3.81" y1="0" x2="-2.286" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.81" y1="0" x2="-3.175" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="0" x2="-3.175" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-6.096" y1="2.032" x2="6.096" y2="2.032" width="0.1524" layer="21"/>
<wire x1="6.604" y1="1.524" x2="6.604" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="6.096" y1="-2.032" x2="-6.096" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="-6.604" y1="-1.524" x2="-6.604" y2="1.524" width="0.1524" layer="21"/>
<wire x1="6.096" y1="2.032" x2="6.604" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.096" y1="-2.032" x2="6.604" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="-1.524" x2="-6.096" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="1.524" x2="-6.096" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="1.016" shape="octagon"/>
<text x="-6.096" y="2.413" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.524" y="-1.651" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C102-054X133">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 10.2 mm, outline 5.4 x 13.3 mm</description>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.286" y1="1.27" x2="-2.286" y2="0" width="0.4064" layer="21"/>
<wire x1="3.81" y1="0" x2="-2.286" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.81" y1="0" x2="-3.175" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="0" x2="-3.175" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-6.096" y1="2.54" x2="6.096" y2="2.54" width="0.1524" layer="21"/>
<wire x1="6.604" y1="2.032" x2="6.604" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="6.096" y1="-2.54" x2="-6.096" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-6.604" y1="-2.032" x2="-6.604" y2="2.032" width="0.1524" layer="21"/>
<wire x1="6.096" y1="2.54" x2="6.604" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.096" y1="-2.54" x2="6.604" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="-2.032" x2="-6.096" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="2.032" x2="-6.096" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="1.016" shape="octagon"/>
<text x="-6.096" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.524" y="-1.905" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C102-064X133">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 10.2 mm, outline 6.4 x 13.3 mm</description>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.286" y1="1.27" x2="-2.286" y2="0" width="0.4064" layer="21"/>
<wire x1="3.81" y1="0" x2="-2.286" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.81" y1="0" x2="-3.175" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="0" x2="-3.175" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-6.096" y1="3.048" x2="6.096" y2="3.048" width="0.1524" layer="21"/>
<wire x1="6.604" y1="2.54" x2="6.604" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="6.096" y1="-3.048" x2="-6.096" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-6.604" y1="-2.54" x2="-6.604" y2="2.54" width="0.1524" layer="21"/>
<wire x1="6.096" y1="3.048" x2="6.604" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.096" y1="-3.048" x2="6.604" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="-2.54" x2="-6.096" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="2.54" x2="-6.096" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="1.016" shape="octagon"/>
<text x="-6.096" y="3.429" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.524" y="-2.032" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C102_152-062X184">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 10.2 mm + 15.2 mm, outline 6.2 x 18.4 mm</description>
<wire x1="-2.286" y1="1.27" x2="-2.286" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-3.175" y2="0" width="0.4064" layer="21"/>
<wire x1="-3.175" y1="0" x2="-3.175" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-3.683" y1="0" x2="-3.175" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.286" y1="0" x2="3.683" y2="0" width="0.1524" layer="21"/>
<wire x1="6.477" y1="0" x2="8.636" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.096" y1="3.048" x2="6.223" y2="3.048" width="0.1524" layer="21"/>
<wire x1="6.223" y1="-3.048" x2="-6.096" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-6.604" y1="-2.54" x2="-6.604" y2="2.54" width="0.1524" layer="21"/>
<wire x1="6.223" y1="3.048" x2="6.731" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.223" y1="-3.048" x2="6.731" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="-2.54" x2="-6.096" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-6.604" y1="2.54" x2="-6.096" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="6.731" y1="2.54" x2="6.731" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="11.176" y1="3.048" x2="11.684" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="11.176" y1="-3.048" x2="11.684" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="11.176" y1="-3.048" x2="7.112" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="7.112" y1="3.048" x2="11.176" y2="3.048" width="0.1524" layer="21"/>
<wire x1="11.684" y1="2.54" x2="11.684" y2="-2.54" width="0.1524" layer="21"/>
<pad name="1" x="-5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="5.08" y="0" drill="1.016" shape="octagon"/>
<pad name="3" x="10.033" y="0" drill="1.016" shape="octagon"/>
<text x="-5.969" y="3.429" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.524" y="-2.286" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-054X183">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 5.4 x 18.3 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="2.032" x2="9.017" y2="-2.032" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-2.54" x2="-8.509" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-2.032" x2="-9.017" y2="2.032" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="2.54" x2="8.509" y2="2.54" width="0.1524" layer="21"/>
<wire x1="8.509" y1="2.54" x2="9.017" y2="2.032" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-2.54" x2="9.017" y2="-2.032" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-2.032" x2="-8.509" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="2.032" x2="-8.509" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.382" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.032" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-064X183">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 6.4 x 18.3 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="2.54" x2="9.017" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-3.048" x2="-8.509" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-2.54" x2="-9.017" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="3.048" x2="8.509" y2="3.048" width="0.1524" layer="21"/>
<wire x1="8.509" y1="3.048" x2="9.017" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-3.048" x2="9.017" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-2.54" x2="-8.509" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="2.54" x2="-8.509" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.509" y="3.429" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.032" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-072X183">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 7.2 x 18.3 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="3.048" x2="9.017" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-3.556" x2="-8.509" y2="-3.556" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-3.048" x2="-9.017" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="3.556" x2="8.509" y2="3.556" width="0.1524" layer="21"/>
<wire x1="8.509" y1="3.556" x2="9.017" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-3.556" x2="9.017" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-3.048" x2="-8.509" y2="-3.556" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="3.048" x2="-8.509" y2="3.556" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.509" y="3.937" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.286" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-084X183">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 8.4 x 18.3 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="3.556" x2="9.017" y2="-3.556" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-4.064" x2="-8.509" y2="-4.064" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-3.556" x2="-9.017" y2="3.556" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="4.064" x2="8.509" y2="4.064" width="0.1524" layer="21"/>
<wire x1="8.509" y1="4.064" x2="9.017" y2="3.556" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-4.064" x2="9.017" y2="-3.556" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-3.556" x2="-8.509" y2="-4.064" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="3.556" x2="-8.509" y2="4.064" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.509" y="4.445" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.54" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C150-091X182">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 15 mm, outline 9.1 x 18.2 mm</description>
<wire x1="-5.08" y1="1.27" x2="-5.08" y2="0" width="0.4064" layer="21"/>
<wire x1="-5.08" y1="0" x2="-5.08" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="1.27" x2="-4.191" y2="0" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="-4.191" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-4.191" y1="0" x2="6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0" x2="-6.096" y2="0" width="0.1524" layer="21"/>
<wire x1="9.017" y1="3.937" x2="9.017" y2="-3.937" width="0.1524" layer="21"/>
<wire x1="8.509" y1="-4.445" x2="-8.509" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="-9.017" y1="-3.937" x2="-9.017" y2="3.937" width="0.1524" layer="21"/>
<wire x1="-8.509" y1="4.445" x2="8.509" y2="4.445" width="0.1524" layer="21"/>
<wire x1="8.509" y1="4.445" x2="9.017" y2="3.937" width="0.1524" layer="21" curve="-90"/>
<wire x1="8.509" y1="-4.445" x2="9.017" y2="-3.937" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="-3.937" x2="-8.509" y2="-4.445" width="0.1524" layer="21" curve="90"/>
<wire x1="-9.017" y1="3.937" x2="-8.509" y2="4.445" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-7.493" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="7.493" y="0" drill="1.016" shape="octagon"/>
<text x="-8.509" y="4.826" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.429" y="-2.54" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-062X268">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 6.2 x 26.8 mm</description>
<wire x1="-12.827" y1="3.048" x2="12.827" y2="3.048" width="0.1524" layer="21"/>
<wire x1="13.335" y1="2.54" x2="13.335" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-3.048" x2="-12.827" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-2.54" x2="-13.335" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="3.048" x2="13.335" y2="2.54" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-3.048" x2="13.335" y2="-2.54" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-2.54" x2="-12.827" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="2.54" x2="-12.827" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.7" y="3.429" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-074X268">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 7.4 x 26.8 mm</description>
<wire x1="-12.827" y1="3.556" x2="12.827" y2="3.556" width="0.1524" layer="21"/>
<wire x1="13.335" y1="3.048" x2="13.335" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-3.556" x2="-12.827" y2="-3.556" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-3.048" x2="-13.335" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="3.556" x2="13.335" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-3.556" x2="13.335" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-3.048" x2="-12.827" y2="-3.556" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="3.048" x2="-12.827" y2="3.556" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.827" y="3.937" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-087X268">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 8.7 x 26.8 mm</description>
<wire x1="-12.827" y1="4.318" x2="12.827" y2="4.318" width="0.1524" layer="21"/>
<wire x1="13.335" y1="3.81" x2="13.335" y2="-3.81" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-4.318" x2="-12.827" y2="-4.318" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-3.81" x2="-13.335" y2="3.81" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="4.318" x2="13.335" y2="3.81" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-4.318" x2="13.335" y2="-3.81" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-3.81" x2="-12.827" y2="-4.318" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="3.81" x2="-12.827" y2="4.318" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.827" y="4.699" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-108X268">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 10.8 x 26.8 mm</description>
<wire x1="-12.827" y1="5.334" x2="12.827" y2="5.334" width="0.1524" layer="21"/>
<wire x1="13.335" y1="4.826" x2="13.335" y2="-4.826" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-5.334" x2="-12.827" y2="-5.334" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-4.826" x2="-13.335" y2="4.826" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="5.334" x2="13.335" y2="4.826" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-5.334" x2="13.335" y2="-4.826" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-4.826" x2="-12.827" y2="-5.334" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="4.826" x2="-12.827" y2="5.334" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.954" y="5.715" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C225-113X268">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 22.5 mm, outline 11.3 x 26.8 mm</description>
<wire x1="-12.827" y1="5.588" x2="12.827" y2="5.588" width="0.1524" layer="21"/>
<wire x1="13.335" y1="5.08" x2="13.335" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="12.827" y1="-5.588" x2="-12.827" y2="-5.588" width="0.1524" layer="21"/>
<wire x1="-13.335" y1="-5.08" x2="-13.335" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="12.827" y1="5.588" x2="13.335" y2="5.08" width="0.1524" layer="21" curve="-90"/>
<wire x1="12.827" y1="-5.588" x2="13.335" y2="-5.08" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="-5.08" x2="-12.827" y2="-5.588" width="0.1524" layer="21" curve="90"/>
<wire x1="-13.335" y1="5.08" x2="-12.827" y2="5.588" width="0.1524" layer="21" curve="-90"/>
<wire x1="-9.652" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="9.652" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-11.303" y="0" drill="1.016" shape="octagon"/>
<pad name="2" x="11.303" y="0" drill="1.016" shape="octagon"/>
<text x="-12.954" y="5.969" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-093X316">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 9.3 x 31.6 mm</description>
<wire x1="-15.24" y1="4.572" x2="15.24" y2="4.572" width="0.1524" layer="21"/>
<wire x1="15.748" y1="4.064" x2="15.748" y2="-4.064" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-4.572" x2="-15.24" y2="-4.572" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-4.064" x2="-15.748" y2="4.064" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="4.572" x2="15.748" y2="4.064" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-4.572" x2="15.748" y2="-4.064" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-4.064" x2="-15.24" y2="-4.572" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="4.064" x2="-15.24" y2="4.572" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="4.953" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-113X316">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 11.3 x 31.6 mm</description>
<wire x1="-15.24" y1="5.588" x2="15.24" y2="5.588" width="0.1524" layer="21"/>
<wire x1="15.748" y1="5.08" x2="15.748" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-5.588" x2="-15.24" y2="-5.588" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-5.08" x2="-15.748" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="5.588" x2="15.748" y2="5.08" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-5.588" x2="15.748" y2="-5.08" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-5.08" x2="-15.24" y2="-5.588" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="5.08" x2="-15.24" y2="5.588" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="5.969" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-134X316">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 13.4 x 31.6 mm</description>
<wire x1="-15.24" y1="6.604" x2="15.24" y2="6.604" width="0.1524" layer="21"/>
<wire x1="15.748" y1="6.096" x2="15.748" y2="-6.096" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-6.604" x2="-15.24" y2="-6.604" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-6.096" x2="-15.748" y2="6.096" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="6.604" x2="15.748" y2="6.096" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-6.604" x2="15.748" y2="-6.096" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-6.096" x2="-15.24" y2="-6.604" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="6.096" x2="-15.24" y2="6.604" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="6.985" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-205X316">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 20.5 x 31.6 mm</description>
<wire x1="-15.24" y1="10.16" x2="15.24" y2="10.16" width="0.1524" layer="21"/>
<wire x1="15.748" y1="9.652" x2="15.748" y2="-9.652" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-10.16" x2="-15.24" y2="-10.16" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-9.652" x2="-15.748" y2="9.652" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="10.16" x2="15.748" y2="9.652" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-10.16" x2="15.748" y2="-9.652" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-9.652" x2="-15.24" y2="-10.16" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="9.652" x2="-15.24" y2="10.16" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="10.541" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-4.318" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C325-137X374">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 32.5 mm, outline 13.7 x 37.4 mm</description>
<wire x1="-14.2748" y1="0" x2="-12.7" y2="0" width="0.1524" layer="21"/>
<wire x1="-12.7" y1="1.905" x2="-12.7" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="1.905" x2="-11.811" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="0" x2="14.2748" y2="0" width="0.1524" layer="21"/>
<wire x1="-11.811" y1="0" x2="-11.811" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-12.7" y1="0" x2="-12.7" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="18.542" y1="6.731" x2="18.542" y2="-6.731" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="6.731" x2="-18.542" y2="-6.731" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="-6.731" x2="18.542" y2="-6.731" width="0.1524" layer="21"/>
<wire x1="18.542" y1="6.731" x2="-18.542" y2="6.731" width="0.1524" layer="21"/>
<pad name="1" x="-16.256" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="16.256" y="0" drill="1.1938" shape="octagon"/>
<text x="-18.2372" y="7.0612" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-10.8458" y="-2.8702" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C325-162X374">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 32.5 mm, outline 16.2 x 37.4 mm</description>
<wire x1="-14.2748" y1="0" x2="-12.7" y2="0" width="0.1524" layer="21"/>
<wire x1="-12.7" y1="1.905" x2="-12.7" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="1.905" x2="-11.811" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="0" x2="14.2748" y2="0" width="0.1524" layer="21"/>
<wire x1="-11.811" y1="0" x2="-11.811" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-12.7" y1="0" x2="-12.7" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="18.542" y1="8.001" x2="18.542" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="8.001" x2="-18.542" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="-8.001" x2="18.542" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="18.542" y1="8.001" x2="-18.542" y2="8.001" width="0.1524" layer="21"/>
<pad name="1" x="-16.256" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="16.256" y="0" drill="1.1938" shape="octagon"/>
<text x="-18.3642" y="8.3312" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-10.8458" y="-2.8702" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C325-182X374">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 32.5 mm, outline 18.2 x 37.4 mm</description>
<wire x1="-14.2748" y1="0" x2="-12.7" y2="0" width="0.1524" layer="21"/>
<wire x1="-12.7" y1="1.905" x2="-12.7" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="1.905" x2="-11.811" y2="0" width="0.4064" layer="21"/>
<wire x1="-11.811" y1="0" x2="14.2748" y2="0" width="0.1524" layer="21"/>
<wire x1="-11.811" y1="0" x2="-11.811" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-12.7" y1="0" x2="-12.7" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="18.542" y1="9.017" x2="18.542" y2="-9.017" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="9.017" x2="-18.542" y2="-9.017" width="0.1524" layer="21"/>
<wire x1="-18.542" y1="-9.017" x2="18.542" y2="-9.017" width="0.1524" layer="21"/>
<wire x1="18.542" y1="9.017" x2="-18.542" y2="9.017" width="0.1524" layer="21"/>
<pad name="1" x="-16.256" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="16.256" y="0" drill="1.1938" shape="octagon"/>
<text x="-18.3642" y="9.3472" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-10.8458" y="-2.8702" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C375-192X418">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 37.5 mm, outline 19.2 x 41.8 mm</description>
<wire x1="-20.32" y1="8.509" x2="20.32" y2="8.509" width="0.1524" layer="21"/>
<wire x1="20.828" y1="8.001" x2="20.828" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="20.32" y1="-8.509" x2="-20.32" y2="-8.509" width="0.1524" layer="21"/>
<wire x1="-20.828" y1="-8.001" x2="-20.828" y2="8.001" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="20.32" y1="8.509" x2="20.828" y2="8.001" width="0.1524" layer="21" curve="-90"/>
<wire x1="20.32" y1="-8.509" x2="20.828" y2="-8.001" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="-8.001" x2="-20.32" y2="-8.509" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="8.001" x2="-20.32" y2="8.509" width="0.1524" layer="21" curve="-90"/>
<wire x1="-16.002" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="16.002" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-18.796" y="0" drill="1.3208" shape="octagon"/>
<pad name="2" x="18.796" y="0" drill="1.3208" shape="octagon"/>
<text x="-20.447" y="8.89" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C375-203X418">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 37.5 mm, outline 20.3 x 41.8 mm</description>
<wire x1="-20.32" y1="10.16" x2="20.32" y2="10.16" width="0.1524" layer="21"/>
<wire x1="20.828" y1="9.652" x2="20.828" y2="-9.652" width="0.1524" layer="21"/>
<wire x1="20.32" y1="-10.16" x2="-20.32" y2="-10.16" width="0.1524" layer="21"/>
<wire x1="-20.828" y1="-9.652" x2="-20.828" y2="9.652" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="20.32" y1="10.16" x2="20.828" y2="9.652" width="0.1524" layer="21" curve="-90"/>
<wire x1="20.32" y1="-10.16" x2="20.828" y2="-9.652" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="-9.652" x2="-20.32" y2="-10.16" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="9.652" x2="-20.32" y2="10.16" width="0.1524" layer="21" curve="-90"/>
<wire x1="-16.002" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="16.002" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-18.796" y="0" drill="1.3208" shape="octagon"/>
<pad name="2" x="18.796" y="0" drill="1.3208" shape="octagon"/>
<text x="-20.32" y="10.541" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C050-035X075">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 5 mm, outline 3.5 x 7.5 mm</description>
<wire x1="-0.3048" y1="0.635" x2="-0.3048" y2="0" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-0.3048" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="-0.3048" y1="0" x2="-1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="0.3302" y1="0.635" x2="0.3302" y2="0" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="0.3302" y2="-0.635" width="0.3048" layer="21"/>
<wire x1="0.3302" y1="0" x2="1.524" y2="0" width="0.1524" layer="21"/>
<wire x1="-3.683" y1="1.524" x2="-3.683" y2="-1.524" width="0.1524" layer="21"/>
<wire x1="-3.429" y1="-1.778" x2="3.429" y2="-1.778" width="0.1524" layer="21"/>
<wire x1="3.683" y1="-1.524" x2="3.683" y2="1.524" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.778" x2="-3.429" y2="1.778" width="0.1524" layer="21"/>
<wire x1="3.429" y1="1.778" x2="3.683" y2="1.524" width="0.1524" layer="21" curve="-90"/>
<wire x1="3.429" y1="-1.778" x2="3.683" y2="-1.524" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="-1.524" x2="-3.429" y2="-1.778" width="0.1524" layer="21" curve="90"/>
<wire x1="-3.683" y1="1.524" x2="-3.429" y2="1.778" width="0.1524" layer="21" curve="-90"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" shape="octagon"/>
<pad name="2" x="2.54" y="0" drill="0.8128" shape="octagon"/>
<text x="-3.556" y="2.159" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.556" y="-3.429" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C375-155X418">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 37.5 mm, outline 15.5 x 41.8 mm</description>
<wire x1="-20.32" y1="7.62" x2="20.32" y2="7.62" width="0.1524" layer="21"/>
<wire x1="20.828" y1="7.112" x2="20.828" y2="-7.112" width="0.1524" layer="21"/>
<wire x1="20.32" y1="-7.62" x2="-20.32" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-20.828" y1="-7.112" x2="-20.828" y2="7.112" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="20.32" y1="7.62" x2="20.828" y2="7.112" width="0.1524" layer="21" curve="-90"/>
<wire x1="20.32" y1="-7.62" x2="20.828" y2="-7.112" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="-7.112" x2="-20.32" y2="-7.62" width="0.1524" layer="21" curve="90"/>
<wire x1="-20.828" y1="7.112" x2="-20.32" y2="7.62" width="0.1524" layer="21" curve="-90"/>
<wire x1="-16.002" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="16.002" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-18.796" y="0" drill="1.3208" shape="octagon"/>
<pad name="2" x="18.796" y="0" drill="1.3208" shape="octagon"/>
<text x="-20.447" y="8.001" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C075-063X106">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 7.5 mm, outline 6.3 x 10.6 mm</description>
<wire x1="4.953" y1="3.048" x2="-4.953" y2="3.048" width="0.1524" layer="21"/>
<wire x1="-5.207" y1="2.794" x2="-5.207" y2="-2.794" width="0.1524" layer="21"/>
<wire x1="-4.953" y1="-3.048" x2="4.953" y2="-3.048" width="0.1524" layer="21"/>
<wire x1="5.207" y1="-2.794" x2="5.207" y2="2.794" width="0.1524" layer="21"/>
<wire x1="4.953" y1="3.048" x2="5.207" y2="2.794" width="0.1524" layer="21" curve="-90"/>
<wire x1="4.953" y1="-3.048" x2="5.207" y2="-2.794" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.207" y1="-2.794" x2="-4.953" y2="-3.048" width="0.1524" layer="21" curve="90"/>
<wire x1="-5.207" y1="2.794" x2="-4.953" y2="3.048" width="0.1524" layer="21" curve="-90"/>
<wire x1="-1.27" y1="0" x2="2.667" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.667" y1="0" x2="-2.159" y2="0" width="0.1524" layer="21"/>
<wire x1="-2.159" y1="1.27" x2="-2.159" y2="0" width="0.4064" layer="21"/>
<wire x1="-2.159" y1="0" x2="-2.159" y2="-1.27" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="0" width="0.4064" layer="21"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-1.27" width="0.4064" layer="21"/>
<pad name="1" x="-3.81" y="0" drill="0.9144" shape="octagon"/>
<pad name="2" x="3.81" y="0" drill="0.9144" shape="octagon"/>
<text x="-4.826" y="3.429" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-154X316">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 15.4 x 31.6 mm</description>
<wire x1="-15.24" y1="7.62" x2="15.24" y2="7.62" width="0.1524" layer="21"/>
<wire x1="15.748" y1="7.112" x2="15.748" y2="-7.112" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-7.62" x2="-15.24" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-7.112" x2="-15.748" y2="7.112" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="7.62" x2="15.748" y2="7.112" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-7.62" x2="15.748" y2="-7.112" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-7.112" x2="-15.24" y2="-7.62" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="7.112" x2="-15.24" y2="7.62" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="8.001" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C275-173X316">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
grid 27.5 mm, outline 17.3 x 31.6 mm</description>
<wire x1="-15.24" y1="8.509" x2="15.24" y2="8.509" width="0.1524" layer="21"/>
<wire x1="15.748" y1="8.001" x2="15.748" y2="-8.001" width="0.1524" layer="21"/>
<wire x1="15.24" y1="-8.509" x2="-15.24" y2="-8.509" width="0.1524" layer="21"/>
<wire x1="-15.748" y1="-8.001" x2="-15.748" y2="8.001" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="1.905" x2="-6.731" y2="0" width="0.4064" layer="21"/>
<wire x1="-6.731" y1="0" x2="-6.731" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0" width="0.4064" layer="21"/>
<wire x1="-7.62" y1="0" x2="-7.62" y2="-1.905" width="0.4064" layer="21"/>
<wire x1="15.24" y1="8.509" x2="15.748" y2="8.001" width="0.1524" layer="21" curve="-90"/>
<wire x1="15.24" y1="-8.509" x2="15.748" y2="-8.001" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="-8.001" x2="-15.24" y2="-8.509" width="0.1524" layer="21" curve="90"/>
<wire x1="-15.748" y1="8.001" x2="-15.24" y2="8.509" width="0.1524" layer="21" curve="-90"/>
<wire x1="-11.557" y1="0" x2="-7.62" y2="0" width="0.1524" layer="21"/>
<wire x1="-6.731" y1="0" x2="11.557" y2="0" width="0.1524" layer="21"/>
<pad name="1" x="-13.716" y="0" drill="1.1938" shape="octagon"/>
<pad name="2" x="13.716" y="0" drill="1.1938" shape="octagon"/>
<text x="-15.24" y="8.89" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-5.08" y="-2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C0402K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 0204 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 1005</description>
<wire x1="-0.425" y1="0.2" x2="0.425" y2="0.2" width="0.1016" layer="51"/>
<wire x1="0.425" y1="-0.2" x2="-0.425" y2="-0.2" width="0.1016" layer="51"/>
<smd name="1" x="-0.6" y="0" dx="0.925" dy="0.74" layer="1"/>
<smd name="2" x="0.6" y="0" dx="0.925" dy="0.74" layer="1"/>
<text x="-0.5" y="0.425" size="1.016" layer="25">&gt;NAME</text>
<text x="-0.5" y="-1.45" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-0.5" y1="-0.25" x2="-0.225" y2="0.25" layer="51"/>
<rectangle x1="0.225" y1="-0.25" x2="0.5" y2="0.25" layer="51"/>
</package>
<package name="C0603K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 0603 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 1608</description>
<wire x1="-0.725" y1="0.35" x2="0.725" y2="0.35" width="0.1016" layer="51"/>
<wire x1="0.725" y1="-0.35" x2="-0.725" y2="-0.35" width="0.1016" layer="51"/>
<smd name="1" x="-0.875" y="0" dx="1.05" dy="1.08" layer="1"/>
<smd name="2" x="0.875" y="0" dx="1.05" dy="1.08" layer="1"/>
<text x="-0.8" y="0.65" size="1.016" layer="25">&gt;NAME</text>
<text x="-0.8" y="-1.65" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8" y1="-0.4" x2="-0.45" y2="0.4" layer="51"/>
<rectangle x1="0.45" y1="-0.4" x2="0.8" y2="0.4" layer="51"/>
</package>
<package name="C0805K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 0805 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 2012</description>
<wire x1="-0.925" y1="0.6" x2="0.925" y2="0.6" width="0.1016" layer="51"/>
<wire x1="0.925" y1="-0.6" x2="-0.925" y2="-0.6" width="0.1016" layer="51"/>
<smd name="1" x="-1" y="0" dx="1.3" dy="1.6" layer="1"/>
<smd name="2" x="1" y="0" dx="1.3" dy="1.6" layer="1"/>
<text x="-1" y="0.875" size="1.016" layer="25">&gt;NAME</text>
<text x="-1" y="-1.9" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-1" y1="-0.65" x2="-0.5" y2="0.65" layer="51"/>
<rectangle x1="0.5" y1="-0.65" x2="1" y2="0.65" layer="51"/>
</package>
<package name="C1206K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 1206 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 3216</description>
<wire x1="-1.525" y1="0.75" x2="1.525" y2="0.75" width="0.1016" layer="51"/>
<wire x1="1.525" y1="-0.75" x2="-1.525" y2="-0.75" width="0.1016" layer="51"/>
<smd name="1" x="-1.5" y="0" dx="1.5" dy="2" layer="1"/>
<smd name="2" x="1.5" y="0" dx="1.5" dy="2" layer="1"/>
<text x="-1.6" y="1.1" size="1.016" layer="25">&gt;NAME</text>
<text x="-1.6" y="-2.1" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6" y1="-0.8" x2="-1.1" y2="0.8" layer="51"/>
<rectangle x1="1.1" y1="-0.8" x2="1.6" y2="0.8" layer="51"/>
</package>
<package name="C1210K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 1210 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 3225</description>
<wire x1="-1.525" y1="1.175" x2="1.525" y2="1.175" width="0.1016" layer="51"/>
<wire x1="1.525" y1="-1.175" x2="-1.525" y2="-1.175" width="0.1016" layer="51"/>
<smd name="1" x="-1.5" y="0" dx="1.5" dy="2.9" layer="1"/>
<smd name="2" x="1.5" y="0" dx="1.5" dy="2.9" layer="1"/>
<text x="-1.6" y="1.55" size="1.016" layer="25">&gt;NAME</text>
<text x="-1.6" y="-2.575" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6" y1="-1.25" x2="-1.1" y2="1.25" layer="51"/>
<rectangle x1="1.1" y1="-1.25" x2="1.6" y2="1.25" layer="51"/>
</package>
<package name="C1812K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 1812 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 4532</description>
<wire x1="-2.175" y1="1.525" x2="2.175" y2="1.525" width="0.1016" layer="51"/>
<wire x1="2.175" y1="-1.525" x2="-2.175" y2="-1.525" width="0.1016" layer="51"/>
<smd name="1" x="-2.05" y="0" dx="1.8" dy="3.7" layer="1"/>
<smd name="2" x="2.05" y="0" dx="1.8" dy="3.7" layer="1"/>
<text x="-2.25" y="1.95" size="1.016" layer="25">&gt;NAME</text>
<text x="-2.25" y="-2.975" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-2.25" y1="-1.6" x2="-1.65" y2="1.6" layer="51"/>
<rectangle x1="1.65" y1="-1.6" x2="2.25" y2="1.6" layer="51"/>
</package>
<package name="C1825K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 1825 reflow solder&lt;/b&gt;&lt;p&gt;
Metric Code Size 4564</description>
<wire x1="-1.525" y1="3.125" x2="1.525" y2="3.125" width="0.1016" layer="51"/>
<wire x1="1.525" y1="-3.125" x2="-1.525" y2="-3.125" width="0.1016" layer="51"/>
<smd name="1" x="-1.5" y="0" dx="1.8" dy="6.9" layer="1"/>
<smd name="2" x="1.5" y="0" dx="1.8" dy="6.9" layer="1"/>
<text x="-1.6" y="3.55" size="1.016" layer="25">&gt;NAME</text>
<text x="-1.6" y="-4.625" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6" y1="-3.2" x2="-1.1" y2="3.2" layer="51"/>
<rectangle x1="1.1" y1="-3.2" x2="1.6" y2="3.2" layer="51"/>
</package>
<package name="C2220K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 2220 reflow solder&lt;/b&gt;&lt;p&gt;Metric Code Size 5650</description>
<wire x1="-2.725" y1="2.425" x2="2.725" y2="2.425" width="0.1016" layer="51"/>
<wire x1="2.725" y1="-2.425" x2="-2.725" y2="-2.425" width="0.1016" layer="51"/>
<smd name="1" x="-2.55" y="0" dx="1.85" dy="5.5" layer="1"/>
<smd name="2" x="2.55" y="0" dx="1.85" dy="5.5" layer="1"/>
<text x="-2.8" y="2.95" size="1.016" layer="25">&gt;NAME</text>
<text x="-2.8" y="-3.975" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-2.8" y1="-2.5" x2="-2.2" y2="2.5" layer="51"/>
<rectangle x1="2.2" y1="-2.5" x2="2.8" y2="2.5" layer="51"/>
</package>
<package name="C2225K">
<description>&lt;b&gt;Ceramic Chip Capacitor KEMET 2225 reflow solder&lt;/b&gt;&lt;p&gt;Metric Code Size 5664</description>
<wire x1="-2.725" y1="3.075" x2="2.725" y2="3.075" width="0.1016" layer="51"/>
<wire x1="2.725" y1="-3.075" x2="-2.725" y2="-3.075" width="0.1016" layer="51"/>
<smd name="1" x="-2.55" y="0" dx="1.85" dy="6.8" layer="1"/>
<smd name="2" x="2.55" y="0" dx="1.85" dy="6.8" layer="1"/>
<text x="-2.8" y="3.6" size="1.016" layer="25">&gt;NAME</text>
<text x="-2.8" y="-4.575" size="1.016" layer="27">&gt;VALUE</text>
<rectangle x1="-2.8" y1="-3.15" x2="-2.2" y2="3.15" layer="51"/>
<rectangle x1="2.2" y1="-3.15" x2="2.8" y2="3.15" layer="51"/>
</package>
<package name="C0201">
<description>Source: http://www.avxcorp.com/docs/catalogs/cx5r.pdf</description>
<smd name="1" x="-0.25" y="0" dx="0.25" dy="0.35" layer="1"/>
<smd name="2" x="0.25" y="0" dx="0.25" dy="0.35" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.3" y1="-0.15" x2="-0.15" y2="0.15" layer="51"/>
<rectangle x1="0.15" y1="-0.15" x2="0.3" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="0.1" x2="0.15" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="-0.15" x2="0.15" y2="-0.1" layer="51"/>
</package>
<package name="C1808">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<wire x1="-1.4732" y1="0.9502" x2="1.4732" y2="0.9502" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-0.9502" x2="1.4732" y2="-0.9502" width="0.1016" layer="51"/>
<smd name="1" x="-1.95" y="0" dx="1.6" dy="2.2" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.6" dy="2.2" layer="1"/>
<text x="-2.233" y="1.827" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.233" y="-2.842" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.275" y1="-1.015" x2="-1.225" y2="1.015" layer="51"/>
<rectangle x1="1.225" y1="-1.015" x2="2.275" y2="1.015" layer="51"/>
</package>
<package name="C3640">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<wire x1="-3.8322" y1="5.0496" x2="3.8322" y2="5.0496" width="0.1016" layer="51"/>
<wire x1="-3.8322" y1="-5.0496" x2="3.8322" y2="-5.0496" width="0.1016" layer="51"/>
<smd name="1" x="-4.267" y="0" dx="2.6" dy="10.7" layer="1"/>
<smd name="2" x="4.267" y="0" dx="2.6" dy="10.7" layer="1"/>
<text x="-4.647" y="6.465" size="1.27" layer="25">&gt;NAME</text>
<text x="-4.647" y="-7.255" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-4.57" y1="-5.1" x2="-3.05" y2="5.1" layer="51"/>
<rectangle x1="3.05" y1="-5.1" x2="4.5688" y2="5.1" layer="51"/>
</package>
</packages>
<symbols>
<symbol name="C-US">
<wire x1="-2.54" y1="0" x2="2.54" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="-1.016" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-1" x2="2.4892" y2="-1.8542" width="0.254" layer="94" curve="-37.878202"/>
<wire x1="-2.4668" y1="-1.8504" x2="0" y2="-1.0161" width="0.254" layer="94" curve="-37.373024"/>
<text x="1.016" y="0.635" size="1.778" layer="95">&gt;NAME</text>
<text x="1.016" y="-4.191" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="0" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="C-US" prefix="C" uservalue="yes">
<description>&lt;B&gt;CAPACITOR&lt;/B&gt;, American symbol</description>
<gates>
<gate name="G$1" symbol="C-US" x="0" y="0"/>
</gates>
<devices>
<device name="C0402" package="C0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0504" package="C0504">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0603" package="C0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0805" package="C0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1005" package="C1005">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1206" package="C1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1210" package="C1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1310" package="C1310">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1608" package="C1608">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1812" package="C1812">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1825" package="C1825">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C2012" package="C2012">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3216" package="C3216">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3225" package="C3225">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C4532" package="C4532">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C4564" package="C4564">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025-024X044" package="C025-024X044">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025-025X050" package="C025-025X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025-030X050" package="C025-030X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025-040X050" package="C025-040X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025-050X050" package="C025-050X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025-060X050" package="C025-060X050">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C025_050-024X070" package="C025_050-024X070">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025_050-025X075" package="C025_050-025X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025_050-035X075" package="C025_050-035X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025_050-045X075" package="C025_050-045X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="025_050-055X075" package="C025_050-055X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050-024X044" package="C050-024X044">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050-025X075" package="C050-025X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050-045X075" package="C050-045X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050-030X075" package="C050-030X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050-050X075" package="C050-050X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050-055X075" package="C050-055X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050-075X075" package="C050-075X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050H075X075" package="C050H075X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="075-032X103" package="C075-032X103">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="075-042X103" package="C075-042X103">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="075-052X106" package="C075-052X106">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="102-043X133" package="C102-043X133">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="102-054X133" package="C102-054X133">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="102-064X133" package="C102-064X133">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="102_152-062X184" package="C102_152-062X184">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="150-054X183" package="C150-054X183">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="150-064X183" package="C150-064X183">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="150-072X183" package="C150-072X183">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="150-084X183" package="C150-084X183">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="150-091X182" package="C150-091X182">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="225-062X268" package="C225-062X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="225-074X268" package="C225-074X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="225-087X268" package="C225-087X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="225-108X268" package="C225-108X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="225-113X268" package="C225-113X268">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="275-093X316" package="C275-093X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="275-113X316" package="C275-113X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="275-134X316" package="C275-134X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="275-205X316" package="C275-205X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="325-137X374" package="C325-137X374">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="325-162X374" package="C325-162X374">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="325-182X374" package="C325-182X374">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="375-192X418" package="C375-192X418">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="375-203X418" package="C375-203X418">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="050-035X075" package="C050-035X075">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="375-155X418" package="C375-155X418">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="075-063X106" package="C075-063X106">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="275-154X316" package="C275-154X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="275-173X316" package="C275-173X316">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0402K" package="C0402K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0603K" package="C0603K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0805K" package="C0805K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1206K" package="C1206K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1210K" package="C1210K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1812K" package="C1812K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1825K" package="C1825K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C2220K" package="C2220K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C2225K" package="C2225K">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0201" package="C0201">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1808" package="C1808">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3640" package="C3640">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="LARA-R2">
<packages>
<package name="XCVR_LARA-R2">
<wire x1="-12" y1="13" x2="-12" y2="-13" width="0.127" layer="21"/>
<wire x1="-12" y1="-13" x2="12" y2="-13" width="0.127" layer="21"/>
<wire x1="12" y1="-13" x2="12" y2="13" width="0.127" layer="21"/>
<wire x1="12" y1="13" x2="-12" y2="13" width="0.127" layer="21"/>
<circle x="-12.95" y="11.6" radius="0.2" width="0.4" layer="21"/>
<wire x1="12" y1="13" x2="-12" y2="13" width="0.127" layer="51"/>
<wire x1="-12" y1="13" x2="-12" y2="-13" width="0.127" layer="51"/>
<wire x1="12" y1="-13" x2="12" y2="13" width="0.127" layer="51"/>
<wire x1="-12" y1="-13" x2="12" y2="-13" width="0.127" layer="51"/>
<wire x1="-12.25" y1="13.25" x2="-12.25" y2="-13.25" width="0.05" layer="39"/>
<wire x1="-12.25" y1="-13.25" x2="12.25" y2="-13.25" width="0.05" layer="39"/>
<wire x1="12.25" y1="-13.25" x2="12.25" y2="13.25" width="0.05" layer="39"/>
<wire x1="12.25" y1="13.25" x2="-12.25" y2="13.25" width="0.05" layer="39"/>
<text x="-12.2675" y="13.5193" size="2.54363125" layer="25">&gt;NAME</text>
<text x="-12.518" y="-16.023" size="2.54365" layer="27">&gt;VALUE</text>
<rectangle x1="-7.71468125" y1="10.6452" x2="-6.2" y2="11.375" layer="31"/>
<rectangle x1="-7.70796875" y1="9.534859375" x2="-6.2" y2="10.275" layer="31"/>
<rectangle x1="-7.706240625" y1="8.43183125" x2="-6.2" y2="9.175" layer="31"/>
<rectangle x1="-7.70463125" y1="7.329409375" x2="-6.2" y2="8.075" layer="31"/>
<rectangle x1="-7.711759375" y1="6.234509375" x2="-6.2" y2="6.975" layer="31"/>
<rectangle x1="-7.7148" y1="5.13485" x2="-6.2" y2="5.875" layer="31"/>
<rectangle x1="-7.712440625" y1="4.0315" x2="-6.2" y2="4.775" layer="31"/>
<rectangle x1="-7.7033" y1="2.92625" x2="-6.2" y2="3.675" layer="31"/>
<rectangle x1="-7.70156875" y1="1.82536875" x2="-6.2" y2="2.575" layer="31"/>
<rectangle x1="-7.700240625" y1="0.725021875" x2="-6.2" y2="1.475" layer="31"/>
<rectangle x1="-7.70886875" y1="-0.37543125" x2="-6.2" y2="0.375" layer="31"/>
<rectangle x1="-7.7114" y1="-1.47718125" x2="-6.2" y2="-0.725" layer="31"/>
<rectangle x1="-7.702909375" y1="-2.57596875" x2="-6.2" y2="-1.825" layer="31"/>
<rectangle x1="-7.713159375" y1="-3.68128125" x2="-6.2" y2="-2.925" layer="31"/>
<rectangle x1="-7.708159375" y1="-4.780059375" x2="-6.2" y2="-4.025" layer="31"/>
<rectangle x1="-7.709090625" y1="-5.88193125" x2="-6.2" y2="-5.125" layer="31"/>
<rectangle x1="-7.714209375" y1="-6.98788125" x2="-6.2" y2="-6.225" layer="31"/>
<rectangle x1="-7.71498125" y1="-8.090709375" x2="-6.2" y2="-7.325" layer="31"/>
<rectangle x1="-7.70568125" y1="-9.18176875" x2="-6.2" y2="-8.425" layer="31"/>
<rectangle x1="-7.702990625" y1="-10.279" x2="-6.2" y2="-9.525" layer="31"/>
<rectangle x1="-7.70145" y1="-11.3771" x2="-6.2" y2="-10.625" layer="31"/>
<rectangle x1="6.21081875" y1="10.6435" x2="7.7" y2="11.375" layer="31"/>
<rectangle x1="6.20361875" y1="9.530559375" x2="7.7" y2="10.275" layer="31"/>
<rectangle x1="6.205" y1="8.431790625" x2="7.7" y2="9.175" layer="31"/>
<rectangle x1="6.207340625" y1="7.33366875" x2="7.7" y2="8.075" layer="31"/>
<rectangle x1="6.211890625" y1="6.236940625" x2="7.7" y2="6.975" layer="31"/>
<rectangle x1="6.205640625" y1="5.129659375" x2="7.7" y2="5.875" layer="31"/>
<rectangle x1="6.20053125" y1="4.02535" x2="7.7" y2="4.775" layer="31"/>
<rectangle x1="6.21111875" y1="2.93025" x2="7.7" y2="3.675" layer="31"/>
<rectangle x1="6.206190625" y1="1.82681875" x2="7.7" y2="2.575" layer="31"/>
<rectangle x1="6.201059375" y1="0.725125" x2="7.7" y2="1.475" layer="31"/>
<rectangle x1="6.20616875" y1="-0.375371875" x2="7.7" y2="0.375" layer="31"/>
<rectangle x1="6.20903125" y1="-1.47715" x2="7.7" y2="-0.725" layer="31"/>
<rectangle x1="6.20963125" y1="-2.579" x2="7.7" y2="-1.825" layer="31"/>
<rectangle x1="6.210090625" y1="-3.68098125" x2="7.7" y2="-2.925" layer="31"/>
<rectangle x1="6.20216875" y1="-4.77666875" x2="7.7" y2="-4.025" layer="31"/>
<rectangle x1="6.205190625" y1="-5.87991875" x2="7.7" y2="-5.125" layer="31"/>
<rectangle x1="6.20126875" y1="-6.97643125" x2="7.7" y2="-6.225" layer="31"/>
<rectangle x1="6.203790625" y1="-8.07993125" x2="7.7" y2="-7.325" layer="31"/>
<rectangle x1="6.20785" y1="-9.186609375" x2="7.7" y2="-8.425" layer="31"/>
<rectangle x1="6.20406875" y1="-10.2817" x2="7.7" y2="-9.525" layer="31"/>
<rectangle x1="6.203040625" y1="-11.3806" x2="7.7" y2="-10.625" layer="31"/>
<rectangle x1="-6.254259375" y1="-12.3334" x2="-4.75" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="-5.159190625" y1="-12.347" x2="-3.65" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="-4.05381875" y1="-12.3366" x2="-2.55" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="-2.95491875" y1="-12.3456" x2="-1.45" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="-1.8535" y1="-12.3483" x2="-0.35" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="-0.751240625" y1="-12.3454" x2="0.75" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="0.350684375" y1="-12.3491" x2="1.85" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="1.45148125" y1="-12.3376" x2="2.95" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="2.5509" y1="-12.3293" x2="4.05" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="3.65525" y1="-12.3427" x2="5.15" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="4.75368125" y1="-12.3346" x2="6.25" y2="-11.575" layer="31" rot="R90"/>
<rectangle x1="-6.255159375" y1="11.5845" x2="-4.75" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="-5.15916875" y1="11.5956" x2="-3.65" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="-4.05305" y1="11.5837" x2="-2.55" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="-2.95545" y1="11.5964" x2="-1.45" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="-1.85133125" y1="11.5833" x2="-0.35" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="-0.750378125" y1="11.5808" x2="0.75" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="0.3506625" y1="11.5969" x2="1.85" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="1.451340625" y1="11.5857" x2="2.95" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="2.553909375" y1="11.5927" x2="4.05" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="3.65383125" y1="11.5871" x2="5.15" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="4.75531875" y1="11.588" x2="6.25" y2="12.325" layer="31" rot="R90"/>
<rectangle x1="0.525959375" y1="7.9395" x2="1.575" y2="8.975" layer="31"/>
<rectangle x1="-1.575790625" y1="7.92895" x2="-0.525" y2="8.975" layer="31"/>
<rectangle x1="4.729059375" y1="7.931809375" x2="5.775" y2="8.975" layer="31"/>
<rectangle x1="-5.78345" y1="7.936590625" x2="-4.725" y2="8.975" layer="31"/>
<rectangle x1="-3.681690625" y1="7.93943125" x2="-2.625" y2="8.975" layer="31"/>
<rectangle x1="2.629090625" y1="7.937340625" x2="3.675" y2="8.975" layer="31"/>
<rectangle x1="0.52569375" y1="9.73785" x2="1.575" y2="10.775" layer="31"/>
<rectangle x1="-1.577409375" y1="9.73986875" x2="-0.525" y2="10.775" layer="31"/>
<rectangle x1="4.73045" y1="9.73621875" x2="5.775" y2="10.775" layer="31"/>
<rectangle x1="-5.777259375" y1="9.7288" x2="-4.725" y2="10.775" layer="31"/>
<rectangle x1="-3.675459375" y1="9.726209375" x2="-2.625" y2="10.775" layer="31"/>
<rectangle x1="2.62683125" y1="9.731759375" x2="3.675" y2="10.775" layer="31"/>
<rectangle x1="0.52574375" y1="6.1337" x2="1.575" y2="7.175" layer="31"/>
<rectangle x1="-1.57755" y1="6.13493125" x2="-0.525" y2="7.175" layer="31"/>
<rectangle x1="4.734440625" y1="6.13723125" x2="5.775" y2="7.175" layer="31"/>
<rectangle x1="-5.784590625" y1="6.13516875" x2="-4.725" y2="7.175" layer="31"/>
<rectangle x1="0.525296875" y1="-8.98008125" x2="1.575" y2="-7.925" layer="31"/>
<rectangle x1="-1.575190625" y1="-8.97606875" x2="-0.525" y2="-7.925" layer="31"/>
<rectangle x1="4.72686875" y1="-8.978540625" x2="5.775" y2="-7.925" layer="31"/>
<rectangle x1="-5.786209375" y1="-8.99243125" x2="-4.725" y2="-7.925" layer="31"/>
<rectangle x1="-3.67685" y1="-8.97953125" x2="-2.625" y2="-7.925" layer="31"/>
<rectangle x1="2.62531875" y1="-8.976109375" x2="3.675" y2="-7.925" layer="31"/>
<rectangle x1="0.52573125" y1="-7.18496875" x2="1.575" y2="-6.125" layer="31"/>
<rectangle x1="-1.57773125" y1="-7.187440625" x2="-0.525" y2="-6.125" layer="31"/>
<rectangle x1="4.727740625" y1="-7.179159375" x2="5.775" y2="-6.125" layer="31"/>
<rectangle x1="-5.775840625" y1="-7.176040625" x2="-4.725" y2="-6.125" layer="31"/>
<rectangle x1="0.5253625" y1="-10.7824" x2="1.575" y2="-9.725" layer="31"/>
<rectangle x1="-1.57521875" y1="-10.7765" x2="-0.525" y2="-9.725" layer="31"/>
<rectangle x1="4.725640625" y1="-10.7765" x2="5.775" y2="-9.725" layer="31"/>
<rectangle x1="-5.782190625" y1="-10.7884" x2="-4.725" y2="-9.725" layer="31"/>
<rectangle x1="-3.67566875" y1="-10.777" x2="-2.625" y2="-9.725" layer="31"/>
<rectangle x1="2.62556875" y1="-10.7774" x2="3.675" y2="-9.725" layer="31"/>
<rectangle x1="4.72953125" y1="2.52741875" x2="5.775" y2="3.575" layer="31"/>
<rectangle x1="-5.778140625" y1="2.52636875" x2="-4.725" y2="3.575" layer="31"/>
<rectangle x1="4.729159375" y1="-3.578140625" x2="5.775" y2="-2.525" layer="31"/>
<rectangle x1="-5.7801" y1="-3.578159375" x2="-4.725" y2="-2.525" layer="31"/>
<rectangle x1="-7.301540625" y1="11.8025" x2="-6.7" y2="12.4" layer="21"/>
<smd name="1" x="-6.95" y="11" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="2" x="-6.95" y="9.9" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="3" x="-6.95" y="8.8" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="4" x="-6.95" y="7.7" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="5" x="-6.95" y="6.6" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="6" x="-6.95" y="5.5" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="7" x="-6.95" y="4.4" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="8" x="-6.95" y="3.3" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="9" x="-6.95" y="2.2" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="10" x="-6.95" y="1.1" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="11" x="-6.95" y="0" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="12" x="-6.95" y="-1.1" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="13" x="-6.95" y="-2.2" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="14" x="-6.95" y="-3.3" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="15" x="-6.95" y="-4.4" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="16" x="-6.95" y="-5.5" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="17" x="-6.95" y="-6.6" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="18" x="-6.95" y="-7.7" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="19" x="-6.95" y="-8.8" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="20" x="-6.95" y="-9.9" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="21" x="-6.95" y="-11" dx="0.8" dy="1.55" layer="1" rot="R90" cream="no"/>
<smd name="22" x="-5.5" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="23" x="-4.4" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="24" x="-3.3" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="25" x="-2.2" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="26" x="-1.1" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="27" x="0" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="28" x="1.1" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="29" x="2.2" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="30" x="3.3" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="31" x="4.4" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="32" x="5.5" y="-11.95" dx="0.8" dy="1.55" layer="1" rot="R180" cream="no"/>
<smd name="33" x="6.95" y="-11" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="34" x="6.95" y="-9.9" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="35" x="6.95" y="-8.8" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="36" x="6.95" y="-7.7" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="37" x="6.95" y="-6.6" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="38" x="6.95" y="-5.5" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="39" x="6.95" y="-4.4" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="40" x="6.95" y="-3.3" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="41" x="6.95" y="-2.2" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="42" x="6.95" y="-1.1" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="43" x="6.95" y="0" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="44" x="6.95" y="1.1" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="45" x="6.95" y="2.2" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="46" x="6.95" y="3.3" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="47" x="6.95" y="4.4" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="48" x="6.95" y="5.5" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="49" x="6.95" y="6.6" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="50" x="6.95" y="7.7" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="51" x="6.95" y="8.8" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="52" x="6.95" y="9.9" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="53" x="6.95" y="11" dx="0.8" dy="1.55" layer="1" rot="R270" cream="no"/>
<smd name="54" x="5.5" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="55" x="4.4" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="56" x="3.3" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="57" x="2.2" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="58" x="1.1" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="59" x="0" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="60" x="-1.1" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="61" x="-2.2" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="62" x="-3.3" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="63" x="-4.4" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="64" x="-5.5" y="11.95" dx="0.8" dy="1.55" layer="1" cream="no"/>
<smd name="91" x="-5.25" y="-10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="92" x="-3.15" y="-10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="93" x="-1.05" y="-10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="94" x="1.05" y="-10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="95" x="3.15" y="-10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="96" x="5.25" y="-10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="90" x="5.25" y="-8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="89" x="3.15" y="-8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="88" x="1.05" y="-8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="87" x="-1.05" y="-8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="86" x="-3.15" y="-8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="85" x="-5.25" y="-8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="83" x="-5.25" y="-6.65" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="99" x="-1.05" y="-6.65" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="100" x="1.05" y="-6.65" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="84" x="5.25" y="-6.65" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="82" x="5.25" y="-3.05" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="81" x="-5.25" y="-3.05" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="80" x="5.25" y="3.05" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="79" x="-5.25" y="3.05" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="78" x="5.25" y="6.65" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="98" x="1.05" y="6.65" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="97" x="-1.05" y="6.65" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="77" x="-5.25" y="6.65" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="76" x="5.25" y="8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="75" x="3.15" y="8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="74" x="1.05" y="8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="73" x="-1.05" y="8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="72" x="-3.15" y="8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="71" x="-5.25" y="8.45" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="70" x="5.25" y="10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="69" x="3.15" y="10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="68" x="1.05" y="10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="67" x="-1.05" y="10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="66" x="-3.15" y="10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
<smd name="65" x="-5.25" y="10.25" dx="1.1" dy="1.1" layer="1" cream="no"/>
</package>
</packages>
<symbols>
<symbol name="LARA-R2">
<wire x1="-20.32" y1="40.64" x2="-20.32" y2="-35.56" width="0.254" layer="94"/>
<wire x1="-20.32" y1="-35.56" x2="20.32" y2="-35.56" width="0.254" layer="94"/>
<wire x1="20.32" y1="-35.56" x2="20.32" y2="40.64" width="0.254" layer="94"/>
<wire x1="20.32" y1="40.64" x2="-20.32" y2="40.64" width="0.254" layer="94"/>
<text x="-20.3503" y="40.7007" size="2.543790625" layer="95">&gt;NAME</text>
<text x="-20.3536" y="-38.163" size="2.5442" layer="96">&gt;VALUE</text>
<pin name="VCC" x="22.86" y="38.1" length="short" direction="pwr" rot="R180"/>
<pin name="GND" x="22.86" y="-33.02" length="short" direction="pwr" rot="R180"/>
<pin name="V_BCKP" x="22.86" y="35.56" length="short" direction="pwr" rot="R180"/>
<pin name="V_INT" x="22.86" y="33.02" length="short" direction="pwr" rot="R180"/>
<pin name="PWR_ON" x="-22.86" y="38.1" length="short" direction="in"/>
<pin name="RESET_N" x="-22.86" y="35.56" length="short" direction="in"/>
<pin name="HOST_SELECT" x="-22.86" y="33.02" length="short"/>
<pin name="ANT1" x="-22.86" y="27.94" length="short"/>
<pin name="ANT2" x="-22.86" y="25.4" length="short" direction="in"/>
<pin name="ANT_DET" x="-22.86" y="22.86" length="short" direction="in"/>
<pin name="VSIM" x="22.86" y="27.94" length="short" direction="out" rot="R180"/>
<pin name="SIM_IO" x="22.86" y="20.32" length="short" rot="R180"/>
<pin name="SIM_CLK" x="22.86" y="25.4" length="short" direction="out" function="clk" rot="R180"/>
<pin name="SIM_RST" x="22.86" y="22.86" length="short" direction="out" rot="R180"/>
<pin name="RXD" x="-22.86" y="15.24" length="short" direction="out"/>
<pin name="TXD" x="-22.86" y="17.78" length="short" direction="in"/>
<pin name="CTS" x="-22.86" y="10.16" length="short" direction="out"/>
<pin name="RTS" x="-22.86" y="12.7" length="short" direction="in"/>
<pin name="DSR" x="-22.86" y="5.08" length="short" direction="out"/>
<pin name="RI" x="-22.86" y="2.54" length="short" direction="out"/>
<pin name="DTR" x="-22.86" y="7.62" length="short" direction="in"/>
<pin name="DCD" x="-22.86" y="0" length="short" direction="out"/>
<pin name="VUSB_DET" x="-22.86" y="-5.08" length="short" direction="in"/>
<pin name="USB_D-" x="-22.86" y="-7.62" length="short"/>
<pin name="USB_D+" x="-22.86" y="-10.16" length="short"/>
<pin name="HSIC_DATA" x="22.86" y="15.24" length="short" rot="R180"/>
<pin name="HSIC_STRB" x="22.86" y="12.7" length="short" rot="R180"/>
<pin name="SCL" x="22.86" y="7.62" length="short" direction="out" function="clk" rot="R180"/>
<pin name="SDA" x="22.86" y="5.08" length="short" rot="R180"/>
<pin name="SDIO_D0" x="22.86" y="-2.54" length="short" rot="R180"/>
<pin name="SDIO_D1" x="22.86" y="-5.08" length="short" rot="R180"/>
<pin name="SDIO_D2" x="22.86" y="-7.62" length="short" rot="R180"/>
<pin name="SDIO_D3" x="22.86" y="-10.16" length="short" rot="R180"/>
<pin name="SDIO_CLK" x="22.86" y="2.54" length="short" direction="out" function="clk" rot="R180"/>
<pin name="SDIO_CMD" x="22.86" y="0" length="short" rot="R180"/>
<pin name="I2S_TXD" x="-22.86" y="-17.78" length="short"/>
<pin name="I2S_RXD" x="-22.86" y="-15.24" length="short"/>
<pin name="I2S_CLK" x="-22.86" y="-20.32" length="short" function="clk"/>
<pin name="I2S_WA" x="-22.86" y="-22.86" length="short"/>
<pin name="GPIO6" x="22.86" y="-27.94" length="short" direction="out" rot="R180"/>
<pin name="GPIO1" x="22.86" y="-15.24" length="short" rot="R180"/>
<pin name="GPIO2" x="22.86" y="-17.78" length="short" rot="R180"/>
<pin name="GPIO3" x="22.86" y="-20.32" length="short" rot="R180"/>
<pin name="GPIO4" x="22.86" y="-22.86" length="short" rot="R180"/>
<pin name="GPIO5" x="22.86" y="-25.4" length="short" rot="R180"/>
<pin name="RSVD" x="-22.86" y="-30.48" length="short" direction="pas"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="LARA-R2" prefix="U">
<description>LARA-R2 series: Size-optimized LTE Cat 1 modules in single and multi-mode configurations</description>
<gates>
<gate name="G$1" symbol="LARA-R2" x="0" y="0"/>
</gates>
<devices>
<device name="" package="XCVR_LARA-R2">
<connects>
<connect gate="G$1" pin="ANT1" pad="56"/>
<connect gate="G$1" pin="ANT2" pad="62"/>
<connect gate="G$1" pin="ANT_DET" pad="59"/>
<connect gate="G$1" pin="CTS" pad="11"/>
<connect gate="G$1" pin="DCD" pad="8"/>
<connect gate="G$1" pin="DSR" pad="6"/>
<connect gate="G$1" pin="DTR" pad="9"/>
<connect gate="G$1" pin="GND" pad="1 3 5 14 20 22 30 32 43 50 54 55 57 58 60 61 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96"/>
<connect gate="G$1" pin="GPIO1" pad="16"/>
<connect gate="G$1" pin="GPIO2" pad="23"/>
<connect gate="G$1" pin="GPIO3" pad="24"/>
<connect gate="G$1" pin="GPIO4" pad="25"/>
<connect gate="G$1" pin="GPIO5" pad="42"/>
<connect gate="G$1" pin="GPIO6" pad="19"/>
<connect gate="G$1" pin="HOST_SELECT" pad="21"/>
<connect gate="G$1" pin="HSIC_DATA" pad="99"/>
<connect gate="G$1" pin="HSIC_STRB" pad="100"/>
<connect gate="G$1" pin="I2S_CLK" pad="36"/>
<connect gate="G$1" pin="I2S_RXD" pad="37"/>
<connect gate="G$1" pin="I2S_TXD" pad="35"/>
<connect gate="G$1" pin="I2S_WA" pad="34"/>
<connect gate="G$1" pin="PWR_ON" pad="15"/>
<connect gate="G$1" pin="RESET_N" pad="18"/>
<connect gate="G$1" pin="RI" pad="7"/>
<connect gate="G$1" pin="RSVD" pad="31 33 97 98"/>
<connect gate="G$1" pin="RTS" pad="10"/>
<connect gate="G$1" pin="RXD" pad="13"/>
<connect gate="G$1" pin="SCL" pad="27"/>
<connect gate="G$1" pin="SDA" pad="26"/>
<connect gate="G$1" pin="SDIO_CLK" pad="45"/>
<connect gate="G$1" pin="SDIO_CMD" pad="46"/>
<connect gate="G$1" pin="SDIO_D0" pad="47"/>
<connect gate="G$1" pin="SDIO_D1" pad="49"/>
<connect gate="G$1" pin="SDIO_D2" pad="44"/>
<connect gate="G$1" pin="SDIO_D3" pad="48"/>
<connect gate="G$1" pin="SIM_CLK" pad="38"/>
<connect gate="G$1" pin="SIM_IO" pad="39"/>
<connect gate="G$1" pin="SIM_RST" pad="40"/>
<connect gate="G$1" pin="TXD" pad="12"/>
<connect gate="G$1" pin="USB_D+" pad="29"/>
<connect gate="G$1" pin="USB_D-" pad="28"/>
<connect gate="G$1" pin="VCC" pad="51 52 53"/>
<connect gate="G$1" pin="VSIM" pad="41"/>
<connect gate="G$1" pin="VUSB_DET" pad="17"/>
<connect gate="G$1" pin="V_BCKP" pad="2"/>
<connect gate="G$1" pin="V_INT" pad="4"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="Unavailable"/>
<attribute name="DESCRIPTION" value=" Cellular 4G LTE CAT-1 (Verizon) Transceiver Module 900MHz, 1.8GHz Antenna Not Included, Castellation Surface Mount "/>
<attribute name="MF" value="U-Blox America"/>
<attribute name="MP" value="LARA-R2"/>
<attribute name="PACKAGE" value="SMD-100 U-Blox America"/>
<attribute name="PRICE" value="None"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="MAX9860ETG_">
<packages>
<package name="QFN50P400X400X75-25N">
<wire x1="-2.65" y1="2.65" x2="2.65" y2="2.65" width="0.127" layer="39"/>
<wire x1="2.65" y1="2.65" x2="2.65" y2="-2.65" width="0.127" layer="39"/>
<wire x1="2.65" y1="-2.65" x2="-2.65" y2="-2.65" width="0.127" layer="39"/>
<wire x1="-2.65" y1="-2.65" x2="-2.65" y2="2.65" width="0.127" layer="39"/>
<wire x1="-2" y1="2" x2="2" y2="2" width="0.127" layer="51"/>
<wire x1="2" y1="2" x2="2" y2="-2" width="0.127" layer="51"/>
<wire x1="2" y1="-2" x2="-2" y2="-2" width="0.127" layer="51"/>
<wire x1="-2" y1="-2" x2="-2" y2="2" width="0.127" layer="51"/>
<wire x1="-2" y1="1.5" x2="-2" y2="1.6" width="0.127" layer="21"/>
<wire x1="-2" y1="1.6" x2="-1.6" y2="2" width="0.127" layer="21"/>
<wire x1="-1.6" y1="2" x2="-1.5" y2="2" width="0.127" layer="21"/>
<wire x1="1.5" y1="2" x2="2" y2="2" width="0.127" layer="21"/>
<wire x1="2" y1="2" x2="2" y2="1.5" width="0.127" layer="21"/>
<wire x1="2" y1="-1.5" x2="2" y2="-2" width="0.127" layer="21"/>
<wire x1="2" y1="-2" x2="1.5" y2="-2" width="0.127" layer="21"/>
<wire x1="-1.5" y1="-2" x2="-2" y2="-2" width="0.127" layer="21"/>
<wire x1="-2" y1="-2" x2="-2" y2="-1.5" width="0.127" layer="21"/>
<text x="-2.200909375" y="2.400990625" size="1.27053125" layer="25">&gt;NAME</text>
<text x="-2.703740625" y="-3.70511875" size="1.271759375" layer="27">&gt;VALUE</text>
<smd name="1" x="-1.95" y="1.25" dx="0.85" dy="0.3" layer="1" roundness="100"/>
<smd name="2" x="-1.95" y="0.75" dx="0.85" dy="0.3" layer="1" roundness="100"/>
<smd name="3" x="-1.95" y="0.25" dx="0.85" dy="0.3" layer="1" roundness="100"/>
<smd name="4" x="-1.95" y="-0.25" dx="0.85" dy="0.3" layer="1" roundness="100"/>
<smd name="5" x="-1.95" y="-0.75" dx="0.85" dy="0.3" layer="1" roundness="100"/>
<smd name="6" x="-1.95" y="-1.25" dx="0.85" dy="0.3" layer="1" roundness="100"/>
<smd name="7" x="-1.25" y="-1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R90"/>
<smd name="8" x="-0.75" y="-1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R90"/>
<smd name="9" x="-0.25" y="-1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R90"/>
<smd name="10" x="0.25" y="-1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R90"/>
<smd name="11" x="0.75" y="-1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R90"/>
<smd name="12" x="1.25" y="-1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R90"/>
<smd name="13" x="1.95" y="-1.25" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R180"/>
<smd name="14" x="1.95" y="-0.75" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R180"/>
<smd name="15" x="1.95" y="-0.25" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R180"/>
<smd name="16" x="1.95" y="0.25" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R180"/>
<smd name="17" x="1.95" y="0.75" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R180"/>
<smd name="18" x="1.95" y="1.25" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R180"/>
<smd name="19" x="1.25" y="1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R270"/>
<smd name="20" x="0.75" y="1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R270"/>
<smd name="21" x="0.25" y="1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R270"/>
<smd name="22" x="-0.25" y="1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R270"/>
<smd name="23" x="-0.75" y="1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R270"/>
<smd name="24" x="-1.25" y="1.95" dx="0.85" dy="0.3" layer="1" roundness="100" rot="R270"/>
<smd name="25" x="0" y="0" dx="2.6" dy="2.6" layer="1" roundness="2"/>
</package>
</packages>
<symbols>
<symbol name="MAX9860ETG+">
<wire x1="-12.7" y1="17.78" x2="-12.7" y2="-20.32" width="0.254" layer="94"/>
<wire x1="-12.7" y1="-20.32" x2="10.16" y2="-20.32" width="0.254" layer="94"/>
<wire x1="10.16" y1="-20.32" x2="10.16" y2="17.78" width="0.254" layer="94"/>
<wire x1="10.16" y1="17.78" x2="-12.7" y2="17.78" width="0.254" layer="94"/>
<text x="-12.4571" y="18.3044" size="1.271140625" layer="95">&gt;NAME</text>
<text x="-12.7149" y="-22.3782" size="1.271490625" layer="96">&gt;VALUE</text>
<pin name="MICBIAS" x="-17.78" y="-10.16" length="middle" direction="pas"/>
<pin name="PREG" x="-17.78" y="-15.24" length="middle" direction="pas"/>
<pin name="REG" x="-17.78" y="-12.7" length="middle" direction="pas"/>
<pin name="REF" x="-17.78" y="-17.78" length="middle" direction="pas"/>
<pin name="AGND" x="15.24" y="-12.7" length="middle" direction="pwr" rot="R180"/>
<pin name="AVDD" x="15.24" y="12.7" length="middle" direction="pwr" rot="R180"/>
<pin name="OUTP" x="15.24" y="0" length="middle" direction="out" rot="R180"/>
<pin name="OUTN" x="15.24" y="-2.54" length="middle" direction="out" rot="R180"/>
<pin name="SDA" x="15.24" y="-5.08" length="middle" direction="out" rot="R180"/>
<pin name="SCL" x="-17.78" y="12.7" length="middle" direction="in" function="clk"/>
<pin name="DVDDIO" x="15.24" y="10.16" length="middle" direction="pwr" rot="R180"/>
<pin name="DGND" x="15.24" y="-10.16" length="middle" direction="pwr" rot="R180"/>
<pin name="DVDD" x="15.24" y="15.24" length="middle" direction="pwr" rot="R180"/>
<pin name="SDOUT" x="15.24" y="5.08" length="middle" direction="out" rot="R180"/>
<pin name="MCLK" x="-17.78" y="0" length="middle" direction="in"/>
<pin name="SDIN" x="-17.78" y="15.24" length="middle" direction="in"/>
<pin name="LRCLK" x="-17.78" y="-2.54" length="middle"/>
<pin name="BCLK" x="-17.78" y="-5.08" length="middle"/>
<pin name="MICRN" x="-17.78" y="7.62" length="middle" direction="in"/>
<pin name="!IRQ" x="15.24" y="2.54" length="middle" direction="out" rot="R180"/>
<pin name="MICRP" x="-17.78" y="10.16" length="middle" direction="in"/>
<pin name="MICLN" x="-17.78" y="2.54" length="middle" direction="in"/>
<pin name="MICLP" x="-17.78" y="5.08" length="middle" direction="in"/>
<pin name="MICGND" x="15.24" y="-15.24" length="middle" direction="pwr" rot="R180"/>
<pin name="EP" x="15.24" y="-17.78" length="middle" direction="pwr" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="MAX9860ETG+" prefix="U">
<description>Audio Codec 1ADC / 2DAC 16-Bit 24-Pin TQFN EP</description>
<gates>
<gate name="G$1" symbol="MAX9860ETG+" x="0" y="0"/>
</gates>
<devices>
<device name="" package="QFN50P400X400X75-25N">
<connects>
<connect gate="G$1" pin="!IRQ" pad="19"/>
<connect gate="G$1" pin="AGND" pad="5"/>
<connect gate="G$1" pin="AVDD" pad="6"/>
<connect gate="G$1" pin="BCLK" pad="18"/>
<connect gate="G$1" pin="DGND" pad="12"/>
<connect gate="G$1" pin="DVDD" pad="13"/>
<connect gate="G$1" pin="DVDDIO" pad="11"/>
<connect gate="G$1" pin="EP" pad="25"/>
<connect gate="G$1" pin="LRCLK" pad="17"/>
<connect gate="G$1" pin="MCLK" pad="14"/>
<connect gate="G$1" pin="MICBIAS" pad="1"/>
<connect gate="G$1" pin="MICGND" pad="24"/>
<connect gate="G$1" pin="MICLN" pad="22"/>
<connect gate="G$1" pin="MICLP" pad="23"/>
<connect gate="G$1" pin="MICRN" pad="20"/>
<connect gate="G$1" pin="MICRP" pad="21"/>
<connect gate="G$1" pin="OUTN" pad="8"/>
<connect gate="G$1" pin="OUTP" pad="7"/>
<connect gate="G$1" pin="PREG" pad="3"/>
<connect gate="G$1" pin="REF" pad="4"/>
<connect gate="G$1" pin="REG" pad="2"/>
<connect gate="G$1" pin="SCL" pad="10"/>
<connect gate="G$1" pin="SDA" pad="9"/>
<connect gate="G$1" pin="SDIN" pad="16"/>
<connect gate="G$1" pin="SDOUT" pad="15"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="Unavailable"/>
<attribute name="DESCRIPTION" value=" Audio Interface 16 b Serial 24-TQFN (4x4) "/>
<attribute name="MF" value="Maxim Integrated"/>
<attribute name="MP" value="MAX9860ETG+"/>
<attribute name="PACKAGE" value="TQFN-24 Maxim"/>
<attribute name="PRICE" value="None"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="frames" urn="urn:adsk.eagle:library:229">
<description>&lt;b&gt;Frames for Sheet and Layout&lt;/b&gt;</description>
<packages>
</packages>
<symbols>
<symbol name="DOCFIELD" urn="urn:adsk.eagle:symbol:13864/1" library_version="1">
<wire x1="0" y1="0" x2="71.12" y2="0" width="0.1016" layer="94"/>
<wire x1="101.6" y1="15.24" x2="87.63" y2="15.24" width="0.1016" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="5.08" width="0.1016" layer="94"/>
<wire x1="0" y1="5.08" x2="71.12" y2="5.08" width="0.1016" layer="94"/>
<wire x1="0" y1="5.08" x2="0" y2="15.24" width="0.1016" layer="94"/>
<wire x1="101.6" y1="15.24" x2="101.6" y2="5.08" width="0.1016" layer="94"/>
<wire x1="71.12" y1="5.08" x2="71.12" y2="0" width="0.1016" layer="94"/>
<wire x1="71.12" y1="5.08" x2="87.63" y2="5.08" width="0.1016" layer="94"/>
<wire x1="71.12" y1="0" x2="101.6" y2="0" width="0.1016" layer="94"/>
<wire x1="87.63" y1="15.24" x2="87.63" y2="5.08" width="0.1016" layer="94"/>
<wire x1="87.63" y1="15.24" x2="0" y2="15.24" width="0.1016" layer="94"/>
<wire x1="87.63" y1="5.08" x2="101.6" y2="5.08" width="0.1016" layer="94"/>
<wire x1="101.6" y1="5.08" x2="101.6" y2="0" width="0.1016" layer="94"/>
<wire x1="0" y1="15.24" x2="0" y2="22.86" width="0.1016" layer="94"/>
<wire x1="101.6" y1="35.56" x2="0" y2="35.56" width="0.1016" layer="94"/>
<wire x1="101.6" y1="35.56" x2="101.6" y2="22.86" width="0.1016" layer="94"/>
<wire x1="0" y1="22.86" x2="101.6" y2="22.86" width="0.1016" layer="94"/>
<wire x1="0" y1="22.86" x2="0" y2="35.56" width="0.1016" layer="94"/>
<wire x1="101.6" y1="22.86" x2="101.6" y2="15.24" width="0.1016" layer="94"/>
<text x="1.27" y="1.27" size="2.54" layer="94">Date:</text>
<text x="12.7" y="1.27" size="2.54" layer="94">&gt;LAST_DATE_TIME</text>
<text x="72.39" y="1.27" size="2.54" layer="94">Sheet:</text>
<text x="86.36" y="1.27" size="2.54" layer="94">&gt;SHEET</text>
<text x="88.9" y="11.43" size="2.54" layer="94">REV:</text>
<text x="1.27" y="19.05" size="2.54" layer="94">TITLE:</text>
<text x="1.27" y="11.43" size="2.54" layer="94">Document Number:</text>
<text x="17.78" y="19.05" size="2.54" layer="94">&gt;DRAWING_NAME</text>
</symbol>
<symbol name="FRAME_C_L" urn="urn:adsk.eagle:symbol:13884/1" library_version="1">
<frame x1="0" y1="0" x2="558.8" y2="431.8" columns="11" rows="9" layer="94" border-bottom="no"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="FRAME_C_L" urn="urn:adsk.eagle:component:13947/1" prefix="FRAME" uservalue="yes" library_version="1">
<description>&lt;b&gt;FRAME&lt;/b&gt; C Size , 17 x 22 INCH, Landscape&lt;p&gt;</description>
<gates>
<gate name="G$1" symbol="FRAME_C_L" x="0" y="0" addlevel="always"/>
<gate name="G$2" symbol="DOCFIELD" x="452.12" y="0" addlevel="always"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="microphon" urn="urn:adsk.eagle:library:297">
<description>&lt;b&gt;Microphon&lt;/b&gt; from&lt;p&gt;
JLI Electronics - www.jlielectronics.com&lt;br&gt;
Panansonic - http://industrial.panasonic.com&lt;br&gt;
&lt;p&gt;
&lt;author&gt;librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
<package name="F6035AP" urn="urn:adsk.eagle:footprint:21013/1" library_version="2">
<description>&lt;b&gt;Omnibidirectional Electret Condenser Microphon&lt;/b&gt;&lt;p&gt;
Source: F6035AP.pdf</description>
<circle x="0" y="0" radius="2.8754" width="0.2032" layer="21"/>
<circle x="1.9" y="0" radius="0.4279" width="0" layer="21"/>
<circle x="0" y="0" radius="2.625" width="1" layer="41"/>
<pad name="2" x="0" y="-0.95" drill="0.7" diameter="1.2"/>
<pad name="1" x="0" y="0.95" drill="0.7" diameter="1.2"/>
<text x="-2.4" y="3.2" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.4" y="-4.8" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="F6050AP" urn="urn:adsk.eagle:footprint:21014/1" library_version="2">
<description>&lt;b&gt;Omnibidirectional Electret Condenser Microphon&lt;/b&gt;&lt;p&gt;
Source: F6050AP.pdf</description>
<circle x="0" y="0" radius="2.8754" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="2.625" width="1" layer="41"/>
<pad name="2" x="0" y="-1.27" drill="0.7" diameter="1.2"/>
<pad name="1" x="0" y="1.27" drill="0.7" diameter="1.2"/>
<text x="-2.4" y="3.2" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.4" y="-4.8" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="1.5499" y1="-2.0251" x2="1.9499" y2="-1.4751" layer="21" rot="R45"/>
<rectangle x1="-1.95" y1="-2.025" x2="-1.55" y2="-1.475" layer="21" rot="R315"/>
</package>
<package name="WM-61A" urn="urn:adsk.eagle:footprint:21015/1" library_version="2">
<description>&lt;b&gt;Omnidirectional Back Electret Condenser Microphone Cartridge&lt;/b&gt;&lt;p&gt;
Source: www.panasonic.com/industrial/components/pdf/em06_wm61_a_b_dne.pdf</description>
<wire x1="-2.75" y1="0.5" x2="-2.25" y2="0.5" width="0.2032" layer="21"/>
<wire x1="-2.25" y1="0.5" x2="-2.25" y2="-0.5" width="0.2032" layer="21"/>
<wire x1="-2.25" y1="-0.5" x2="-2.75" y2="-0.5" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="2.9" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="2.85" width="0.6" layer="41"/>
<circle x="1.9" y="0" radius="0.3758" width="0" layer="21"/>
<smd name="1" x="0" y="0.95" dx="2.5" dy="1.3" layer="1" roundness="100"/>
<smd name="2" x="0" y="-0.95" dx="2.5" dy="1.3" layer="1" roundness="100"/>
<text x="-2.794" y="3.302" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.794" y="-4.572" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="WM-61B" urn="urn:adsk.eagle:footprint:21016/1" library_version="2">
<description>&lt;b&gt;Omnidirectional Back Electret Condenser Microphone Cartridge&lt;/b&gt;&lt;p&gt;
Source: www.panasonic.com/industrial/components/pdf/em06_wm61_a_b_dne.pdf</description>
<circle x="0" y="0" radius="2.9" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="2.85" width="0.6" layer="41"/>
<circle x="2" y="0" radius="0.3783" width="0" layer="21"/>
<pad name="1" x="0" y="0.95" drill="0.6" diameter="1"/>
<pad name="2" x="0" y="-0.95" drill="0.6" diameter="1"/>
<text x="-2.794" y="3.302" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.794" y="-4.572" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.8" y1="-0.225" x2="-2.325" y2="0.225" layer="21"/>
</package>
<package name="WM-62PC/62PK" urn="urn:adsk.eagle:footprint:21017/1" library_version="2">
<description>&lt;b&gt;Omnidirectional Back Electret Condenser Microphone Cartridge&lt;/b&gt;&lt;p&gt;
Source: http://industrial.panasonic.com/www-data/pdf/ABA5000/ABA5000CE10.pdf</description>
<circle x="0" y="0" radius="2.9" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="2.85" width="0.6" layer="41"/>
<pad name="1" x="-1" y="0.95" drill="0.6" diameter="1"/>
<pad name="2" x="-1" y="-0.95" drill="0.6" diameter="1"/>
<text x="-2.794" y="3.302" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.794" y="-4.572" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="WM-63PR" urn="urn:adsk.eagle:footprint:21018/1" library_version="2">
<description>&lt;b&gt;Omnidirectional Back Electret Condenser Microphone Cartridge&lt;/b&gt;&lt;p&gt;
Source: http://industrial.panasonic.com/www-data/pdf/ABA5000/ABA5000CE3.pdf</description>
<circle x="0" y="0" radius="2.9" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="2.85" width="0.6" layer="41"/>
<pad name="1" x="-1" y="0.95" drill="0.6" diameter="1"/>
<pad name="2" x="-1" y="-0.95" drill="0.6" diameter="1"/>
<text x="-2.794" y="3.302" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.794" y="-4.572" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="WM-64PC/64PK" urn="urn:adsk.eagle:footprint:21019/1" library_version="2">
<description>&lt;b&gt;Omnidirectional Back Electret Condenser Microphone Cartridge&lt;/b&gt;&lt;p&gt;
Source: http://industrial.panasonic.com/www-data/pdf/ABA5000/ABA5000CE10.pdf</description>
<circle x="0" y="0" radius="2.9" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="2.85" width="0.6" layer="41"/>
<pad name="1" x="-1" y="0.95" drill="0.6" diameter="1"/>
<pad name="2" x="-1" y="-0.95" drill="0.6" diameter="1"/>
<text x="-2.794" y="3.302" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.794" y="-4.572" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="WM-64PN" urn="urn:adsk.eagle:footprint:21020/1" library_version="2">
<description>&lt;b&gt;Omnidirectional Back Electret Condenser Microphone Cartridge&lt;/b&gt;&lt;p&gt;
Source: http://industrial.panasonic.com/www-data/pdf/ABA5000/ABA5000CE10.pdf</description>
<circle x="0" y="0" radius="2.9" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="2.85" width="0.6" layer="41"/>
<pad name="1" x="-1" y="0.95" drill="0.6" diameter="1"/>
<pad name="2" x="-1" y="-0.95" drill="0.6" diameter="1"/>
<text x="-2.794" y="3.302" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.794" y="-4.572" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="TOM-1545P-R" urn="urn:adsk.eagle:footprint:21021/1" library_version="2">
<description>&lt;b&gt;Mocrophone 4 x 1.5mm&lt;/b&gt;&lt;p&gt;
Source: Projects Unlimited Inc. Microphone_TOM-1545P-R_40092-1.pdf</description>
<pad name="-" x="-0.6" y="0.4" drill="0.5" diameter="0.8"/>
<pad name="+" x="0.6" y="0.4" drill="0.5" diameter="0.8"/>
<circle x="0" y="0" radius="2" width="0.1016" layer="21"/>
<text x="-2.0508" y="2.1778" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.0508" y="-3.9558" size="1.27" layer="27">&gt;VALUE</text>
</package>
</packages>
<packages3d>
<package3d name="F6035AP" urn="urn:adsk.eagle:package:21041/1" type="box" library_version="2">
<description>Omnibidirectional Electret Condenser Microphon
Source: F6035AP.pdf</description>
<packageinstances>
<packageinstance name="F6035AP"/>
</packageinstances>
</package3d>
<package3d name="F6050AP" urn="urn:adsk.eagle:package:21036/1" type="box" library_version="2">
<description>Omnibidirectional Electret Condenser Microphon
Source: F6050AP.pdf</description>
<packageinstances>
<packageinstance name="F6050AP"/>
</packageinstances>
</package3d>
<package3d name="WM-61A" urn="urn:adsk.eagle:package:21033/1" type="box" library_version="2">
<description>Omnidirectional Back Electret Condenser Microphone Cartridge
Source: www.panasonic.com/industrial/components/pdf/em06_wm61_a_b_dne.pdf</description>
<packageinstances>
<packageinstance name="WM-61A"/>
</packageinstances>
</package3d>
<package3d name="WM-61B" urn="urn:adsk.eagle:package:21037/1" type="box" library_version="2">
<description>Omnidirectional Back Electret Condenser Microphone Cartridge
Source: www.panasonic.com/industrial/components/pdf/em06_wm61_a_b_dne.pdf</description>
<packageinstances>
<packageinstance name="WM-61B"/>
</packageinstances>
</package3d>
<package3d name="WM-62PC/62PK" urn="urn:adsk.eagle:package:21040/1" type="box" library_version="2">
<description>Omnidirectional Back Electret Condenser Microphone Cartridge
Source: http://industrial.panasonic.com/www-data/pdf/ABA5000/ABA5000CE10.pdf</description>
<packageinstances>
<packageinstance name="WM-62PC/62PK"/>
</packageinstances>
</package3d>
<package3d name="WM-63PR" urn="urn:adsk.eagle:package:21035/1" type="box" library_version="2">
<description>Omnidirectional Back Electret Condenser Microphone Cartridge
Source: http://industrial.panasonic.com/www-data/pdf/ABA5000/ABA5000CE3.pdf</description>
<packageinstances>
<packageinstance name="WM-63PR"/>
</packageinstances>
</package3d>
<package3d name="WM-64PC/64PK" urn="urn:adsk.eagle:package:21034/1" type="box" library_version="2">
<description>Omnidirectional Back Electret Condenser Microphone Cartridge
Source: http://industrial.panasonic.com/www-data/pdf/ABA5000/ABA5000CE10.pdf</description>
<packageinstances>
<packageinstance name="WM-64PC/64PK"/>
</packageinstances>
</package3d>
<package3d name="WM-64PN" urn="urn:adsk.eagle:package:21039/1" type="box" library_version="2">
<description>Omnidirectional Back Electret Condenser Microphone Cartridge
Source: http://industrial.panasonic.com/www-data/pdf/ABA5000/ABA5000CE10.pdf</description>
<packageinstances>
<packageinstance name="WM-64PN"/>
</packageinstances>
</package3d>
<package3d name="TOM-1545P-R" urn="urn:adsk.eagle:package:21038/1" type="box" library_version="2">
<description>Mocrophone 4 x 1.5mm
Source: Projects Unlimited Inc. Microphone_TOM-1545P-R_40092-1.pdf</description>
<packageinstances>
<packageinstance name="TOM-1545P-R"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="CONDENSER-MICROPHON" urn="urn:adsk.eagle:symbol:21012/1" library_version="2">
<wire x1="1.27" y1="-1.27" x2="2.032" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="2.032" y1="-0.254" x2="2.032" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="2.032" y1="-1.27" x2="2.032" y2="-2.286" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-0.254" x2="2.54" y2="-1.27" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-1.27" x2="2.54" y2="-2.286" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-1.27" x2="3.302" y2="-1.27" width="0.1524" layer="94"/>
<circle x="2.286" y="-1.27" radius="2.54" width="0.254" layer="94"/>
<rectangle x1="4.826" y1="-3.81" x2="5.334" y2="1.27" layer="94"/>
<pin name="1" x="-5.08" y="0" visible="pad" length="middle" direction="pas"/>
<pin name="2" x="-5.08" y="-2.54" visible="pad" length="middle" direction="pas"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="ELECTRET_MICROPHON-" urn="urn:adsk.eagle:component:21042/2" prefix="M" library_version="2">
<description>&lt;b&gt;Electret Condenser Microphone&lt;/b&gt;&lt;p&gt;</description>
<gates>
<gate name="G$1" symbol="CONDENSER-MICROPHON" x="0" y="0"/>
</gates>
<devices>
<device name="F6035AP" package="F6035AP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21041/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
<device name="F6050AP" package="F6050AP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21036/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="2" constant="no"/>
</technology>
</technologies>
</device>
<device name="WM-61A" package="WM-61A">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21033/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
<device name="WM-61B" package="WM-61B">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21037/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="1" constant="no"/>
</technology>
</technologies>
</device>
<device name="WM-62PC/62PK" package="WM-62PC/62PK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21040/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
<device name="WM-63PR" package="WM-63PR">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21035/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
<device name="WM-64PC/64PK" package="WM-64PC/64PK">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21034/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
<device name="WM.64PN" package="WM-64PN">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21039/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
<device name="TOM-1545P-R" package="TOM-1545P-R">
<connects>
<connect gate="G$1" pin="1" pad="+"/>
<connect gate="G$1" pin="2" pad="-"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:21038/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="1" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="jumper" urn="urn:adsk.eagle:library:252">
<description>&lt;b&gt;Jumpers&lt;/b&gt;&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
<package name="JP1" urn="urn:adsk.eagle:footprint:15398/1" library_version="2">
<description>&lt;b&gt;JUMPER&lt;/b&gt;</description>
<wire x1="-1.016" y1="0" x2="-1.27" y2="0.254" width="0.1524" layer="21"/>
<wire x1="-1.016" y1="0" x2="-1.27" y2="-0.254" width="0.1524" layer="21"/>
<wire x1="1.016" y1="0" x2="1.27" y2="0.254" width="0.1524" layer="21"/>
<wire x1="1.016" y1="0" x2="1.27" y2="-0.254" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-0.254" x2="1.27" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="1.016" y1="-2.54" x2="1.27" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="1.27" y1="2.286" x2="1.016" y2="2.54" width="0.1524" layer="21"/>
<wire x1="1.27" y1="2.286" x2="1.27" y2="0.254" width="0.1524" layer="21"/>
<wire x1="1.016" y1="2.54" x2="-1.016" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="2.286" x2="-1.016" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="2.286" x2="-1.27" y2="0.254" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-0.254" x2="-1.27" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="-1.016" y1="-2.54" x2="-1.27" y2="-2.286" width="0.1524" layer="21"/>
<wire x1="-1.016" y1="-2.54" x2="1.016" y2="-2.54" width="0.1524" layer="21"/>
<pad name="1" x="0" y="-1.27" drill="0.9144" shape="long"/>
<pad name="2" x="0" y="1.27" drill="0.9144" shape="long"/>
<text x="-1.651" y="-2.54" size="1.27" layer="25" ratio="10" rot="R90">&gt;NAME</text>
<text x="2.921" y="-2.54" size="1.27" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<rectangle x1="-0.3048" y1="0.9652" x2="0.3048" y2="1.5748" layer="51"/>
<rectangle x1="-0.3048" y1="-1.5748" x2="0.3048" y2="-0.9652" layer="51"/>
</package>
</packages>
<packages3d>
<package3d name="JP1" urn="urn:adsk.eagle:package:15455/1" type="box" library_version="2">
<description>JUMPER</description>
<packageinstances>
<packageinstance name="JP1"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="JP2E" urn="urn:adsk.eagle:symbol:15391/1" library_version="2">
<wire x1="0" y1="0" x2="0" y2="1.27" width="0.1524" layer="94"/>
<wire x1="0" y1="2.54" x2="0" y2="1.27" width="0.4064" layer="94"/>
<wire x1="2.54" y1="0" x2="2.54" y2="1.27" width="0.1524" layer="94"/>
<wire x1="2.54" y1="2.54" x2="2.54" y2="1.27" width="0.4064" layer="94"/>
<wire x1="-0.635" y1="0" x2="3.175" y2="0" width="0.4064" layer="94"/>
<wire x1="3.175" y1="0" x2="3.175" y2="0.635" width="0.4064" layer="94"/>
<wire x1="3.175" y1="0.635" x2="-0.635" y2="0.635" width="0.4064" layer="94"/>
<wire x1="-0.635" y1="0.635" x2="-0.635" y2="0" width="0.4064" layer="94"/>
<text x="-1.27" y="0" size="1.778" layer="95" rot="R90">&gt;NAME</text>
<text x="5.715" y="0" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="1" x="0" y="-2.54" visible="pad" length="short" direction="pas" rot="R90"/>
<pin name="2" x="2.54" y="-2.54" visible="pad" length="short" direction="pas" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="JP1E" urn="urn:adsk.eagle:component:15487/2" prefix="JP" uservalue="yes" library_version="2">
<description>&lt;b&gt;JUMPER&lt;/b&gt;</description>
<gates>
<gate name="A" symbol="JP2E" x="2.54" y="0"/>
</gates>
<devices>
<device name="" package="JP1">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:15455/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="61" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="PCM13SMTR">
<packages>
<package name="SW_PCM13SMTR">
<wire x1="-4.85" y1="1.3" x2="4.85" y2="1.3" width="0.2" layer="51"/>
<wire x1="4.25" y1="-1.3" x2="1.5" y2="-1.3" width="0.2" layer="21"/>
<wire x1="1.5" y1="-1.3" x2="-1.5" y2="-1.3" width="0.2" layer="21"/>
<wire x1="-1.5" y1="-1.3" x2="-4.25" y2="-1.3" width="0.2" layer="21"/>
<circle x="-3.9" y="2.1" radius="0.14141875" width="0.2" layer="21"/>
<wire x1="-1.5" y1="-1.3" x2="-1.5" y2="-2.7" width="0.2" layer="21"/>
<wire x1="-1.5" y1="-2.7" x2="1.5" y2="-2.7" width="0.2" layer="21"/>
<wire x1="1.5" y1="-2.7" x2="1.5" y2="-1.3" width="0.2" layer="21"/>
<text x="-6.111259375" y="-1.40258125" size="1.272340625" layer="25" rot="R90">&gt;NAME</text>
<text x="7.31118125" y="-1.7026" size="1.271940625" layer="27" rot="R90">&gt;VALUE</text>
<hole x="-2.5" y="0" drill="0.9"/>
<hole x="2.5" y="0" drill="0.9"/>
<smd name="1" x="-3" y="1.75" dx="0.7" dy="1.5" layer="1" rot="R180"/>
<smd name="2" x="-1.5" y="1.75" dx="0.7" dy="1.5" layer="1" rot="R180"/>
<smd name="3" x="1.5" y="1.75" dx="0.7" dy="1.5" layer="1" rot="R180"/>
<smd name="4" x="3" y="1.75" dx="0.7" dy="1.5" layer="1" rot="R180"/>
<smd name="P$1" x="-5.15" y="1.1" dx="1" dy="0.8" layer="1"/>
<smd name="P$2" x="-5.15" y="-1.1" dx="1" dy="0.8" layer="1"/>
<smd name="P$3" x="5.15" y="1.1" dx="1" dy="0.8" layer="1"/>
<smd name="P$4" x="5.15" y="-1.1" dx="1" dy="0.8" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="PCM13SMTR">
<circle x="2.54" y="2.54" radius="0.508" width="0.254" layer="94"/>
<circle x="2.54" y="0" radius="0.508" width="0.254" layer="94"/>
<circle x="2.54" y="-2.54" radius="0.508" width="0.254" layer="94"/>
<circle x="-2.54" y="0" radius="0.508" width="0.254" layer="94"/>
<wire x1="-2.54" y1="0" x2="2.54" y2="2.54" width="0.254" layer="94"/>
<wire x1="-5.08" y1="5.08" x2="5.08" y2="5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="5.08" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="-5.08" x2="-5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-5.08" y1="-5.08" x2="-5.08" y2="5.08" width="0.254" layer="94"/>
<polygon width="0.254" layer="94">
<vertex x="-3.048" y="0"/>
<vertex x="-2.54" y="0.508"/>
<vertex x="-2.032" y="0"/>
<vertex x="-2.54" y="-0.508"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="2.032" y="0"/>
<vertex x="2.54" y="0.508"/>
<vertex x="3.048" y="0"/>
<vertex x="2.54" y="-0.508"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="2.032" y="2.54"/>
<vertex x="2.54" y="2.032"/>
<vertex x="3.048" y="2.54"/>
<vertex x="2.54" y="3.048"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="2.032" y="-2.54"/>
<vertex x="2.54" y="-2.032"/>
<vertex x="3.048" y="-2.54"/>
<vertex x="2.54" y="-3.048"/>
</polygon>
<text x="-5.08978125" y="5.08978125" size="1.27245" layer="95">&gt;NAME</text>
<text x="-5.08605" y="-7.62906875" size="1.271509375" layer="96">&gt;VALUE</text>
<pin name="3" x="-7.62" y="0" visible="pad" length="middle" direction="pas"/>
<pin name="1" x="7.62" y="2.54" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="2" x="7.62" y="0" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="4" x="7.62" y="-2.54" visible="pad" length="middle" direction="pas" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="PCM13SMTR" prefix="S">
<description>PCM Series SP3T On-On-On Right Angle Gull Wing SMT Ultraminiature Slide Switch </description>
<gates>
<gate name="G$1" symbol="PCM13SMTR" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SW_PCM13SMTR">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DESCRIPTION" value=" Slide Switch SP3T Surface Mount, Right Angle "/>
<attribute name="DIGI-KEY_PART_NUMBER" value="401-2017-1-ND"/>
<attribute name="MF" value="C&amp;K"/>
<attribute name="MP" value="PCM13SMTR"/>
<attribute name="PACKAGE" value="None"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Diode" urn="urn:adsk.eagle:library:16378169">
<description>&lt;B&gt;PN Junction, BridgeRectifier, Zener, Schottky, Switching</description>
<packages>
<package name="DIOMELF3516" urn="urn:adsk.eagle:footprint:16378178/1" library_version="6">
<description>MELF, 3.50 mm length, 1.65 mm diameter
&lt;p&gt;MELF Diode package with 3.50 mm length and 1.65 mm diameter&lt;/p&gt;</description>
<wire x1="0.983" y1="1.239" x2="-2.5717" y2="1.239" width="0.12" layer="21"/>
<wire x1="-2.5717" y1="1.239" x2="-2.5717" y2="-1.239" width="0.12" layer="21"/>
<wire x1="-2.5717" y1="-1.239" x2="0.983" y2="-1.239" width="0.12" layer="21"/>
<wire x1="1.85" y1="-0.85" x2="-1.85" y2="-0.85" width="0.12" layer="51"/>
<wire x1="-1.85" y1="-0.85" x2="-1.85" y2="0.85" width="0.12" layer="51"/>
<wire x1="-1.85" y1="0.85" x2="1.85" y2="0.85" width="0.12" layer="51"/>
<wire x1="1.85" y1="0.85" x2="1.85" y2="-0.85" width="0.12" layer="51"/>
<smd name="1" x="-1.6203" y="0" dx="1.2747" dy="1.85" layer="1"/>
<smd name="2" x="1.6203" y="0" dx="1.2747" dy="1.85" layer="1"/>
<text x="0" y="1.874" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.874" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="DIOMELF5024" urn="urn:adsk.eagle:footprint:16378176/1" library_version="6">
<description>MELF, 5.00 mm length, 2.49 mm diameter
&lt;p&gt;MELF Diode package with 5.00 mm length and 2.49 mm diameter&lt;/p&gt;</description>
<wire x1="1.8515" y1="1.659" x2="-3.3217" y2="1.659" width="0.12" layer="21"/>
<wire x1="-3.3217" y1="1.659" x2="-3.3217" y2="-1.659" width="0.12" layer="21"/>
<wire x1="-3.3217" y1="-1.659" x2="1.8515" y2="-1.659" width="0.12" layer="21"/>
<wire x1="2.6" y1="-1.27" x2="-2.6" y2="-1.27" width="0.12" layer="51"/>
<wire x1="-2.6" y1="-1.27" x2="-2.6" y2="1.27" width="0.12" layer="51"/>
<wire x1="-2.6" y1="1.27" x2="2.6" y2="1.27" width="0.12" layer="51"/>
<wire x1="2.6" y1="1.27" x2="2.6" y2="-1.27" width="0.12" layer="51"/>
<smd name="1" x="-2.4296" y="0" dx="1.1561" dy="2.69" layer="1"/>
<smd name="2" x="2.4296" y="0" dx="1.1561" dy="2.69" layer="1"/>
<text x="0" y="2.294" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.294" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SOD3715X135" urn="urn:adsk.eagle:footprint:9427064/1" library_version="6">
<description>SOD, 3.70 mm span, 2.70 X 1.55 X 1.35 mm body
&lt;p&gt;SOD package with 3.70 mm span with body size 2.70 X 1.55 X 1.35 mm&lt;/p&gt;</description>
<wire x1="1.425" y1="0.85" x2="-2.5991" y2="0.85" width="0.12" layer="21"/>
<wire x1="-2.5991" y1="0.85" x2="-2.5991" y2="-0.85" width="0.12" layer="21"/>
<wire x1="-2.5991" y1="-0.85" x2="1.425" y2="-0.85" width="0.12" layer="21"/>
<wire x1="1.425" y1="-0.85" x2="-1.425" y2="-0.85" width="0.12" layer="51"/>
<wire x1="-1.425" y1="-0.85" x2="-1.425" y2="0.85" width="0.12" layer="51"/>
<wire x1="-1.425" y1="0.85" x2="1.425" y2="0.85" width="0.12" layer="51"/>
<wire x1="1.425" y1="0.85" x2="1.425" y2="-0.85" width="0.12" layer="51"/>
<smd name="1" x="-1.7215" y="0" dx="1.1272" dy="0.7839" layer="1"/>
<smd name="2" x="1.7215" y="0" dx="1.1272" dy="0.7839" layer="1"/>
<text x="0" y="1.485" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.485" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SOD6126X290" urn="urn:adsk.eagle:footprint:9427065/1" library_version="6">
<description>SOD, 6.10 mm span, 4.33 X 2.60 X 2.90 mm body
&lt;p&gt;SOD package with 6.10 mm span with body size 4.33 X 2.60 X 2.90 mm&lt;/p&gt;</description>
<wire x1="2.3" y1="1.475" x2="-3.9179" y2="1.475" width="0.12" layer="21"/>
<wire x1="-3.9179" y1="1.475" x2="-3.9179" y2="-1.475" width="0.12" layer="21"/>
<wire x1="-3.9179" y1="-1.475" x2="2.3" y2="-1.475" width="0.12" layer="21"/>
<wire x1="2.3" y1="-1.475" x2="-2.3" y2="-1.475" width="0.12" layer="51"/>
<wire x1="-2.3" y1="-1.475" x2="-2.3" y2="1.475" width="0.12" layer="51"/>
<wire x1="-2.3" y1="1.475" x2="2.3" y2="1.475" width="0.12" layer="51"/>
<wire x1="2.3" y1="1.475" x2="2.3" y2="-1.475" width="0.12" layer="51"/>
<smd name="1" x="-2.7048" y="0" dx="1.7981" dy="1.7253" layer="1"/>
<smd name="2" x="2.7048" y="0" dx="1.7981" dy="1.7253" layer="1"/>
<text x="0" y="2.11" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.11" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SOD6126X350" urn="urn:adsk.eagle:footprint:9933385/1" library_version="6">
<description>SOD, 6.10 mm span, 4.20 X 2.65 X 3.50 mm body
&lt;p&gt;SOD package with 6.10 mm span with body size 4.20 X 2.65 X 3.50 mm&lt;/p&gt;</description>
<wire x1="2.225" y1="1.65" x2="-3.9179" y2="1.65" width="0.12" layer="21"/>
<wire x1="-3.9179" y1="1.65" x2="-3.9179" y2="-1.65" width="0.12" layer="21"/>
<wire x1="-3.9179" y1="-1.65" x2="2.225" y2="-1.65" width="0.12" layer="21"/>
<wire x1="2.225" y1="-1.65" x2="-2.225" y2="-1.65" width="0.12" layer="51"/>
<wire x1="-2.225" y1="-1.65" x2="-2.225" y2="1.65" width="0.12" layer="51"/>
<wire x1="-2.225" y1="1.65" x2="2.225" y2="1.65" width="0.12" layer="51"/>
<wire x1="2.225" y1="1.65" x2="2.225" y2="-1.65" width="0.12" layer="51"/>
<smd name="1" x="-2.7048" y="0" dx="1.7981" dy="1.7689" layer="1"/>
<smd name="2" x="2.7048" y="0" dx="1.7981" dy="1.7689" layer="1"/>
<text x="0" y="2.285" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.285" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SOD6236X265" urn="urn:adsk.eagle:footprint:9427053/1" library_version="6">
<description>SOD, 6.22 mm span, 4.33 X 3.63 X 2.65 mm body
&lt;p&gt;SOD package with 6.22 mm span with body size 4.33 X 3.63 X 2.65 mm&lt;/p&gt;</description>
<wire x1="2.3" y1="1.975" x2="-3.9196" y2="1.975" width="0.12" layer="21"/>
<wire x1="-3.9196" y1="1.975" x2="-3.9196" y2="-1.975" width="0.12" layer="21"/>
<wire x1="-3.9196" y1="-1.975" x2="2.3" y2="-1.975" width="0.12" layer="21"/>
<wire x1="2.3" y1="-1.975" x2="-2.3" y2="-1.975" width="0.12" layer="51"/>
<wire x1="-2.3" y1="-1.975" x2="-2.3" y2="1.975" width="0.12" layer="51"/>
<wire x1="-2.3" y1="1.975" x2="2.3" y2="1.975" width="0.12" layer="51"/>
<wire x1="2.3" y1="1.975" x2="2.3" y2="-1.975" width="0.12" layer="51"/>
<smd name="1" x="-2.7561" y="0" dx="1.699" dy="2.2839" layer="1"/>
<smd name="2" x="2.7561" y="0" dx="1.699" dy="2.2839" layer="1"/>
<text x="0" y="2.61" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.61" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SOD9959X265" urn="urn:adsk.eagle:footprint:9427066/1" library_version="6">
<description>SOD, 9.93 mm span, 6.88 X 5.90 X 2.65 mm body
&lt;p&gt;SOD package with 9.93 mm span with body size 6.88 X 5.90 X 2.65 mm&lt;/p&gt;</description>
<wire x1="3.575" y1="3.125" x2="-5.7696" y2="3.125" width="0.12" layer="21"/>
<wire x1="-5.7696" y1="3.125" x2="-5.7696" y2="-3.125" width="0.12" layer="21"/>
<wire x1="-5.7696" y1="-3.125" x2="3.575" y2="-3.125" width="0.12" layer="21"/>
<wire x1="3.575" y1="-3.125" x2="-3.575" y2="-3.125" width="0.12" layer="51"/>
<wire x1="-3.575" y1="-3.125" x2="-3.575" y2="3.125" width="0.12" layer="51"/>
<wire x1="-3.575" y1="3.125" x2="3.575" y2="3.125" width="0.12" layer="51"/>
<wire x1="3.575" y1="3.125" x2="3.575" y2="-3.125" width="0.12" layer="51"/>
<smd name="1" x="-4.5203" y="0" dx="1.8706" dy="3.2802" layer="1"/>
<smd name="2" x="4.5203" y="0" dx="1.8706" dy="3.2802" layer="1"/>
<text x="0" y="3.76" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-3.76" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL2513X70" urn="urn:adsk.eagle:footprint:9427167/1" library_version="6">
<description>SODFL, 2.50 mm span, 1.90 X 1.30 X 0.70 mm body
&lt;p&gt;SODFL package with 2.50 mm span with body size 1.90 X 1.30 X 0.70 mm&lt;/p&gt;</description>
<wire x1="1" y1="0.7009" x2="-1.8717" y2="0.7009" width="0.12" layer="21"/>
<wire x1="-1.8717" y1="0.7009" x2="-1.8717" y2="-0.7009" width="0.12" layer="21"/>
<wire x1="-1.8717" y1="-0.7009" x2="1" y2="-0.7009" width="0.12" layer="21"/>
<wire x1="1" y1="-0.7" x2="-1" y2="-0.7" width="0.12" layer="51"/>
<wire x1="-1" y1="-0.7" x2="-1" y2="0.7" width="0.12" layer="51"/>
<wire x1="-1" y1="0.7" x2="1" y2="0.7" width="0.12" layer="51"/>
<wire x1="1" y1="0.7" x2="1" y2="-0.7" width="0.12" layer="51"/>
<smd name="1" x="-1.065" y="0" dx="0.9854" dy="0.7739" layer="1"/>
<smd name="2" x="1.065" y="0" dx="0.9854" dy="0.7739" layer="1"/>
<text x="0" y="1.3359" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.3359" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL2513X75" urn="urn:adsk.eagle:footprint:9427168/1" library_version="6">
<description>SODFL, 2.50 mm span, 2.20 X 1.30 X 0.75 mm body
&lt;p&gt;SODFL package with 2.50 mm span with body size 2.20 X 1.30 X 0.75 mm&lt;/p&gt;</description>
<wire x1="1.15" y1="0.7009" x2="-1.8717" y2="0.7009" width="0.12" layer="21"/>
<wire x1="-1.8717" y1="0.7009" x2="-1.8717" y2="-0.7009" width="0.12" layer="21"/>
<wire x1="-1.8717" y1="-0.7009" x2="1.15" y2="-0.7009" width="0.12" layer="21"/>
<wire x1="1.15" y1="-0.7" x2="-1.15" y2="-0.7" width="0.12" layer="51"/>
<wire x1="-1.15" y1="-0.7" x2="-1.15" y2="0.7" width="0.12" layer="51"/>
<wire x1="-1.15" y1="0.7" x2="1.15" y2="0.7" width="0.12" layer="51"/>
<wire x1="1.15" y1="0.7" x2="1.15" y2="-0.7" width="0.12" layer="51"/>
<smd name="1" x="-0.7394" y="0" dx="1.6364" dy="1.003" layer="1"/>
<smd name="2" x="0.7394" y="0" dx="1.0027" dy="0.7739" layer="1"/>
<text x="0" y="1.3359" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.3359" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL3718X115" urn="urn:adsk.eagle:footprint:9427170/1" library_version="6">
<description>SODFL, 3.70 mm span, 2.80 X 1.80 X 1.15 mm body
&lt;p&gt;SODFL package with 3.70 mm span with body size 2.80 X 1.80 X 1.15 mm&lt;/p&gt;</description>
<wire x1="1.45" y1="0.9946" x2="-2.4717" y2="0.9946" width="0.12" layer="21"/>
<wire x1="-2.4717" y1="0.9946" x2="-2.4717" y2="-0.9946" width="0.12" layer="21"/>
<wire x1="-2.4717" y1="-0.9946" x2="1.45" y2="-0.9946" width="0.12" layer="21"/>
<wire x1="1.45" y1="-0.95" x2="-1.45" y2="-0.95" width="0.12" layer="51"/>
<wire x1="-1.45" y1="-0.95" x2="-1.45" y2="0.95" width="0.12" layer="51"/>
<wire x1="-1.45" y1="0.95" x2="1.45" y2="0.95" width="0.12" layer="51"/>
<wire x1="1.45" y1="0.95" x2="1.45" y2="-0.95" width="0.12" layer="51"/>
<smd name="1" x="-1.6004" y="0" dx="1.1146" dy="1.3612" layer="1"/>
<smd name="2" x="1.6004" y="0" dx="1.1146" dy="1.3612" layer="1"/>
<text x="0" y="1.6296" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.6296" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL3718X140" urn="urn:adsk.eagle:footprint:9427171/1" library_version="6">
<description>SODFL, 3.70 mm span, 2.80 X 1.80 X 1.40 mm body
&lt;p&gt;SODFL package with 3.70 mm span with body size 2.80 X 1.80 X 1.40 mm&lt;/p&gt;</description>
<wire x1="1.45" y1="0.9946" x2="-2.4717" y2="0.9946" width="0.12" layer="21"/>
<wire x1="-2.4717" y1="0.9946" x2="-2.4717" y2="-0.9946" width="0.12" layer="21"/>
<wire x1="-2.4717" y1="-0.9946" x2="1.45" y2="-0.9946" width="0.12" layer="21"/>
<wire x1="1.45" y1="-0.95" x2="-1.45" y2="-0.95" width="0.12" layer="51"/>
<wire x1="-1.45" y1="-0.95" x2="-1.45" y2="0.95" width="0.12" layer="51"/>
<wire x1="-1.45" y1="0.95" x2="1.45" y2="0.95" width="0.12" layer="51"/>
<wire x1="1.45" y1="0.95" x2="1.45" y2="-0.95" width="0.12" layer="51"/>
<smd name="1" x="-1.5233" y="0" dx="1.2688" dy="1.3612" layer="1"/>
<smd name="2" x="1.5233" y="0" dx="1.2688" dy="1.3612" layer="1"/>
<text x="0" y="1.6296" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.6296" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL5336X110" urn="urn:adsk.eagle:footprint:9427173/1" library_version="6">
<description>SODFL, 5.35 mm span, 4.33 X 3.63 X 1.10 mm body
&lt;p&gt;SODFL package with 5.35 mm span with body size 4.33 X 3.63 X 1.10 mm&lt;/p&gt;</description>
<wire x1="2.3" y1="1.975" x2="-3.3202" y2="1.975" width="0.12" layer="21"/>
<wire x1="-3.3202" y1="1.975" x2="-3.3202" y2="-1.975" width="0.12" layer="21"/>
<wire x1="-3.3202" y1="-1.975" x2="2.3" y2="-1.975" width="0.12" layer="21"/>
<wire x1="2.3" y1="-1.975" x2="-2.3" y2="-1.975" width="0.12" layer="51"/>
<wire x1="-2.3" y1="-1.975" x2="-2.3" y2="1.975" width="0.12" layer="51"/>
<wire x1="-2.3" y1="1.975" x2="2.3" y2="1.975" width="0.12" layer="51"/>
<wire x1="2.3" y1="1.975" x2="2.3" y2="-1.975" width="0.12" layer="51"/>
<smd name="1" x="-2.1302" y="0" dx="1.752" dy="2.2239" layer="1"/>
<smd name="2" x="2.1302" y="0" dx="1.752" dy="2.2239" layer="1"/>
<text x="0" y="2.61" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.61" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL7959X110" urn="urn:adsk.eagle:footprint:9427174/1" library_version="6">
<description>SODFL, 7.95 mm span, 6.88 X 5.90 X 1.10 mm body
&lt;p&gt;SODFL package with 7.95 mm span with body size 6.88 X 5.90 X 1.10 mm&lt;/p&gt;</description>
<wire x1="3.575" y1="3.125" x2="-4.5967" y2="3.125" width="0.12" layer="21"/>
<wire x1="-4.5967" y1="3.125" x2="-4.5967" y2="-3.125" width="0.12" layer="21"/>
<wire x1="-4.5967" y1="-3.125" x2="3.575" y2="-3.125" width="0.12" layer="21"/>
<wire x1="3.575" y1="-3.125" x2="-3.575" y2="-3.125" width="0.12" layer="51"/>
<wire x1="-3.575" y1="-3.125" x2="-3.575" y2="3.125" width="0.12" layer="51"/>
<wire x1="-3.575" y1="3.125" x2="3.575" y2="3.125" width="0.12" layer="51"/>
<wire x1="3.575" y1="3.125" x2="3.575" y2="-3.125" width="0.12" layer="51"/>
<smd name="1" x="-3.4233" y="0" dx="1.7188" dy="3.2202" layer="1"/>
<smd name="2" x="3.4233" y="0" dx="1.7188" dy="3.2202" layer="1"/>
<text x="0" y="3.76" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-3.76" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL5226X110" urn="urn:adsk.eagle:footprint:9427175/1" library_version="6">
<description>SODFL, 5.20 mm span, 4.28 X 2.60 X 1.10 mm body
&lt;p&gt;SODFL package with 5.20 mm span with body size 4.28 X 2.60 X 1.10 mm&lt;/p&gt;</description>
<wire x1="2.3" y1="1.475" x2="-3.3179" y2="1.475" width="0.12" layer="21"/>
<wire x1="-3.3179" y1="1.475" x2="-3.3179" y2="-1.475" width="0.12" layer="21"/>
<wire x1="-3.3179" y1="-1.475" x2="2.3" y2="-1.475" width="0.12" layer="21"/>
<wire x1="2.3" y1="-1.475" x2="-2.3" y2="-1.475" width="0.12" layer="51"/>
<wire x1="-2.3" y1="-1.475" x2="-2.3" y2="1.475" width="0.12" layer="51"/>
<wire x1="-2.3" y1="1.475" x2="2.3" y2="1.475" width="0.12" layer="51"/>
<wire x1="2.3" y1="1.475" x2="2.3" y2="-1.475" width="0.12" layer="51"/>
<smd name="1" x="-2.0722" y="0" dx="1.8634" dy="1.6653" layer="1"/>
<smd name="2" x="2.0722" y="0" dx="1.8634" dy="1.6653" layer="1"/>
<text x="0" y="2.11" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.11" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL4725X110" urn="urn:adsk.eagle:footprint:9427177/1" library_version="6">
<description>SODFL, 4.70 mm span, 3.80 X 2.50 X 1.10 mm body
&lt;p&gt;SODFL package with 4.70 mm span with body size 3.80 X 2.50 X 1.10 mm&lt;/p&gt;</description>
<wire x1="2" y1="1.35" x2="-3.0192" y2="1.35" width="0.12" layer="21"/>
<wire x1="-3.0192" y1="1.35" x2="-3.0192" y2="-1.35" width="0.12" layer="21"/>
<wire x1="-3.0192" y1="-1.35" x2="2" y2="-1.35" width="0.12" layer="21"/>
<wire x1="2" y1="-1.35" x2="-2" y2="-1.35" width="0.12" layer="51"/>
<wire x1="-2" y1="-1.35" x2="-2" y2="1.35" width="0.12" layer="51"/>
<wire x1="-2" y1="1.35" x2="2" y2="1.35" width="0.12" layer="51"/>
<wire x1="2" y1="1.35" x2="2" y2="-1.35" width="0.12" layer="51"/>
<smd name="1" x="-2.11" y="0" dx="1.1904" dy="2.0153" layer="1"/>
<smd name="2" x="2.11" y="0" dx="1.1904" dy="2.0153" layer="1"/>
<text x="0" y="1.985" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.985" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="SODFL1608X70" urn="urn:adsk.eagle:footprint:16378177/1" library_version="6">
<description>SODFL, 1.60 mm span, 1.20 X 0.80 X 0.70 mm body
&lt;p&gt;SODFL package with 1.60 mm span with body size 1.20 X 0.80 X 0.70 mm&lt;/p&gt;</description>
<wire x1="0.65" y1="0.514" x2="-1.3786" y2="0.514" width="0.12" layer="21"/>
<wire x1="-1.3786" y1="0.514" x2="-1.3786" y2="-0.514" width="0.12" layer="21"/>
<wire x1="-1.3786" y1="-0.514" x2="0.65" y2="-0.514" width="0.12" layer="21"/>
<wire x1="0.65" y1="-0.45" x2="-0.65" y2="-0.45" width="0.12" layer="51"/>
<wire x1="-0.65" y1="-0.45" x2="-0.65" y2="0.45" width="0.12" layer="51"/>
<wire x1="-0.65" y1="0.45" x2="0.65" y2="0.45" width="0.12" layer="51"/>
<wire x1="0.65" y1="0.45" x2="0.65" y2="-0.45" width="0.12" layer="51"/>
<smd name="1" x="-0.7956" y="0" dx="0.538" dy="0.4" layer="1"/>
<smd name="2" x="0.7956" y="0" dx="0.538" dy="0.4" layer="1"/>
<text x="0" y="1.149" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.149" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="DIOM5226X290N" urn="urn:adsk.eagle:footprint:16378179/1" library_version="6">
<description>Molded Body, 5.20 X 2.60 X 2.90 mm body
&lt;p&gt;Molded Body package with body size 5.20 X 2.60 X 2.90 mm&lt;/p&gt;</description>
<wire x1="2.8" y1="1.475" x2="-3.6179" y2="1.475" width="0.12" layer="21"/>
<wire x1="-3.6179" y1="1.475" x2="-3.6179" y2="-1.475" width="0.12" layer="21"/>
<wire x1="-3.6179" y1="-1.475" x2="2.8" y2="-1.475" width="0.12" layer="21"/>
<wire x1="2.8" y1="-1.475" x2="-2.8" y2="-1.475" width="0.12" layer="51"/>
<wire x1="-2.8" y1="-1.475" x2="-2.8" y2="1.475" width="0.12" layer="51"/>
<wire x1="-2.8" y1="1.475" x2="2.8" y2="1.475" width="0.12" layer="51"/>
<wire x1="2.8" y1="1.475" x2="2.8" y2="-1.475" width="0.12" layer="51"/>
<smd name="1" x="-2.1079" y="0" dx="2.392" dy="1.5653" layer="1"/>
<smd name="2" x="2.1079" y="0" dx="2.392" dy="1.5653" layer="1"/>
<text x="0" y="2.11" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.11" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="DIOM5336X265N" urn="urn:adsk.eagle:footprint:16378175/1" library_version="6">
<description>Molded Body, 5.35 X 3.63 X 2.65 mm body
&lt;p&gt;Molded Body package with body size 5.35 X 3.63 X 2.65 mm&lt;/p&gt;</description>
<wire x1="2.8" y1="1.975" x2="-3.6202" y2="1.975" width="0.12" layer="21"/>
<wire x1="-3.6202" y1="1.975" x2="-3.6202" y2="-1.975" width="0.12" layer="21"/>
<wire x1="-3.6202" y1="-1.975" x2="2.8" y2="-1.975" width="0.12" layer="21"/>
<wire x1="2.8" y1="-1.975" x2="-2.8" y2="-1.975" width="0.12" layer="51"/>
<wire x1="-2.8" y1="-1.975" x2="-2.8" y2="1.975" width="0.12" layer="51"/>
<wire x1="-2.8" y1="1.975" x2="2.8" y2="1.975" width="0.12" layer="51"/>
<wire x1="2.8" y1="1.975" x2="2.8" y2="-1.975" width="0.12" layer="51"/>
<smd name="1" x="-2.1641" y="0" dx="2.2841" dy="2.1239" layer="1"/>
<smd name="2" x="2.1641" y="0" dx="2.2841" dy="2.1239" layer="1"/>
<text x="0" y="2.61" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.61" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="DIOM7959X625N" urn="urn:adsk.eagle:footprint:16378174/1" library_version="6">
<description>Molded Body, 7.95 X 5.90 X 6.25 mm body
&lt;p&gt;Molded Body package with body size 7.95 X 5.90 X 6.25 mm&lt;/p&gt;</description>
<wire x1="4.075" y1="3.125" x2="-4.8967" y2="3.125" width="0.12" layer="21"/>
<wire x1="-4.8967" y1="3.125" x2="-4.8967" y2="-3.125" width="0.12" layer="21"/>
<wire x1="-4.8967" y1="-3.125" x2="4.075" y2="-3.125" width="0.12" layer="21"/>
<wire x1="4.075" y1="-3.125" x2="-4.075" y2="-3.125" width="0.12" layer="51"/>
<wire x1="-4.075" y1="-3.125" x2="-4.075" y2="3.125" width="0.12" layer="51"/>
<wire x1="-4.075" y1="3.125" x2="4.075" y2="3.125" width="0.12" layer="51"/>
<wire x1="4.075" y1="3.125" x2="4.075" y2="-3.125" width="0.12" layer="51"/>
<smd name="1" x="-3.4567" y="0" dx="2.2518" dy="3.1202" layer="1"/>
<smd name="2" x="3.4567" y="0" dx="2.2518" dy="3.1202" layer="1"/>
<text x="0" y="3.76" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-3.76" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
</packages>
<packages3d>
<package3d name="DIOMELF3516L" urn="urn:adsk.eagle:package:16378190/2" type="model" library_version="6">
<description>MELF, 3.50 mm length, 1.65 mm diameter
&lt;p&gt;MELF Diode package with 3.50 mm length and 1.65 mm diameter&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="DIOMELF3516"/>
</packageinstances>
</package3d>
<package3d name="DIOMELF5024" urn="urn:adsk.eagle:package:16378191/1" type="model" library_version="6">
<description>MELF, 5.00 mm length, 2.49 mm diameter
&lt;p&gt;MELF Diode package with 5.00 mm length and 2.49 mm diameter&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="DIOMELF5024"/>
</packageinstances>
</package3d>
<package3d name="SOD3715X135" urn="urn:adsk.eagle:package:9427058/2" type="model" library_version="6">
<description>SOD, 3.70 mm span, 2.70 X 1.55 X 1.35 mm body
&lt;p&gt;SOD package with 3.70 mm span with body size 2.70 X 1.55 X 1.35 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SOD3715X135"/>
</packageinstances>
</package3d>
<package3d name="SOD6126X290" urn="urn:adsk.eagle:package:9427057/2" type="model" library_version="6">
<description>SOD, 6.10 mm span, 4.33 X 2.60 X 2.90 mm body
&lt;p&gt;SOD package with 6.10 mm span with body size 4.33 X 2.60 X 2.90 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SOD6126X290"/>
</packageinstances>
</package3d>
<package3d name="SOD6126X350" urn="urn:adsk.eagle:package:9932483/2" type="model" library_version="6">
<description>SOD, 6.10 mm span, 4.20 X 2.65 X 3.50 mm body
&lt;p&gt;SOD package with 6.10 mm span with body size 4.20 X 2.65 X 3.50 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SOD6126X350"/>
</packageinstances>
</package3d>
<package3d name="SOD6236X265" urn="urn:adsk.eagle:package:9427046/2" type="model" library_version="6">
<description>SOD, 6.22 mm span, 4.33 X 3.63 X 2.65 mm body
&lt;p&gt;SOD package with 6.22 mm span with body size 4.33 X 3.63 X 2.65 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SOD6236X265"/>
</packageinstances>
</package3d>
<package3d name="SOD9959X265" urn="urn:adsk.eagle:package:9427056/2" type="model" library_version="6">
<description>SOD, 9.93 mm span, 6.88 X 5.90 X 2.65 mm body
&lt;p&gt;SOD package with 9.93 mm span with body size 6.88 X 5.90 X 2.65 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SOD9959X265"/>
</packageinstances>
</package3d>
<package3d name="SODFL2513X70" urn="urn:adsk.eagle:package:9427155/2" type="model" library_version="6">
<description>SODFL, 2.50 mm span, 1.90 X 1.30 X 0.70 mm body
&lt;p&gt;SODFL package with 2.50 mm span with body size 1.90 X 1.30 X 0.70 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL2513X70"/>
</packageinstances>
</package3d>
<package3d name="SODFL2513X75" urn="urn:adsk.eagle:package:9427154/2" type="model" library_version="6">
<description>SODFL, 2.50 mm span, 2.20 X 1.30 X 0.75 mm body
&lt;p&gt;SODFL package with 2.50 mm span with body size 2.20 X 1.30 X 0.75 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL2513X75"/>
</packageinstances>
</package3d>
<package3d name="SODFL3718X115" urn="urn:adsk.eagle:package:9427153/2" type="model" library_version="6">
<description>SODFL, 3.70 mm span, 2.80 X 1.80 X 1.15 mm body
&lt;p&gt;SODFL package with 3.70 mm span with body size 2.80 X 1.80 X 1.15 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL3718X115"/>
</packageinstances>
</package3d>
<package3d name="SODFL3718X140" urn="urn:adsk.eagle:package:9427152/2" type="model" library_version="6">
<description>SODFL, 3.70 mm span, 2.80 X 1.80 X 1.40 mm body
&lt;p&gt;SODFL package with 3.70 mm span with body size 2.80 X 1.80 X 1.40 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL3718X140"/>
</packageinstances>
</package3d>
<package3d name="SODFL5336X110" urn="urn:adsk.eagle:package:9427151/2" type="model" library_version="6">
<description>SODFL, 5.35 mm span, 4.33 X 3.63 X 1.10 mm body
&lt;p&gt;SODFL package with 5.35 mm span with body size 4.33 X 3.63 X 1.10 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL5336X110"/>
</packageinstances>
</package3d>
<package3d name="SODFL7959X110" urn="urn:adsk.eagle:package:9427150/2" type="model" library_version="6">
<description>SODFL, 7.95 mm span, 6.88 X 5.90 X 1.10 mm body
&lt;p&gt;SODFL package with 7.95 mm span with body size 6.88 X 5.90 X 1.10 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL7959X110"/>
</packageinstances>
</package3d>
<package3d name="SODFL5226X110" urn="urn:adsk.eagle:package:9427148/2" type="model" library_version="6">
<description>SODFL, 5.20 mm span, 4.28 X 2.60 X 1.10 mm body
&lt;p&gt;SODFL package with 5.20 mm span with body size 4.28 X 2.60 X 1.10 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL5226X110"/>
</packageinstances>
</package3d>
<package3d name="SODFL4725X110" urn="urn:adsk.eagle:package:9427149/2" type="model" library_version="6">
<description>SODFL, 4.70 mm span, 3.80 X 2.50 X 1.10 mm body
&lt;p&gt;SODFL package with 4.70 mm span with body size 3.80 X 2.50 X 1.10 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL4725X110"/>
</packageinstances>
</package3d>
<package3d name="SODFL1608X70" urn="urn:adsk.eagle:package:16378187/1" type="model" library_version="6">
<description>SODFL, 1.60 mm span, 1.20 X 0.80 X 0.70 mm body
&lt;p&gt;SODFL package with 1.60 mm span with body size 1.20 X 0.80 X 0.70 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="SODFL1608X70"/>
</packageinstances>
</package3d>
<package3d name="DIOM5226X290N" urn="urn:adsk.eagle:package:16378188/1" type="model" library_version="6">
<description>Molded Body, 5.20 X 2.60 X 2.90 mm body
&lt;p&gt;Molded Body package with body size 5.20 X 2.60 X 2.90 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="DIOM5226X290N"/>
</packageinstances>
</package3d>
<package3d name="DIOM5336X265N" urn="urn:adsk.eagle:package:16378189/1" type="model" library_version="6">
<description>Molded Body, 5.35 X 3.63 X 2.65 mm body
&lt;p&gt;Molded Body package with body size 5.35 X 3.63 X 2.65 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="DIOM5336X265N"/>
</packageinstances>
</package3d>
<package3d name="DIOM7959X625N" urn="urn:adsk.eagle:package:16378186/1" type="model" library_version="6">
<description>Molded Body, 7.95 X 5.90 X 6.25 mm body
&lt;p&gt;Molded Body package with body size 7.95 X 5.90 X 6.25 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="DIOM7959X625N"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="DIODE" urn="urn:adsk.eagle:symbol:16378170/2" library_version="6">
<description>Diode</description>
<pin name="A" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="C" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<text x="0" y="5.08" size="1.778" layer="95" align="center">&gt;NAME</text>
<text x="0" y="-5.08" size="1.778" layer="95" align="center">&gt;VALUE</text>
<text x="0" y="-7.62" size="1.778" layer="95" align="center">&gt;SPICEMODEL</text>
<text x="0" y="-10.16" size="1.778" layer="95" align="center">&gt;SPICEEXTRA</text>
<wire x1="-2.54" y1="-2.54" x2="-2.54" y2="2.54" width="0.254" layer="94"/>
<wire x1="-2.54" y1="2.54" x2="2.54" y2="0" width="0.254" layer="94"/>
<wire x1="2.54" y1="0" x2="-2.54" y2="-2.54" width="0.254" layer="94"/>
<wire x1="2.54" y1="2.54" x2="2.54" y2="-2.54" width="0.254" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="DIODE" urn="urn:adsk.eagle:component:16378193/5" prefix="D" library_version="7">
<description>&lt;B&gt;Diode Rectifier - Generic</description>
<gates>
<gate name="G$1" symbol="DIODE" x="0" y="0"/>
</gates>
<devices>
<device name="DO-213AA(SOD-80)" package="DIOMELF3516">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378190/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-213AB(5025-METRIC)" package="DIOMELF5024">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378191/1"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-AD" package="SOD3715X135">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427058/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-AC" package="SOD6126X290">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427057/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-BA" package="SOD6126X350">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9932483/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-AA" package="SOD6236X265">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427046/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-215-AB" package="SOD9959X265">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427056/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-219-AC(SOD323F)" package="SODFL2513X70">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427155/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-219-AD" package="SODFL2513X75">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427154/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-219-AB(SOD123F)" package="SODFL3718X115">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427153/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-219-AA" package="SODFL3718X140">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427152/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-221-AA" package="SODFL5336X110">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427151/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-221-AB" package="SODFL7959X110">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427150/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-221-AC" package="SODFL5226X110">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427148/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-221-AD" package="SODFL4725X110">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9427149/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="SODFL(1608-METRIC)" package="SODFL1608X70">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378187/1"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-214AC(SMA)" package="DIOM5226X290N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378188/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-214AA(SMB)" package="DIOM5336X265N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378189/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
<device name="DO-214AB(SMC)" package="DIOM7959X625N">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="C" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16378186/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="CATEGORY" value="Diode" constant="no"/>
<attribute name="DESCRIPTION" value="" constant="no"/>
<attribute name="FORWARD_CURRENT" value="" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="REVERSE_VOLTAGE" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="Rectifier" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="DIODE" constant="no"/>
</technology>
</technologies>
</device>
</devices>
<spice>
<pinmapping spiceprefix="D">
<pinmap gate="G$1" pin="A" pinorder="1"/>
<pinmap gate="G$1" pin="C" pinorder="2"/>
</pinmapping>
<model name="DMOD">
**********************
* Autodesk EAGLE - Spice Model File
* Date: 9/17/17
* basic diode intrinsic model
**********************
.MODEL DMOD D</model>
</spice>
</deviceset>
</devicesets>
</library>
<library name="con-coax" urn="urn:adsk.eagle:library:133">
<description>&lt;b&gt;Coax Connectors&lt;/b&gt;&lt;p&gt;
Radiall  and M/A COM.&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
<package name="BU-SMA-H" urn="urn:adsk.eagle:footprint:6179/1" library_version="2">
<description>FEMALE &lt;b&gt;SMA CONNECTOR&lt;/b&gt;&lt;p&gt;
Radiall&lt;p&gt;</description>
<wire x1="-1.1" y1="3.2" x2="1.1" y2="3.2" width="0.2032" layer="21"/>
<wire x1="3.2" y1="1.1" x2="3.2" y2="-1.1" width="0.2032" layer="21"/>
<wire x1="1.1" y1="-3.2" x2="-1.1" y2="-3.2" width="0.2032" layer="21"/>
<wire x1="-3.2" y1="-1.1" x2="-3.2" y2="1.1" width="0.2032" layer="21"/>
<wire x1="-3.1999" y1="3.1999" x2="3.2" y2="3.2" width="0.2032" layer="51"/>
<wire x1="3.2" y1="3.2" x2="3.2" y2="2.9" width="0.2032" layer="51"/>
<wire x1="3.2" y1="2.9" x2="3.2" y2="-2.9" width="0.2032" layer="51"/>
<wire x1="3.2" y1="-2.9" x2="3.1999" y2="-3.1999" width="0.2032" layer="51"/>
<wire x1="3.1999" y1="-3.1999" x2="-3.2" y2="-3.2" width="0.2032" layer="51"/>
<wire x1="-3.2" y1="-3.2" x2="-3.1999" y2="3.1999" width="0.2032" layer="51"/>
<wire x1="3.2" y1="2.9" x2="4.3" y2="2.9" width="0.2032" layer="51"/>
<wire x1="4.3" y1="2.9" x2="8.3" y2="2.9" width="0.2032" layer="21"/>
<wire x1="8.3" y1="2.9" x2="8.6" y2="3.4" width="0.2032" layer="21"/>
<wire x1="10.7" y1="3.4" x2="11" y2="2.9" width="0.2032" layer="21"/>
<wire x1="11" y1="2.9" x2="11.6" y2="2.9" width="0.2032" layer="21"/>
<wire x1="11.6" y1="-2.9" x2="11.6" y2="2.9" width="0.2032" layer="21"/>
<wire x1="8.6" y1="3.4" x2="10.7" y2="3.4" width="0.2032" layer="21"/>
<wire x1="3.2" y1="-2.9" x2="4.3" y2="-2.9" width="0.2032" layer="51"/>
<wire x1="4.3" y1="-2.9" x2="8.3" y2="-2.9" width="0.2032" layer="21"/>
<wire x1="8.3" y1="-2.9" x2="8.6" y2="-3.4" width="0.2032" layer="21"/>
<wire x1="10.7" y1="-3.4" x2="11" y2="-2.9" width="0.2032" layer="21"/>
<wire x1="11" y1="-2.9" x2="11.6" y2="-2.9" width="0.2032" layer="21"/>
<wire x1="8.6" y1="-3.4" x2="10.7" y2="-3.4" width="0.2032" layer="21"/>
<wire x1="11" y1="-2.9" x2="11" y2="2.9" width="0.2032" layer="21"/>
<wire x1="8.3" y1="-2.9" x2="8.3" y2="2.9" width="0.2032" layer="21"/>
<circle x="0" y="0" radius="3.1999" width="0.2032" layer="51"/>
<circle x="0" y="0" radius="1.7" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0" drill="1.27"/>
<pad name="2" x="-2.5499" y="2.5499" drill="1.778"/>
<pad name="3" x="2.5499" y="2.5499" drill="1.778"/>
<pad name="4" x="2.5499" y="-2.5499" drill="1.778"/>
<pad name="5" x="-2.5499" y="-2.5499" drill="1.778"/>
<text x="-2.54" y="4.445" size="1.27" layer="25">&gt;NAME</text>
<text x="-3.175" y="-5.715" size="1.27" layer="27">&gt;VALUE</text>
</package>
</packages>
<packages3d>
<package3d name="BU-SMA-H" urn="urn:adsk.eagle:package:6206/1" type="box" library_version="2">
<description>FEMALE SMA CONNECTOR
Radiall</description>
<packageinstances>
<packageinstance name="BU-SMA-H"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="BNC-FGND" urn="urn:adsk.eagle:symbol:6174/1" library_version="2">
<wire x1="0" y1="-2.54" x2="-0.762" y2="-1.778" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-0.508" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="0.508" x2="-0.762" y2="0.508" width="0.254" layer="94"/>
<wire x1="-0.762" y1="0.508" x2="-0.508" y2="0" width="0.254" layer="94"/>
<wire x1="-0.508" y1="0" x2="-0.762" y2="-0.508" width="0.254" layer="94"/>
<wire x1="-0.762" y1="-0.508" x2="-2.54" y2="-0.508" width="0.254" layer="94"/>
<wire x1="-2.54" y1="2.54" x2="0" y2="0.508" width="0.3048" layer="94" curve="-79.611142" cap="flat"/>
<wire x1="-2.54" y1="-2.54" x2="0" y2="-0.508" width="0.3048" layer="94" curve="79.611142" cap="flat"/>
<text x="-2.54" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<text x="-2.54" y="3.302" size="1.778" layer="95">&gt;NAME</text>
<pin name="1" x="2.54" y="0" visible="off" length="short" direction="pas" rot="R180"/>
<pin name="2" x="2.54" y="-2.54" visible="off" length="short" direction="pas" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="BU-SMA-H" urn="urn:adsk.eagle:component:6234/2" prefix="X" library_version="2">
<description>FEMALE &lt;b&gt;SMA CONNECTOR&lt;/b&gt;&lt;p&gt;
Radiall&lt;p&gt;</description>
<gates>
<gate name="G$1" symbol="BNC-FGND" x="0" y="0"/>
</gates>
<devices>
<device name="" package="BU-SMA-H">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2 3 4 5"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:6206/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="MF" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OC_FARNELL" value="unknown" constant="no"/>
<attribute name="OC_NEWARK" value="unknown" constant="no"/>
<attribute name="POPULARITY" value="4" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="CRM2512-JZ-R047ELF">
<packages>
<package name="RESC6331X80N">
<text x="-3.86" y="-2" size="0.5" layer="27" align="top-left">&gt;VALUE</text>
<text x="-3.86" y="2" size="0.5" layer="25">&gt;NAME</text>
<wire x1="3.25" y1="-1.65" x2="-3.25" y2="-1.65" width="0.127" layer="51"/>
<wire x1="3.25" y1="1.65" x2="-3.25" y2="1.65" width="0.127" layer="51"/>
<wire x1="3.25" y1="-1.65" x2="3.25" y2="1.65" width="0.127" layer="51"/>
<wire x1="-3.25" y1="-1.65" x2="-3.25" y2="1.65" width="0.127" layer="51"/>
<wire x1="-0.85" y1="1.65" x2="0.85" y2="1.65" width="0.127" layer="21"/>
<wire x1="-0.85" y1="-1.65" x2="0.85" y2="-1.65" width="0.127" layer="21"/>
<wire x1="-3.858" y1="-1.908" x2="3.858" y2="-1.908" width="0.05" layer="39"/>
<wire x1="-3.858" y1="1.908" x2="3.858" y2="1.908" width="0.05" layer="39"/>
<wire x1="-3.858" y1="-1.908" x2="-3.858" y2="1.908" width="0.05" layer="39"/>
<wire x1="3.858" y1="-1.908" x2="3.858" y2="1.908" width="0.05" layer="39"/>
<smd name="1" x="-2.39" y="0" dx="2.44" dy="3.32" layer="1"/>
<smd name="2" x="2.39" y="0" dx="2.44" dy="3.32" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="CRM2512-JZ-R047ELF">
<wire x1="-5.08" y1="0" x2="-4.445" y2="1.905" width="0.254" layer="94"/>
<wire x1="-4.445" y1="1.905" x2="-3.175" y2="-1.905" width="0.254" layer="94"/>
<wire x1="-3.175" y1="-1.905" x2="-1.905" y2="1.905" width="0.254" layer="94"/>
<wire x1="-1.905" y1="1.905" x2="-0.635" y2="-1.905" width="0.254" layer="94"/>
<wire x1="-0.635" y1="-1.905" x2="0.635" y2="1.905" width="0.254" layer="94"/>
<wire x1="0.635" y1="1.905" x2="1.905" y2="-1.905" width="0.254" layer="94"/>
<wire x1="1.905" y1="-1.905" x2="3.175" y2="1.905" width="0.254" layer="94"/>
<wire x1="3.175" y1="1.905" x2="4.445" y2="-1.905" width="0.254" layer="94"/>
<wire x1="4.445" y1="-1.905" x2="5.08" y2="0" width="0.254" layer="94"/>
<text x="-7.624440625" y="2.54148125" size="2.54148125" layer="95">&gt;NAME</text>
<text x="-7.62996875" y="-5.086640625" size="2.54331875" layer="96">&gt;VALUE</text>
<pin name="1" x="-10.16" y="0" visible="off" length="middle" direction="pas"/>
<pin name="2" x="10.16" y="0" visible="off" length="middle" direction="pas" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="CRM2512-JZ-R047ELF" prefix="R">
<description>RES SMD 47 MOHM 5% 2W 2512 </description>
<gates>
<gate name="G$1" symbol="CRM2512-JZ-R047ELF" x="0" y="0"/>
</gates>
<devices>
<device name="" package="RESC6331X80N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="Unavailable"/>
<attribute name="DESCRIPTION" value=" Res .047 Ohm 2w 5% 2512 Smd "/>
<attribute name="MF" value="Bourns"/>
<attribute name="MP" value="CRM2512-JZ-R047ELF"/>
<attribute name="PACKAGE" value="6331 Bourns"/>
<attribute name="PRICE" value="None"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-rcl">
<packages>
<package name="0402-1005X55N">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="-0.5" y1="-0.25" x2="0.5" y2="-0.25" width="0.025" layer="51"/>
<wire x1="0.5" y1="-0.25" x2="0.5" y2="0.25" width="0.025" layer="51"/>
<wire x1="0.5" y1="0.25" x2="-0.5" y2="0.25" width="0.025" layer="51"/>
<wire x1="-0.5" y1="0.25" x2="-0.5" y2="-0.25" width="0.025" layer="51"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="-0.95" y1="0.45" x2="0.95" y2="0.45" width="0.05" layer="39"/>
<wire x1="0.95" y1="0.45" x2="0.95" y2="-0.45" width="0.05" layer="39"/>
<wire x1="0.95" y1="-0.45" x2="-0.95" y2="-0.45" width="0.05" layer="39"/>
<wire x1="-0.95" y1="-0.45" x2="-0.95" y2="0.45" width="0.05" layer="39"/>
<smd name="1" x="-0.45" y="0" dx="0.62" dy="0.62" layer="1" roundness="3"/>
<smd name="2" x="0.45" y="0" dx="0.62" dy="0.62" layer="1" roundness="3"/>
<text x="-0.9" y="0.5" size="0.4064" layer="51" font="vector" ratio="10">&gt;NAME</text>
</package>
<package name="0805-R2013X50N">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="1" y1="-0.625" x2="1" y2="0.625" width="0.025" layer="51"/>
<wire x1="1" y1="0.625" x2="-1" y2="0.625" width="0.025" layer="51"/>
<wire x1="-1" y1="0.625" x2="-1" y2="-0.625" width="0.025" layer="51"/>
<wire x1="-1" y1="-0.625" x2="1" y2="-0.625" width="0.025" layer="51"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="0.35" y1="0" x2="-0.35" y2="0" width="0.05" layer="39"/>
<wire x1="-1.75" y1="1" x2="1.75" y2="1" width="0.05" layer="39"/>
<wire x1="1.75" y1="1" x2="1.75" y2="-1" width="0.05" layer="39"/>
<wire x1="1.75" y1="-1" x2="-1.75" y2="-1" width="0.05" layer="39"/>
<wire x1="-1.75" y1="-1" x2="-1.75" y2="1" width="0.05" layer="39"/>
<smd name="1" x="-1" y="0" dx="0.95" dy="1.45" layer="1" roundness="3"/>
<smd name="2" x="1" y="0" dx="0.95" dy="1.45" layer="1" roundness="3"/>
<text x="0" y="1.27" size="0.6096" layer="25" font="vector" ratio="10" align="center">&gt;NAME</text>
</package>
<package name="0204V">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;&lt;p&gt;
type 0204, grid 2.5 mm</description>
<wire x1="-1.27" y1="0" x2="1.27" y2="0" width="0.508" layer="51"/>
<wire x1="-0.127" y1="0" x2="0.127" y2="0" width="0.508" layer="21"/>
<circle x="-1.27" y="0" radius="0.889" width="0.1524" layer="51"/>
<circle x="-1.27" y="0" radius="0.635" width="0.0508" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="square"/>
<text x="-2.1336" y="1.1684" size="1.27" layer="25" ratio="12">&gt;NAME</text>
</package>
<package name="PWR">
<description>Multilayer SMD</description>
<wire x1="-2.8004" y1="4.375" x2="2.8004" y2="4.375" width="0.127" layer="21"/>
<wire x1="2.8004" y1="-4.375" x2="-2.8004" y2="-4.375" width="0.127" layer="21"/>
<smd name="1" x="-5.4" y="0" dx="5.2" dy="8.75" layer="1"/>
<smd name="2" x="5.4" y="0" dx="5.2" dy="8.75" layer="1"/>
<text x="0" y="0" size="0.6096" layer="25" align="center">&gt;NAME</text>
</package>
<package name="C0201">
<smd name="1" x="-0.35" y="0" dx="0.45" dy="0.45" layer="1" roundness="20" rot="R90"/>
<smd name="2" x="0.33" y="0" dx="0.45" dy="0.45" layer="1" roundness="20" rot="R90"/>
<rectangle x1="-0.3" y1="-0.15" x2="0.3" y2="0.15" layer="21"/>
<text x="0" y="-0.9525" size="0.6096" layer="25" font="vector" ratio="10" align="center">&gt;NAME</text>
</package>
<package name="C0603">
<wire x1="-0.9" y1="0.45" x2="-0.5" y2="0.45" width="0.127" layer="21"/>
<wire x1="-0.5" y1="0.45" x2="0.5" y2="0.45" width="0.127" layer="21"/>
<wire x1="0.5" y1="0.45" x2="0.9" y2="0.45" width="0.127" layer="21"/>
<wire x1="-0.9" y1="-0.45" x2="-0.5" y2="-0.45" width="0.127" layer="21"/>
<wire x1="-0.5" y1="-0.45" x2="0.5" y2="-0.45" width="0.127" layer="21"/>
<wire x1="0.5" y1="-0.45" x2="0.9" y2="-0.45" width="0.127" layer="21"/>
<wire x1="0.9" y1="0.45" x2="0.9" y2="-0.45" width="0.127" layer="21"/>
<wire x1="-0.9" y1="0.45" x2="-0.9" y2="-0.45" width="0.127" layer="21"/>
<wire x1="-0.5" y1="0.45" x2="-0.5" y2="-0.45" width="0.127" layer="21"/>
<wire x1="0.5" y1="0.45" x2="0.5" y2="-0.45" width="0.127" layer="21"/>
<text x="0" y="-1.27" size="0.8128" layer="25" font="vector" ratio="10" align="center">&gt;NAME</text>
<smd name="1" x="-0.8" y="0" dx="1" dy="0.95" layer="1" roundness="20" rot="R90"/>
<smd name="2" x="0.8" y="0" dx="1" dy="0.95" layer="1" roundness="20" rot="R90"/>
</package>
<package name="C1206">
<smd name="1" x="-1.4" y="0" dx="1.8" dy="1.45" layer="1" roundness="20" rot="R90"/>
<smd name="2" x="1.4" y="0" dx="1.8" dy="1.45" layer="1" roundness="20" rot="R90"/>
<wire x1="-1.6" y1="-0.85" x2="-1" y2="-0.85" width="0.127" layer="21"/>
<wire x1="-1" y1="-0.85" x2="1" y2="-0.85" width="0.127" layer="21"/>
<wire x1="1" y1="-0.85" x2="1.6" y2="-0.85" width="0.127" layer="21"/>
<wire x1="-1.6" y1="0.85" x2="-1" y2="0.85" width="0.127" layer="21"/>
<wire x1="-1" y1="0.85" x2="1" y2="0.85" width="0.127" layer="21"/>
<wire x1="1" y1="0.85" x2="1.6" y2="0.85" width="0.127" layer="21"/>
<wire x1="-1.6" y1="0.85" x2="-1.6" y2="-0.85" width="0.127" layer="21"/>
<wire x1="1.6" y1="0.85" x2="1.6" y2="-0.85" width="0.127" layer="21"/>
<wire x1="-1" y1="0.85" x2="-1" y2="-0.85" width="0.127" layer="21"/>
<wire x1="1" y1="0.85" x2="1" y2="-0.85" width="0.127" layer="21"/>
<text x="0" y="-1.5875" size="0.8128" layer="25" font="vector" ratio="10" align="center">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="R">
<description>Resistor</description>
<wire x1="-2.286" y1="0.762" x2="2.286" y2="0.762" width="0.2794" layer="94"/>
<wire x1="-2.286" y1="-0.762" x2="2.286" y2="-0.762" width="0.2794" layer="94"/>
<wire x1="-2.286" y1="-0.762" x2="-2.286" y2="0" width="0.2794" layer="94"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="0.762" width="0.2794" layer="94"/>
<wire x1="2.286" y1="0.762" x2="2.286" y2="0" width="0.2794" layer="94"/>
<wire x1="2.286" y1="0" x2="2.286" y2="-0.762" width="0.2794" layer="94"/>
<wire x1="2.286" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="0" x2="-2.286" y2="0" width="0.1524" layer="94"/>
<pin name="1" x="-2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1"/>
<pin name="2" x="2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1" rot="R180"/>
<text x="0" y="1.27" size="1.778" layer="95" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.27" size="1.778" layer="96" align="top-center">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="R" prefix="R" uservalue="yes">
<description>SMD Resistor</description>
<gates>
<gate name="G$1" symbol="R" x="0" y="0"/>
</gates>
<devices>
<device name="-0402" package="0402-1005X55N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0R">
<attribute name="CODE-ARDUINO" value="0039" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-070RL/311-0.0LRCT-ND/2827888" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-0.0LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-070RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="0R" constant="no"/>
</technology>
<technology name="-100K">
<attribute name="CODE-ARDUINO" value="0134" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-07100KL/311-100KLRCT-ND/729473" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-100KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo " constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07100KL " constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="100k" constant="no"/>
</technology>
<technology name="-100R">
<attribute name="CODE-ARDUINO" value="A5359" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-search/en?keywords=311-100LRCT-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-100LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07100RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="100R" constant="no"/>
</technology>
<technology name="-10K">
<attribute name="CODE-ARDUINO" value="0136" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-0710KL/311-10.0KLRCT-ND/729470" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-10.0KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0710KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="10k" constant="no"/>
</technology>
<technology name="-10K2">
<attribute name="CODE-ARDUINO" value="2265" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RT0402DRD0710K2L/311-2129-1-ND/6128548" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-2129-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RT0402DRD0710K2L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="10k2" constant="no"/>
</technology>
<technology name="-10R">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-0710KL/311-10KJRCT-ND/729365 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-10KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-0710KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="10R" constant="no"/>
</technology>
<technology name="-120K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-07120KL/311-120KJRCT-ND/729368" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-120KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07120KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="120k" constant="no"/>
</technology>
<technology name="-120R">
<attribute name="CODE-ARDUINO" value="2278" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-07120RL/311-120JRCT-ND/2827967" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-120JRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07120RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="120R" constant="no"/>
</technology>
<technology name="-12K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-0712KL/311-12KJRCT-ND/729370" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-12KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-0712KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="12k" constant="no"/>
</technology>
<technology name="-12K7">
<attribute name="CODE-ARDUINO" value="2260" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0712K7L/YAG2964CT-ND/5281829" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG2964CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0712K7L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="12k7" constant="no"/>
</technology>
<technology name="-137R">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07137RL/YAG2973CT-ND/5281838" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG2973CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07137RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="137R" constant="no"/>
</technology>
<technology name="-19K6">
<attribute name="CODE-ARDUINO" value="A5310" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0719K6L/YAG3026CT-ND/5281891" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3026CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0719K6L" constant="no"/>
<attribute name="NOTE" value="1% ONLY" constant="no"/>
<attribute name="VALUE" value="19k6" constant="no"/>
</technology>
<technology name="-1K">
<attribute name="CODE-ARDUINO" value="0140" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-071KL/311-1.00KLRCT-ND/729460 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-1.00KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="1k" constant="no"/>
</technology>
<technology name="-1K69">
<attribute name="CODE-ARDUINO" value="A5360" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-071K69L/YAG3044CT-ND/5281909" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3044CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071K69L " constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="1k69" constant="no"/>
</technology>
<technology name="-1K7">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-071K69L/YAG3044CT-ND/5281909" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3044CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071K69L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="1k69" constant="no"/>
</technology>
<technology name="-1K91">
<attribute name="CODE-ARDUINO" value="2267" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-071K91L/YAG3049CT-ND/5281914" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3049CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071K91L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="1k91" constant="no"/>
</technology>
<technology name="-1M">
<attribute name="CODE-ARDUINO" value="0139" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-07330RL/311-330JRCT-ND/729412 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-330JRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07330RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="1M" constant="no"/>
</technology>
<technology name="-1M2">
<attribute name="CODE-ARDUINO" value="2352" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/products/en?keywords=RC0402FR-071M2L-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="RC0402FR-071M2L-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071M2L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="1M2" constant="no"/>
</technology>
<technology name="-200K">
<attribute name="CODE-ARDUINO" value="2231" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-07200KL/311-200KJRCT-ND/729387" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-200KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07200KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="200k" constant="no"/>
</technology>
<technology name="-200R">
<attribute name="CODE-ARDUINO" value="A5361" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07200RL/311-200LRCT-ND/2827887" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-200LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07200RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="200R" constant="no"/>
</technology>
<technology name="-220K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-07220KL/311-220KJRCT-ND/729390" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-220KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07220KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="220k" constant="no"/>
</technology>
<technology name="-22K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/NewPortal/yageodocoutput?fileName=/pdf/R-Chip/PYu-AC_51_RoHS_L_6.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.se/products/en?keywords=%09YAG3532CT-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3532CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="AC0402JR-0722KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="22K" constant="no"/>
</technology>
<technology name="-22R">
<attribute name="CODE-ARDUINO" value="0468" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/products/en?keywords=311-22.0LRCT-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-22.0LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0722RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="22R" constant="no"/>
</technology>
<technology name="-261R">
<attribute name="CODE-ARDUINO" value="A5344" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/documents/recent/PYu-RC_Group_51_RoHS_L_9.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07261RL/YAG3078CT-ND/5281943" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3078CT-ND " constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07261RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="261R" constant="no"/>
</technology>
<technology name="-270R">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-07270RL/311-270JRCT-ND/729395" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-270JRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07270RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="270R" constant="no"/>
</technology>
<technology name="-2K87">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-07330RL/311-330JRCT-ND/729412" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3105CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-072K87L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="2k87" constant="no"/>
</technology>
<technology name="-2M">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-072ML/YAG3295CT-ND/5282161" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3295CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-072ML" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="2M" constant="no"/>
</technology>
<technology name="-330K">
<attribute name="CODE-ARDUINO" value="2192" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-07330KL/311-330KJRCT-ND/729413 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-330KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07330KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="330k" constant="no"/>
</technology>
<technology name="-330R">
<attribute name="CODE-ARDUINO" value="2229" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-07330RL/311-330LRCT-ND/729541" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-330LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo " constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07330RL " constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="330R" constant="no"/>
</technology>
<technology name="-390R">
<attribute name="CODE-ARDUINO" value="2195" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07390RL/311-390LRCT-ND/2827929" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-390LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07390RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="390R" constant="no"/>
</technology>
<technology name="-39K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-0739KL/311-39KJRCT-ND/729420" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-39KJRCT-ND " constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-0739KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="39k" constant="no"/>
</technology>
<technology name="-39R">
<attribute name="CODE-ARDUINO" value="0138" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-0739RL/311-39.0LRCT-ND/729549" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-39.0LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo " constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0739RL " constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="39R" constant="no"/>
</technology>
<technology name="-3K3">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-073K3L/311-3.30KLRCT-ND/729527" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-3.30KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-073K3L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="3k3" constant="no"/>
</technology>
<technology name="-3K83">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-073K83L/311-3.83KLRCT-ND/2827952" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-3.83KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-073K83L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="3k83" constant="no"/>
</technology>
<technology name="-402R">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07402RL/YAG3152CT-ND/5282017" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3152CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07402RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="402R" constant="no"/>
</technology>
<technology name="-43K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0743KL/311-43.0KLRCT-ND/729556" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-43.0KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0743KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="43k" constant="no"/>
</technology>
<technology name="-470K">
<attribute name="CODE-ARDUINO" value="2350" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-07470KL/311-470KJRCT-ND/729430" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-470KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07470KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="470k" constant="no"/>
</technology>
<technology name="-47K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-0747KL/311-47KJRCT-ND/729432" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-47KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-0747KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="47k" constant="no"/>
</technology>
<technology name="-49R9">
<attribute name="CODE-ARDUINO" value="A5282" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0749R9L/311-49.9LRCT-ND/729568" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-49.9LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0749R9L" constant="no"/>
<attribute name="NOTE" value="1% ONLY" constant="no"/>
<attribute name="VALUE" value="49R9" constant="no"/>
</technology>
<technology name="-4K7">
<attribute name="CODE-ARDUINO" value="2196" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-074K7L/311-4.7KLRCT-ND/2827881" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-4.7KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo " constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-074K7L " constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="4k7" constant="no"/>
</technology>
<technology name="-53K6">
<attribute name="CODE-ARDUINO" value="A5313" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0753K6L/311-53.6KLRCT-ND/729581" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-53.6KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0753K6L" constant="no"/>
<attribute name="NOTE" value="1% ONLY" constant="no"/>
<attribute name="VALUE" value="53k6" constant="no"/>
</technology>
<technology name="-56K">
<attribute name="CODE-ARDUINO" value="A5311" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/AC0402FR-0756KL/YAG3501CT-ND/6006350" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3501CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="AC0402FR-0756KL" constant="no"/>
<attribute name="NOTE" value="1% ONLY" constant="no"/>
<attribute name="VALUE" value="56k" constant="no"/>
</technology>
<technology name="-5K49">
<attribute name="CODE-ARDUINO" value="2197" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-075K49L/311-5.49KLRCT-ND/729573" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-5.49KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-075K49L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="5k49" constant="no"/>
</technology>
<technology name="-62K">
<attribute name="CODE-ARDUINO" value="A5312" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0762KL/311-62.0KLRCT-ND/729592" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-62.0KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0762KL" constant="no"/>
<attribute name="NOTE" value="1% ONLY" constant="no"/>
<attribute name="VALUE" value="62k" constant="no"/>
</technology>
<technology name="-660R">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-07665RL/YAG3208CT-ND/5282073" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3208CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07665RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="665R" constant="no"/>
</technology>
<technology name="-680K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/it/yageo/RC0402JR-07680KL/311-680KJRTR-ND/726501 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-680KJRTR-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07680KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="680k" constant="no"/>
</technology>
<technology name="-82R">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-0782RL/311-82JRCT-ND/729456" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-82JRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-0782RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="82R" constant="no"/>
</technology>
<technology name="-8K2">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-078K2L/311-8.2KJRCT-ND/729454" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-8.2KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-078K2L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="8k2" constant="no"/>
</technology>
<technology name="-910K">
<attribute name="CODE-ARDUINO" value="2198" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07910KL/YAG3257CT-ND/5282123" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3257CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07910KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="910k" constant="no"/>
</technology>
<technology name="-9K76">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RT0402DRD079K76L/311-2213-1-ND/6128632" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-2213-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RT0402DRD079K76L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="9k76" constant="no"/>
</technology>
<technology name="-DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="12K-1%">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/NewPortal/yageodocoutput?fileName=/pdf/R-Chip/PYu-RC_Group_51_RoHS_L_4.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0712KL/311-12.0KLRCT-ND/729479" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-12.0KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0712KL" constant="no"/>
<attribute name="NOTE" value="1% only" constant="no"/>
<attribute name="VALUE" value="12k-1%" constant="no"/>
</technology>
<technology name="12K4-1%">
<attribute name="CODE-ARDUINO" value="2297" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/NewPortal/yageodocoutput?fileName=/pdf/R-Chip/PYu-RC_Group_51_RoHS_L_4.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0712K4L/311-12.4KLRCT-ND/2827940" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-12.4KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0712K4L" constant="no"/>
<attribute name="NOTE" value="1% only" constant="no"/>
<attribute name="VALUE" value="12k4-1%" constant="no"/>
</technology>
<technology name="390K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-07390KL/YAG3143CT-ND/5282008" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3143CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07390KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="VALUE" value="390k" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0805" package="0805-R2013X50N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0.012R">
<attribute name="DATASHEET" value="https://industrial.panasonic.com/cdbs/www-data/pdf/RDA0000/AOA0000C295.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/panasonic-electronic-components/ERJ-6CWFR012V/P19198CT-ND/6004553" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="P19198CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Panasonic" constant="no"/>
<attribute name="MANUFACTURER-PN" value="ERJ-6CWFR012V" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="RESTRICTIONS" value="-" constant="no"/>
<attribute name="VALUE" value="0.012R" constant="no"/>
</technology>
<technology name="-100R">
<attribute name="DATASHEET" value="http://www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.de/product-detail/en/yageo/RC0805FR-07100RL/311-100CRTR-ND/727543?cur=EUR&amp;lang=en " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-100CRTR-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0805FR-07100RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="RESTRICTIONS" value="-" constant="no"/>
<attribute name="VALUE" value="100R" constant="no"/>
</technology>
<technology name="-47R">
<attribute name="DATASHEET" value="http://www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.de/product-detail/en/yageo/RC0805FR-0747RL/311-47.0CRCT-ND/730919" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-47.0CRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0805FR-0747RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="RESTRICTIONS" value="-" constant="no"/>
<attribute name="VALUE" value="47R" constant="no"/>
</technology>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="RESTRICTIONS" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="TH-VERTICAL" package="0204V">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="PWR" package="PWR">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-.03MR">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.vishay.com/docs/30176/wslp3921.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/products/en?keywords=%20WSLPD-.0003CT-ND%20" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="WSLPD-.0003CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Vishay Dale" constant="no"/>
<attribute name="MANUFACTURER-PN" value="WSLP5931L3000FEB" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="0.3mR" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0201" package="C0201">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0R">
<attribute name="DATASHEET" value="http://www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0201JR-070RL/311-0.0NCT-ND/1949004" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-0.0NCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0201JR-070RL" constant="no"/>
<attribute name="VALUE" value="0R" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0603" package="C0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0R">
<attribute name="CODE-ARDUINO" value="0233" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/exep/pages/download/literatures/PYu-R_Marking_2.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0603JR-070RL/311-0.0GRCT-ND/729622" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-0.0GRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0603JR-070RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="0R" constant="no"/>
</technology>
<technology name="-100K">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/documents/recent/PYu-RC_Group_51_RoHS_L_8.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0603FR-07100KL/311-100KHRCT-ND/729836" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-100KHRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0603FR-07100KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="100k" constant="no"/>
</technology>
<technology name="-100R">
<attribute name="CODE-ARDUINO" value="0131" constant="no"/>
<attribute name="DATASHEET" value="www.rohm.com/web/global/datasheet/ESR01MZPF/esr-e" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/products/en?keywords=%20RHM100DCT-ND%20" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="RHM100DCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Rohm" constant="no"/>
<attribute name="MANUFACTURER-PN" value="ESR03EZPJ101" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="100R" constant="no"/>
</technology>
<technology name="-10K">
<attribute name="CODE-ARDUINO" value="0028" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/documents/recent/PYu-RC_Group_51_RoHS_L_8.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0603JR-0710KL/311-10KGRCT-ND/729647" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-10KGRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0603JR-0710KL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="10k" constant="no"/>
</technology>
<technology name="-12K4">
<attribute name="CODE-ARDUINO" value="0984" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/documents/recent/PYu-RT_1-to-0.01_RoHS_L_9.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RT0603BRD0712K4L/YAG1518TR-ND/1072228" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG1518TR-ND " constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RT0603BRD0712K4L" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="12k4" constant="no"/>
</technology>
<technology name="-1M">
<attribute name="CODE-ARDUINO" value="0004" constant="no"/>
<attribute name="DATASHEET" value="industrial.panasonic.com/www-cgi/jvcr13pz.cgi?E+PZ+3+AOA0001+ERJ3GEYJ105V+7+WW" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/panasonic-electronic-components/ERJ-3GEYJ105V/P1.0MGCT-ND/134885" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="P1.0MGCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Panasonic" constant="no"/>
<attribute name="MANUFACTURER-PN" value="ERJ-3GEYJ105V" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="CR0603-JW-105ELF" constant="no"/>
<attribute name="VALUE" value="1M" constant="no"/>
</technology>
<technology name="-22R">
<attribute name="CODE-ARDUINO" value="0247" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/documents/recent/PYu-RC_Group_51_RoHS_L_9.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0603JR-0722RL/311-22GRDKR-ND/732637" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-22GRDKR-ND " constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value=" RC0603JR-0722RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="22R" constant="no"/>
</technology>
<technology name="-390R">
<attribute name="CODE-ARDUINO" value="A5329" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/exep/pages/download/literatures/PYu-R_Marking_2.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/AC0603JR-07390RL/YAG3668CT-ND/6006517" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3668CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="AC0603JR-07390RL" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="390R" constant="no"/>
</technology>
<technology name="-470R">
<attribute name="CODE-ARDUINO" value="A5330" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/exep/pages/download/literatures/PYu-R_Marking_2.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="RC0603FR-07470RP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG1301CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="YAG1301CT-ND" constant="no"/>
<attribute name="NOTE" value="NO" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="470R" constant="no"/>
</technology>
<technology name="-49R9">
<attribute name="CODE-ARDUINO" value="A5283" constant="no"/>
<attribute name="DATASHEET" value="https://industrial.panasonic.com/cdbs/www-data/pdf/RDA0000/AOA0000C304.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/panasonic-electronic-components/ERJ-3EKF49R9V/P49.9HCT-ND/198412" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="P49.9HCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Panasonic" constant="no"/>
<attribute name="MANUFACTURER-PN" value="ERJ-3EKF49R9V" constant="no"/>
<attribute name="NOTE" value="1% ONLY" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="49R9" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="PN-ALTERNATIVE1" value="" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-1206" package="C1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0.01R">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.te.com/commerce/DocumentDelivery/DDEController?Action=srchrtrv&amp;DocNm=1773269&amp;DocType=DS&amp;DocLang=English" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/te-connectivity-passive-product/RLP73V2BR010FTDF/A109621CT-ND/4032387" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="A109621CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="TE" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RLP73V2BR010FTDF" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="10m" constant="no"/>
</technology>
<technology name="-0.15R">
<attribute name="CODE-ARDUINO" value="0361" constant="no"/>
<attribute name="DATASHEET" value="http://www.susumu.co.jp/common/pdf/n_catalog_partition08_en.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/susumu/RL1632R-R150-F/RL16R.15FCT-ND/714518" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="RL1632R-R150-F" constant="no"/>
<attribute name="MANUFACTURER" value="Susumu" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RL16R.15FCT-ND" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="150m" constant="no"/>
</technology>
<technology name="-20R">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.susumu.co.jp/common/pdf/n_catalog_partition24_en.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/susumu/HRG3216Q-20R0-D-T1/408-1893-1-ND/5762673" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="408-1893-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Susumu" constant="no"/>
<attribute name="MANUFACTURER-PN" value="HRG3216Q-20R0-D-T1" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="20R" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-supply">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
</packages>
<symbols>
<symbol name="GND">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND" prefix="GND">
<description>GND symbol</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="GND" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-transistors">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="PWR_SC70-6L">
<circle x="-0.8" y="-0.7" radius="0.1" width="0.127" layer="21"/>
<wire x1="-1" y1="1" x2="1" y2="1" width="0.127" layer="21"/>
<wire x1="1" y1="1" x2="1" y2="-1" width="0.127" layer="51"/>
<wire x1="-1" y1="-1" x2="-1" y2="1" width="0.127" layer="51"/>
<wire x1="-1" y1="1" x2="-1" y2="-1" width="0.127" layer="21"/>
<wire x1="1" y1="-1" x2="1" y2="1" width="0.127" layer="21"/>
<wire x1="-1" y1="-1" x2="1" y2="-1" width="0.127" layer="21"/>
<smd name="1" x="-0.5" y="-0.925" dx="0.25" dy="0.35" layer="1" rot="R180"/>
<smd name="2" x="0" y="-0.925" dx="0.25" dy="0.35" layer="1" rot="R180"/>
<smd name="3" x="0.5" y="-0.925" dx="0.25" dy="0.35" layer="1" rot="R180"/>
<smd name="4" x="0.5" y="0.925" dx="0.25" dy="0.35" layer="1"/>
<smd name="5" x="0" y="0.925" dx="0.25" dy="0.35" layer="1"/>
<smd name="6" x="-0.5" y="0.925" dx="0.25" dy="0.35" layer="1"/>
<smd name="D" x="0.405" y="0" dx="0.5" dy="0.9" layer="1" roundness="20" rot="R180"/>
<smd name="K" x="-0.405" y="0" dx="0.5" dy="0.9" layer="1" roundness="20" rot="R180"/>
<text x="2.6" y="-2.5" size="1.27" layer="25" font="vector" rot="R90">&gt;NAME</text>
<text x="4.3" y="-2.5" size="1.27" layer="27" font="vector" rot="R90">&gt;VALUE</text>
</package>
<package name="PWR_SC70-6L2">
<wire x1="-1" y1="1" x2="1" y2="1" width="0.127" layer="21"/>
<wire x1="1" y1="1" x2="1" y2="-1" width="0.127" layer="51"/>
<wire x1="-1" y1="-1" x2="-1" y2="1" width="0.127" layer="51"/>
<wire x1="-1" y1="1" x2="-1" y2="-1" width="0.127" layer="21"/>
<wire x1="1" y1="-1" x2="1" y2="1" width="0.127" layer="21"/>
<circle x="-0.8" y="-0.7" radius="0.1" width="0.127" layer="21"/>
<smd name="2" x="0" y="-0.95" dx="0.4" dy="0.5" layer="1" rot="R180"/>
<smd name="3" x="0.65" y="-0.95" dx="0.4" dy="0.5" layer="1" rot="R180"/>
<smd name="1" x="-0.65" y="-0.95" dx="0.4" dy="0.5" layer="1" rot="R180"/>
<smd name="5" x="0" y="0.95" dx="0.4" dy="0.5" layer="1"/>
<smd name="6" x="-0.65" y="0.95" dx="0.4" dy="0.5" layer="1"/>
<smd name="4" x="0.65" y="0.95" dx="0.4" dy="0.5" layer="1"/>
<text x="0" y="0" size="0.6096" layer="25" font="vector" align="center">&gt;NAME</text>
<wire x1="-1" y1="-1" x2="1" y2="-1" width="0.127" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="MOSFET_N-CHN">
<text x="2.54" y="0" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="G" x="-5.08" y="-2.54" visible="pad" length="short" direction="pas"/>
<pin name="D" x="0" y="5.08" visible="pad" length="short" direction="pas" rot="R270"/>
<pin name="S" x="0" y="-5.08" visible="pad" length="short" direction="pas" rot="R90"/>
<wire x1="-1.778" y1="0.762" x2="-1.778" y2="0" width="0.254" layer="94"/>
<wire x1="-1.778" y1="0" x2="-1.778" y2="-0.762" width="0.254" layer="94"/>
<wire x1="-1.778" y1="3.175" x2="-1.778" y2="2.54" width="0.254" layer="94"/>
<wire x1="-1.778" y1="2.54" x2="-1.778" y2="1.905" width="0.254" layer="94"/>
<wire x1="-1.778" y1="0" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-1.778" y1="-1.905" x2="-1.778" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-1.778" y1="-2.54" x2="-1.778" y2="-3.175" width="0.254" layer="94"/>
<wire x1="-2.54" y1="2.54" x2="-2.54" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.778" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="1.27" y1="2.54" x2="1.27" y2="0.508" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.508" x2="1.27" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="1.27" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-1.778" y1="2.54" x2="1.27" y2="2.54" width="0.1524" layer="94"/>
<wire x1="2.032" y1="0.762" x2="1.778" y2="0.508" width="0.1524" layer="94"/>
<wire x1="1.778" y1="0.508" x2="1.27" y2="0.508" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.508" x2="0.762" y2="0.508" width="0.1524" layer="94"/>
<wire x1="0.762" y1="0.508" x2="0.508" y2="0.254" width="0.1524" layer="94"/>
<circle x="0" y="-2.54" radius="0.3592" width="0" layer="94"/>
<circle x="0" y="2.54" radius="0.3592" width="0" layer="94"/>
<polygon width="0.1524" layer="94">
<vertex x="1.27" y="0.508"/>
<vertex x="0.762" y="-0.254"/>
<vertex x="1.778" y="-0.254"/>
</polygon>
<polygon width="0.1524" layer="94">
<vertex x="-1.524" y="0"/>
<vertex x="-0.508" y="0.762"/>
<vertex x="-0.508" y="-0.762"/>
</polygon>
</symbol>
</symbols>
<devicesets>
<deviceset name="2N7002DW-7-F" prefix="Q">
<description>MOSFET 2N-CH 60V 0.23A SOT-363</description>
<gates>
<gate name="-1" symbol="MOSFET_N-CHN" x="0" y="10.16"/>
<gate name="-2" symbol="MOSFET_N-CHN" x="0" y="-10.16"/>
</gates>
<devices>
<device name="PAD" package="PWR_SC70-6L">
<connects>
<connect gate="-1" pin="D" pad="3 D"/>
<connect gate="-1" pin="G" pad="2"/>
<connect gate="-1" pin="S" pad="1"/>
<connect gate="-2" pin="D" pad="6 K"/>
<connect gate="-2" pin="G" pad="5"/>
<connect gate="-2" pin="S" pad="4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.diodes.com/assets/Datasheets/ds30120.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/diodes-incorporated/2N7002DW-7-F/2N7002DW-FDICT-ND/750003" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="2N7002DW-FDICT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Diodes Incorporated" constant="no"/>
<attribute name="MANUFACTURER-PN" value="2N7002DW-7-F" constant="no"/>
<attribute name="VALUE" value="2N7002" constant="no"/>
</technology>
</technologies>
</device>
<device name="NO_PAD" package="PWR_SC70-6L2">
<connects>
<connect gate="-1" pin="D" pad="3"/>
<connect gate="-1" pin="G" pad="5"/>
<connect gate="-1" pin="S" pad="4"/>
<connect gate="-2" pin="D" pad="6"/>
<connect gate="-2" pin="G" pad="2"/>
<connect gate="-2" pin="S" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="http://www.diodes.com/_files/datasheets/ds30120.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/diodes-incorporated/2N7002DW-7-F/2N7002DW-FDITR-ND/749948" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="2N7002DW-FDITR-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Diodes Incorporated" constant="no"/>
<attribute name="MANUFACTURER-PN" value="2N7002DW-7-F" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SJ2-35984E-SMT-TR">
<packages>
<package name="CUI_SJ2-35984E-SMT-TR">
<wire x1="3.75" y1="4" x2="3.45" y2="4.3" width="0" layer="46" curve="-90"/>
<wire x1="3.45" y1="4.3" x2="3.75" y2="4.6" width="0" layer="46" curve="-90"/>
<wire x1="3.75" y1="4.6" x2="4.75" y2="4.6" width="0" layer="46"/>
<wire x1="4.75" y1="4.6" x2="5.05" y2="4.3" width="0" layer="46" curve="-90"/>
<wire x1="5.05" y1="4.3" x2="4.75" y2="4" width="0" layer="46" curve="-90"/>
<wire x1="4.75" y1="4" x2="3.75" y2="4" width="0" layer="46"/>
<wire x1="-0.6" y1="-4.6" x2="-0.9" y2="-4.3" width="0" layer="46" curve="-90"/>
<wire x1="-0.9" y1="-4.3" x2="-0.6" y2="-4" width="0" layer="46" curve="-90"/>
<wire x1="-0.6" y1="-4" x2="0.4" y2="-4" width="0" layer="46"/>
<wire x1="0.4" y1="-4" x2="0.7" y2="-4.3" width="0" layer="46" curve="-90"/>
<wire x1="0.7" y1="-4.3" x2="0.4" y2="-4.6" width="0" layer="46" curve="-90"/>
<wire x1="0.4" y1="-4.6" x2="-0.6" y2="-4.6" width="0" layer="46"/>
<wire x1="-3.45" y1="-4.6" x2="-3.75" y2="-4.3" width="0" layer="46" curve="-90"/>
<wire x1="-3.75" y1="-4.3" x2="-3.45" y2="-4" width="0" layer="46" curve="-90"/>
<wire x1="-3.45" y1="-4" x2="-2.45" y2="-4" width="0" layer="46"/>
<wire x1="-2.45" y1="-4" x2="-2.15" y2="-4.3" width="0" layer="46" curve="-90"/>
<wire x1="-2.15" y1="-4.3" x2="-2.45" y2="-4.6" width="0" layer="46" curve="-90"/>
<wire x1="-2.45" y1="-4.6" x2="-3.45" y2="-4.6" width="0" layer="46"/>
<wire x1="-6.65" y1="8" x2="-6.65" y2="3.15" width="0" layer="46"/>
<wire x1="-6.65" y1="3.15" x2="-3.65" y2="3.15" width="0" layer="46"/>
<wire x1="-2.45" y1="3.15" x2="7.15" y2="3.15" width="0" layer="46"/>
<wire x1="7.15" y1="2.15" x2="7.15" y2="-2.15" width="0" layer="46"/>
<wire x1="7.15" y1="-3.15" x2="2.35" y2="-3.15" width="0" layer="46"/>
<wire x1="1.15" y1="-3.15" x2="-6.65" y2="-3.15" width="0" layer="46"/>
<wire x1="-6.65" y1="-3.15" x2="-6.65" y2="-8" width="0" layer="46"/>
<wire x1="7.15" y1="3.15" x2="7.15" y2="2.15" width="0" layer="46" curve="-180"/>
<wire x1="7.15" y1="-2.15" x2="7.15" y2="-3.15" width="0" layer="46" curve="-180"/>
<wire x1="-2.45" y1="3.5" x2="-2.45" y2="3.15" width="0" layer="46"/>
<wire x1="-3.65" y1="3.5" x2="-3.65" y2="3.15" width="0" layer="46"/>
<wire x1="-3.65" y1="3.5" x2="-2.45" y2="3.5" width="0" layer="46" curve="-180"/>
<wire x1="1.15" y1="-3.5" x2="1.15" y2="-3.15" width="0" layer="46"/>
<wire x1="2.35" y1="-3.5" x2="2.35" y2="-3.15" width="0" layer="46"/>
<wire x1="2.35" y1="-3.5" x2="1.15" y2="-3.5" width="0" layer="46" curve="-180"/>
<text x="-8.15681875" y="6.75565" size="1.271059375" layer="25">&gt;NAME</text>
<text x="-8.150390625" y="-6.2503" size="1.270059375" layer="27" align="top-left">&gt;VALUE</text>
<wire x1="-8.25" y1="-5.5" x2="7.8" y2="-5.5" width="0.05" layer="39"/>
<wire x1="7.8" y1="-5.5" x2="7.8" y2="5.5" width="0.05" layer="39"/>
<wire x1="7.8" y1="5.5" x2="-8.25" y2="5.5" width="0.05" layer="39"/>
<wire x1="-8.25" y1="5.5" x2="-8.25" y2="-5.5" width="0.05" layer="39"/>
<wire x1="-6.65" y1="3" x2="-6.65" y2="2.75" width="0.127" layer="51"/>
<text x="-19.3555" y="9.35266875" size="1.270359375" layer="51">PCB edge</text>
<wire x1="-6.65" y1="2.75" x2="-6.65" y2="-2.75" width="0.127" layer="51"/>
<wire x1="-6.65" y1="-2.75" x2="-6.65" y2="-3" width="0.127" layer="51"/>
<circle x="-4.55" y="6" radius="0.15" width="0.3" layer="21"/>
<wire x1="-6.65" y1="3" x2="6.65" y2="3" width="0.127" layer="51"/>
<wire x1="6.65" y1="3" x2="6.65" y2="-3" width="0.127" layer="51"/>
<wire x1="6.65" y1="-3" x2="-6.65" y2="-3" width="0.127" layer="51"/>
<wire x1="-6.65" y1="2.75" x2="-7.85" y2="2.75" width="0.127" layer="51"/>
<wire x1="-7.85" y1="2.75" x2="-7.85" y2="-2.75" width="0.127" layer="51"/>
<wire x1="-7.85" y1="-2.75" x2="-6.65" y2="-2.75" width="0.127" layer="51"/>
<wire x1="-6.65" y1="2.75" x2="-7.85" y2="2.75" width="0.127" layer="21"/>
<wire x1="-7.85" y1="2.75" x2="-7.85" y2="-2.75" width="0.127" layer="21"/>
<wire x1="-7.85" y1="-2.75" x2="-6.65" y2="-2.75" width="0.127" layer="21"/>
<wire x1="-6.65" y1="-2.75" x2="-6.65" y2="-3" width="0.127" layer="21"/>
<wire x1="-6.65" y1="-3" x2="6.65" y2="-3" width="0.127" layer="21"/>
<wire x1="6.65" y1="-3" x2="6.65" y2="3" width="0.127" layer="21"/>
<wire x1="6.65" y1="3" x2="-6.65" y2="3" width="0.127" layer="21"/>
<wire x1="-6.65" y1="3" x2="-6.65" y2="-2.75" width="0.127" layer="21"/>
<smd name="1" x="-4.55" y="4.125" dx="1.9" dy="1.95" layer="1"/>
<smd name="4" x="-1.55" y="4.125" dx="1.9" dy="1.95" layer="1"/>
<smd name="3" x="1.3" y="4.125" dx="1.9" dy="1.95" layer="1"/>
<smd name="2" x="3.15" y="-4.125" dx="1.9" dy="1.95" layer="1"/>
<pad name="10" x="4.25" y="4.3" drill="0.6" shape="long"/>
<pad name="11" x="-0.1" y="-4.3" drill="0.6" shape="long"/>
<pad name="12" x="-2.95" y="-4.3" drill="0.6" shape="long"/>
</package>
</packages>
<symbols>
<symbol name="SJ2-35984E-SMT-TR">
<wire x1="-12.7" y1="17.78" x2="12.7" y2="17.78" width="0.254" layer="94"/>
<wire x1="12.7" y1="17.78" x2="12.7" y2="15.24" width="0.254" layer="94"/>
<wire x1="12.7" y1="15.24" x2="12.7" y2="10.16" width="0.254" layer="94"/>
<wire x1="12.7" y1="10.16" x2="12.7" y2="5.08" width="0.254" layer="94"/>
<wire x1="12.7" y1="5.08" x2="12.7" y2="0" width="0.254" layer="94"/>
<wire x1="12.7" y1="0" x2="12.7" y2="-5.08" width="0.254" layer="94"/>
<wire x1="12.7" y1="-5.08" x2="12.7" y2="-10.16" width="0.254" layer="94"/>
<wire x1="12.7" y1="-10.16" x2="12.7" y2="-15.24" width="0.254" layer="94"/>
<wire x1="12.7" y1="-15.24" x2="12.7" y2="-17.78" width="0.254" layer="94"/>
<wire x1="12.7" y1="-17.78" x2="-12.7" y2="-17.78" width="0.254" layer="94"/>
<wire x1="-12.7" y1="-17.78" x2="-12.7" y2="17.78" width="0.254" layer="94"/>
<wire x1="12.7" y1="15.24" x2="-8.89" y2="15.24" width="0.1524" layer="94"/>
<wire x1="-8.89" y1="15.24" x2="-8.89" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-8.89" y1="2.54" x2="-7.62" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-7.62" y1="2.54" x2="-7.62" y2="-6.985" width="0.1524" layer="94"/>
<wire x1="-7.62" y1="-6.985" x2="-10.16" y2="-6.985" width="0.1524" layer="94"/>
<wire x1="-10.16" y1="-6.985" x2="-10.16" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-10.16" y1="2.54" x2="-8.89" y2="2.54" width="0.1524" layer="94"/>
<wire x1="12.7" y1="10.16" x2="5.08" y2="10.16" width="0.1524" layer="94"/>
<wire x1="5.08" y1="10.16" x2="-2.54" y2="10.16" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="10.16" x2="-3.81" y2="7.62" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="7.62" x2="-5.08" y2="10.16" width="0.1524" layer="94"/>
<wire x1="12.7" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<text x="-12.7075" y="20.332" size="2.5415" layer="95">&gt;NAME</text>
<text x="-12.7243" y="-22.9038" size="2.544859375" layer="96">&gt;VALUE</text>
<wire x1="5.08" y1="0" x2="0.635" y2="0" width="0.1524" layer="94"/>
<wire x1="0.635" y1="0" x2="-0.635" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-0.635" y1="-2.54" x2="-1.905" y2="0" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-15.24" x2="5.08" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-15.24" x2="3.175" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-15.24" x2="1.905" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="1.905" y1="-12.7" x2="0.635" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-10.16" x2="5.08" y2="-10.16" width="0.1524" layer="94"/>
<wire x1="5.08" y1="-10.16" x2="5.08" y2="-15.24" width="0.1524" layer="94"/>
<polygon width="0.1524" layer="94">
<vertex x="5.08" y="-15.24"/>
<vertex x="4.445" y="-12.7"/>
<vertex x="5.715" y="-12.7"/>
</polygon>
<polygon width="0.1524" layer="94">
<vertex x="5.08" y="0"/>
<vertex x="5.715" y="-2.54"/>
<vertex x="4.445" y="-2.54"/>
</polygon>
<wire x1="5.08" y1="0" x2="5.08" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="12.7" y1="-5.08" x2="5.08" y2="-5.08" width="0.1524" layer="94"/>
<polygon width="0.1524" layer="94">
<vertex x="5.08" y="10.16"/>
<vertex x="5.715" y="7.62"/>
<vertex x="4.445" y="7.62"/>
</polygon>
<wire x1="5.08" y1="10.16" x2="5.08" y2="5.08" width="0.1524" layer="94"/>
<wire x1="12.7" y1="5.08" x2="5.08" y2="5.08" width="0.1524" layer="94"/>
<pin name="SLEEVE" x="17.78" y="15.24" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="RING2" x="17.78" y="10.16" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="RING1" x="17.78" y="0" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="TIP" x="17.78" y="-15.24" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="TIP_SWITCH" x="17.78" y="-10.16" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="RING1_SWITCH" x="17.78" y="-5.08" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="RING2_SWITCH" x="17.78" y="5.08" visible="pad" length="middle" direction="pas" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="SJ2-35984E-SMT-TR" prefix="J">
<description>4 conductors, 3.5mm, SMT Audio Jack w/ 3 Switch </description>
<gates>
<gate name="G$1" symbol="SJ2-35984E-SMT-TR" x="0" y="0"/>
</gates>
<devices>
<device name="" package="CUI_SJ2-35984E-SMT-TR">
<connects>
<connect gate="G$1" pin="RING1" pad="3"/>
<connect gate="G$1" pin="RING1_SWITCH" pad="11"/>
<connect gate="G$1" pin="RING2" pad="4"/>
<connect gate="G$1" pin="RING2_SWITCH" pad="12"/>
<connect gate="G$1" pin="SLEEVE" pad="1"/>
<connect gate="G$1" pin="TIP" pad="2"/>
<connect gate="G$1" pin="TIP_SWITCH" pad="10"/>
</connects>
<technologies>
<technology name="">
<attribute name="MANUFACTURER" value="CUI"/>
<attribute name="PARTREV" value=""/>
<attribute name="STANDARD" value="Manufacturer recommendation"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="CMS-151135-078S-67">
<packages>
<package name="SPKR_CMS-151135-078S-67">
<wire x1="-5.5" y1="7.5" x2="5.5" y2="7.5" width="0.127" layer="51"/>
<wire x1="5.5" y1="7.5" x2="5.5" y2="-7.5" width="0.127" layer="51"/>
<wire x1="-5.5" y1="-7.5" x2="-5.5" y2="7.5" width="0.127" layer="51"/>
<text x="-6.96765" y="-7.36543125" size="1.272490625" layer="21">-</text>
<text x="6.3401" y="-7.48403125" size="1.27101875" layer="21">+</text>
<wire x1="-5.75" y1="7.75" x2="5.75" y2="7.75" width="0.05" layer="39"/>
<text x="-5.08615" y="8.064759375" size="1.271540625" layer="25">&gt;NAME</text>
<text x="-5.78523125" y="-10.004" size="1.27115" layer="27">&gt;VALUE</text>
<wire x1="5.5" y1="-7.5" x2="-5.5" y2="-7.5" width="0.127" layer="51"/>
<polygon width="0.0001" layer="1">
<vertex x="-5.9" y="-5.3"/>
<vertex x="-4.92" y="-5.3"/>
<vertex x="-3.9" y="-6.32"/>
<vertex x="-3.9" y="-7.7"/>
<vertex x="-5.9" y="-7.7"/>
</polygon>
<polygon width="0.0001" layer="1">
<vertex x="4.92" y="-5.3"/>
<vertex x="5.9" y="-5.3"/>
<vertex x="5.9" y="-7.7"/>
<vertex x="3.9" y="-7.7"/>
<vertex x="3.9" y="-6.32"/>
</polygon>
<wire x1="-3.96" y1="-6.31" x2="-4.88" y2="-5.39" width="0.0001" layer="29"/>
<wire x1="-4.88" y1="-5.39" x2="-5.86" y2="-5.39" width="0.0001" layer="29"/>
<polygon width="0.0001" layer="29">
<vertex x="-6" y="-5.2"/>
<vertex x="-4.92" y="-5.2"/>
<vertex x="-3.8" y="-6.32"/>
<vertex x="-3.8" y="-7.8"/>
<vertex x="-6" y="-7.8"/>
</polygon>
<wire x1="3.96" y1="-6.31" x2="4.88" y2="-5.39" width="0.0001" layer="29"/>
<wire x1="4.88" y1="-5.39" x2="5.86" y2="-5.39" width="0.0001" layer="29"/>
<polygon width="0.0001" layer="29">
<vertex x="6" y="-5.2"/>
<vertex x="4.92" y="-5.2"/>
<vertex x="3.8" y="-6.32"/>
<vertex x="3.8" y="-7.8"/>
<vertex x="6" y="-7.8"/>
</polygon>
<wire x1="-5.9" y1="-7.7" x2="-5.9" y2="-5.3" width="0.0001" layer="1"/>
<wire x1="-5.9" y1="-5.3" x2="-4.92" y2="-5.3" width="0.0001" layer="1"/>
<wire x1="-4.92" y1="-5.3" x2="-3.9" y2="-6.32" width="0.0001" layer="1"/>
<wire x1="-3.9" y1="-6.32" x2="-3.9" y2="-7.7" width="0.0001" layer="1"/>
<wire x1="-3.9" y1="-7.7" x2="-5.9" y2="-7.7" width="0.0001" layer="1"/>
<polygon width="0.0001" layer="31">
<vertex x="-5.9" y="-5.3"/>
<vertex x="-4.92" y="-5.3"/>
<vertex x="-3.9" y="-6.32"/>
<vertex x="-3.9" y="-7.7"/>
<vertex x="-5.9" y="-7.7"/>
</polygon>
<polygon width="0.0001" layer="31">
<vertex x="4.92" y="-5.3"/>
<vertex x="5.9" y="-5.3"/>
<vertex x="5.9" y="-7.7"/>
<vertex x="3.9" y="-7.7"/>
<vertex x="3.9" y="-6.32"/>
</polygon>
<wire x1="-5.5" y1="-4.973" x2="-5.5" y2="7.5" width="0.127" layer="21"/>
<wire x1="-5.5" y1="7.5" x2="5.5" y2="7.5" width="0.127" layer="21"/>
<wire x1="5.5" y1="7.5" x2="5.5" y2="-4.946" width="0.127" layer="21"/>
<wire x1="-3.573" y1="-7.5" x2="3.573" y2="-7.5" width="0.127" layer="21"/>
<wire x1="-5.75" y1="7.75" x2="-5.75" y2="-5.05" width="0.05" layer="39"/>
<wire x1="-5.75" y1="-5.05" x2="-6.15" y2="-5.05" width="0.05" layer="39"/>
<wire x1="-6.15" y1="-5.05" x2="-6.15" y2="-7.95" width="0.05" layer="39"/>
<wire x1="-6.15" y1="-7.95" x2="-3.65" y2="-7.95" width="0.05" layer="39"/>
<wire x1="-3.65" y1="-7.95" x2="-3.65" y2="-7.75" width="0.05" layer="39"/>
<wire x1="-3.65" y1="-7.75" x2="3.65" y2="-7.75" width="0.05" layer="39"/>
<wire x1="3.65" y1="-7.75" x2="3.65" y2="-7.95" width="0.05" layer="39"/>
<wire x1="3.65" y1="-7.95" x2="6.15" y2="-7.95" width="0.05" layer="39"/>
<wire x1="6.15" y1="-7.95" x2="6.15" y2="-5.05" width="0.05" layer="39"/>
<wire x1="6.15" y1="-5.05" x2="5.75" y2="-5.05" width="0.05" layer="39"/>
<wire x1="5.75" y1="-5.05" x2="5.75" y2="7.75" width="0.05" layer="39"/>
<smd name="M" x="-5" y="-6.99" dx="1" dy="1" layer="1" stop="no" cream="no"/>
<smd name="P" x="5" y="-6.99" dx="1" dy="1" layer="1" stop="no" cream="no"/>
</package>
</packages>
<symbols>
<symbol name="CMS-151135-078S-67">
<text x="-3.822040625" y="8.91808125" size="1.78361875" layer="95">&gt;NAME</text>
<text x="-3.828709375" y="-11.4861" size="1.78673125" layer="96">&gt;VALUE</text>
<wire x1="-0.635" y1="1.27" x2="0" y2="1.27" width="0.254" layer="94"/>
<wire x1="0" y1="1.27" x2="0.635" y2="1.27" width="0.254" layer="94"/>
<wire x1="0.635" y1="1.27" x2="0.635" y2="-1.27" width="0.254" layer="94"/>
<wire x1="0.635" y1="-1.27" x2="0" y2="-1.27" width="0.254" layer="94"/>
<wire x1="0" y1="-1.27" x2="-0.635" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-0.635" y1="-1.27" x2="-0.635" y2="1.27" width="0.254" layer="94"/>
<wire x1="0.635" y1="1.27" x2="1.905" y2="3.175" width="0.254" layer="94"/>
<wire x1="1.905" y1="3.175" x2="1.905" y2="-3.175" width="0.254" layer="94"/>
<wire x1="1.905" y1="-3.175" x2="0.635" y2="-1.27" width="0.254" layer="94"/>
<wire x1="0" y1="1.27" x2="0" y2="2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-1.27" x2="0" y2="-2.54" width="0.254" layer="94"/>
<text x="-1.915859375" y="1.27723125" size="1.78813125" layer="94">+</text>
<text x="-1.922059375" y="-3.81958125" size="1.793909375" layer="94">-</text>
<pin name="P" x="0" y="5.08" visible="off" length="short" direction="pas" rot="R270"/>
<pin name="M" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="CMS-151135-078S-67" prefix="LS">
<description>15 x 11 mm, Rectangular Frame, 0.7 W, 8 Ohm, Neodymium Magnet, Mylar Cone, Spring Contacts </description>
<gates>
<gate name="G$1" symbol="CMS-151135-078S-67" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SPKR_CMS-151135-078S-67">
<connects>
<connect gate="G$1" pin="M" pad="M"/>
<connect gate="G$1" pin="P" pad="P"/>
</connects>
<technologies>
<technology name="">
<attribute name="MANUFACTURER" value="CUI Inc"/>
<attribute name="PARTREV" value="1.0"/>
<attribute name="STANDARD" value="Manufacturer Recommendations"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="con-lstb" urn="urn:adsk.eagle:library:162">
<description>&lt;b&gt;Pin Headers&lt;/b&gt;&lt;p&gt;
Naming:&lt;p&gt;
MA = male&lt;p&gt;
# contacts - # rows&lt;p&gt;
W = angled&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
<package name="MA08-2" urn="urn:adsk.eagle:footprint:8269/1" library_version="2">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-9.525" y1="2.54" x2="-8.255" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="2.54" x2="-7.62" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-6.985" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="2.54" x2="-5.715" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="2.54" x2="-5.08" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="2.54" x2="-10.16" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="1.905" x2="-4.445" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="2.54" x2="-3.175" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="2.54" x2="-2.54" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="2.54" x2="-0.635" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="2.54" x2="0" y2="1.905" width="0.1524" layer="21"/>
<wire x1="0" y1="1.905" x2="0.635" y2="2.54" width="0.1524" layer="21"/>
<wire x1="0.635" y1="2.54" x2="1.905" y2="2.54" width="0.1524" layer="21"/>
<wire x1="1.905" y1="2.54" x2="2.54" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="2.54" x2="-2.54" y2="1.905" width="0.1524" layer="21"/>
<wire x1="2.54" y1="1.905" x2="3.175" y2="2.54" width="0.1524" layer="21"/>
<wire x1="3.175" y1="2.54" x2="4.445" y2="2.54" width="0.1524" layer="21"/>
<wire x1="4.445" y1="2.54" x2="5.08" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-1.905" x2="-8.255" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-1.905" x2="-5.715" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="-2.54" x2="-6.985" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="-2.54" x2="-7.62" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="1.905" x2="-10.16" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="-1.905" x2="-9.525" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="-2.54" x2="-9.525" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="-1.905" x2="-3.175" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-2.54" x2="-4.445" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="-2.54" x2="-5.08" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="0" y1="-1.905" x2="-0.635" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="2.54" y1="-1.905" x2="1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-2.54" x2="0.635" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="0.635" y1="-2.54" x2="0" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="-1.905" x2="-1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-2.54" x2="-1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-1.905" x2="4.445" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="4.445" y1="-2.54" x2="3.175" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-2.54" x2="2.54" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="5.715" y1="2.54" x2="6.985" y2="2.54" width="0.1524" layer="21"/>
<wire x1="6.985" y1="2.54" x2="7.62" y2="1.905" width="0.1524" layer="21"/>
<wire x1="7.62" y1="1.905" x2="8.255" y2="2.54" width="0.1524" layer="21"/>
<wire x1="8.255" y1="2.54" x2="9.525" y2="2.54" width="0.1524" layer="21"/>
<wire x1="9.525" y1="2.54" x2="10.16" y2="1.905" width="0.1524" layer="21"/>
<wire x1="5.715" y1="2.54" x2="5.08" y2="1.905" width="0.1524" layer="21"/>
<wire x1="10.16" y1="1.905" x2="10.16" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-1.905" x2="6.985" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="10.16" y1="-1.905" x2="9.525" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="9.525" y1="-2.54" x2="8.255" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="8.255" y1="-2.54" x2="7.62" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-1.905" x2="5.715" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="6.985" y1="-2.54" x2="5.715" y2="-2.54" width="0.1524" layer="21"/>
<pad name="1" x="-8.89" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="3" x="-6.35" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="5" x="-3.81" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="7" x="-1.27" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="9" x="1.27" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="11" x="3.81" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="2" x="-8.89" y="1.27" drill="1.016" shape="octagon"/>
<pad name="4" x="-6.35" y="1.27" drill="1.016" shape="octagon"/>
<pad name="6" x="-3.81" y="1.27" drill="1.016" shape="octagon"/>
<pad name="8" x="-1.27" y="1.27" drill="1.016" shape="octagon"/>
<pad name="10" x="1.27" y="1.27" drill="1.016" shape="octagon"/>
<pad name="12" x="3.81" y="1.27" drill="1.016" shape="octagon"/>
<pad name="13" x="6.35" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="15" x="8.89" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="14" x="6.35" y="1.27" drill="1.016" shape="octagon"/>
<pad name="16" x="8.89" y="1.27" drill="1.016" shape="octagon"/>
<text x="-9.398" y="-4.191" size="1.27" layer="21" ratio="10">1</text>
<text x="-10.16" y="2.921" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="7.62" y="2.921" size="1.27" layer="21" ratio="10">16</text>
<text x="0" y="-4.191" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<rectangle x1="-6.604" y1="-1.524" x2="-6.096" y2="-1.016" layer="51"/>
<rectangle x1="-9.144" y1="-1.524" x2="-8.636" y2="-1.016" layer="51"/>
<rectangle x1="-4.064" y1="-1.524" x2="-3.556" y2="-1.016" layer="51"/>
<rectangle x1="1.016" y1="-1.524" x2="1.524" y2="-1.016" layer="51"/>
<rectangle x1="-1.524" y1="-1.524" x2="-1.016" y2="-1.016" layer="51"/>
<rectangle x1="3.556" y1="-1.524" x2="4.064" y2="-1.016" layer="51"/>
<rectangle x1="-9.144" y1="1.016" x2="-8.636" y2="1.524" layer="51"/>
<rectangle x1="-6.604" y1="1.016" x2="-6.096" y2="1.524" layer="51"/>
<rectangle x1="-4.064" y1="1.016" x2="-3.556" y2="1.524" layer="51"/>
<rectangle x1="-1.524" y1="1.016" x2="-1.016" y2="1.524" layer="51"/>
<rectangle x1="1.016" y1="1.016" x2="1.524" y2="1.524" layer="51"/>
<rectangle x1="3.556" y1="1.016" x2="4.064" y2="1.524" layer="51"/>
<rectangle x1="8.636" y1="-1.524" x2="9.144" y2="-1.016" layer="51"/>
<rectangle x1="6.096" y1="-1.524" x2="6.604" y2="-1.016" layer="51"/>
<rectangle x1="6.096" y1="1.016" x2="6.604" y2="1.524" layer="51"/>
<rectangle x1="8.636" y1="1.016" x2="9.144" y2="1.524" layer="51"/>
</package>
</packages>
<packages3d>
<package3d name="MA08-2" urn="urn:adsk.eagle:package:8335/1" type="box" library_version="2">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="MA08-2"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="MA08-2" urn="urn:adsk.eagle:symbol:8268/1" library_version="2">
<wire x1="3.81" y1="-10.16" x2="-3.81" y2="-10.16" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="2.54" y2="-2.54" width="0.6096" layer="94"/>
<wire x1="1.27" y1="-5.08" x2="2.54" y2="-5.08" width="0.6096" layer="94"/>
<wire x1="1.27" y1="-7.62" x2="2.54" y2="-7.62" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="-2.54" x2="-1.27" y2="-2.54" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="-5.08" x2="-1.27" y2="-5.08" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="-7.62" x2="-1.27" y2="-7.62" width="0.6096" layer="94"/>
<wire x1="1.27" y1="2.54" x2="2.54" y2="2.54" width="0.6096" layer="94"/>
<wire x1="1.27" y1="0" x2="2.54" y2="0" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="2.54" x2="-1.27" y2="2.54" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="0" x2="-1.27" y2="0" width="0.6096" layer="94"/>
<wire x1="1.27" y1="10.16" x2="2.54" y2="10.16" width="0.6096" layer="94"/>
<wire x1="1.27" y1="7.62" x2="2.54" y2="7.62" width="0.6096" layer="94"/>
<wire x1="1.27" y1="5.08" x2="2.54" y2="5.08" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="10.16" x2="-1.27" y2="10.16" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="7.62" x2="-1.27" y2="7.62" width="0.6096" layer="94"/>
<wire x1="-2.54" y1="5.08" x2="-1.27" y2="5.08" width="0.6096" layer="94"/>
<wire x1="-3.81" y1="12.7" x2="-3.81" y2="-10.16" width="0.4064" layer="94"/>
<wire x1="3.81" y1="-10.16" x2="3.81" y2="12.7" width="0.4064" layer="94"/>
<wire x1="-3.81" y1="12.7" x2="3.81" y2="12.7" width="0.4064" layer="94"/>
<text x="-3.81" y="-12.7" size="1.778" layer="96">&gt;VALUE</text>
<text x="-3.81" y="13.462" size="1.778" layer="95">&gt;NAME</text>
<pin name="1" x="7.62" y="-7.62" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="3" x="7.62" y="-5.08" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="5" x="7.62" y="-2.54" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="2" x="-7.62" y="-7.62" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="4" x="-7.62" y="-5.08" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="6" x="-7.62" y="-2.54" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="7" x="7.62" y="0" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="9" x="7.62" y="2.54" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="8" x="-7.62" y="0" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="10" x="-7.62" y="2.54" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="11" x="7.62" y="5.08" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="13" x="7.62" y="7.62" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="15" x="7.62" y="10.16" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="12" x="-7.62" y="5.08" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="14" x="-7.62" y="7.62" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="16" x="-7.62" y="10.16" visible="pad" length="middle" direction="pas" swaplevel="1"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="MA08-2" urn="urn:adsk.eagle:component:8373/2" prefix="SV" uservalue="yes" library_version="2">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="G$1" symbol="MA08-2" x="0" y="0"/>
</gates>
<devices>
<device name="" package="MA08-2">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10" pad="10"/>
<connect gate="G$1" pin="11" pad="11"/>
<connect gate="G$1" pin="12" pad="12"/>
<connect gate="G$1" pin="13" pad="13"/>
<connect gate="G$1" pin="14" pad="14"/>
<connect gate="G$1" pin="15" pad="15"/>
<connect gate="G$1" pin="16" pad="16"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8" pad="8"/>
<connect gate="G$1" pin="9" pad="9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:8335/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="MF" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OC_FARNELL" value="unknown" constant="no"/>
<attribute name="OC_NEWARK" value="unknown" constant="no"/>
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="EVQ-P7L01P">
<packages>
<package name="SW_EVQ-P7L01P">
<wire x1="-1.75" y1="-1.6" x2="-1.75" y2="1.45" width="0.127" layer="51"/>
<wire x1="-1.75" y1="1.45" x2="1.75" y2="1.45" width="0.127" layer="51"/>
<wire x1="1.75" y1="1.45" x2="1.75" y2="-1.6" width="0.127" layer="51"/>
<wire x1="1.75" y1="-1.6" x2="0.85" y2="-1.6" width="0.127" layer="51"/>
<wire x1="0.85" y1="-1.6" x2="-0.85" y2="-1.6" width="0.127" layer="51"/>
<wire x1="-0.85" y1="-1.6" x2="-1.75" y2="-1.6" width="0.127" layer="51"/>
<wire x1="-0.85" y1="-1.6" x2="-0.85" y2="-2.1" width="0.127" layer="51"/>
<wire x1="-0.85" y1="-2.1" x2="0.85" y2="-2.1" width="0.127" layer="51"/>
<wire x1="0.85" y1="-2.1" x2="0.85" y2="-1.6" width="0.127" layer="51"/>
<wire x1="-1.75" y1="1.57" x2="1.75" y2="1.57" width="0.127" layer="21"/>
<wire x1="-1.75" y1="-1.6" x2="-0.85" y2="-1.6" width="0.127" layer="21"/>
<wire x1="-0.85" y1="-1.6" x2="-0.85" y2="-2.1" width="0.127" layer="21"/>
<wire x1="-0.85" y1="-2.1" x2="0.85" y2="-2.1" width="0.127" layer="21"/>
<wire x1="0.85" y1="-2.1" x2="0.85" y2="-1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="-1.6" x2="1.75" y2="-1.6" width="0.127" layer="21"/>
<wire x1="-2.75" y1="-1.85" x2="-2.75" y2="1.7" width="0.05" layer="39"/>
<wire x1="-2.75" y1="1.7" x2="2.75" y2="1.7" width="0.05" layer="39"/>
<wire x1="2.75" y1="1.7" x2="2.75" y2="-1.85" width="0.05" layer="39"/>
<wire x1="2.75" y1="-1.85" x2="1.1" y2="-1.85" width="0.05" layer="39"/>
<wire x1="1.1" y1="-1.85" x2="1.1" y2="-2.35" width="0.05" layer="39"/>
<wire x1="1.1" y1="-2.35" x2="-1.1" y2="-2.35" width="0.05" layer="39"/>
<wire x1="-1.1" y1="-2.35" x2="-1.1" y2="-1.85" width="0.05" layer="39"/>
<wire x1="-1.1" y1="-1.85" x2="-2.75" y2="-1.85" width="0.05" layer="39"/>
<text x="-2.8" y="1.8" size="0.8128" layer="25">&gt;NAME</text>
<text x="-2.8" y="-3.3" size="0.8128" layer="27">&gt;VALUE</text>
<circle x="-3.5" y="0.8" radius="0.1" width="0.2" layer="21"/>
<circle x="-3.5" y="0.8" radius="0.1" width="0.2" layer="51"/>
<smd name="1_1" x="-1.8" y="0.725" dx="1.4" dy="1.05" layer="1"/>
<smd name="1_2" x="1.8" y="0.725" dx="1.4" dy="1.05" layer="1"/>
<smd name="2_1" x="-1.8" y="-0.725" dx="1.4" dy="1.05" layer="1"/>
<smd name="2_2" x="1.8" y="-0.725" dx="1.4" dy="1.05" layer="1"/>
<hole x="0" y="0.9" drill="0.7"/>
<hole x="0" y="-0.9" drill="0.7"/>
</package>
</packages>
<symbols>
<symbol name="EVQ-P7L01P">
<circle x="-2.032" y="0" radius="0.359209375" width="0.254" layer="94"/>
<circle x="2.032" y="0" radius="0.359209375" width="0.254" layer="94"/>
<wire x1="1.651" y1="0" x2="-1.778" y2="1.016" width="0.254" layer="94"/>
<wire x1="-5.08" y1="-2.54" x2="-5.08" y2="2.54" width="0.254" layer="94"/>
<wire x1="-5.08" y1="2.54" x2="5.08" y2="2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="-2.54" x2="-5.08" y2="-2.54" width="0.254" layer="94"/>
<text x="-5.08" y="3.302" size="1.778" layer="95">&gt;NAME</text>
<text x="-5.08" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-7.62" y="0" visible="pad" length="middle" direction="pas"/>
<pin name="2" x="7.62" y="0" visible="pad" length="middle" direction="pas" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="EVQ-P7L01P" prefix="S">
<description>Switch Tactile N.O. SPST Rectangular Button Gull Wing 0.05A 12VDC 100000Cycle 1.6N SMD Embossed T/R &lt;a href="https://snapeda.com/parts/EVQ-P7L01P/Panasonic%20Electronic%20Components/view-part/?ref=eda"&gt;Buy Part&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="EVQ-P7L01P" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SW_EVQ-P7L01P">
<connects>
<connect gate="G$1" pin="1" pad="1_1 1_2"/>
<connect gate="G$1" pin="2" pad="2_1 2_2"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="Warning"/>
<attribute name="DESCRIPTION" value=" Tactile Switch SPST-NO Side Actuated Surface Mount, Right Angle "/>
<attribute name="MF" value="Panasonic Electronic Components"/>
<attribute name="MOUSER-PURCHASE-URL" value="https://snapeda.com/shop?store=Mouser&amp;id=3622449"/>
<attribute name="MP" value="EVQ-P7L01P"/>
<attribute name="PACKAGE" value="None"/>
<attribute name="PRICE" value="None"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Molex - 52271-0879">
<description>Upverter Parts Library

Created by Upverter.com</description>
<packages>
<package name="MOLEX_52271-0879_0">
<description>MOLX-52271-0879</description>
<wire x1="-6.5" y1="-0.175" x2="6.5" y2="-0.175" width="0.1" layer="51"/>
<wire x1="7.412" y1="-6.875" x2="7.5" y2="-6.787" width="0.1" layer="51"/>
<wire x1="7.412" y1="-5.775" x2="7.5" y2="-5.863" width="0.1" layer="51"/>
<wire x1="7.5" y1="-6.787" x2="7.5" y2="-5.863" width="0.1" layer="51"/>
<wire x1="6.05" y1="-5.775" x2="6.05" y2="-4.375" width="0.1" layer="51"/>
<wire x1="-6.5" y1="-4.375" x2="-6.05" y2="-4.375" width="0.1" layer="51"/>
<wire x1="6.05" y1="-4.375" x2="6.5" y2="-4.375" width="0.1" layer="51"/>
<wire x1="6.5" y1="-4.375" x2="6.5" y2="-0.175" width="0.1" layer="51"/>
<wire x1="-6.5" y1="-4.375" x2="-6.5" y2="-0.175" width="0.1" layer="51"/>
<wire x1="-7.5" y1="-6.787" x2="-7.412" y2="-6.875" width="0.1" layer="51"/>
<wire x1="-7.5" y1="-5.863" x2="-7.412" y2="-5.775" width="0.1" layer="51"/>
<wire x1="-7.412" y1="-5.775" x2="7.412" y2="-5.775" width="0.1" layer="51"/>
<wire x1="-7.5" y1="-6.787" x2="-7.5" y2="-5.863" width="0.1" layer="51"/>
<wire x1="-7.412" y1="-6.875" x2="7.412" y2="-6.875" width="0.1" layer="51"/>
<wire x1="-6.05" y1="-5.775" x2="-6.05" y2="-4.375" width="0.1" layer="51"/>
<wire x1="7.412" y1="-6.875" x2="7.5" y2="-6.787" width="0.15" layer="21"/>
<wire x1="7.412" y1="-5.775" x2="7.5" y2="-5.863" width="0.15" layer="21"/>
<wire x1="6.05" y1="-5.775" x2="6.05" y2="-4.375" width="0.15" layer="21"/>
<wire x1="6.5" y1="-4.375" x2="6.5" y2="-2.975" width="0.15" layer="21"/>
<wire x1="-5.2" y1="-0.175" x2="5.2" y2="-0.175" width="0.15" layer="21"/>
<wire x1="6.05" y1="-4.375" x2="6.5" y2="-4.375" width="0.15" layer="21"/>
<wire x1="7.5" y1="-6.787" x2="7.5" y2="-5.863" width="0.15" layer="21"/>
<wire x1="-7.412" y1="-6.875" x2="7.412" y2="-6.875" width="0.15" layer="21"/>
<wire x1="6.05" y1="-5.775" x2="7.412" y2="-5.775" width="0.15" layer="21"/>
<wire x1="-7.5" y1="-6.787" x2="-7.412" y2="-6.875" width="0.15" layer="21"/>
<wire x1="-7.5" y1="-5.863" x2="-7.412" y2="-5.775" width="0.15" layer="21"/>
<wire x1="-7.412" y1="-5.775" x2="-6.05" y2="-5.775" width="0.15" layer="21"/>
<wire x1="-7.5" y1="-6.787" x2="-7.5" y2="-5.863" width="0.15" layer="21"/>
<wire x1="-6.5" y1="-4.375" x2="-6.05" y2="-4.375" width="0.15" layer="21"/>
<wire x1="-6.05" y1="-5.775" x2="-6.05" y2="-4.375" width="0.15" layer="21"/>
<wire x1="-6.5" y1="-4.375" x2="-6.5" y2="-2.975" width="0.15" layer="21"/>
<wire x1="-7.8" y1="-6.975" x2="-7.8" y2="2.225" width="0.1" layer="39"/>
<wire x1="-7.8" y1="2.225" x2="7.8" y2="2.225" width="0.1" layer="39"/>
<wire x1="7.8" y1="2.225" x2="7.8" y2="-6.975" width="0.1" layer="39"/>
<wire x1="7.8" y1="-6.975" x2="-7.8" y2="-6.975" width="0.1" layer="39"/>
<text x="-8.8" y="2.8" size="1" layer="25">&gt;NAME</text>
<circle x="-3.5" y="2.675" radius="0.125" width="0.25" layer="21"/>
<rectangle x1="3.95" y1="-1.975" x2="5.6" y2="-0.375" layer="41"/>
<rectangle x1="-5.6" y1="-1.975" x2="-3.95" y2="-0.375" layer="41"/>
<smd name="8" x="3.5" y="1.175" dx="0.6" dy="1.9" layer="1"/>
<smd name="7" x="2.5" y="1.175" dx="0.6" dy="1.9" layer="1"/>
<smd name="6" x="1.5" y="1.175" dx="0.6" dy="1.9" layer="1"/>
<smd name="5" x="0.5" y="1.175" dx="0.6" dy="1.9" layer="1"/>
<smd name="MP2" x="6.65" y="-1.175" dx="2.1" dy="2.8" layer="1"/>
<smd name="MP1" x="-6.65" y="-1.175" dx="2.1" dy="2.8" layer="1"/>
<smd name="4" x="-0.5" y="1.175" dx="0.6" dy="1.9" layer="1"/>
<smd name="3" x="-1.5" y="1.175" dx="0.6" dy="1.9" layer="1"/>
<smd name="2" x="-2.5" y="1.175" dx="0.6" dy="1.9" layer="1"/>
<smd name="1" x="-3.5" y="1.175" dx="0.6" dy="1.9" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="MOLEX_52271-0879_0_0">
<description>MOLX-52271-0879</description>
<wire x1="0" y1="-10.16" x2="0" y2="-5.08" width="0.254" layer="94"/>
<wire x1="0" y1="-5.08" x2="30.48" y2="-5.08" width="0.254" layer="94"/>
<wire x1="30.48" y1="-5.08" x2="30.48" y2="-10.16" width="0.254" layer="94"/>
<wire x1="30.48" y1="-10.16" x2="0" y2="-10.16" width="0.254" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="10.16" y2="-8.382" width="0.254" layer="94"/>
<wire x1="7.62" y1="-10.16" x2="7.62" y2="-8.382" width="0.254" layer="94"/>
<wire x1="5.08" y1="-10.16" x2="5.08" y2="-8.382" width="0.254" layer="94"/>
<wire x1="2.54" y1="-10.16" x2="2.54" y2="-8.382" width="0.254" layer="94"/>
<wire x1="12.7" y1="-10.16" x2="12.7" y2="-8.382" width="0.254" layer="94"/>
<wire x1="15.24" y1="-10.16" x2="15.24" y2="-8.382" width="0.254" layer="94"/>
<wire x1="17.78" y1="-10.16" x2="17.78" y2="-8.382" width="0.254" layer="94"/>
<wire x1="20.32" y1="-10.16" x2="20.32" y2="-8.382" width="0.254" layer="94"/>
<wire x1="2.54" y1="-10.16" x2="2.54" y2="-10.16" width="0.15" layer="94"/>
<wire x1="5.08" y1="-10.16" x2="5.08" y2="-10.16" width="0.15" layer="94"/>
<wire x1="7.62" y1="-10.16" x2="7.62" y2="-10.16" width="0.15" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="10.16" y2="-10.16" width="0.15" layer="94"/>
<wire x1="25.4" y1="-10.16" x2="25.4" y2="-10.16" width="0.15" layer="94"/>
<wire x1="27.94" y1="-10.16" x2="27.94" y2="-10.16" width="0.15" layer="94"/>
<wire x1="12.7" y1="-10.16" x2="12.7" y2="-10.16" width="0.15" layer="94"/>
<wire x1="15.24" y1="-10.16" x2="15.24" y2="-10.16" width="0.15" layer="94"/>
<wire x1="17.78" y1="-10.16" x2="17.78" y2="-10.16" width="0.15" layer="94"/>
<wire x1="20.32" y1="-10.16" x2="20.32" y2="-10.16" width="0.15" layer="94"/>
<text x="0" y="-2.54" size="2.54" layer="95" align="top-left">&gt;NAME</text>
<text x="0" y="-15.24" size="2.54" layer="95" align="top-left">52271-0879</text>
<pin name="1" x="2.54" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="2" x="5.08" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="3" x="7.62" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="4" x="10.16" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="MP1" x="25.4" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="MP2" x="27.94" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="5" x="12.7" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="6" x="15.24" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="7" x="17.78" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<pin name="8" x="20.32" y="-15.24" visible="pad" length="middle" direction="pas" rot="R90"/>
<circle x="10.16" y="-7.62" radius="0.762" width="0.254" layer="94"/>
<circle x="7.62" y="-7.62" radius="0.762" width="0.254" layer="94"/>
<circle x="5.08" y="-7.62" radius="0.762" width="0.254" layer="94"/>
<circle x="2.54" y="-7.62" radius="0.762" width="0.254" layer="94"/>
<circle x="12.7" y="-7.62" radius="0.762" width="0.254" layer="94"/>
<circle x="15.24" y="-7.62" radius="0.762" width="0.254" layer="94"/>
<circle x="17.78" y="-7.62" radius="0.762" width="0.254" layer="94"/>
<circle x="20.32" y="-7.62" radius="0.762" width="0.254" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="MOLEX_52271-0879" prefix="J">
<description>MOLX-52271-0879</description>
<gates>
<gate name="G$0" symbol="MOLEX_52271-0879_0_0" x="0" y="0"/>
</gates>
<devices>
<device name="MOLEX_52271-0879_0_0" package="MOLEX_52271-0879_0">
<connects>
<connect gate="G$0" pin="1" pad="1"/>
<connect gate="G$0" pin="2" pad="2"/>
<connect gate="G$0" pin="3" pad="3"/>
<connect gate="G$0" pin="4" pad="4"/>
<connect gate="G$0" pin="5" pad="5"/>
<connect gate="G$0" pin="6" pad="6"/>
<connect gate="G$0" pin="7" pad="7"/>
<connect gate="G$0" pin="8" pad="8"/>
<connect gate="G$0" pin="MP1" pad="MP1"/>
<connect gate="G$0" pin="MP2" pad="MP2"/>
</connects>
<technologies>
<technology name="">
<attribute name="CIIVA_IDS" value="605436"/>
<attribute name="CIRCUITS_LOADED" value="8"/>
<attribute name="COMPONENT_LINK_1_DESCRIPTION" value="Manufacturer URL"/>
<attribute name="COMPONENT_LINK_1_URL" value="http://www.molex.com/molex/index.jsp"/>
<attribute name="COMPONENT_LINK_3_DESCRIPTION" value="Package Specification"/>
<attribute name="COMPONENT_LINK_3_URL" value="http://www.molex.com/pdm_docs/sd/522710879_sd.pdf"/>
<attribute name="CONTACT_POSITION" value="Bottom"/>
<attribute name="CURRENT_MAX_PER_CONTACT" value="0.5A"/>
<attribute name="DATASHEET" value="http://www.molex.com/webdocs/datasheets/pdf/en-us/0522710879_FFC_FPC_CONNECTORS.pdf"/>
<attribute name="DURABILITY_MATING_CYCLES_MAX" value="30"/>
<attribute name="ENTRY_ANGLE" value="90degrees Angle"/>
<attribute name="FOOTPRINT_VARIANT_NAME_0" value="Manufacturer Recommended"/>
<attribute name="IMPORTED" value="yes"/>
<attribute name="IMPORTED_FROM" value="vault"/>
<attribute name="IMPORT_TS" value="1521845783"/>
<attribute name="MATED_HEIGHT" value="3.00mm"/>
<attribute name="MATERIAL___METAL" value="Phosphor Bronze"/>
<attribute name="MATERIAL___PLATING_MATING" value="Tin-Bismuth"/>
<attribute name="MATERIAL___PLATING_TERMINATION" value="Tin-Bismuth"/>
<attribute name="MF" value="Molex"/>
<attribute name="MOUNTING_TECHNOLOGY" value="Surface Mount"/>
<attribute name="MPN" value="52271-0879"/>
<attribute name="NUMBER_OF_ROWS" value="1"/>
<attribute name="ORIENTATION" value="Right Angle"/>
<attribute name="PACKAGE" value="52271-0879"/>
<attribute name="PACKAGE_DESCRIPTION" value="8-Lead FPC Connector, Pitch 1.0 mm"/>
<attribute name="PACKAGE_VERSION" value="Rev. B, 04/2004"/>
<attribute name="PACKING" value="Tape and Reel"/>
<attribute name="PCB_LOCATOR" value="No"/>
<attribute name="PCB_RETENTION" value="Yes"/>
<attribute name="PITCH___MATING_INTERFACE" value="1.00mm"/>
<attribute name="PITCH___TERMINATION_INTERFACE" value="1.00mm"/>
<attribute name="POLARIZED_TO_PCB" value="Yes"/>
<attribute name="PREFIX" value="J"/>
<attribute name="RELEASE_DATE" value="1411372468"/>
<attribute name="ROHS" value="Yes"/>
<attribute name="STACKABLE" value="No"/>
<attribute name="VAULT_GUID" value="6E0E35AC-EB58-4C9C-8B40-B34D68BAFD49"/>
<attribute name="VAULT_REVISION" value="B8D0B5D1-BD2E-4A74-BF2B-C0B6D1E0611E"/>
<attribute name="VOLTAGE_MAX" value="50V AC (RMS)/DC"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-connectors">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="MICROSIM8">
<smd name="VCC" x="5.03" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
<smd name="GND" x="3.93" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
<smd name="SW" x="2.83" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
<smd name="RST" x="1.73" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
<smd name="VPP" x="0.63" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
<smd name="CLK" x="-0.47" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
<smd name="IO" x="-1.57" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
<smd name="NC1" x="-2.67" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
<smd name="SH1" x="-5.64" y="6.995" dx="1.7" dy="0.5" layer="1"/>
<smd name="SH2" x="-6.175" y="2.865" dx="1.35" dy="2" layer="1"/>
<smd name="SH3" x="6.175" y="2.865" dx="1.35" dy="2" layer="1"/>
<smd name="SH4" x="-6.175" y="-4.755" dx="1.35" dy="2" layer="1"/>
<smd name="SH5" x="6.175" y="-4.755" dx="1.35" dy="2" layer="1"/>
<wire x1="-4.5" y1="7.7" x2="-4.5" y2="6.8" width="0.025" layer="51"/>
<wire x1="-4.5" y1="6.8" x2="-4.5" y2="6.5" width="0.025" layer="51"/>
<wire x1="-4.5" y1="6.5" x2="-4" y2="6" width="0.025" layer="51" curve="90"/>
<wire x1="-4" y1="6" x2="5.3" y2="6" width="0.025" layer="51"/>
<wire x1="5.3" y1="6" x2="5.8" y2="6.5" width="0.025" layer="51" curve="90"/>
<wire x1="5.8" y1="6.5" x2="5.8" y2="7.7" width="0.025" layer="51"/>
<wire x1="5.8" y1="7.7" x2="7" y2="7.7" width="0.025" layer="51"/>
<wire x1="7" y1="7.7" x2="7" y2="-6.5" width="0.025" layer="51"/>
<wire x1="7" y1="-6.5" x2="6.57" y2="-6.5" width="0.025" layer="51"/>
<wire x1="6.57" y1="-6.5" x2="6.57" y2="-6.2" width="0.025" layer="51"/>
<wire x1="6.57" y1="-6.2" x2="6.47" y2="-5.9" width="0.025" layer="51" curve="36.869898"/>
<wire x1="6.47" y1="-5.9" x2="6.07" y2="-5.7" width="0.025" layer="51" curve="53.130102"/>
<wire x1="6.07" y1="-5.7" x2="3.9" y2="-5.7" width="0.025" layer="51"/>
<wire x1="3.9" y1="-5.7" x2="3.2" y2="-5" width="0.025" layer="51" curve="-90"/>
<wire x1="3.2" y1="-5" x2="2.6" y2="-4.5" width="0.025" layer="51" curve="90"/>
<wire x1="-7" y1="7.7" x2="-7" y2="-6.4" width="0.025" layer="51"/>
<wire x1="-7" y1="-6.4" x2="-6.6" y2="-6.4" width="0.025" layer="51"/>
<wire x1="-6.6" y1="-6.4" x2="-6.6" y2="-6.1" width="0.025" layer="51"/>
<wire x1="-6.6" y1="-6.1" x2="-6.5" y2="-5.8" width="0.025" layer="51" curve="-36.869898"/>
<wire x1="-6.5" y1="-5.8" x2="-6.1" y2="-5.6" width="0.025" layer="51" curve="-53.130102"/>
<wire x1="-6.1" y1="-5.6" x2="-5.2" y2="-5.6" width="0.025" layer="51"/>
<wire x1="-5.2" y1="-5.6" x2="-4.5" y2="-4.9" width="0.025" layer="51" curve="90"/>
<wire x1="-4.5" y1="-4.9" x2="-4.1" y2="-4.5" width="0.025" layer="51" curve="-90"/>
<wire x1="-4.1" y1="-4.5" x2="2.6" y2="-4.5" width="0.025" layer="51"/>
<wire x1="-7" y1="7.7" x2="-4.5" y2="7.7" width="0.025" layer="51"/>
<wire x1="-4.5" y1="6.8" x2="-3.8" y2="7.7" width="0.025" layer="51"/>
<wire x1="-3.8" y1="7.7" x2="5.8" y2="7.7" width="0.025" layer="51"/>
<wire x1="2.2" y1="0.8" x2="2.9" y2="1.5" width="0.025" layer="51"/>
<wire x1="2.9" y1="1.5" x2="4.3" y2="1.5" width="0.025" layer="51"/>
<wire x1="4.3" y1="1.5" x2="4.3" y2="-0.6" width="0.025" layer="51"/>
<wire x1="4.3" y1="-0.6" x2="2.2" y2="-0.6" width="0.025" layer="51"/>
<wire x1="2.2" y1="-0.6" x2="2.2" y2="0.8" width="0.025" layer="51"/>
<wire x1="2.9" y1="0" x2="3.5" y2="0" width="0.025" layer="51"/>
<wire x1="3.5" y1="0" x2="3.2" y2="0.9" width="0.025" layer="51"/>
<wire x1="3.2" y1="0.9" x2="2.9" y2="0" width="0.025" layer="51"/>
<wire x1="-6.5" y1="-5.8" x2="-6.5" y2="-6.8" width="0.025" layer="51"/>
<wire x1="-6.5" y1="-6.8" x2="-6" y2="-7.3" width="0.025" layer="51" curve="90"/>
<wire x1="-6" y1="-7.3" x2="5.97" y2="-7.3" width="0.025" layer="51"/>
<wire x1="5.97" y1="-7.3" x2="6.47" y2="-6.8" width="0.025" layer="51" curve="90"/>
<wire x1="6.47" y1="-6.8" x2="6.47" y2="-5.9" width="0.025" layer="51"/>
<text x="0" y="2.54" size="1.016" layer="25" font="vector" align="center">&gt;NAME</text>
<smd name="NC2" x="-3.94" y="6.77" dx="0.95" dy="0.67" layer="1" rot="R90"/>
</package>
</packages>
<symbols>
<symbol name="SIM8">
<wire x1="-10.16" y1="7.62" x2="-10.16" y2="-12.7" width="0.4064" layer="94"/>
<wire x1="-10.16" y1="-12.7" x2="10.16" y2="-12.7" width="0.4064" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="10.16" y2="12.7" width="0.4064" layer="94"/>
<wire x1="10.16" y1="12.7" x2="-5.08" y2="12.7" width="0.4064" layer="94"/>
<wire x1="-5.08" y1="12.7" x2="-10.16" y2="7.62" width="0.4064" layer="94"/>
<pin name="I/O" x="-7.62" y="-17.78" length="middle" rot="R90"/>
<pin name="VPP" x="-5.08" y="-17.78" length="middle" rot="R90"/>
<pin name="GND" x="-2.54" y="-17.78" length="middle" rot="R90"/>
<pin name="CLK" x="0" y="-17.78" length="middle" rot="R90"/>
<pin name="RST" x="2.54" y="-17.78" length="middle" rot="R90"/>
<pin name="VCC" x="5.08" y="-17.78" length="middle" rot="R90"/>
<pin name="SW" x="7.62" y="-17.78" length="middle" rot="R90"/>
<text x="-2.54" y="0" size="1.778" layer="95" font="vector">&gt;NAME</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="SIM" prefix="SIM">
<description>SIM connector</description>
<gates>
<gate name="G$1" symbol="SIM8" x="0" y="0"/>
</gates>
<devices>
<device name="" package="MICROSIM8">
<connects>
<connect gate="G$1" pin="CLK" pad="CLK"/>
<connect gate="G$1" pin="GND" pad="GND SH1 SH2 SH3 SH4 SH5"/>
<connect gate="G$1" pin="I/O" pad="IO"/>
<connect gate="G$1" pin="RST" pad="RST"/>
<connect gate="G$1" pin="SW" pad="SW"/>
<connect gate="G$1" pin="VCC" pad="VCC"/>
<connect gate="G$1" pin="VPP" pad="VPP"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="-" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.te.com/commerce/DocumentDelivery/DDEController?Action=srchrtrv&amp;DocNm=2199337&amp;DocType=Customer+Drawing&amp;DocLang=English" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/te-connectivity-amp-connectors/2199337-5/A125065CT-ND/6810766" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="A125065CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="TE" constant="no"/>
<attribute name="MANUFACTURER-PN" value="2199337-5" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="led" urn="urn:adsk.eagle:library:259">
<description>&lt;b&gt;LEDs&lt;/b&gt;&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;&lt;br&gt;
Extended by Federico Battaglin &lt;author&gt;&amp;lt;federico.rd@fdpinternational.com&amp;gt;&lt;/author&gt; with DUOLED</description>
<packages>
<package name="LUXEON_REBEL" urn="urn:adsk.eagle:footprint:15729/1" library_version="5">
<description>&lt;b&gt;LUXEON® Rebel LED&lt;/b&gt;&lt;p&gt;

Set DRC - Clearance - &lt;b&gt;Same Signals&lt;/b&gt; to &lt;b&gt;0&lt;/b&gt; to avoid DRC error message for Pad in SMD.&lt;br&gt;
Please read the Device's Description how to connect it correctly in the Schematic.&lt;p&gt;
Source: http://www.lumileds.com/pdfs/AB32.pdf</description>
<wire x1="1.435" y1="-2.845" x2="-1.435" y2="-2.845" width="0.2032" layer="51"/>
<wire x1="-1.435" y1="-2.845" x2="-1.435" y2="1.405" width="0.2032" layer="51"/>
<wire x1="-1.435" y1="1.405" x2="1.435" y2="1.405" width="0.2032" layer="51"/>
<wire x1="1.435" y1="1.405" x2="1.435" y2="-2.845" width="0.2032" layer="51"/>
<wire x1="-1.095" y1="-0.475" x2="1.075" y2="-0.475" width="0.1016" layer="21" curve="132.288823"/>
<wire x1="-1.435" y1="-2.083" x2="-1.435" y2="-0.627" width="0.2032" layer="21"/>
<wire x1="1.435" y1="-0.627" x2="1.435" y2="-2.083" width="0.2032" layer="21"/>
<wire x1="0.038" y1="-2.845" x2="-0.018" y2="-2.845" width="0.2032" layer="21"/>
<circle x="0.01" y="-0.06" radius="0.22" width="0" layer="29"/>
<circle x="0.01" y="1.2" radius="0.22" width="0" layer="29"/>
<circle x="0" y="0" radius="1.175" width="0.1016" layer="51"/>
<circle x="0" y="-2.248" radius="0.05" width="0" layer="21"/>
<circle x="1.25" y="1.25" radius="0.05" width="0" layer="51"/>
<pad name="TH@3" x="0.01" y="-0.06" drill="0.25" diameter="0.35" rot="R180" stop="no"/>
<pad name="TH@4" x="0.01" y="1.2" drill="0.35" diameter="0.5" rot="R180" stop="no"/>
<smd name="A" x="0.87" y="-2.51" dx="1.26" dy="0.73" layer="1" roundness="25" rot="R180" stop="no" cream="no"/>
<smd name="C" x="-0.87" y="-2.51" dx="1.26" dy="0.73" layer="1" roundness="25" rot="R180" stop="no" cream="no"/>
<smd name="TH" x="0.01" y="0.49" dx="2.86" dy="1.83" layer="1" rot="R180" stop="no" cream="no"/>
<smd name="C@1" x="-1.39" y="-2.79" dx="1.1" dy="0.57" layer="1" roundness="50" rot="R225" stop="no" cream="no"/>
<smd name="A@1" x="1.39" y="-2.78" dx="1.1" dy="0.57" layer="1" roundness="50" rot="R315" stop="no" cream="no"/>
<smd name="TH@2" x="1.39" y="1.38" dx="1.1" dy="0.57" layer="1" roundness="50" rot="R45" stop="no" cream="no"/>
<smd name="TH@1" x="-1.39" y="1.37" dx="1.1" dy="0.57" layer="1" roundness="50" rot="R135" stop="no" cream="no"/>
<text x="-1.397" y="2.032" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.651" y="-4.953" size="1.27" layer="27">&gt;VALUE</text>
<polygon width="0.1016" layer="29">
<vertex x="0.37" y="-2.74"/>
<vertex x="0.37" y="-2.28"/>
<vertex x="1.37" y="-2.28"/>
<vertex x="1.37" y="-2.43"/>
<vertex x="1.85" y="-2.91" curve="-73.739795"/>
<vertex x="1.52" y="-3.24"/>
<vertex x="1.02" y="-2.74"/>
</polygon>
<polygon width="0.1016" layer="29">
<vertex x="-0.37" y="-2.28"/>
<vertex x="-0.37" y="-2.74"/>
<vertex x="-1.01" y="-2.74"/>
<vertex x="-1.51" y="-3.24" curve="-79.982598"/>
<vertex x="-1.84" y="-2.91"/>
<vertex x="-1.37" y="-2.44"/>
<vertex x="-1.37" y="-2.28"/>
</polygon>
<polygon width="0.1016" layer="29">
<vertex x="-0.52" y="1.33"/>
<vertex x="-0.52" y="1.2" curve="90"/>
<vertex x="0.01" y="0.67"/>
<vertex x="0.01" y="0.47" curve="90"/>
<vertex x="-0.52" y="-0.06"/>
<vertex x="-0.52" y="-0.23"/>
<vertex x="-1.37" y="-0.23"/>
<vertex x="-1.37" y="1.02"/>
<vertex x="-1.85" y="1.5" curve="-73.739795"/>
<vertex x="-1.52" y="1.83"/>
<vertex x="-1.02" y="1.33"/>
</polygon>
<polygon width="0.1016" layer="29">
<vertex x="0.54" y="-0.23"/>
<vertex x="0.54" y="-0.06" curve="90"/>
<vertex x="0.01" y="0.47"/>
<vertex x="0.01" y="0.67" curve="90"/>
<vertex x="0.54" y="1.2"/>
<vertex x="0.54" y="1.33"/>
<vertex x="1.01" y="1.33"/>
<vertex x="1.51" y="1.83" curve="-79.982598"/>
<vertex x="1.84" y="1.5"/>
<vertex x="1.37" y="1.03"/>
<vertex x="1.37" y="-0.23"/>
</polygon>
<polygon width="0.0508" layer="31">
<vertex x="-0.52" y="1.33"/>
<vertex x="-0.52" y="1.2" curve="90"/>
<vertex x="0.01" y="0.67"/>
<vertex x="0.01" y="0.47" curve="90"/>
<vertex x="-0.52" y="-0.06"/>
<vertex x="-0.52" y="-0.23"/>
<vertex x="-1.37" y="-0.23"/>
<vertex x="-1.37" y="1.02"/>
<vertex x="-1.85" y="1.5" curve="-73.739795"/>
<vertex x="-1.52" y="1.83"/>
<vertex x="-1.02" y="1.33"/>
</polygon>
<polygon width="0.0508" layer="31">
<vertex x="0.54" y="-0.23"/>
<vertex x="0.54" y="-0.06" curve="90"/>
<vertex x="0.01" y="0.47"/>
<vertex x="0.01" y="0.67" curve="90"/>
<vertex x="0.54" y="1.2"/>
<vertex x="0.54" y="1.33"/>
<vertex x="1.01" y="1.33"/>
<vertex x="1.51" y="1.83" curve="-79.982598"/>
<vertex x="1.84" y="1.5"/>
<vertex x="1.37" y="1.03"/>
<vertex x="1.37" y="-0.23"/>
</polygon>
<polygon width="0.0508" layer="31">
<vertex x="0.37" y="-2.74"/>
<vertex x="0.37" y="-2.28"/>
<vertex x="1.37" y="-2.28"/>
<vertex x="1.37" y="-2.43"/>
<vertex x="1.85" y="-2.91" curve="-73.739795"/>
<vertex x="1.52" y="-3.24"/>
<vertex x="1.02" y="-2.74"/>
</polygon>
<polygon width="0.0508" layer="31">
<vertex x="-0.37" y="-2.28"/>
<vertex x="-0.37" y="-2.74"/>
<vertex x="-1.01" y="-2.74"/>
<vertex x="-1.51" y="-3.24" curve="-79.982598"/>
<vertex x="-1.84" y="-2.91"/>
<vertex x="-1.37" y="-2.44"/>
<vertex x="-1.37" y="-2.28"/>
</polygon>
</package>
</packages>
<packages3d>
<package3d name="LUXEON_REBEL" urn="urn:adsk.eagle:package:15855/1" type="box" library_version="5">
<description>LUXEON® Rebel LED

Set DRC - Clearance - Same Signals to 0 to avoid DRC error message for Pad in SMD.
Please read the Device's Description how to connect it correctly in the Schematic.
Source: http://www.lumileds.com/pdfs/AB32.pdf</description>
<packageinstances>
<packageinstance name="LUXEON_REBEL"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="LED" urn="urn:adsk.eagle:symbol:15639/2" library_version="5">
<wire x1="1.27" y1="0" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-2.032" y1="-0.762" x2="-3.429" y2="-2.159" width="0.1524" layer="94"/>
<wire x1="-1.905" y1="-1.905" x2="-3.302" y2="-3.302" width="0.1524" layer="94"/>
<text x="3.556" y="-4.572" size="1.778" layer="95" rot="R90">&gt;NAME</text>
<text x="5.715" y="-4.572" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="C" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="A" x="0" y="2.54" visible="off" length="short" direction="pas" rot="R270"/>
<polygon width="0.1524" layer="94">
<vertex x="-3.429" y="-2.159"/>
<vertex x="-3.048" y="-1.27"/>
<vertex x="-2.54" y="-1.778"/>
</polygon>
<polygon width="0.1524" layer="94">
<vertex x="-3.302" y="-3.302"/>
<vertex x="-2.921" y="-2.413"/>
<vertex x="-2.413" y="-2.921"/>
</polygon>
</symbol>
<symbol name="THERMAL" urn="urn:adsk.eagle:symbol:15715/1" library_version="5">
<circle x="0" y="-1.524" radius="1.397" width="0.254" layer="94"/>
<text x="-2.54" y="-5.08" size="1.778" layer="95">&gt;NAME</text>
<text x="-0.889" y="-2.032" size="1.016" layer="95">TH</text>
<pin name="TH" x="0" y="2.54" visible="off" length="short" direction="pas" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="LUXEON_REBEL" urn="urn:adsk.eagle:component:15951/3" prefix="LED" library_version="5">
<description>&lt;b&gt;LUXEON Rebel&lt;/b&gt;&lt;p&gt;

Display layer 93, Pins, and connect all contact points with a net.&lt;br&gt;
The thermal pads are defined in a separate gate with addlevel REQUEST.&lt;br&gt;
Draw a net named 'TH' and connect all thermal pads with it.&lt;br&gt;
Please read the Package's Description about DRC settings.&lt;p&gt;
Source: http://www.lumileds.com/pdfs/AB32.pdf</description>
<gates>
<gate name="G$1" symbol="LED" x="0" y="0"/>
<gate name="TH" symbol="THERMAL" x="10.16" y="-2.54" addlevel="request"/>
</gates>
<devices>
<device name="" package="LUXEON_REBEL">
<connects>
<connect gate="G$1" pin="A" pad="A A@1"/>
<connect gate="G$1" pin="C" pad="C C@1"/>
<connect gate="TH" pin="TH" pad="TH TH@1 TH@2 TH@3 TH@4"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:15855/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="con-garry" urn="urn:adsk.eagle:library:147">
<description>&lt;b&gt;Pin Header Connectors&lt;/b&gt;&lt;p&gt;
&lt;a href="www.mpe-connector.de"&gt;Menufacturer&lt;/a&gt;&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
<package name="332-06" urn="urn:adsk.eagle:footprint:6787/1" library_version="2">
<description>&lt;b&gt;6 Pin - 2mm Dual Row&lt;/b&gt;&lt;p&gt;
Source: www.mpe-connector.de / garry_shortform_2012.pdf</description>
<wire x1="-2.85" y1="-1.9" x2="2.85" y2="-1.9" width="0.2032" layer="21"/>
<wire x1="2.85" y1="-1.9" x2="2.85" y2="-0.4" width="0.2032" layer="21"/>
<wire x1="2.85" y1="0.4" x2="2.85" y2="1.9" width="0.2032" layer="21"/>
<wire x1="2.85" y1="1.9" x2="-2.85" y2="1.9" width="0.2032" layer="21"/>
<wire x1="-2.85" y1="1.9" x2="-2.85" y2="0.4" width="0.2032" layer="21"/>
<wire x1="-2.85" y1="-0.4" x2="-2.85" y2="-1.9" width="0.2032" layer="21"/>
<wire x1="-2.85" y1="0.4" x2="-2.85" y2="-0.4" width="0.2032" layer="21" curve="-129.185"/>
<wire x1="2.85" y1="-0.4" x2="2.85" y2="0.4" width="0.2032" layer="21" curve="-129.185"/>
<wire x1="-2" y1="1" x2="-2" y2="-6" width="0.55" layer="51"/>
<wire x1="0" y1="1" x2="0" y2="-6" width="0.55" layer="51"/>
<wire x1="2" y1="1" x2="2" y2="-6" width="0.55" layer="51"/>
<pad name="1" x="-2" y="-1" drill="0.9" diameter="1.27"/>
<pad name="2" x="-2" y="1" drill="0.9" diameter="1.27"/>
<pad name="3" x="0" y="-1" drill="0.9" diameter="1.27"/>
<pad name="4" x="0" y="1" drill="0.9" diameter="1.27"/>
<pad name="5" x="2" y="-1" drill="0.9" diameter="1.27"/>
<pad name="6" x="2" y="1" drill="0.9" diameter="1.27"/>
<text x="-2.65" y="-1.75" size="0.3048" layer="21" font="vector">1</text>
<text x="-2.62" y="2.19" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.62" y="3.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.25" y1="-1.25" x2="-1.75" y2="-0.75" layer="51"/>
<rectangle x1="-2.25" y1="0.75" x2="-1.75" y2="1.25" layer="51"/>
<rectangle x1="-0.25" y1="-1.25" x2="0.25" y2="-0.75" layer="51"/>
<rectangle x1="-0.25" y1="0.75" x2="0.25" y2="1.25" layer="51"/>
<rectangle x1="1.75" y1="-1.25" x2="2.25" y2="-0.75" layer="51"/>
<rectangle x1="1.75" y1="0.75" x2="2.25" y2="1.25" layer="51"/>
</package>
</packages>
<packages3d>
<package3d name="332-06" urn="urn:adsk.eagle:package:6811/1" type="box" library_version="2">
<description>6 Pin - 2mm Dual Row
Source: www.mpe-connector.de / garry_shortform_2012.pdf</description>
<packageinstances>
<packageinstance name="332-06"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="MV" urn="urn:adsk.eagle:symbol:6783/1" library_version="2">
<wire x1="1.27" y1="0" x2="0" y2="0" width="0.6096" layer="94"/>
<text x="2.54" y="-0.762" size="1.524" layer="95">&gt;NAME</text>
<text x="-0.762" y="1.397" size="1.778" layer="96">&gt;VALUE</text>
<pin name="S" x="-2.54" y="0" visible="off" length="short" direction="pas"/>
</symbol>
<symbol name="M" urn="urn:adsk.eagle:symbol:6785/1" library_version="2">
<wire x1="1.27" y1="0" x2="0" y2="0" width="0.6096" layer="94"/>
<text x="2.54" y="-0.762" size="1.524" layer="95">&gt;NAME</text>
<pin name="S" x="-2.54" y="0" visible="off" length="short" direction="pas"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="332-06" urn="urn:adsk.eagle:component:6841/2" prefix="X" library_version="2">
<description>&lt;b&gt;6 Pin - 2mm Dual Row&lt;/b&gt;&lt;p&gt;
Source: www.mpe-connector.de / garry_shortform_2012.pdf</description>
<gates>
<gate name="-1" symbol="MV" x="-10.16" y="2.54" addlevel="always"/>
<gate name="-2" symbol="MV" x="10.16" y="2.54" addlevel="always"/>
<gate name="-3" symbol="M" x="-10.16" y="0" addlevel="always"/>
<gate name="-4" symbol="M" x="10.16" y="0" addlevel="always"/>
<gate name="-5" symbol="M" x="-10.16" y="-2.54" addlevel="always"/>
<gate name="-6" symbol="M" x="10.16" y="-2.54" addlevel="always"/>
</gates>
<devices>
<device name="" package="332-06">
<connects>
<connect gate="-1" pin="S" pad="1"/>
<connect gate="-2" pin="S" pad="2"/>
<connect gate="-3" pin="S" pad="3"/>
<connect gate="-4" pin="S" pad="4"/>
<connect gate="-5" pin="S" pad="5"/>
<connect gate="-6" pin="S" pad="6"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:6811/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="0" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SN74AVC4T774PW">
<packages>
<package name="SOP65P640X120-16N">
<circle x="-4.19" y="2.275" radius="0.1" width="0.2" layer="21"/>
<circle x="-4.19" y="2.275" radius="0.1" width="0.2" layer="51"/>
<wire x1="-2.2" y1="2.5" x2="2.2" y2="2.5" width="0.127" layer="51"/>
<wire x1="-2.2" y1="-2.5" x2="2.2" y2="-2.5" width="0.127" layer="51"/>
<wire x1="-1.765" y1="2.5" x2="1.765" y2="2.5" width="0.127" layer="21"/>
<wire x1="-2.2" y1="2.5" x2="-2.2" y2="-2.5" width="0.127" layer="51"/>
<wire x1="2.2" y1="2.5" x2="2.2" y2="-2.5" width="0.127" layer="51"/>
<wire x1="-3.905" y1="2.75" x2="3.905" y2="2.75" width="0.05" layer="39"/>
<wire x1="-3.905" y1="-2.75" x2="3.905" y2="-2.75" width="0.05" layer="39"/>
<wire x1="-3.905" y1="2.75" x2="-3.905" y2="-2.75" width="0.05" layer="39"/>
<wire x1="3.905" y1="2.75" x2="3.905" y2="-2.75" width="0.05" layer="39"/>
<text x="-3.5" y="-3" size="1.27" layer="27" align="top-left">&gt;VALUE</text>
<text x="-3.5" y="3" size="1.27" layer="25">&gt;NAME</text>
<wire x1="1.765" y1="-2.5" x2="-1.765" y2="-2.5" width="0.127" layer="21"/>
<smd name="1" x="-2.87" y="2.275" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="2" x="-2.87" y="1.625" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="3" x="-2.87" y="0.975" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="4" x="-2.87" y="0.325" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="5" x="-2.87" y="-0.325" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="6" x="-2.87" y="-0.975" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="7" x="-2.87" y="-1.625" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="8" x="-2.87" y="-2.275" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="9" x="2.87" y="-2.275" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="10" x="2.87" y="-1.625" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="11" x="2.87" y="-0.975" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="12" x="2.87" y="-0.325" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="13" x="2.87" y="0.325" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="14" x="2.87" y="0.975" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="15" x="2.87" y="1.625" dx="1.57" dy="0.41" layer="1" roundness="25"/>
<smd name="16" x="2.87" y="2.275" dx="1.57" dy="0.41" layer="1" roundness="25"/>
</package>
</packages>
<symbols>
<symbol name="SN74AVC4T774PW">
<wire x1="-12.7" y1="22.86" x2="12.7" y2="22.86" width="0.41" layer="94"/>
<wire x1="12.7" y1="22.86" x2="12.7" y2="-22.86" width="0.41" layer="94"/>
<wire x1="12.7" y1="-22.86" x2="-12.7" y2="-22.86" width="0.41" layer="94"/>
<wire x1="-12.7" y1="-22.86" x2="-12.7" y2="22.86" width="0.41" layer="94"/>
<text x="-12.7" y="23.86" size="2.0828" layer="95" ratio="10" rot="SR0">&gt;NAME</text>
<text x="-12.7" y="-26.86" size="2.0828" layer="96" ratio="10" rot="SR0">&gt;VALUE</text>
<pin name="!OE" x="-17.78" y="12.7" length="middle" direction="in"/>
<pin name="DIR1" x="-17.78" y="10.16" length="middle" direction="in"/>
<pin name="DIR2" x="-17.78" y="7.62" length="middle" direction="in"/>
<pin name="DIR3" x="-17.78" y="5.08" length="middle" direction="in"/>
<pin name="DIR4" x="-17.78" y="2.54" length="middle" direction="in"/>
<pin name="A1" x="-17.78" y="-2.54" length="middle"/>
<pin name="A2" x="-17.78" y="-5.08" length="middle"/>
<pin name="B1" x="-17.78" y="-10.16" length="middle"/>
<pin name="B2" x="-17.78" y="-12.7" length="middle"/>
<pin name="VCCA" x="17.78" y="20.32" length="middle" direction="pwr" rot="R180"/>
<pin name="VCCB" x="17.78" y="17.78" length="middle" direction="pwr" rot="R180"/>
<pin name="A3" x="17.78" y="-2.54" length="middle" rot="R180"/>
<pin name="A4" x="17.78" y="-5.08" length="middle" rot="R180"/>
<pin name="B3" x="17.78" y="-10.16" length="middle" rot="R180"/>
<pin name="B4" x="17.78" y="-12.7" length="middle" rot="R180"/>
<pin name="GND" x="17.78" y="-17.78" length="middle" direction="pwr" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="SN74AVC4T774PW" prefix="U">
<description> &lt;a href="https://pricing.snapeda.com/search/part/SN74AVC4T774PW/?ref=eda"&gt;Check prices&lt;/a&gt;</description>
<gates>
<gate name="A" symbol="SN74AVC4T774PW" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOP65P640X120-16N">
<connects>
<connect gate="A" pin="!OE" pad="9"/>
<connect gate="A" pin="A1" pad="3"/>
<connect gate="A" pin="A2" pad="4"/>
<connect gate="A" pin="A3" pad="5"/>
<connect gate="A" pin="A4" pad="6"/>
<connect gate="A" pin="B1" pad="14"/>
<connect gate="A" pin="B2" pad="13"/>
<connect gate="A" pin="B3" pad="12"/>
<connect gate="A" pin="B4" pad="11"/>
<connect gate="A" pin="DIR1" pad="1"/>
<connect gate="A" pin="DIR2" pad="2"/>
<connect gate="A" pin="DIR3" pad="7"/>
<connect gate="A" pin="DIR4" pad="8"/>
<connect gate="A" pin="GND" pad="10"/>
<connect gate="A" pin="VCCA" pad="16"/>
<connect gate="A" pin="VCCB" pad="15"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="Good"/>
<attribute name="DESCRIPTION" value=" 4-bit dual-supply bus transceiver with configurable voltage-level shifting and 3-state outputs 16-TSSOP -40 to 85 "/>
<attribute name="MF" value="Texas Instruments"/>
<attribute name="MP" value="SN74AVC4T774PW"/>
<attribute name="PACKAGE" value="TSSOP-16 Texas Instruments"/>
<attribute name="PRICE" value="None"/>
<attribute name="PURCHASE-URL" value="https://pricing.snapeda.com/search/part/SN74AVC4T774PW/?ref=eda"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Capacitor" urn="urn:adsk.eagle:library:16290819">
<description>&lt;B&gt;Capacitors - Fixed, Variable, Trimmers</description>
<packages>
<package name="CAPC1005X60" urn="urn:adsk.eagle:footprint:16290849/2" library_version="4">
<description>Chip, 1.00 X 0.50 X 0.60 mm body
&lt;p&gt;Chip package with body size 1.00 X 0.50 X 0.60 mm&lt;/p&gt;</description>
<wire x1="0.55" y1="0.6286" x2="-0.55" y2="0.6286" width="0.127" layer="21"/>
<wire x1="0.55" y1="-0.6286" x2="-0.55" y2="-0.6286" width="0.127" layer="21"/>
<wire x1="0.55" y1="-0.3" x2="-0.55" y2="-0.3" width="0.12" layer="51"/>
<wire x1="-0.55" y1="-0.3" x2="-0.55" y2="0.3" width="0.12" layer="51"/>
<wire x1="-0.55" y1="0.3" x2="0.55" y2="0.3" width="0.12" layer="51"/>
<wire x1="0.55" y1="0.3" x2="0.55" y2="-0.3" width="0.12" layer="51"/>
<smd name="1" x="-0.4846" y="0" dx="0.56" dy="0.6291" layer="1"/>
<smd name="2" x="0.4846" y="0" dx="0.56" dy="0.6291" layer="1"/>
<text x="0" y="1.2636" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.2636" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPC1110X102" urn="urn:adsk.eagle:footprint:16290845/2" library_version="4">
<description>Chip, 1.17 X 1.02 X 1.02 mm body
&lt;p&gt;Chip package with body size 1.17 X 1.02 X 1.02 mm&lt;/p&gt;</description>
<wire x1="0.66" y1="0.9552" x2="-0.66" y2="0.9552" width="0.127" layer="21"/>
<wire x1="0.66" y1="-0.9552" x2="-0.66" y2="-0.9552" width="0.127" layer="21"/>
<wire x1="0.66" y1="-0.635" x2="-0.66" y2="-0.635" width="0.12" layer="51"/>
<wire x1="-0.66" y1="-0.635" x2="-0.66" y2="0.635" width="0.12" layer="51"/>
<wire x1="-0.66" y1="0.635" x2="0.66" y2="0.635" width="0.12" layer="51"/>
<wire x1="0.66" y1="0.635" x2="0.66" y2="-0.635" width="0.12" layer="51"/>
<smd name="1" x="-0.5388" y="0" dx="0.6626" dy="1.2823" layer="1"/>
<smd name="2" x="0.5388" y="0" dx="0.6626" dy="1.2823" layer="1"/>
<text x="0" y="1.5902" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.5902" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPC1608X85" urn="urn:adsk.eagle:footprint:16290847/2" library_version="4">
<description>Chip, 1.60 X 0.80 X 0.85 mm body
&lt;p&gt;Chip package with body size 1.60 X 0.80 X 0.85 mm&lt;/p&gt;</description>
<wire x1="0.875" y1="0.7991" x2="-0.875" y2="0.7991" width="0.127" layer="21"/>
<wire x1="0.875" y1="-0.7991" x2="-0.875" y2="-0.7991" width="0.127" layer="21"/>
<wire x1="0.875" y1="-0.475" x2="-0.875" y2="-0.475" width="0.12" layer="51"/>
<wire x1="-0.875" y1="-0.475" x2="-0.875" y2="0.475" width="0.12" layer="51"/>
<wire x1="-0.875" y1="0.475" x2="0.875" y2="0.475" width="0.12" layer="51"/>
<wire x1="0.875" y1="0.475" x2="0.875" y2="-0.475" width="0.12" layer="51"/>
<smd name="1" x="-0.7746" y="0" dx="0.9209" dy="0.9702" layer="1"/>
<smd name="2" x="0.7746" y="0" dx="0.9209" dy="0.9702" layer="1"/>
<text x="0" y="1.4341" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.4341" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPC2012X110" urn="urn:adsk.eagle:footprint:16290848/2" library_version="4">
<description>Chip, 2.00 X 1.25 X 1.10 mm body
&lt;p&gt;Chip package with body size 2.00 X 1.25 X 1.10 mm&lt;/p&gt;</description>
<wire x1="1.1" y1="1.0467" x2="-1.1" y2="1.0467" width="0.127" layer="21"/>
<wire x1="1.1" y1="-1.0467" x2="-1.1" y2="-1.0467" width="0.127" layer="21"/>
<wire x1="1.1" y1="-0.725" x2="-1.1" y2="-0.725" width="0.12" layer="51"/>
<wire x1="-1.1" y1="-0.725" x2="-1.1" y2="0.725" width="0.12" layer="51"/>
<wire x1="-1.1" y1="0.725" x2="1.1" y2="0.725" width="0.12" layer="51"/>
<wire x1="1.1" y1="0.725" x2="1.1" y2="-0.725" width="0.12" layer="51"/>
<smd name="1" x="-0.8754" y="0" dx="1.1646" dy="1.4653" layer="1"/>
<smd name="2" x="0.8754" y="0" dx="1.1646" dy="1.4653" layer="1"/>
<text x="0" y="1.6817" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.6817" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPC3216X135" urn="urn:adsk.eagle:footprint:16290836/2" library_version="4">
<description>Chip, 3.20 X 1.60 X 1.35 mm body
&lt;p&gt;Chip package with body size 3.20 X 1.60 X 1.35 mm&lt;/p&gt;</description>
<wire x1="1.7" y1="1.2217" x2="-1.7" y2="1.2217" width="0.127" layer="21"/>
<wire x1="1.7" y1="-1.2217" x2="-1.7" y2="-1.2217" width="0.127" layer="21"/>
<wire x1="1.7" y1="-0.9" x2="-1.7" y2="-0.9" width="0.12" layer="51"/>
<wire x1="-1.7" y1="-0.9" x2="-1.7" y2="0.9" width="0.12" layer="51"/>
<wire x1="-1.7" y1="0.9" x2="1.7" y2="0.9" width="0.12" layer="51"/>
<wire x1="1.7" y1="0.9" x2="1.7" y2="-0.9" width="0.12" layer="51"/>
<smd name="1" x="-1.4754" y="0" dx="1.1646" dy="1.8153" layer="1"/>
<smd name="2" x="1.4754" y="0" dx="1.1646" dy="1.8153" layer="1"/>
<text x="0" y="1.8567" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.8567" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPC3225X135" urn="urn:adsk.eagle:footprint:16290843/2" library_version="4">
<description>Chip, 3.20 X 2.50 X 1.35 mm body
&lt;p&gt;Chip package with body size 3.20 X 2.50 X 1.35 mm&lt;/p&gt;</description>
<wire x1="1.7" y1="1.6717" x2="-1.7" y2="1.6717" width="0.127" layer="21"/>
<wire x1="1.7" y1="-1.6717" x2="-1.7" y2="-1.6717" width="0.12" layer="21"/>
<wire x1="1.7" y1="-1.35" x2="-1.7" y2="-1.35" width="0.12" layer="51"/>
<wire x1="-1.7" y1="-1.35" x2="-1.7" y2="1.35" width="0.12" layer="51"/>
<wire x1="-1.7" y1="1.35" x2="1.7" y2="1.35" width="0.12" layer="51"/>
<wire x1="1.7" y1="1.35" x2="1.7" y2="-1.35" width="0.12" layer="51"/>
<smd name="1" x="-1.4754" y="0" dx="1.1646" dy="2.7153" layer="1"/>
<smd name="2" x="1.4754" y="0" dx="1.1646" dy="2.7153" layer="1"/>
<text x="0" y="2.3067" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.3067" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPC4532X135" urn="urn:adsk.eagle:footprint:16290841/2" library_version="4">
<description>Chip, 4.50 X 3.20 X 1.35 mm body
&lt;p&gt;Chip package with body size 4.50 X 3.20 X 1.35 mm&lt;/p&gt;</description>
<wire x1="2.4" y1="2.0217" x2="-2.4" y2="2.0217" width="0.127" layer="21"/>
<wire x1="2.4" y1="-2.0217" x2="-2.4" y2="-2.0217" width="0.127" layer="21"/>
<wire x1="2.4" y1="-1.7" x2="-2.4" y2="-1.7" width="0.12" layer="51"/>
<wire x1="-2.4" y1="-1.7" x2="-2.4" y2="1.7" width="0.12" layer="51"/>
<wire x1="-2.4" y1="1.7" x2="2.4" y2="1.7" width="0.12" layer="51"/>
<wire x1="2.4" y1="1.7" x2="2.4" y2="-1.7" width="0.12" layer="51"/>
<smd name="1" x="-2.0565" y="0" dx="1.3973" dy="3.4153" layer="1"/>
<smd name="2" x="2.0565" y="0" dx="1.3973" dy="3.4153" layer="1"/>
<text x="0" y="2.6567" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.6567" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPM3216X180" urn="urn:adsk.eagle:footprint:16290835/2" library_version="4">
<description>Molded Body, 3.20 X 1.60 X 1.80 mm body
&lt;p&gt;Molded Body package with body size 3.20 X 1.60 X 1.80 mm&lt;/p&gt;</description>
<wire x1="-1.7" y1="0.9084" x2="1.7" y2="0.9084" width="0.127" layer="21"/>
<wire x1="-1.7" y1="-0.9084" x2="1.7" y2="-0.9084" width="0.127" layer="21"/>
<wire x1="1.7" y1="-0.9" x2="-1.7" y2="-0.9" width="0.12" layer="51"/>
<wire x1="-1.7" y1="-0.9" x2="-1.7" y2="0.9" width="0.12" layer="51"/>
<wire x1="-1.7" y1="0.9" x2="1.7" y2="0.9" width="0.12" layer="51"/>
<wire x1="1.7" y1="0.9" x2="1.7" y2="-0.9" width="0.12" layer="51"/>
<smd name="1" x="-1.3099" y="0" dx="1.7955" dy="1.1887" layer="1"/>
<smd name="2" x="1.3099" y="0" dx="1.7955" dy="1.1887" layer="1"/>
<text x="0" y="1.5434" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.5434" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPM3528X210" urn="urn:adsk.eagle:footprint:16290844/2" library_version="4">
<description>Molded Body, 3.50 X 2.80 X 2.10 mm body
&lt;p&gt;Molded Body package with body size 3.50 X 2.80 X 2.10 mm&lt;/p&gt;</description>
<wire x1="-1.85" y1="1.5" x2="1.85" y2="1.5" width="0.127" layer="21"/>
<wire x1="-1.85" y1="-1.5" x2="1.85" y2="-1.5" width="0.127" layer="21"/>
<wire x1="1.85" y1="-1.5" x2="-1.85" y2="-1.5" width="0.12" layer="51"/>
<wire x1="-1.85" y1="-1.5" x2="-1.85" y2="1.5" width="0.12" layer="51"/>
<wire x1="-1.85" y1="1.5" x2="1.85" y2="1.5" width="0.12" layer="51"/>
<wire x1="1.85" y1="1.5" x2="1.85" y2="-1.5" width="0.12" layer="51"/>
<smd name="1" x="-1.4599" y="0" dx="1.7955" dy="2.2036" layer="1"/>
<smd name="2" x="1.4599" y="0" dx="1.7955" dy="2.2036" layer="1"/>
<text x="0" y="2.135" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.135" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPM6032X280" urn="urn:adsk.eagle:footprint:16290839/2" library_version="4">
<description>Molded Body, 6.00 X 3.20 X 2.80 mm body
&lt;p&gt;Molded Body package with body size 6.00 X 3.20 X 2.80 mm&lt;/p&gt;</description>
<wire x1="-3.15" y1="1.75" x2="3.15" y2="1.75" width="0.127" layer="21"/>
<wire x1="-3.15" y1="-1.75" x2="3.15" y2="-1.75" width="0.127" layer="21"/>
<wire x1="3.15" y1="-1.75" x2="-3.15" y2="-1.75" width="0.12" layer="51"/>
<wire x1="-3.15" y1="-1.75" x2="-3.15" y2="1.75" width="0.12" layer="51"/>
<wire x1="-3.15" y1="1.75" x2="3.15" y2="1.75" width="0.12" layer="51"/>
<wire x1="3.15" y1="1.75" x2="3.15" y2="-1.75" width="0.12" layer="51"/>
<smd name="1" x="-2.4712" y="0" dx="2.368" dy="2.2036" layer="1"/>
<smd name="2" x="2.4712" y="0" dx="2.368" dy="2.2036" layer="1"/>
<text x="0" y="2.385" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.385" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPM7343X310" urn="urn:adsk.eagle:footprint:16290840/2" library_version="4">
<description>Molded Body, 7.30 X 4.30 X 3.10 mm body
&lt;p&gt;Molded Body package with body size 7.30 X 4.30 X 3.10 mm&lt;/p&gt;</description>
<wire x1="-3.8" y1="2.3" x2="3.8" y2="2.3" width="0.127" layer="21"/>
<wire x1="-3.8" y1="-2.3" x2="3.8" y2="-2.3" width="0.127" layer="21"/>
<wire x1="3.8" y1="-2.3" x2="-3.8" y2="-2.3" width="0.12" layer="51"/>
<wire x1="-3.8" y1="-2.3" x2="-3.8" y2="2.3" width="0.12" layer="51"/>
<wire x1="-3.8" y1="2.3" x2="3.8" y2="2.3" width="0.12" layer="51"/>
<wire x1="3.8" y1="2.3" x2="3.8" y2="-2.3" width="0.12" layer="51"/>
<smd name="1" x="-3.1212" y="0" dx="2.368" dy="2.4036" layer="1"/>
<smd name="2" x="3.1212" y="0" dx="2.368" dy="2.4036" layer="1"/>
<text x="0" y="2.935" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-2.935" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPC4564X110" urn="urn:adsk.eagle:footprint:16290837/2" library_version="4">
<description>Chip, 4.50 X 6.40 X 1.10 mm body
&lt;p&gt;Chip package with body size 4.50 X 6.40 X 1.10 mm&lt;/p&gt;</description>
<wire x1="2.4" y1="3.7179" x2="-2.4" y2="3.7179" width="0.127" layer="21"/>
<wire x1="2.4" y1="-3.7179" x2="-2.4" y2="-3.7179" width="0.127" layer="21"/>
<wire x1="2.4" y1="-3.4" x2="-2.4" y2="-3.4" width="0.12" layer="51"/>
<wire x1="-2.4" y1="-3.4" x2="-2.4" y2="3.4" width="0.12" layer="51"/>
<wire x1="-2.4" y1="3.4" x2="2.4" y2="3.4" width="0.12" layer="51"/>
<wire x1="2.4" y1="3.4" x2="2.4" y2="-3.4" width="0.12" layer="51"/>
<smd name="1" x="-2.0565" y="0" dx="1.3973" dy="6.8078" layer="1"/>
<smd name="2" x="2.0565" y="0" dx="1.3973" dy="6.8078" layer="1"/>
<text x="0" y="4.3529" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-4.3529" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPRD550W60D1025H1250B" urn="urn:adsk.eagle:footprint:16290829/2" library_version="4">
<description>Radial Non-Polarized Capacitor, 5.50 mm pitch, 10.25 mm body diameter, 12.50 mm body height
&lt;p&gt;Radial Non-Polarized Capacitor package with 5.50 mm pitch (lead spacing), 0.60 mm lead diameter, 10.25 mm body diameter and 12.50 mm body height&lt;/p&gt;</description>
<circle x="0" y="0" radius="5.25" width="0.127" layer="21"/>
<circle x="0" y="0" radius="5.25" width="0.12" layer="51"/>
<pad name="1" x="-2.75" y="0" drill="0.8" diameter="1.4"/>
<pad name="2" x="2.75" y="0" drill="0.8" diameter="1.4"/>
<text x="0" y="5.885" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-5.885" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
<package name="CAPRD2261W240D5080H5555B" urn="urn:adsk.eagle:footprint:16290850/2" library_version="4">
<description>Radial Non-Polarized Capacitor, 22.61 mm pitch, 50.80 mm body diameter, 55.55 mm body height
&lt;p&gt;Radial Non-Polarized Capacitor package with 22.61 mm pitch (lead spacing), 2.40 mm lead diameter, 50.80 mm body diameter and 55.55 mm body height&lt;/p&gt;</description>
<circle x="0" y="0" radius="25.79" width="0.127" layer="21"/>
<circle x="0" y="0" radius="25.79" width="0.12" layer="51"/>
<pad name="1" x="-11.305" y="0" drill="2.6" diameter="3.9"/>
<pad name="2" x="11.305" y="0" drill="2.6" diameter="3.9"/>
<text x="0" y="26.425" size="1.27" layer="25" align="bottom-center">&gt;NAME</text>
<text x="0" y="-26.425" size="1.27" layer="27" align="top-center">&gt;VALUE</text>
</package>
</packages>
<packages3d>
<package3d name="CAPC1005X60" urn="urn:adsk.eagle:package:16290895/2" type="model" library_version="4">
<description>Chip, 1.00 X 0.50 X 0.60 mm body
&lt;p&gt;Chip package with body size 1.00 X 0.50 X 0.60 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPC1005X60"/>
</packageinstances>
</package3d>
<package3d name="CAPC1110X102" urn="urn:adsk.eagle:package:16290904/2" type="model" library_version="4">
<description>Chip, 1.17 X 1.02 X 1.02 mm body
&lt;p&gt;Chip package with body size 1.17 X 1.02 X 1.02 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPC1110X102"/>
</packageinstances>
</package3d>
<package3d name="CAPC1608X85" urn="urn:adsk.eagle:package:16290898/2" type="model" library_version="4">
<description>Chip, 1.60 X 0.80 X 0.85 mm body
&lt;p&gt;Chip package with body size 1.60 X 0.80 X 0.85 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPC1608X85"/>
</packageinstances>
</package3d>
<package3d name="CAPC2012X110" urn="urn:adsk.eagle:package:16290897/2" type="model" library_version="4">
<description>Chip, 2.00 X 1.25 X 1.10 mm body
&lt;p&gt;Chip package with body size 2.00 X 1.25 X 1.10 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPC2012X110"/>
</packageinstances>
</package3d>
<package3d name="CAPC3216X135" urn="urn:adsk.eagle:package:16290893/2" type="model" library_version="4">
<description>Chip, 3.20 X 1.60 X 1.35 mm body
&lt;p&gt;Chip package with body size 3.20 X 1.60 X 1.35 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPC3216X135"/>
</packageinstances>
</package3d>
<package3d name="CAPC3225X135" urn="urn:adsk.eagle:package:16290903/2" type="model" library_version="4">
<description>Chip, 3.20 X 2.50 X 1.35 mm body
&lt;p&gt;Chip package with body size 3.20 X 2.50 X 1.35 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPC3225X135"/>
</packageinstances>
</package3d>
<package3d name="CAPC4532X135" urn="urn:adsk.eagle:package:16290900/2" type="model" library_version="4">
<description>Chip, 4.50 X 3.20 X 1.35 mm body
&lt;p&gt;Chip package with body size 4.50 X 3.20 X 1.35 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPC4532X135"/>
</packageinstances>
</package3d>
<package3d name="CAPM3216X180" urn="urn:adsk.eagle:package:16290894/2" type="model" library_version="4">
<description>Molded Body, 3.20 X 1.60 X 1.80 mm body
&lt;p&gt;Molded Body package with body size 3.20 X 1.60 X 1.80 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPM3216X180"/>
</packageinstances>
</package3d>
<package3d name="CAPM3528X210" urn="urn:adsk.eagle:package:16290902/2" type="model" library_version="4">
<description>Molded Body, 3.50 X 2.80 X 2.10 mm body
&lt;p&gt;Molded Body package with body size 3.50 X 2.80 X 2.10 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPM3528X210"/>
</packageinstances>
</package3d>
<package3d name="CAPM6032X280" urn="urn:adsk.eagle:package:16290896/2" type="model" library_version="4">
<description>Molded Body, 6.00 X 3.20 X 2.80 mm body
&lt;p&gt;Molded Body package with body size 6.00 X 3.20 X 2.80 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPM6032X280"/>
</packageinstances>
</package3d>
<package3d name="CAPM7343X310" urn="urn:adsk.eagle:package:16290891/2" type="model" library_version="4">
<description>Molded Body, 7.30 X 4.30 X 3.10 mm body
&lt;p&gt;Molded Body package with body size 7.30 X 4.30 X 3.10 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPM7343X310"/>
</packageinstances>
</package3d>
<package3d name="CAPC4564X110L" urn="urn:adsk.eagle:package:16290887/3" type="model" library_version="4">
<description>Chip, 4.50 X 6.40 X 1.10 mm body
&lt;p&gt;Chip package with body size 4.50 X 6.40 X 1.10 mm&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPC4564X110"/>
</packageinstances>
</package3d>
<package3d name="CAPRD550W60D1025H1250B" urn="urn:adsk.eagle:package:16290858/2" type="model" library_version="4">
<description>Radial Non-Polarized Capacitor, 5.50 mm pitch, 10.25 mm body diameter, 12.50 mm body height
&lt;p&gt;Radial Non-Polarized Capacitor package with 5.50 mm pitch (lead spacing), 0.60 mm lead diameter, 10.25 mm body diameter and 12.50 mm body height&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPRD550W60D1025H1250B"/>
</packageinstances>
</package3d>
<package3d name="CAPRD2261W240D5080H5555B" urn="urn:adsk.eagle:package:16290864/2" type="model" library_version="4">
<description>Radial Non-Polarized Capacitor, 22.61 mm pitch, 50.80 mm body diameter, 55.55 mm body height
&lt;p&gt;Radial Non-Polarized Capacitor package with 22.61 mm pitch (lead spacing), 2.40 mm lead diameter, 50.80 mm body diameter and 55.55 mm body height&lt;/p&gt;</description>
<packageinstances>
<packageinstance name="CAPRD2261W240D5080H5555B"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="C" urn="urn:adsk.eagle:symbol:16290820/1" library_version="4">
<description>Capacitor</description>
<rectangle x1="-2.032" y1="-2.032" x2="2.032" y2="-1.524" layer="94"/>
<rectangle x1="-2.032" y1="-1.016" x2="2.032" y2="-0.508" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-0.508" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="0" y2="-2.032" width="0.1524" layer="94"/>
<pin name="1" x="0" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
<text x="2.54" y="2.54" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-2.54" size="1.778" layer="97">&gt;SPICEMODEL</text>
<text x="2.54" y="0" size="1.778" layer="96">&gt;VALUE</text>
<text x="2.54" y="-5.08" size="1.778" layer="97">&gt;SPICEEXTRA</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="C" urn="urn:adsk.eagle:component:16290909/4" prefix="C" uservalue="yes" library_version="4">
<description>&lt;B&gt;Capacitor - Generic</description>
<gates>
<gate name="G$1" symbol="C" x="0" y="0"/>
</gates>
<devices>
<device name="CHIP-0402(1005-METRIC)" package="CAPC1005X60">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290895/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-0504(1310-METRIC)" package="CAPC1110X102">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290904/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-0603(1608-METRIC)" package="CAPC1608X85">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290898/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-0805(2012-METRIC)" package="CAPC2012X110">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290897/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-1206(3216-METRIC)" package="CAPC3216X135">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290893/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-1210(3225-METRIC)" package="CAPC3225X135">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290903/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-1812(4532-METRIC)" package="CAPC4532X135">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290900/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="TANTALUM-1206(3216-METRIC)" package="CAPM3216X180">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290894/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="TANTALUM-1411(3528-METRIC)" package="CAPM3528X210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290902/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="TANTALUM-2412(6032-METRIC)" package="CAPM6032X280">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290896/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="TANTALUM-2917(7343-METRIC)" package="CAPM7343X310">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290891/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="CHIP-1825(4564-METRIC)" package="CAPC4564X110">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290887/3"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="RADIAL-12.5MM-DIA" package="CAPRD550W60D1025H1250B">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290858/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
<device name="RADIAL-55.5MM-DIA" package="CAPRD2261W240D5080H5555B">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16290864/2"/>
</package3dinstances>
<technologies>
<technology name="_">
<attribute name="CATEGORY" value="Capacitor" constant="no"/>
<attribute name="MANUFACTURER" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OPERATING_TEMP" value="" constant="no"/>
<attribute name="PART_STATUS" value="" constant="no"/>
<attribute name="ROHS_COMPLIANT" value="" constant="no"/>
<attribute name="SERIES" value="" constant="no"/>
<attribute name="SUB-CATEGORY" value="" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="" constant="no"/>
<attribute name="VALUE" value="" constant="no"/>
<attribute name="VOLTAGE_RATING" value="" constant="no"/>
</technology>
</technologies>
</device>
</devices>
<spice>
<pinmapping spiceprefix="C">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
</deviceset>
</devicesets>
</library>
<library name="PESD0402-140">
<packages>
<package name="RESC1005X35N">
<text x="-0.95" y="-0.63" size="0.5" layer="27" align="top-left">&gt;VALUE</text>
<text x="-0.95" y="0.63" size="0.5" layer="25">&gt;NAME</text>
<wire x1="0.53" y1="-0.28" x2="-0.53" y2="-0.28" width="0.127" layer="51"/>
<wire x1="0.53" y1="0.28" x2="-0.53" y2="0.28" width="0.127" layer="51"/>
<wire x1="0.53" y1="-0.28" x2="0.53" y2="0.28" width="0.127" layer="51"/>
<wire x1="-0.53" y1="-0.28" x2="-0.53" y2="0.28" width="0.127" layer="51"/>
<wire x1="-0.95" y1="-0.55" x2="0.95" y2="-0.55" width="0.05" layer="39"/>
<wire x1="-0.95" y1="0.55" x2="0.95" y2="0.55" width="0.05" layer="39"/>
<wire x1="-0.95" y1="-0.55" x2="-0.95" y2="0.55" width="0.05" layer="39"/>
<wire x1="0.95" y1="-0.55" x2="0.95" y2="0.55" width="0.05" layer="39"/>
<smd name="1" x="-0.457" y="0" dx="0.49" dy="0.6" layer="1"/>
<smd name="2" x="0.457" y="0" dx="0.49" dy="0.6" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="PESD0402-140">
<text x="0" y="3.81093125" size="1.77843125" layer="95">&gt;NAME</text>
<text x="0" y="-5.08848125" size="1.78096875" layer="96">&gt;VALUE</text>
<rectangle x1="0" y1="-1.906859375" x2="0.635" y2="1.905" layer="94"/>
<rectangle x1="1.90685" y1="-1.90685" x2="2.54" y2="1.905" layer="94"/>
<pin name="2" x="5.08" y="0" visible="pad" length="short" direction="pas" rot="R180"/>
<pin name="1" x="-2.54" y="0" visible="pad" length="short" direction="pas"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="PESD0402-140" prefix="C">
<description>PESD0402 Series 40 V 0.25 pF Bi-Directional Surface Mount ESD Protector &lt;a href="https://pricing.snapeda.com/search/part/PESD0402-140/?ref=eda"&gt;Check prices&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="PESD0402-140" x="0" y="0"/>
</gates>
<devices>
<device name="" package="RESC1005X35N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="Good"/>
<attribute name="DESCRIPTION" value=" 40V Clamp Ipp Tvs Diode Surface Mount 0402 "/>
<attribute name="MF" value="Littelfuse Inc."/>
<attribute name="MP" value="PESD0402-140"/>
<attribute name="PACKAGE" value="0402 Littelfuse"/>
<attribute name="PRICE" value="None"/>
<attribute name="PURCHASE-URL" value="https://pricing.snapeda.com/search/part/PESD0402-140/?ref=eda"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="HA_FONA_LARA">
<description>Generated from &lt;b&gt;HA_FONA_LARA.sch&lt;/b&gt;&lt;p&gt;
by exp-lbrs.ulp</description>
<packages>
<package name="MICROBUILDER_CHIPLED_0603">
<description>&lt;b&gt;CHIPLED 0603&lt;/b&gt;</description>
<circle x="-0.35" y="0.625" radius="0.075" width="0.0508" layer="51"/>
<wire x1="-0.3" y1="0.8" x2="0.3" y2="0.8" width="0.1016" layer="51" curve="170.055574"/>
<wire x1="-0.275" y1="-0.825" x2="0.275" y2="-0.825" width="0.0508" layer="51" curve="-180"/>
<wire x1="-0.4" y1="0.375" x2="-0.4" y2="-0.35" width="0.1016" layer="51"/>
<wire x1="0.4" y1="0.35" x2="0.4" y2="-0.35" width="0.1016" layer="51"/>
<wire x1="-0.65" y1="-1.4" x2="-0.65" y2="1.4" width="0.2032" layer="21"/>
<wire x1="0.65" y1="1.4" x2="0.65" y2="-1.4" width="0.2032" layer="21"/>
<wire x1="-0.65" y1="1.4" x2="0.65" y2="1.4" width="0.2032" layer="21"/>
<wire x1="-0.65" y1="-1.4" x2="0.65" y2="-1.4" width="0.2032" layer="21"/>
<wire x1="-0.4" y1="0.2" x2="0" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0" y1="0.2" x2="0.4" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0" y1="0.2" x2="-0.4" y2="-0.2" width="0.2032" layer="21"/>
<wire x1="-0.4" y1="-0.2" x2="0.4" y2="-0.2" width="0.2032" layer="21"/>
<wire x1="0.4" y1="-0.2" x2="0" y2="0.2" width="0.2032" layer="21"/>
<rectangle x1="-0.45" y1="0.7" x2="-0.25" y2="0.85" layer="51"/>
<rectangle x1="-0.275" y1="0.55" x2="-0.225" y2="0.6" layer="51"/>
<rectangle x1="-0.45" y1="0.35" x2="-0.4" y2="0.725" layer="51"/>
<rectangle x1="0.25" y1="0.55" x2="0.45" y2="0.85" layer="51"/>
<rectangle x1="-0.45" y1="0.35" x2="0.45" y2="0.575" layer="51"/>
<rectangle x1="-0.45" y1="-0.85" x2="-0.25" y2="-0.35" layer="51"/>
<rectangle x1="0.25" y1="-0.85" x2="0.45" y2="-0.35" layer="51"/>
<rectangle x1="-0.275" y1="-0.575" x2="0.275" y2="-0.35" layer="51"/>
<rectangle x1="-0.275" y1="-0.65" x2="-0.175" y2="-0.55" layer="51"/>
<rectangle x1="0.175" y1="-0.65" x2="0.275" y2="-0.55" layer="51"/>
<smd name="A" x="0" y="-0.75" dx="0.8" dy="0.8" layer="1"/>
<smd name="C" x="0" y="0.75" dx="0.8" dy="0.8" layer="1"/>
<text x="-0.762" y="-1.27" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.27" y="-1.27" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
</package>
<package name="MICROBUILDER_CHIPLED_0603_NOOUTLINE">
<circle x="-0.35" y="0.625" radius="0.075" width="0.0508" layer="51"/>
<wire x1="-0.3" y1="0.8" x2="0.3" y2="0.8" width="0.1016" layer="51" curve="170.055574"/>
<wire x1="-0.275" y1="-0.825" x2="0.275" y2="-0.825" width="0.0508" layer="51" curve="-180"/>
<wire x1="-0.4" y1="0.375" x2="-0.4" y2="-0.35" width="0.1016" layer="51"/>
<wire x1="0.4" y1="0.35" x2="0.4" y2="-0.35" width="0.1016" layer="51"/>
<rectangle x1="-0.45" y1="0.7" x2="-0.25" y2="0.85" layer="51"/>
<rectangle x1="-0.275" y1="0.55" x2="-0.225" y2="0.6" layer="51"/>
<rectangle x1="-0.45" y1="0.35" x2="-0.4" y2="0.725" layer="51"/>
<rectangle x1="0.25" y1="0.55" x2="0.45" y2="0.85" layer="51"/>
<rectangle x1="-0.45" y1="0.35" x2="0.45" y2="0.575" layer="51"/>
<rectangle x1="-0.45" y1="-0.85" x2="-0.25" y2="-0.35" layer="51"/>
<rectangle x1="0.25" y1="-0.85" x2="0.45" y2="-0.35" layer="51"/>
<rectangle x1="-0.275" y1="-0.575" x2="0.275" y2="-0.35" layer="51"/>
<rectangle x1="-0.275" y1="-0.65" x2="-0.175" y2="-0.55" layer="51"/>
<rectangle x1="0.175" y1="-0.65" x2="0.275" y2="-0.55" layer="51"/>
<rectangle x1="-0.381" y1="0.1397" x2="0.381" y2="0.2667" layer="21"/>
<smd name="A" x="0" y="-0.75" dx="0.8" dy="0.8" layer="1"/>
<smd name="C" x="0" y="0.75" dx="0.8" dy="0.8" layer="1"/>
<text x="-0.762" y="-1.27" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.27" y="-1.27" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<polygon width="0.1524" layer="21">
<vertex x="0" y="0.1397"/>
<vertex x="-0.254" y="-0.1778"/>
<vertex x="0.254" y="-0.1778"/>
</polygon>
</package>
<package name="MICROBUILDER_CHIPLED_0805">
<description>&lt;b&gt;CHIPLED 0805&lt;/b&gt;</description>
<circle x="-0.45" y="0.85" radius="0.103" width="0.0762" layer="51"/>
<wire x1="-0.35" y1="0.925" x2="0.35" y2="0.925" width="0.1016" layer="51" curve="162.394521"/>
<wire x1="-0.35" y1="-0.925" x2="0.35" y2="-0.925" width="0.1016" layer="51" curve="-162.394521"/>
<wire x1="0.575" y1="0.525" x2="0.575" y2="-0.525" width="0.1016" layer="51"/>
<wire x1="-0.575" y1="-0.5" x2="-0.575" y2="0.925" width="0.1016" layer="51"/>
<wire x1="-0.4" y1="0.2" x2="0" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0" y1="0.2" x2="0.4" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0" y1="0.2" x2="-0.4" y2="-0.2" width="0.2032" layer="21"/>
<wire x1="-0.4" y1="-0.2" x2="0.4" y2="-0.2" width="0.2032" layer="21"/>
<wire x1="0.4" y1="-0.2" x2="0" y2="0.2" width="0.2032" layer="21"/>
<wire x1="0.85" y1="-1.9" x2="-0.85" y2="-1.9" width="0.2032" layer="21"/>
<wire x1="-0.85" y1="-1.9" x2="-0.85" y2="1.9" width="0.2032" layer="21"/>
<wire x1="-0.85" y1="1.9" x2="0.85" y2="1.9" width="0.2032" layer="21"/>
<wire x1="0.85" y1="1.9" x2="0.85" y2="-1.9" width="0.2032" layer="21"/>
<rectangle x1="0.3" y1="0.5" x2="0.625" y2="1" layer="51"/>
<rectangle x1="-0.325" y1="0.5" x2="-0.175" y2="0.75" layer="51"/>
<rectangle x1="0.175" y1="0.5" x2="0.325" y2="0.75" layer="51"/>
<rectangle x1="-0.2" y1="0.5" x2="0.2" y2="0.675" layer="51"/>
<rectangle x1="0.3" y1="-1" x2="0.625" y2="-0.5" layer="51"/>
<rectangle x1="-0.625" y1="-1" x2="-0.3" y2="-0.5" layer="51"/>
<rectangle x1="0.175" y1="-0.75" x2="0.325" y2="-0.5" layer="51"/>
<rectangle x1="-0.325" y1="-0.75" x2="-0.175" y2="-0.5" layer="51"/>
<rectangle x1="-0.2" y1="-0.675" x2="0.2" y2="-0.5" layer="51"/>
<rectangle x1="-0.6" y1="0.5" x2="-0.3" y2="0.762" layer="51"/>
<rectangle x1="-0.625" y1="0.925" x2="-0.3" y2="1" layer="51"/>
<smd name="A" x="0" y="-1.05" dx="1.2" dy="1.2" layer="1"/>
<smd name="C" x="0" y="1.05" dx="1.2" dy="1.2" layer="1"/>
<text x="-1.016" y="-1.778" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.397" y="-1.778" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<text x="-0.1" y="-1.4" size="0.254" layer="51">A</text>
<text x="-0.1" y="1.2" size="0.254" layer="51">C</text>
</package>
<package name="MICROBUILDER_CHIPLED_0805_NOOUTLINE">
<circle x="-0.45" y="0.85" radius="0.103" width="0.0762" layer="51"/>
<wire x1="-0.35" y1="0.925" x2="0.35" y2="0.925" width="0.1016" layer="51" curve="162.394521"/>
<wire x1="-0.35" y1="-0.925" x2="0.35" y2="-0.925" width="0.1016" layer="51" curve="-162.394521"/>
<wire x1="0.575" y1="0.525" x2="0.575" y2="-0.525" width="0.1016" layer="51"/>
<wire x1="-0.575" y1="-0.5" x2="-0.575" y2="0.925" width="0.1016" layer="51"/>
<rectangle x1="0.3" y1="0.5" x2="0.625" y2="1" layer="51"/>
<rectangle x1="-0.325" y1="0.5" x2="-0.175" y2="0.75" layer="51"/>
<rectangle x1="0.175" y1="0.5" x2="0.325" y2="0.75" layer="51"/>
<rectangle x1="-0.2" y1="0.5" x2="0.2" y2="0.675" layer="51"/>
<rectangle x1="0.3" y1="-1" x2="0.625" y2="-0.5" layer="51"/>
<rectangle x1="-0.625" y1="-1" x2="-0.3" y2="-0.5" layer="51"/>
<rectangle x1="0.175" y1="-0.75" x2="0.325" y2="-0.5" layer="51"/>
<rectangle x1="-0.325" y1="-0.75" x2="-0.175" y2="-0.5" layer="51"/>
<rectangle x1="-0.2" y1="-0.675" x2="0.2" y2="-0.5" layer="51"/>
<rectangle x1="-0.6" y1="0.5" x2="-0.3" y2="0.762" layer="51"/>
<rectangle x1="-0.625" y1="0.925" x2="-0.3" y2="1" layer="51"/>
<rectangle x1="-0.4445" y1="0.1405" x2="0.4445" y2="0.331" layer="21"/>
<smd name="A" x="0" y="-1.05" dx="1.2" dy="1.2" layer="1"/>
<smd name="C" x="0" y="1.05" dx="1.2" dy="1.2" layer="1"/>
<text x="-1.016" y="-1.778" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.397" y="-1.778" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<text x="-0.1" y="-1.4" size="0.254" layer="51">A</text>
<text x="-0.1" y="1.2" size="0.254" layer="51">C</text>
<polygon width="0.1524" layer="21">
<vertex x="0" y="0.254"/>
<vertex x="-0.381" y="-0.254"/>
<vertex x="0.381" y="-0.254"/>
</polygon>
</package>
<package name="MICROBUILDER_CHIPLED_1206">
<description>&lt;b&gt;CHIPLED 1206&lt;/b&gt;</description>
<circle x="-0.55" y="1.425" radius="0.1" width="0.0762" layer="51"/>
<wire x1="-0.4" y1="1.6" x2="0.4" y2="1.6" width="0.1016" layer="51" curve="172.619069"/>
<wire x1="-0.8" y1="-0.95" x2="-0.8" y2="0.95" width="0.1016" layer="51"/>
<wire x1="0.8" y1="0.95" x2="0.8" y2="-0.95" width="0.1016" layer="51"/>
<wire x1="-0.6" y1="0.446" x2="0" y2="0.446" width="0.2032" layer="21"/>
<wire x1="0" y1="0.446" x2="0.6" y2="0.446" width="0.2032" layer="21"/>
<wire x1="0" y1="0.446" x2="-0.6" y2="-0.154" width="0.2032" layer="21"/>
<wire x1="-0.6" y1="-0.154" x2="0.6" y2="-0.154" width="0.2032" layer="21"/>
<wire x1="0.6" y1="-0.154" x2="0" y2="0.446" width="0.2032" layer="21"/>
<wire x1="1" y1="2.4985" x2="-1" y2="2.4985" width="0.2032" layer="21"/>
<wire x1="-1" y1="2.4985" x2="-1" y2="-2.4985" width="0.2032" layer="21"/>
<wire x1="-1" y1="-2.4985" x2="1" y2="-2.4985" width="0.2032" layer="21"/>
<wire x1="1" y1="-2.4985" x2="1" y2="2.4985" width="0.2032" layer="21"/>
<rectangle x1="-0.85" y1="1.525" x2="-0.35" y2="1.65" layer="51"/>
<rectangle x1="-0.85" y1="1.225" x2="-0.625" y2="1.55" layer="51"/>
<rectangle x1="-0.45" y1="1.225" x2="-0.325" y2="1.45" layer="51"/>
<rectangle x1="-0.65" y1="1.225" x2="-0.225" y2="1.35" layer="51"/>
<rectangle x1="0.35" y1="1.3" x2="0.85" y2="1.65" layer="51"/>
<rectangle x1="0.25" y1="1.225" x2="0.85" y2="1.35" layer="51"/>
<rectangle x1="-0.85" y1="0.95" x2="0.85" y2="1.25" layer="51"/>
<rectangle x1="-0.85" y1="-1.65" x2="0.85" y2="-0.95" layer="51"/>
<smd name="A" x="0" y="-1.496" dx="1.5" dy="1.5" layer="1"/>
<smd name="C" x="0" y="1.496" dx="1.5" dy="1.5" layer="1"/>
<text x="-1.27" y="-2.286" size="0.8128" layer="25" ratio="18" rot="R90">&gt;NAME</text>
<text x="1.651" y="-2.286" size="0.4064" layer="27" ratio="10" rot="R90">&gt;VALUE</text>
<text x="-0.1" y="-2.23" size="0.4064" layer="51">A</text>
<text x="-0.1" y="1.86" size="0.4064" layer="51">C</text>
</package>
<package name="MICROBUILDER_EVERLIGHT_45-21">
<wire x1="-1.35" y1="1" x2="1.35" y2="1" width="0.127" layer="51"/>
<wire x1="1.35" y1="1" x2="1.35" y2="0.7" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.7" x2="1.35" y2="-1" width="0.127" layer="51"/>
<wire x1="1.35" y1="-1" x2="0.9" y2="-1" width="0.127" layer="51"/>
<wire x1="0.9" y1="-1" x2="-1.35" y2="-1" width="0.127" layer="51"/>
<wire x1="-1.35" y1="-1" x2="-1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="-1.35" y1="-0.7" x2="-1.35" y2="0.7" width="0.127" layer="51"/>
<wire x1="-1.35" y1="0.7" x2="-1.35" y2="1" width="0.127" layer="51"/>
<wire x1="1.35" y1="0.7" x2="1.5" y2="0.7" width="0.127" layer="51"/>
<wire x1="1.5" y1="0.7" x2="1.5" y2="-0.7" width="0.127" layer="51"/>
<wire x1="1.5" y1="-0.7" x2="1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.55" x2="1.35" y2="0.7" width="0.127" layer="51"/>
<wire x1="-1.35" y1="0.7" x2="-1.5" y2="0.7" width="0.127" layer="51"/>
<wire x1="-1.5" y1="0.7" x2="-1.5" y2="-0.7" width="0.127" layer="51"/>
<wire x1="-1.5" y1="-0.7" x2="-1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="-1.15" y1="0.5" x2="-0.85" y2="0.8" width="0.127" layer="51" curve="-90"/>
<wire x1="-0.85" y1="0.8" x2="0.8" y2="0.8" width="0.127" layer="51"/>
<wire x1="0.8" y1="0.8" x2="1.15" y2="0.45" width="0.127" layer="51" curve="-90"/>
<wire x1="1.15" y1="0.45" x2="1.15" y2="-0.5" width="0.127" layer="51"/>
<wire x1="1.15" y1="-0.5" x2="0.85" y2="-0.8" width="0.127" layer="51" curve="-90"/>
<wire x1="0.85" y1="-0.8" x2="-0.85" y2="-0.8" width="0.127" layer="51"/>
<wire x1="-0.85" y1="-0.8" x2="-1.15" y2="-0.5" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.15" y1="-0.5" x2="-1.15" y2="0.5" width="0.127" layer="51"/>
<wire x1="0.9" y1="-1" x2="1.35" y2="-0.55" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.55" x2="1.35" y2="-0.7" width="0.127" layer="51"/>
<wire x1="1.35" y1="-0.7" x2="1.1" y2="-0.95" width="0.127" layer="51"/>
<wire x1="1.1" y1="-0.95" x2="1.2" y2="-0.95" width="0.127" layer="51"/>
<wire x1="1.2" y1="-0.95" x2="1.3" y2="-0.85" width="0.127" layer="51"/>
<wire x1="-1.45" y1="0.85" x2="-1.45" y2="1.1" width="0.127" layer="21"/>
<wire x1="-1.45" y1="1.1" x2="1.45" y2="1.1" width="0.127" layer="21"/>
<wire x1="1.45" y1="1.1" x2="1.45" y2="0.85" width="0.127" layer="21"/>
<wire x1="-1.45" y1="-0.85" x2="-1.45" y2="-1.1" width="0.127" layer="21"/>
<wire x1="-1.45" y1="-1.1" x2="1.45" y2="-1.1" width="0.127" layer="21"/>
<wire x1="1.45" y1="-1.1" x2="1.45" y2="-0.85" width="0.127" layer="21"/>
<rectangle x1="0.2" y1="-0.6" x2="0.5" y2="0.6" layer="21" rot="R180"/>
<smd name="A" x="-1.45" y="0" dx="1.4" dy="1.4" layer="1"/>
<smd name="K" x="1.45" y="0" dx="1.4" dy="1.4" layer="1"/>
<text x="-1.375" y="1.25" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.375" y="-1.633" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<polygon width="0.1524" layer="21">
<vertex x="0.254" y="0"/>
<vertex x="-0.354" y="0.481"/>
<vertex x="-0.354" y="-0.481"/>
</polygon>
</package>
<package name="MICROBUILDER_PLCC2_REVMOUNT">
<description>&lt;p&gt;PLCC2 - Reverse Mount&lt;/p&gt;
&lt;p&gt;Source: http://catalog.osram-os.com/media/_en/Graphics/00042122_0.pdf&lt;/p&gt;</description>
<circle x="0" y="0" radius="1.220653125" width="0.127" layer="51"/>
<wire x1="-1.7" y1="1.15" x2="-1.7" y2="1.3" width="0.127" layer="51"/>
<wire x1="-1.7" y1="1.3" x2="-1.5" y2="1.5" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.5" y1="1.5" x2="-0.95" y2="1.5" width="0.127" layer="51"/>
<wire x1="-0.95" y1="1.5" x2="1.5" y2="1.5" width="0.127" layer="51"/>
<wire x1="1.5" y1="1.5" x2="1.7" y2="1.3" width="0.127" layer="51" curve="-90"/>
<wire x1="1.7" y1="1.3" x2="1.7" y2="1.15" width="0.127" layer="51"/>
<wire x1="1.7" y1="1.15" x2="2.7" y2="1.15" width="0.127" layer="51"/>
<wire x1="2.7" y1="1.15" x2="2.7" y2="-1.15" width="0.127" layer="51"/>
<wire x1="2.7" y1="-1.15" x2="1.7" y2="-1.15" width="0.127" layer="51"/>
<wire x1="1.7" y1="-1.15" x2="1.7" y2="-1.25" width="0.127" layer="51"/>
<wire x1="1.7" y1="-1.25" x2="1.45" y2="-1.5" width="0.127" layer="51" curve="-90"/>
<wire x1="1.45" y1="-1.5" x2="-1.45" y2="-1.5" width="0.127" layer="51"/>
<wire x1="-1.45" y1="-1.5" x2="-1.7" y2="-1.25" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.7" y1="-1.25" x2="-1.7" y2="-1.15" width="0.127" layer="51"/>
<wire x1="-1.7" y1="-1.15" x2="-2.65" y2="-1.15" width="0.127" layer="51"/>
<wire x1="-2.65" y1="-1.15" x2="-2.65" y2="1.15" width="0.127" layer="51"/>
<wire x1="-2.65" y1="1.15" x2="-1.7" y2="1.15" width="0.127" layer="51"/>
<wire x1="-1.7" y1="1.15" x2="-1.7" y2="0.75" width="0.127" layer="51"/>
<wire x1="-1.7" y1="0.75" x2="-1.7" y2="0.65" width="0.127" layer="51"/>
<wire x1="-1.7" y1="0.65" x2="-1.7" y2="-0.65" width="0.127" layer="51"/>
<wire x1="-1.7" y1="-0.65" x2="-1.7" y2="-1.15" width="0.127" layer="51"/>
<wire x1="-1.7" y1="-0.65" x2="-1.75" y2="-0.65" width="0.127" layer="51"/>
<wire x1="-1.75" y1="-0.65" x2="-1.85" y2="-0.55" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.85" y1="-0.55" x2="-1.85" y2="0.5" width="0.127" layer="51"/>
<wire x1="-1.85" y1="0.5" x2="-1.7" y2="0.65" width="0.127" layer="51" curve="-90"/>
<wire x1="1.7" y1="-1.15" x2="1.7" y2="-0.65" width="0.127" layer="51"/>
<wire x1="1.7" y1="-0.65" x2="1.7" y2="0.65" width="0.127" layer="51"/>
<wire x1="1.7" y1="0.65" x2="1.7" y2="1.15" width="0.127" layer="51"/>
<wire x1="1.7" y1="0.65" x2="1.75" y2="0.65" width="0.127" layer="51"/>
<wire x1="1.75" y1="0.65" x2="1.85" y2="0.55" width="0.127" layer="51" curve="-90"/>
<wire x1="1.85" y1="0.55" x2="1.85" y2="-0.5" width="0.127" layer="51"/>
<wire x1="1.85" y1="-0.5" x2="1.7" y2="-0.65" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.7" y1="0.75" x2="-0.95" y2="1.5" width="0.127" layer="51"/>
<wire x1="0" y1="0.8" x2="0.8" y2="0" width="0.127" layer="51" curve="-90"/>
<wire x1="0.8" y1="0" x2="0" y2="-0.8" width="0.127" layer="51" curve="-90"/>
<wire x1="0" y1="-0.8" x2="-0.8" y2="0" width="0.127" layer="51" curve="-90"/>
<wire x1="-0.8" y1="0" x2="0" y2="0.8" width="0.127" layer="51" curve="-90"/>
<wire x1="-1.75" y1="1.45" x2="-1.6" y2="1.6" width="0.127" layer="21" curve="-90"/>
<wire x1="-1.6" y1="1.6" x2="1.6" y2="1.6" width="0.127" layer="21"/>
<wire x1="1.6" y1="1.6" x2="1.75" y2="1.45" width="0.127" layer="21" curve="-90"/>
<wire x1="-1.75" y1="-1.45" x2="-1.55" y2="-1.6" width="0.127" layer="21" curve="90"/>
<wire x1="-1.55" y1="-1.6" x2="1.55" y2="-1.6" width="0.127" layer="21"/>
<wire x1="1.55" y1="-1.6" x2="1.75" y2="-1.45" width="0.127" layer="21" curve="90"/>
<smd name="A" x="2.4" y="0" dx="1.2" dy="2.6" layer="1"/>
<smd name="K" x="-2.4" y="0" dx="1.2" dy="2.6" layer="1"/>
<text x="-1.79" y="1.84" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.74" y="-2.16" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<hole x="0" y="0" drill="2.5"/>
</package>
<package name="MICROBUILDER_CREE_XLAMP_XPE2">
<description>&lt;p&gt;Source: http://www.cree.com/~/media/Files/Cree/LED%20Components%20and%20Modules/XLamp/Data%20and%20Binning/XLampXPE2.pdf&lt;/p&gt;</description>
<circle x="0" y="0" radius="1.48660625" width="0.127" layer="51"/>
<wire x1="-1.725" y1="1.725" x2="1.725" y2="1.725" width="0.127" layer="51"/>
<wire x1="1.725" y1="1.725" x2="1.725" y2="-1.725" width="0.127" layer="51"/>
<wire x1="1.725" y1="-1.725" x2="-1.725" y2="-1.725" width="0.127" layer="51"/>
<wire x1="-1.725" y1="-1.725" x2="-1.725" y2="1.725" width="0.127" layer="51"/>
<wire x1="-0.6" y1="-1.7" x2="-0.6" y2="-0.7" width="0.127" layer="51"/>
<wire x1="-0.6" y1="-0.7" x2="0.7" y2="-0.7" width="0.127" layer="51"/>
<wire x1="0.7" y1="-0.7" x2="0.7" y2="0.7" width="0.127" layer="51"/>
<wire x1="0.7" y1="0.7" x2="0" y2="0.7" width="0.127" layer="51"/>
<wire x1="0" y1="0.7" x2="0" y2="1.7" width="0.127" layer="51"/>
<wire x1="-1.8" y1="1.8" x2="1.8" y2="1.8" width="0.127" layer="21"/>
<wire x1="1.8" y1="1.8" x2="1.8" y2="0.4" width="0.127" layer="21"/>
<wire x1="-1.8" y1="1.8" x2="-1.8" y2="0.4" width="0.127" layer="21"/>
<wire x1="-1.8" y1="-0.4" x2="-1.8" y2="-1.8" width="0.127" layer="21"/>
<wire x1="-1.8" y1="-1.8" x2="1.8" y2="-1.8" width="0.127" layer="21"/>
<wire x1="1.8" y1="-1.8" x2="1.8" y2="-0.4" width="0.127" layer="21"/>
<rectangle x1="-2.05" y1="-0.25" x2="-1.15" y2="0.25" layer="1"/>
<rectangle x1="-2.1" y1="-0.3" x2="-1.15" y2="0.3" layer="29"/>
<rectangle x1="1.15" y1="-0.25" x2="2.05" y2="0.25" layer="1" rot="R180"/>
<rectangle x1="1.15" y1="-0.3" x2="2.1" y2="0.3" layer="29" rot="R180"/>
<rectangle x1="-0.6" y1="-1.6" x2="0.6" y2="1.6" layer="31"/>
<rectangle x1="-2" y1="-0.2" x2="-1.2" y2="0.2" layer="31"/>
<rectangle x1="-1.6" y1="0.2" x2="-1.2" y2="1.6" layer="31"/>
<rectangle x1="-1.6" y1="-1.6" x2="-1.2" y2="-0.2" layer="31"/>
<rectangle x1="1.2" y1="-0.2" x2="2" y2="0.2" layer="31"/>
<rectangle x1="1.2" y1="0.2" x2="1.6" y2="1.6" layer="31"/>
<rectangle x1="1.2" y1="-1.6" x2="1.6" y2="-0.2" layer="31"/>
<rectangle x1="-1.5" y1="-1.5" x2="-1.3" y2="-1.3" layer="51"/>
<rectangle x1="2.1" y1="0.6" x2="2.4" y2="1.8" layer="21"/>
<rectangle x1="-0.5" y1="-0.5" x2="0.5" y2="0.5" layer="51"/>
<smd name="ANODE" x="1.4" y="0" dx="0.5" dy="3.3" layer="1" cream="no"/>
<smd name="CATHODE" x="-1.4" y="0" dx="0.5" dy="3.3" layer="1" cream="no"/>
<smd name="THERMAL" x="0" y="0" dx="1.3" dy="3.3" layer="1" cream="no"/>
<text x="-1.862" y="2.027" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.762" y="-2.435" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<polygon width="0.1524" layer="21">
<vertex x="2.346" y="1.2"/>
<vertex x="2.954" y="0.719"/>
<vertex x="2.954" y="1.681"/>
</polygon>
</package>
<package name="MICROBUILDER_CREE_XLAMP_XTE">
<circle x="0" y="0" radius="1.5811375" width="0.127" layer="51"/>
<circle x="0" y="0" radius="1.3928375" width="0.127" layer="51"/>
<wire x1="-1.725" y1="1.725" x2="1.725" y2="1.725" width="0.127" layer="51"/>
<wire x1="1.725" y1="1.725" x2="1.725" y2="-1.725" width="0.127" layer="51"/>
<wire x1="1.725" y1="-1.725" x2="-1.725" y2="-1.725" width="0.127" layer="51"/>
<wire x1="-1.725" y1="-1.725" x2="-1.725" y2="1.725" width="0.127" layer="51"/>
<wire x1="-1.8" y1="1.8" x2="1.8" y2="1.8" width="0.127" layer="21"/>
<wire x1="1.8" y1="1.8" x2="1.8" y2="0.4" width="0.127" layer="21"/>
<wire x1="-1.8" y1="1.8" x2="-1.8" y2="0.4" width="0.127" layer="21"/>
<wire x1="-1.8" y1="-0.4" x2="-1.8" y2="-1.8" width="0.127" layer="21"/>
<wire x1="-1.8" y1="-1.8" x2="1.8" y2="-1.8" width="0.127" layer="21"/>
<wire x1="1.8" y1="-1.8" x2="1.8" y2="-0.4" width="0.127" layer="21"/>
<wire x1="1.2" y1="0.125" x2="1.45" y2="0.125" width="0.1" layer="51"/>
<wire x1="1.45" y1="0.125" x2="1.45" y2="0.375" width="0.1" layer="51"/>
<wire x1="1.45" y1="0.375" x2="1.7" y2="0.375" width="0.1" layer="51"/>
<wire x1="1.7" y1="0.375" x2="1.7" y2="0.125" width="0.1" layer="51"/>
<wire x1="1.7" y1="0.125" x2="1.95" y2="0.125" width="0.1" layer="51"/>
<wire x1="1.95" y1="0.125" x2="1.95" y2="-0.125" width="0.1" layer="51"/>
<wire x1="1.95" y1="-0.125" x2="1.7" y2="-0.125" width="0.1" layer="51"/>
<wire x1="1.7" y1="-0.125" x2="1.7" y2="-0.375" width="0.1" layer="51"/>
<wire x1="1.7" y1="-0.375" x2="1.45" y2="-0.375" width="0.1" layer="51"/>
<wire x1="1.45" y1="-0.375" x2="1.45" y2="-0.125" width="0.1" layer="51"/>
<wire x1="1.45" y1="-0.125" x2="1.2" y2="-0.125" width="0.1" layer="51"/>
<wire x1="1.2" y1="-0.125" x2="1.2" y2="0.125" width="0.1" layer="51"/>
<rectangle x1="-2.05" y1="-0.25" x2="-1.15" y2="0.25" layer="1"/>
<rectangle x1="-2.1" y1="-0.3" x2="-1.15" y2="0.3" layer="29"/>
<rectangle x1="1.15" y1="-0.25" x2="2.05" y2="0.25" layer="1" rot="R180"/>
<rectangle x1="1.15" y1="-0.3" x2="2.1" y2="0.3" layer="29" rot="R180"/>
<rectangle x1="-0.6" y1="-1.6" x2="0.6" y2="1.6" layer="31"/>
<rectangle x1="-2" y1="-0.2" x2="-1.2" y2="0.2" layer="31"/>
<rectangle x1="-1.6" y1="0.2" x2="-1.2" y2="1.6" layer="31"/>
<rectangle x1="-1.6" y1="-1.6" x2="-1.2" y2="-0.2" layer="31"/>
<rectangle x1="1.2" y1="-0.2" x2="2" y2="0.2" layer="31"/>
<rectangle x1="1.2" y1="0.2" x2="1.6" y2="1.6" layer="31"/>
<rectangle x1="1.2" y1="-1.6" x2="1.6" y2="-0.2" layer="31"/>
<rectangle x1="-1.5" y1="-1.5" x2="-1.3" y2="-1.3" layer="51"/>
<rectangle x1="2.1" y1="0.6" x2="2.4" y2="1.8" layer="21"/>
<rectangle x1="-0.5" y1="-0.5" x2="0.5" y2="0.5" layer="51"/>
<smd name="ANODE" x="1.4" y="0" dx="0.5" dy="3.3" layer="1" cream="no"/>
<smd name="CATHODE" x="-1.4" y="0" dx="0.5" dy="3.3" layer="1" cream="no"/>
<smd name="THERMAL" x="0" y="0" dx="1.3" dy="3.3" layer="1" cream="no"/>
<text x="-1.862" y="2.027" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.762" y="-2.435" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
<polygon width="0.1524" layer="21">
<vertex x="2.346" y="1.2"/>
<vertex x="2.954" y="0.719"/>
<vertex x="2.954" y="1.681"/>
</polygon>
</package>
</packages>
<symbols>
<symbol name="MICROBUILDER_LED">
<wire x1="-2.54" y1="1.27" x2="-2.54" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-1.27" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-2.54" y2="1.27" width="0.254" layer="94"/>
<wire x1="0" y1="1.27" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-0.635" y1="1.27" x2="0.635" y2="2.54" width="0.254" layer="94"/>
<wire x1="-1.905" y1="1.27" x2="-0.635" y2="2.54" width="0.254" layer="94"/>
<wire x1="-0.9525" y1="2.8575" x2="-0.3175" y2="2.2225" width="0.254" layer="94"/>
<wire x1="-0.3175" y1="2.2225" x2="0" y2="3.175" width="0.254" layer="94"/>
<wire x1="0" y1="3.175" x2="-0.9525" y2="2.8575" width="0.254" layer="94"/>
<wire x1="0.3175" y1="2.8575" x2="0.9525" y2="2.2225" width="0.254" layer="94"/>
<wire x1="1.27" y1="3.175" x2="0.3175" y2="2.8575" width="0.254" layer="94"/>
<wire x1="0.9525" y1="2.2225" x2="1.27" y2="3.175" width="0.254" layer="94"/>
<pin name="A" x="-5.08" y="0" visible="off" length="short" direction="pas"/>
<pin name="C" x="2.54" y="0" visible="off" length="short" direction="pas" rot="R180"/>
<text x="-1.27" y="4.445" size="1.27" layer="95" align="center">&gt;NAME</text>
<text x="-1.27" y="-2.794" size="1.27" layer="96" align="center">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="MICROBUILDER_LED" prefix="D" uservalue="yes">
<description>&lt;p&gt;&lt;b&gt;LED&lt;/b&gt;&lt;/p&gt;
&lt;b&gt;0603&lt;/b&gt; - 0603 Surface Mount Package
&lt;hr&gt;
&lt;p&gt;&lt;b&gt;&lt;u&gt;2mA:&lt;/u&gt;&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Green LED - Low Power (3.9mcd, 2ma, 1.7Vf) - Digikey: 475-2709-2-ND&lt;/li&gt;
&lt;li&gt;Orange LED - Low Power (9.8mcd, 2ma, 1.8Vf) - Digikey: 475-1194-2-ND&lt;/li&gt;
&lt;li&gt;Red LED - Low Power (5mcd, 2ma, 1.8Vf) - Digikey: 475-1195-2-ND&lt;/li&gt;
&lt;li&gt;Yellow LED - Low Power (7mcd, 2ma, 1.8Vf) - Digikey: 475-1196-2-ND&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;&lt;b&gt;&lt;u&gt;5mA:&lt;/u&gt;&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Blue LED - Low Power (17mcd, 5ma, 2.9Vf) - Digikey: LNJ937W8CRACT-ND&lt;/li&gt;
&lt;/ul&gt;
&lt;b&gt;0805&lt;/b&gt; - 0805 Surface Mount Package
&lt;hr&gt;
&lt;p&gt;&lt;b&gt;&lt;u&gt;2mA:&lt;/u&gt;&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Red LED (8.8mcd, 2mA, 1.8Vf, Clear) - Low Power [Digikey: 475-2510-1-ND]&lt;/li&gt;
&lt;li&gt;Green LED (5mcd, 2mA, 1.8Vf, Clear) - Low Power [Digikey: 475-2730-1-ND]&lt;/li&gt;
&lt;li&gt;Yellow LED (11.3mcd, 2mA, 1.8Vf, Clear) - Low Power [Digikey: 475-2555-1-ND]&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;&lt;b&gt;&lt;u&gt;20mA:&lt;/u&gt;&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Red LED (104mcd, 20mA, Diffused) - LS R976 [Digikey: 475-1278-6-ND]&lt;/li&gt;
&lt;li&gt;Red LED (12mcd, 20mA, 2.0Vf, Clear) - APT2012EC [Digikey: 754-1128-1-ND]&lt;/li&gt;
&lt;li&gt;Green LED (15mcd, 20mA, 2.2Vf, Clear) - APT2012GC [Digikey: 754-1131-1-ND]&lt;/li&gt;
&lt;li&gt;Orange LED (160mcd, 20mA, 2.1Vf, Clear) - APT2012SECK [Digikey: 754-1130-1-ND]&lt;/li&gt;
&lt;/ul&gt;
&lt;li&gt;&lt;b&gt;1206&lt;/b&gt; - 1206 Surface Mount Package
&lt;hr&gt;
&lt;ul&gt;
&lt;li&gt;Green LED (26mcd, 20mA, Diffused) - LG N971  [Digikey: 475-1407-6-ND]&lt;/li&gt;
&lt;li&gt;Red LED (15mcd, 20mA, Diffused) - LH N974 [Digikey: 475-1416-6-ND]&lt;/li&gt;
&lt;/ul&gt;

&lt;li&gt;&lt;b&gt;Cree&lt;/b&gt; - Cree High-Power Surface Mount LEDs
&lt;hr&gt;
&lt;ul&gt;
&lt;li&gt;XPEBWT-L1-0000-00D50 - White 111lm 350mA 2.9Vf 6200K 110°&lt;/li&gt;
&lt;li&gt;XTEAWT-00-0000-00000LEE3 - White 114lm 350mA 2.85Vf 5000K 115°&lt;/li&gt;
&lt;/ul&gt;

&lt;li&gt;&lt;b&gt;Everlight&lt;/b&gt; - Everlight 45-21 Series Surface Mount LEDs
&lt;hr&gt;
&lt;ul&gt;
&lt;li&gt;45-21/QK2C-B2832AC2CB2/2T - Warm White 2000mcd 20mA 3.25Vf 3050K 120°&lt;/li&gt;
&lt;li&gt;45-21/LK2C-B38452C4CB2/2T - Nuetral White 2000mcd 20mA 3.25Vf 4150K 120°&lt;/li&gt;
&lt;li&gt;45-21/LK2C-B50634C6CB2/2T - Cold White 2200mcd 20mA 3.25Vf 5650K 120°&lt;/li&gt;
&lt;/ul&gt;

&lt;li&gt;&lt;b&gt;PLCC2 Reverse Mount&lt;/b&gt;
&lt;hr&gt;
&lt;ul&gt;
&lt;li&gt;LS T77K-J1L2-1-0-2-R18-Z - Red 11.25mcd 2mA 1.8Vf 630nm 120°&lt;/li&gt;
&lt;li&gt;LO T77K-L1M2-24-Z - Orange 19.6mcd 2mA 1.8Vf 606nm 120°&lt;/li&gt;
&lt;li&gt;LY T77K-K2M1-26-Z - Yellow 15.7mcd 2mA 1.8Vf 587nm 120°&lt;/li&gt;
&lt;/ul&gt;</description>
<gates>
<gate name="G$1" symbol="MICROBUILDER_LED" x="0" y="0"/>
</gates>
<devices>
<device name="0603" package="MICROBUILDER_CHIPLED_0603">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0603_NOOUTLINE" package="MICROBUILDER_CHIPLED_0603_NOOUTLINE">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805" package="MICROBUILDER_CHIPLED_0805">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805_NOOUTLINE" package="MICROBUILDER_CHIPLED_0805_NOOUTLINE">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1206" package="MICROBUILDER_CHIPLED_1206">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="EV45-21" package="MICROBUILDER_EVERLIGHT_45-21">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PLCC2_REV" package="MICROBUILDER_PLCC2_REVMOUNT">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="XPE2" package="MICROBUILDER_CREE_XLAMP_XPE2">
<connects>
<connect gate="G$1" pin="A" pad="ANODE"/>
<connect gate="G$1" pin="C" pad="CATHODE"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="XTE" package="MICROBUILDER_CREE_XLAMP_XTE">
<connects>
<connect gate="G$1" pin="A" pad="ANODE"/>
<connect gate="G$1" pin="C" pad="CATHODE"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="2173157-3">
<packages>
<package name="CONN_2173157-3">
<wire x1="-4.1" y1="0.5" x2="-4.1" y2="-4.65" width="0.127" layer="51"/>
<wire x1="-4.1" y1="-4.65" x2="4.1" y2="-4.65" width="0.127" layer="51"/>
<wire x1="4.1" y1="-4.65" x2="4.1" y2="0.5" width="0.127" layer="51"/>
<wire x1="4.1" y1="0.5" x2="-4.1" y2="0.5" width="0.127" layer="51"/>
<wire x1="-4.1" y1="0.501" x2="-4.1" y2="-4.65" width="0.127" layer="21"/>
<wire x1="-4.1" y1="-4.65" x2="4.1" y2="-4.65" width="0.127" layer="21"/>
<wire x1="4.1" y1="-4.65" x2="4.1" y2="0.501" width="0.127" layer="21"/>
<wire x1="-4.35" y1="0.9" x2="-4.35" y2="-4.9" width="0.05" layer="39"/>
<wire x1="-4.35" y1="-4.9" x2="4.35" y2="-4.9" width="0.05" layer="39"/>
<wire x1="4.35" y1="-4.9" x2="4.35" y2="0.9" width="0.05" layer="39"/>
<wire x1="4.35" y1="0.9" x2="-4.35" y2="0.9" width="0.05" layer="39"/>
<text x="-4.500109375" y="1.09826875" size="0.800196875" layer="25">&gt;NAME</text>
<text x="-4.49086875" y="-5.7203" size="0.801584375" layer="27">&gt;VALUE</text>
<smd name="1" x="-1.3" y="0" dx="1.3" dy="0.5" layer="1" rot="R90"/>
<smd name="2" x="-0.65" y="0" dx="1.3" dy="0.5" layer="1" rot="R90"/>
<smd name="3" x="0" y="0" dx="1.3" dy="0.5" layer="1" rot="R90"/>
<smd name="4" x="0.65" y="0" dx="1.3" dy="0.5" layer="1" rot="R90"/>
<smd name="5" x="1.3" y="0" dx="1.3" dy="0.5" layer="1" rot="R90"/>
<smd name="S1" x="-3.075" y="0" dx="1.75" dy="1.3" layer="1"/>
<smd name="S2" x="3.075" y="0" dx="1.75" dy="1.3" layer="1"/>
<smd name="S3" x="-2.075" y="-1.95" dx="2.25" dy="2.3" layer="1"/>
<smd name="S4" x="2.075" y="-1.95" dx="2.25" dy="2.3" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="2173157-3">
<wire x1="5.08" y1="10.16" x2="5.08" y2="-10.16" width="0.254" layer="94"/>
<wire x1="5.08" y1="-10.16" x2="-5.08" y2="-10.16" width="0.254" layer="94"/>
<wire x1="-5.08" y1="-10.16" x2="-5.08" y2="10.16" width="0.254" layer="94"/>
<wire x1="-5.08" y1="10.16" x2="5.08" y2="10.16" width="0.254" layer="94"/>
<text x="-5.34346875" y="10.6869" size="1.8032" layer="95">&gt;NAME</text>
<text x="-5.338990625" y="-12.2034" size="1.80168125" layer="96">&gt;VALUE</text>
<pin name="1" x="10.16" y="7.62" length="middle" direction="pas" rot="R180"/>
<pin name="2" x="10.16" y="5.08" length="middle" direction="pas" rot="R180"/>
<pin name="3" x="10.16" y="2.54" length="middle" direction="pas" rot="R180"/>
<pin name="4" x="10.16" y="0" length="middle" direction="pas" rot="R180"/>
<pin name="5" x="10.16" y="-2.54" length="middle" direction="pas" rot="R180"/>
<pin name="SHIELD" x="10.16" y="-7.62" length="middle" direction="pas" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="2173157-3" prefix="J">
<description>Conn Micro USB 2.0 Type B RCP 5 POS 0.65mm Solder RA SMD 5 Terminal 1 Port T/R &lt;a href="https://pricing.snapeda.com/search/part/2173157-3/?ref=eda"&gt;Check prices&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="2173157-3" x="0" y="0"/>
</gates>
<devices>
<device name="" package="CONN_2173157-3">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="SHIELD" pad="S1 S2 S3 S4"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="Good"/>
<attribute name="CENTERLINE_PITCH" value=".65 mm[.025 in]"/>
<attribute name="COMMENT" value="2173157-3"/>
<attribute name="DESCRIPTION" value=" Conn Micro USB 2.0 Type B RCP 5 POS 0.65mm Solder RA SMD 5 Terminal 1 Port T/R "/>
<attribute name="EU_ROHS_COMPLIANCE" value="Compliant"/>
<attribute name="MF" value="TE Connectivity"/>
<attribute name="MP" value="2173157-3"/>
<attribute name="NUMBER_OF_POSITIONS" value="5"/>
<attribute name="PACKAGE" value="None"/>
<attribute name="PRICE" value="None"/>
<attribute name="PRODUCT_TYPE" value="Connector"/>
<attribute name="PURCHASE-URL" value="https://pricing.snapeda.com/search/part/2173157-3/?ref=eda"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="CSTNE8M00GH5C000R0">
<packages>
<package name="OSC_CSTNE8M00GH5C000R0">
<wire x1="-1.6" y1="0.65" x2="1.6" y2="0.65" width="0.127" layer="51"/>
<wire x1="1.6" y1="-0.65" x2="-1.6" y2="-0.65" width="0.127" layer="51"/>
<wire x1="-1.85" y1="1.2" x2="1.85" y2="1.2" width="0.05" layer="39"/>
<wire x1="1.85" y1="1.2" x2="1.85" y2="-1.2" width="0.05" layer="39"/>
<wire x1="1.85" y1="-1.2" x2="-1.85" y2="-1.2" width="0.05" layer="39"/>
<wire x1="-1.85" y1="-1.2" x2="-1.85" y2="1.2" width="0.05" layer="39"/>
<circle x="-2.22" y="0" radius="0.1" width="0.2" layer="21"/>
<wire x1="-1.6" y1="0.65" x2="-1.6" y2="-0.65" width="0.127" layer="51"/>
<wire x1="1.6" y1="0.65" x2="1.6" y2="-0.65" width="0.127" layer="51"/>
<circle x="-2.22" y="0" radius="0.1" width="0.2" layer="51"/>
<text x="-2" y="1.3" size="0.8128" layer="25">&gt;NAME</text>
<text x="-2" y="-1.3" size="0.8128" layer="27" align="top-left">&gt;VALUE</text>
<wire x1="-1.72" y1="0.65" x2="-1.72" y2="-0.65" width="0.127" layer="21"/>
<wire x1="1.72" y1="0.65" x2="1.72" y2="-0.65" width="0.127" layer="21"/>
<smd name="1" x="-1.2" y="0" dx="0.4" dy="1.9" layer="1"/>
<smd name="2" x="0" y="0" dx="0.4" dy="1.9" layer="1"/>
<smd name="3" x="1.2" y="0" dx="0.4" dy="1.9" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="CSTNE8M00GH5C000R0">
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="0" y2="-5.08" width="0.254" layer="94"/>
<wire x1="0" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="2.54" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="-1.27" y1="3.81" x2="-1.27" y2="2.54" width="0.254" layer="94"/>
<wire x1="-1.27" y1="2.54" x2="-1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="-0.635" y1="1.27" x2="-0.635" y2="3.81" width="0.254" layer="94"/>
<wire x1="-0.635" y1="3.81" x2="0.635" y2="3.81" width="0.254" layer="94"/>
<wire x1="0.635" y1="3.81" x2="0.635" y2="1.27" width="0.254" layer="94"/>
<wire x1="0.635" y1="1.27" x2="-0.635" y2="1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="3.81" x2="1.27" y2="2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="2.54" x2="1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="-2.8575" y1="-1.5875" x2="-2.8575" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-2.8575" y1="-2.54" x2="-2.8575" y2="-3.4925" width="0.254" layer="94"/>
<wire x1="-2.2225" y1="-1.5875" x2="-2.2225" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-2.2225" y1="-2.54" x2="-2.2225" y2="-3.4925" width="0.254" layer="94"/>
<wire x1="2.54" y1="-1.5875" x2="2.54" y2="-2.54" width="0.254" layer="94"/>
<wire x1="2.54" y1="-2.54" x2="2.54" y2="-3.4925" width="0.254" layer="94"/>
<wire x1="3.175" y1="-1.5875" x2="3.175" y2="-2.54" width="0.254" layer="94"/>
<wire x1="3.175" y1="-2.54" x2="3.175" y2="-3.4925" width="0.254" layer="94"/>
<wire x1="-7.62" y1="2.54" x2="-5.08" y2="2.54" width="0.254" layer="94"/>
<wire x1="-5.08" y1="2.54" x2="-1.27" y2="2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="2.54" x2="5.08" y2="2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="-2.8575" y1="-2.54" x2="-5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-5.08" y1="-2.54" x2="-5.08" y2="2.54" width="0.254" layer="94"/>
<wire x1="3.175" y1="-2.54" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="-2.54" x2="5.08" y2="2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-5.08" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-2.2225" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="2.54" y2="-2.54" width="0.254" layer="94"/>
<text x="-7.62" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="1.27" y="-6.35" size="1.778" layer="96" rot="MR180">&gt;VALUE</text>
<pin name="IN" x="-12.7" y="2.54" visible="pad" length="middle" direction="in"/>
<pin name="OUT" x="12.7" y="2.54" visible="pad" length="middle" direction="out" rot="R180"/>
<pin name="GND" x="0" y="-10.16" visible="pad" length="middle" direction="pwr" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="CSTNE8M00GH5C000R0" prefix="Y">
<description>8MHz Ceramic Resonator Built in Capacitor 33pF ±0.13% 40 Ohms -40°C ~ 125°C Surface Mount  &lt;a href="https://pricing.snapeda.com/search/part/CSTNE8M00GH5C000R0/?ref=eda"&gt;Check prices&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="CSTNE8M00GH5C000R0" x="0" y="0"/>
</gates>
<devices>
<device name="" package="OSC_CSTNE8M00GH5C000R0">
<connects>
<connect gate="G$1" pin="GND" pad="2"/>
<connect gate="G$1" pin="IN" pad="1"/>
<connect gate="G$1" pin="OUT" pad="3"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="Good"/>
<attribute name="DESCRIPTION" value=" 8MHz Ceramic Resonator Built in Capacitor 33pF ±0.13% 40 Ohms -40°C ~ 125°C Surface Mount "/>
<attribute name="MF" value="Murata"/>
<attribute name="MP" value="CSTNE8M00GH5C000R0"/>
<attribute name="PACKAGE" value="SMD-3 Murata"/>
<attribute name="PRICE" value="None"/>
<attribute name="PURCHASE-URL" value="https://pricing.snapeda.com/search/part/CSTNE8M00GH5C000R0/?ref=eda"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
<attribute name="COMPANY" value="Hardware Art"/>
<attribute name="DRAWN" value="SMT"/>
<attribute name="REV" value="A"/>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0.19" drill="0.19">
</class>
</classes>
<parts>
<part name="C6" library="microbuilder" deviceset="CAP_CERAMIC" device="0805-NOOUTLINE" value="10µF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="08053D106KAT2A"/>
<attribute name="OC_NEWARK" value="37T9053"/>
</part>
<part name="C7" library="microbuilder" deviceset="CAP_CERAMIC" device="0603_NO" value="1uF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="02016D104KAT2A"/>
<attribute name="OC_NEWARK" value="85K9474"/>
</part>
<part name="U$27" library="microbuilder" deviceset="GND" device=""/>
<part name="U$28" library="microbuilder" deviceset="GND" device=""/>
<part name="C8" library="microbuilder" deviceset="CAP_CERAMIC" device="0805-NOOUTLINE" value="10µF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="08053D106KAT2A"/>
<attribute name="OC_NEWARK" value="37T9053"/>
</part>
<part name="U$29" library="microbuilder" deviceset="GND" device=""/>
<part name="U$30" library="microbuilder" deviceset="GND" device=""/>
<part name="R4" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="22">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="R5" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="22">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="GND1" library="supply1" deviceset="GND" device=""/>
<part name="GND2" library="supply1" deviceset="GND" device=""/>
<part name="C9" library="microbuilder" deviceset="CAP_CERAMIC" device="_0805MP" value="10uF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="08053D106KAT2A"/>
<attribute name="OC_NEWARK" value="37T9053"/>
</part>
<part name="GND3" library="supply1" deviceset="GND" device=""/>
<part name="GND6" library="supply1" deviceset="GND" device=""/>
<part name="GND12" library="supply1" deviceset="GND" device=""/>
<part name="GND7" library="supply1" deviceset="GND" device=""/>
<part name="IC1" library="microbuilder" deviceset="ATMEGA32U4" device="-MU" value="ATMEGA32U4-MU">
<attribute name="MF" value="MICROCHIP"/>
<attribute name="MPN" value="ATMEGA32U4-MU"/>
<attribute name="OC_NEWARK" value="15AC6077"/>
</part>
<part name="C14" library="microbuilder" deviceset="CAP_CERAMIC" device="0603_NO" value="1uF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="02016D104KAT2A"/>
<attribute name="OC_NEWARK" value="85K9474"/>
</part>
<part name="+3V4" library="supply1" deviceset="+3V3" device=""/>
<part name="+3V5" library="supply1" deviceset="+3V3" device=""/>
<part name="+3V6" library="supply1" deviceset="+3V3" device=""/>
<part name="+3V7" library="supply1" deviceset="+3V3" device=""/>
<part name="U$1" library="microbuilder" deviceset="VBUS" device=""/>
<part name="U$3" library="microbuilder" deviceset="VBUS" device=""/>
<part name="U$8" library="microbuilder" deviceset="VBUS" device=""/>
<part name="U2" library="microbuilder" deviceset="VREG_SOT23-5" device="" value="AP2112-3.3K">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="D4" library="microbuilder" deviceset="DIODE-SCHOTTKY" device="SOD-123" value="MBR120">
<attribute name="MF" value="ON SEMICONDUCTOR"/>
<attribute name="MPN" value="MBR120VLSFT1G"/>
<attribute name="OC_NEWARK" value="10N9424"/>
</part>
<part name="U3" library="microbuilder" deviceset="MCP73831/2" device="" value="MCP73831T-2ACI/OT">
<attribute name="MF" value="MICROCHIP"/>
<attribute name="MPN" value="MCP73831T-2ACI/OT"/>
<attribute name="OC_NEWARK" value="56K7045"/>
</part>
<part name="CHG" library="microbuilder" deviceset="LED" device="0805_NOOUTLINE" value="ORANGE">
<attribute name="MF" value="KINGBRIGHT"/>
<attribute name="MPN" value="KPT-2012SECK"/>
<attribute name="OC_NEWARK" value="93T1600"/>
</part>
<part name="R2" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="1K">
<attribute name="MF" value="PANASONIC"/>
<attribute name="MPN" value="ERJ3EKF1001V"/>
<attribute name="OC_NEWARK" value="85Y8498"/>
</part>
<part name="C3" library="microbuilder" deviceset="CAP_CERAMIC" device="0805-NOOUTLINE" value="10µF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="08053D106KAT2A"/>
<attribute name="OC_NEWARK" value="37T9053"/>
</part>
<part name="U$33" library="microbuilder" deviceset="GND" device=""/>
<part name="R8" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="2.2K">
<attribute name="MF" value="YAGEO"/>
<attribute name="MPN" value="RC0603FR-072K2L."/>
<attribute name="OC_NEWARK" value="75X0144"/>
</part>
<part name="U$36" library="microbuilder" deviceset="GND" device=""/>
<part name="U$38" library="microbuilder" deviceset="VBUS" device=""/>
<part name="U$39" library="microbuilder" deviceset="VBAT" device=""/>
<part name="U$12" library="microbuilder" deviceset="GND" device=""/>
<part name="NETSTAT2" library="microbuilder" deviceset="LED" device="0805_NOOUTLINE" value="GREEN">
<attribute name="MF" value="KINGBRIGHT"/>
<attribute name="MPN" value="KPT-2012ZGCK"/>
<attribute name="OC_NEWARK" value="27X9140"/>
</part>
<part name="NETSTAT1" library="microbuilder" deviceset="LED" device="0805_NOOUTLINE" value="BLUE">
<attribute name="MF" value="KINGBRIGHT"/>
<attribute name="MPN" value="KPT-2012LVVBC-D"/>
<attribute name="OC_NEWARK" value="94Y5933"/>
</part>
<part name="U$10" library="microbuilder" deviceset="GND" device=""/>
<part name="R1" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="1K">
<attribute name="MF" value="PANASONIC"/>
<attribute name="MPN" value="ERJ3EKF1001V"/>
<attribute name="OC_NEWARK" value="85Y8498"/>
</part>
<part name="R3" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="1K">
<attribute name="MF" value="PANASONIC"/>
<attribute name="MPN" value="ERJ3EKF1001V"/>
<attribute name="OC_NEWARK" value="85Y8498"/>
</part>
<part name="U$13" library="microbuilder" deviceset="GND" device=""/>
<part name="D5" library="microbuilder" deviceset="DIODE-ZENER" device="SOD123" value="MMSZ5231BT1G">
<attribute name="MF" value="ON SEMICONDUCTOR"/>
<attribute name="MPN" value="MMSZ5231BT1G"/>
<attribute name="OC_NEWARK" value="83H7426"/>
</part>
<part name="U$26" library="microbuilder" deviceset="GND" device=""/>
<part name="C5" library="microbuilder" deviceset="CAP_CERAMIC" device="0805-NOOUTLINE" value="10pF">
<attribute name="MF" value="KEMET"/>
<attribute name="MPN" value="C0805C100D5GACTU"/>
<attribute name="OC_NEWARK" value="07X0850"/>
</part>
<part name="C2" library="microbuilder" deviceset="CAP_CERAMIC" device="0805-NOOUTLINE" value="33pF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="04025A330JAT2A"/>
<attribute name="OC_NEWARK" value="96M1150"/>
</part>
<part name="C4" library="rcl" deviceset="C-US" device="C1210" value="100uF">
<attribute name="MF" value="KEMET"/>
<attribute name="MPN" value="C1210C107M8PACTU"/>
<attribute name="OC_NEWARK" value="87X8674"/>
</part>
<part name="U$37" library="microbuilder" deviceset="VBAT" device=""/>
<part name="X4" library="microbuilder" deviceset="ANTENNA_U.FL" device="" value="uFL">
<attribute name="MF" value="HIROSE(HRS)"/>
<attribute name="MPN" value="U.FL-R-SMT-1(10)"/>
<attribute name="OC_NEWARK" value="50P8856"/>
</part>
<part name="R6" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="100k">
<attribute name="MF" value="MULTICOMP PRO"/>
<attribute name="MPN" value="MCWR06X1003FTL"/>
<attribute name="OC_NEWARK" value="94X1381"/>
</part>
<part name="U4" library="LARA-R2" deviceset="LARA-R2" device="">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="U5" library="MAX9860ETG_" deviceset="MAX9860ETG+" device="">
<attribute name="MF" value="MAXIM INTEGRATED PRODUCTS"/>
<attribute name="MPN" value="MAX9860ETG+"/>
<attribute name="OC_NEWARK" value="99AC0368"/>
</part>
<part name="U$6" library="microbuilder" deviceset="GND" device=""/>
<part name="U$4" library="microbuilder" deviceset="GND" device=""/>
<part name="R9" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="2.2K">
<attribute name="MF" value="YAGEO"/>
<attribute name="MPN" value="RC0603FR-072K2L."/>
<attribute name="OC_NEWARK" value="75X0144"/>
</part>
<part name="C1" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="1.0µF">
<spice>
<pinmapping spiceprefix="C">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
<attribute name="MF" value="KEMET"/>
<attribute name="MPN" value="T491A225K016AT"/>
<attribute name="OC_NEWARK" value="97H5553"/>
</part>
<part name="C10" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="1.0µF">
<spice>
<pinmapping spiceprefix="C">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="02016D104KAT2A"/>
<attribute name="OC_NEWARK" value="85K9474"/>
</part>
<part name="C11" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="1.0µF">
<spice>
<pinmapping spiceprefix="C">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="02016D104KAT2A"/>
<attribute name="OC_NEWARK" value="85K9474"/>
</part>
<part name="C12" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0603(1608-METRIC)" package3d_urn="urn:adsk.eagle:package:16290898/2" technology="_" value="2.2µF">
<spice>
<pinmapping spiceprefix="C">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
<attribute name="MF" value="KEMET"/>
<attribute name="MPN" value="T491A225K016AT"/>
<attribute name="OC_NEWARK" value="97H5553"/>
</part>
<part name="U$7" library="microbuilder" deviceset="GND" device=""/>
<part name="R11" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="10K">
<attribute name="MF" value="VISHAY"/>
<attribute name="MPN" value="CRCW060310K0FKEA"/>
<attribute name="OC_NEWARK" value="52K8063"/>
</part>
<part name="R12" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="4.7K">
<attribute name="MF" value="PANASONIC"/>
<attribute name="MPN" value="ERJ-3EKF4701V"/>
<attribute name="OC_NEWARK" value="64R5349"/>
</part>
<part name="R13" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="4.7K">
<attribute name="MF" value="PANASONIC"/>
<attribute name="MPN" value="ERJ-3EKF4701V"/>
<attribute name="OC_NEWARK" value="64R5349"/>
</part>
<part name="C13" library="microbuilder" deviceset="CAP_CERAMIC" device="0805-NOOUTLINE" value="100nF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="08055C104KAT2A"/>
<attribute name="OC_NEWARK" value="95W1480"/>
</part>
<part name="C15" library="microbuilder" deviceset="CAP_CERAMIC" device="0805-NOOUTLINE" value="10µF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="08053D106KAT2A"/>
<attribute name="OC_NEWARK" value="37T9053"/>
</part>
<part name="C16" library="microbuilder" deviceset="CAP_CERAMIC" device="0805-NOOUTLINE" value="10µF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="08053D106KAT2A"/>
<attribute name="OC_NEWARK" value="37T9053"/>
</part>
<part name="U$5" library="microbuilder" deviceset="GND" device=""/>
<part name="U$11" library="microbuilder" deviceset="GND" device=""/>
<part name="U$18" library="microbuilder" deviceset="GND" device=""/>
<part name="C17" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="1.0µF">
<spice>
<pinmapping spiceprefix="C">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="02016D104KAT2A"/>
<attribute name="OC_NEWARK" value="85K9474"/>
</part>
<part name="C18" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="1.0µF">
<spice>
<pinmapping spiceprefix="C">
<pinmap gate="G$1" pin="1" pinorder="1"/>
<pinmap gate="G$1" pin="2" pinorder="2"/>
</pinmapping>
</spice>
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="02016D104KAT2A"/>
<attribute name="OC_NEWARK" value="85K9474"/>
</part>
<part name="R14" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="1.2K">
<attribute name="MF" value="VISHAY"/>
<attribute name="MPN" value="CRCW06031K20FKEA"/>
<attribute name="OC_NEWARK" value="52K8025"/>
</part>
<part name="JP2" library="jumper" library_urn="urn:adsk.eagle:library:252" deviceset="JP1E" device="" package3d_urn="urn:adsk.eagle:package:15455/1">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="JP4" library="jumper" library_urn="urn:adsk.eagle:library:252" deviceset="JP1E" device="" package3d_urn="urn:adsk.eagle:package:15455/1">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="U$23" library="microbuilder" deviceset="GND" device=""/>
<part name="JP5" library="jumper" library_urn="urn:adsk.eagle:library:252" deviceset="JP1E" device="" package3d_urn="urn:adsk.eagle:package:15455/1">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="S1" library="PCM13SMTR" deviceset="PCM13SMTR" device="">
<attribute name="MF" value="C &amp; K COMPONENTS"/>
<attribute name="MPN" value="PCM13SMTR"/>
<attribute name="OC_NEWARK" value="35AH4616"/>
</part>
<part name="D1" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE" device="DO-214AA(SMB)" package3d_urn="urn:adsk.eagle:package:16378189/1" value="DIODE">
<spice>
<pinmapping spiceprefix="D">
<pinmap gate="G$1" pin="A" pinorder="1"/>
<pinmap gate="G$1" pin="C" pinorder="2"/>
</pinmapping>
<model name="DMOD">
**********************
* Autodesk EAGLE - Spice Model File
* Date: 9/17/17
* basic diode intrinsic model
**********************
.MODEL DMOD D</model>
</spice>
<attribute name="MF" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="D3" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE" device="DO-214AA(SMB)" package3d_urn="urn:adsk.eagle:package:16378189/1" value="DIODE">
<spice>
<pinmapping spiceprefix="D">
<pinmap gate="G$1" pin="A" pinorder="1"/>
<pinmap gate="G$1" pin="C" pinorder="2"/>
</pinmapping>
<model name="DMOD">
**********************
* Autodesk EAGLE - Spice Model File
* Date: 9/17/17
* basic diode intrinsic model
**********************
.MODEL DMOD D</model>
</spice>
<attribute name="MF" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="D7" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE" device="DO-214AA(SMB)" package3d_urn="urn:adsk.eagle:package:16378189/1" value="DIODE">
<spice>
<pinmapping spiceprefix="D">
<pinmap gate="G$1" pin="A" pinorder="1"/>
<pinmap gate="G$1" pin="C" pinorder="2"/>
</pinmapping>
<model name="DMOD">
**********************
* Autodesk EAGLE - Spice Model File
* Date: 9/17/17
* basic diode intrinsic model
**********************
.MODEL DMOD D</model>
</spice>
<attribute name="MF" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="D9" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE" device="DO-214AA(SMB)" package3d_urn="urn:adsk.eagle:package:16378189/1" value="DIODE">
<spice>
<pinmapping spiceprefix="D">
<pinmap gate="G$1" pin="A" pinorder="1"/>
<pinmap gate="G$1" pin="C" pinorder="2"/>
</pinmapping>
<model name="DMOD">
**********************
* Autodesk EAGLE - Spice Model File
* Date: 9/17/17
* basic diode intrinsic model
**********************
.MODEL DMOD D</model>
</spice>
<attribute name="MF" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="D11" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE" device="DO-214AA(SMB)" package3d_urn="urn:adsk.eagle:package:16378189/1" value="DIODE">
<spice>
<pinmapping spiceprefix="D">
<pinmap gate="G$1" pin="A" pinorder="1"/>
<pinmap gate="G$1" pin="C" pinorder="2"/>
</pinmapping>
<model name="DMOD">
**********************
* Autodesk EAGLE - Spice Model File
* Date: 9/17/17
* basic diode intrinsic model
**********************
.MODEL DMOD D</model>
</spice>
<attribute name="MF" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="D12" library="Diode" library_urn="urn:adsk.eagle:library:16378169" deviceset="DIODE" device="DO-214AA(SMB)" package3d_urn="urn:adsk.eagle:package:16378189/1" value="DIODE">
<spice>
<pinmapping spiceprefix="D">
<pinmap gate="G$1" pin="A" pinorder="1"/>
<pinmap gate="G$1" pin="C" pinorder="2"/>
</pinmapping>
<model name="DMOD">
**********************
* Autodesk EAGLE - Spice Model File
* Date: 9/17/17
* basic diode intrinsic model
**********************
.MODEL DMOD D</model>
</spice>
<attribute name="MF" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="GND4" library="supply1" deviceset="GND" device=""/>
<part name="LED1" library="led" library_urn="urn:adsk.eagle:library:259" deviceset="LUXEON_REBEL" device="" package3d_urn="urn:adsk.eagle:package:15855/1"/>
<part name="U$2" library="microbuilder" deviceset="GND" device=""/>
<part name="X1" library="con-coax" library_urn="urn:adsk.eagle:library:133" deviceset="BU-SMA-H" device="" package3d_urn="urn:adsk.eagle:package:6206/1"/>
<part name="U$25" library="microbuilder" deviceset="GND" device=""/>
<part name="+3V1" library="supply1" deviceset="+3V3" device=""/>
<part name="U$32" library="microbuilder" deviceset="GND" device=""/>
<part name="U$34" library="microbuilder" deviceset="GND" device=""/>
<part name="R15" library="CRM2512-JZ-R047ELF" deviceset="CRM2512-JZ-R047ELF" device="">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="+3V8" library="supply1" deviceset="+3V3" device=""/>
<part name="U$19" library="microbuilder" deviceset="GND" device=""/>
<part name="U$20" library="microbuilder" deviceset="GND" device=""/>
<part name="C21" library="microbuilder" deviceset="CAP_CERAMIC" device="_0402" value="100nF">
<attribute name="MF" value="TDK"/>
<attribute name="MPN" value="C1005X7R1C104K050BC"/>
<attribute name="OC_NEWARK" value="90R7598"/>
</part>
<part name="U$22" library="microbuilder" deviceset="GND" device=""/>
<part name="U$24" library="microbuilder" deviceset="GND" device=""/>
<part name="C19" library="microbuilder" deviceset="CAP_CERAMIC" device="_0402" value="100nF">
<attribute name="MF" value="TDK"/>
<attribute name="MPN" value="C1005X7R1C104K050BC"/>
<attribute name="OC_NEWARK" value="90R7598"/>
</part>
<part name="Q5" library="Arduino-transistors" deviceset="2N7002DW-7-F" device="NO_PAD">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="GND66" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="R7" library="Arduino-rcl" deviceset="R" device="-0402" technology="-1M2" value="1M2">
<attribute name="MF" value="MULTICOMP PRO"/>
<attribute name="MPN" value="MCHVR02FTFY1204"/>
<attribute name="OC_NEWARK" value="46AC9958"/>
</part>
<part name="GND67" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="R16" library="Arduino-rcl" deviceset="R" device="-0402" technology="-1M2" value="1M2">
<attribute name="MF" value="MULTICOMP PRO"/>
<attribute name="MPN" value="MCHVR02FTFY1204"/>
<attribute name="OC_NEWARK" value="46AC9958"/>
</part>
<part name="GND5" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="GND47" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="JP1" library="jumper" library_urn="urn:adsk.eagle:library:252" deviceset="JP1E" device="" package3d_urn="urn:adsk.eagle:package:15455/1">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="JP3" library="jumper" library_urn="urn:adsk.eagle:library:252" deviceset="JP1E" device="" package3d_urn="urn:adsk.eagle:package:15455/1">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="C25" library="microbuilder" deviceset="CAP_CERAMIC" device="_0402" value="8.2pF">
<attribute name="MF" value="NIC COMPONENTS"/>
<attribute name="MPN" value="NMC0402NPO8R2C50TRPF"/>
<attribute name="OC_NEWARK" value="18AH4170"/>
</part>
<part name="C26" library="microbuilder" deviceset="CAP_CERAMIC" device="_0402" value="15pF">
<attribute name="MF" value="MULTICOMP PRO"/>
<attribute name="MPN" value="MCMT15N150F500CT"/>
<attribute name="OC_NEWARK" value="03AC2879"/>
</part>
<part name="C27" library="microbuilder" deviceset="CAP_CERAMIC" device="_0402" value="68pF">
<attribute name="MF" value="KEMET"/>
<attribute name="MPN" value="C0603C680J3GACAUTO"/>
<attribute name="OC_NEWARK" value="77Y7549"/>
</part>
<part name="C28" library="microbuilder" deviceset="CAP_CERAMIC" device="_0402" value="10nF">
<attribute name="MF" value="AVX"/>
<attribute name="MPN" value="06035C103KAT2A"/>
<attribute name="OC_NEWARK" value="36K3729"/>
</part>
<part name="C29" library="microbuilder" deviceset="CAP_CERAMIC" device="_0402" value="100nF">
<attribute name="MF" value="TDK"/>
<attribute name="MPN" value="C1005X7R1C104K050BC"/>
<attribute name="OC_NEWARK" value="90R7598"/>
</part>
<part name="C31" library="rcl" deviceset="C-US" device="C1210" value="330uF">
<attribute name="MF" value="MURATA"/>
<attribute name="MPN" value="GRM32EC80E337ME05L"/>
<attribute name="OC_NEWARK" value="01AC8870"/>
</part>
<part name="U$44" library="microbuilder" deviceset="GND" device=""/>
<part name="J1" library="SJ2-35984E-SMT-TR" deviceset="SJ2-35984E-SMT-TR" device="">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="LS1" library="CMS-151135-078S-67" deviceset="CMS-151135-078S-67" device="">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="SV1" library="con-lstb" library_urn="urn:adsk.eagle:library:162" deviceset="MA08-2" device="" package3d_urn="urn:adsk.eagle:package:8335/1"/>
<part name="U$45" library="microbuilder" deviceset="GND" device=""/>
<part name="JP6" library="jumper" library_urn="urn:adsk.eagle:library:252" deviceset="JP1E" device="" package3d_urn="urn:adsk.eagle:package:15455/1">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="JP7" library="jumper" library_urn="urn:adsk.eagle:library:252" deviceset="JP1E" device="" package3d_urn="urn:adsk.eagle:package:15455/1">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="S2" library="EVQ-P7L01P" deviceset="EVQ-P7L01P" device="">
<attribute name="MF" value="PANASONIC"/>
<attribute name="MPN" value="EVQP7L01P"/>
<attribute name="OC_NEWARK" value="57AC6749"/>
</part>
<part name="M2" library="microphon" library_urn="urn:adsk.eagle:library:297" deviceset="ELECTRET_MICROPHON-" device="WM-61A" package3d_urn="urn:adsk.eagle:package:21033/1">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="FRAME2" library="frames" library_urn="urn:adsk.eagle:library:229" deviceset="FRAME_C_L" device=""/>
<part name="U$46" library="microbuilder" deviceset="VBAT" device=""/>
<part name="X6" library="microbuilder" deviceset="CON_JST_PH_2PIN" device="" value="JSTPH">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="U$47" library="microbuilder" deviceset="VBAT" device=""/>
<part name="L" library="HA_FONA_LARA" deviceset="MICROBUILDER_LED" device="0603" value="RED">
<attribute name="MF" value="KINGBRIGHT"/>
<attribute name="MPN" value="KPT-1608LVSECK-J3-PRV"/>
<attribute name="OC_NEWARK" value="94Y5925"/>
</part>
<part name="R10" library="microbuilder" deviceset="RESISTOR" device="_0603_NOOUT" value="2.2K">
<attribute name="MF" value="YAGEO"/>
<attribute name="MPN" value="RC0603FR-072K2L."/>
<attribute name="OC_NEWARK" value="75X0144"/>
</part>
<part name="GND10" library="supply1" deviceset="GND" device=""/>
<part name="J2" library="Molex - 52271-0879" deviceset="MOLEX_52271-0879" device="MOLEX_52271-0879_0_0">
<attribute name="MF" value="MOLEX"/>
<attribute name="MPN" value="52271-0879-CUT-TAPE"/>
<attribute name="OC_NEWARK" value="78AC0708"/>
</part>
<part name="SIM2" library="Arduino-connectors" deviceset="SIM" device="" value="-">
<attribute name="MF" value=""/>
<attribute name="MPN" value=""/>
<attribute name="OC_NEWARK" value="unknown"/>
</part>
<part name="GND8" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="X2" library="con-garry" library_urn="urn:adsk.eagle:library:147" deviceset="332-06" device="" package3d_urn="urn:adsk.eagle:package:6811/1"/>
<part name="+3V3" library="supply1" deviceset="+3V3" device=""/>
<part name="U6" library="SN74AVC4T774PW" deviceset="SN74AVC4T774PW" device=""/>
<part name="U$9" library="microbuilder" deviceset="GND" device=""/>
<part name="C20" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="47 pF"/>
<part name="C22" library="PESD0402-140" deviceset="PESD0402-140" device=""/>
<part name="C23" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="100 nF"/>
<part name="C24" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="47 pF"/>
<part name="C30" library="PESD0402-140" deviceset="PESD0402-140" device=""/>
<part name="C32" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="47 pF"/>
<part name="C33" library="PESD0402-140" deviceset="PESD0402-140" device=""/>
<part name="C34" library="Capacitor" library_urn="urn:adsk.eagle:library:16290819" deviceset="C" device="CHIP-0402(1005-METRIC)" package3d_urn="urn:adsk.eagle:package:16290895/2" technology="_" value="47 pF"/>
<part name="C35" library="PESD0402-140" deviceset="PESD0402-140" device=""/>
<part name="X3" library="2173157-3" deviceset="2173157-3" device=""/>
<part name="Y1" library="CSTNE8M00GH5C000R0" deviceset="CSTNE8M00GH5C000R0" device=""/>
<part name="U$14" library="microbuilder" deviceset="VBUS" device=""/>
</parts>
<sheets>
<sheet>
<plain>
<text x="45.72" y="337.82" size="1.778" layer="94">POWER AND FILTERING</text>
<wire x1="-5.08" y1="254" x2="152.4" y2="254" width="0.1524" layer="94" style="shortdash"/>
<wire x1="152.4" y1="-43.18" x2="152.4" y2="101.6" width="0.1524" layer="94" style="shortdash"/>
<wire x1="152.4" y1="101.6" x2="152.4" y2="121.92" width="0.1524" layer="94" style="shortdash"/>
<wire x1="152.4" y1="121.92" x2="152.4" y2="167.64" width="0.1524" layer="94" style="shortdash"/>
<wire x1="152.4" y1="167.64" x2="152.4" y2="254" width="0.1524" layer="94" style="shortdash"/>
<text x="124.46" y="106.68" size="2.54" layer="94">RESET</text>
<wire x1="152.4" y1="254" x2="152.4" y2="386.08" width="0.1524" layer="94" style="shortdash"/>
<text x="162.56" y="279.4" size="1.778" layer="94">ATMEGA32U4 MCU</text>
<wire x1="287.02" y1="388.62" x2="287.02" y2="167.64" width="0.1524" layer="94" style="shortdash"/>
<wire x1="287.02" y1="167.64" x2="152.4" y2="167.64" width="0.1524" layer="94" style="shortdash"/>
<wire x1="287.02" y1="101.6" x2="287.02" y2="167.64" width="0.1524" layer="94" style="shortdash"/>
<text x="33.02" y="241.3" size="1.778" layer="97">10K  = 100mA</text>
<text x="33.02" y="238.76" size="1.778" layer="97">5.0K  = 200mA</text>
<text x="33.02" y="236.22" size="1.778" layer="97">2.0K  = 500mA</text>
<text x="33.02" y="233.68" size="1.778" layer="97">1.0K  = 1000mA</text>
<text x="88.9" y="106.68" size="2.54" layer="94" align="center">ANTENNA</text>
<text x="68.58" y="162.56" size="2.54" layer="94" align="center">SIM CARD</text>
<text x="114.3" y="337.82" size="1.778" layer="94" align="center">POWER DECOUPLING</text>
<wire x1="152.4" y1="167.64" x2="-5.08" y2="167.64" width="0.1524" layer="94" style="shortdash"/>
<text x="35.56" y="106.68" size="2.54" layer="94">LEDs</text>
<wire x1="152.4" y1="121.92" x2="-7.62" y2="121.92" width="0.1524" layer="94" style="shortdash"/>
<text x="215.9" y="154.94" size="2.54" layer="94">KEYPAD</text>
<wire x1="287.02" y1="101.6" x2="152.4" y2="101.6" width="0.1524" layer="94" style="shortdash"/>
<text x="48.26" y="248.92" size="2.54" layer="94">USB POWER and 3 Phase Dynamo to Rectified DC</text>
<text x="60.96" y="60.96" size="1.778" layer="97">50 Ohm Impedence required.  There are isolation
circuits (cap and inductor) used for dual antennas.
Since this is single antenna, the isolation circuit is not
used.  Perhaps this is an error on our part, but the 2G
design with single antenna does not have LC circuit.</text>
<text x="312.42" y="83.82" size="1.778" layer="97">"standard"
1 - mic+
2 - left spkr-
3 - right spkr+
4 - GND

Nokia 3210
1 - mic-
2 - spkr+
3 - mic+
4 - spkr-

Nokia 8210 (on EV board mono headset)
1 - gnd
2 - spkr+
3 - mic+

separated direct telephone headset PTT
1 - spk-
2 - mic+
3 - mic-
4 - spk+</text>
<text x="434.34" y="78.74" size="1.778" layer="97">Test SpeakerPhone Speaker:
Jump to ONBRD_SPKP/ONBRD_SPKN to SPK_P/SPK_N header
Test SpeakerPhone Microphone:
Connect microphone's twisted wire to MIC_P and MIC_N header
To test Headsets and speakerphone switching:
Dependent on configuration of headset, but for typ headset only test: 
short 7-8, 9-10, 11-12, 13-14</text>
<text x="-5.08" y="203.2" size="1.778" layer="97">NOTE:  VBUS charges VBAT independent of switch.</text>
<text x="215.9" y="314.96" size="2.54" layer="94">Microprocessor</text>
<text x="388.62" y="375.92" size="2.54" layer="94">Micro to Modem UART level shifters, Modem, Maxim Audio Codec, and audio I/O</text>
<text x="403.86" y="73.66" size="1.778" layer="97">DNI</text>
<wire x1="393.7" y1="73.66" x2="393.7" y2="86.36" width="0.1524" layer="97"/>
<wire x1="393.7" y1="86.36" x2="429.26" y2="86.36" width="0.1524" layer="97"/>
<wire x1="429.26" y1="86.36" x2="429.26" y2="73.66" width="0.1524" layer="97"/>
<wire x1="429.26" y1="73.66" x2="393.7" y2="73.66" width="0.1524" layer="97"/>
</plain>
<instances>
<instance part="C6" gate="G$1" x="20.32" y="312.42" smashed="yes">
<attribute name="NAME" x="18.03" y="313.67" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="22.62" y="313.67" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="20.32" y="312.42" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="20.32" y="312.42" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="20.32" y="312.42" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C7" gate="G$1" x="66.04" y="312.42" smashed="yes">
<attribute name="NAME" x="63.75" y="313.67" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="68.34" y="313.67" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="66.04" y="312.42" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="66.04" y="312.42" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="66.04" y="312.42" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$27" gate="G$1" x="20.32" y="304.8" smashed="yes">
<attribute name="VALUE" x="18.796" y="302.26" size="1.27" layer="96"/>
</instance>
<instance part="U$28" gate="G$1" x="66.04" y="304.8" smashed="yes">
<attribute name="VALUE" x="64.516" y="302.26" size="1.27" layer="96"/>
</instance>
<instance part="C8" gate="G$1" x="58.42" y="312.42" smashed="yes">
<attribute name="NAME" x="56.13" y="313.67" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="60.72" y="313.67" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="58.42" y="312.42" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="58.42" y="312.42" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="58.42" y="312.42" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$29" gate="G$1" x="58.42" y="304.8" smashed="yes">
<attribute name="VALUE" x="56.896" y="302.26" size="1.27" layer="96"/>
</instance>
<instance part="U$30" gate="G$1" x="35.56" y="304.8" smashed="yes">
<attribute name="VALUE" x="34.036" y="302.26" size="1.27" layer="96"/>
</instance>
<instance part="R4" gate="G$1" x="193.04" y="259.08" smashed="yes">
<attribute name="NAME" x="193.04" y="261.62" size="1.27" layer="95" font="vector" align="center"/>
<attribute name="VALUE" x="193.04" y="259.08" size="1.016" layer="96" font="vector" ratio="15" align="center"/>
<attribute name="OC_NEWARK" x="193.04" y="259.08" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="193.04" y="259.08" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="193.04" y="259.08" size="1.778" layer="96" display="off"/>
</instance>
<instance part="R5" gate="G$1" x="185.42" y="256.54" smashed="yes">
<attribute name="NAME" x="185.42" y="259.08" size="1.27" layer="95" font="vector" align="center"/>
<attribute name="VALUE" x="185.42" y="256.54" size="1.016" layer="96" font="vector" ratio="15" align="center"/>
<attribute name="OC_NEWARK" x="185.42" y="256.54" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="185.42" y="256.54" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="185.42" y="256.54" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND1" gate="1" x="180.34" y="266.7" smashed="yes">
<attribute name="VALUE" x="177.8" y="264.16" size="1.778" layer="96"/>
</instance>
<instance part="GND2" gate="1" x="203.2" y="210.82" smashed="yes" rot="R270">
<attribute name="VALUE" x="200.66" y="213.36" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="C9" gate="G$1" x="185.42" y="246.38" smashed="yes">
<attribute name="NAME" x="183.13" y="247.63" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="187.72" y="247.63" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="185.42" y="246.38" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="185.42" y="246.38" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="185.42" y="246.38" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND3" gate="1" x="185.42" y="241.3" smashed="yes">
<attribute name="VALUE" x="182.88" y="238.76" size="1.778" layer="96"/>
</instance>
<instance part="GND6" gate="1" x="170.18" y="223.52" smashed="yes" rot="R270">
<attribute name="VALUE" x="167.64" y="226.06" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="GND12" gate="1" x="88.9" y="304.8" smashed="yes" rot="MR0">
<attribute name="VALUE" x="91.44" y="302.26" size="1.778" layer="96" rot="MR0"/>
</instance>
<instance part="GND7" gate="1" x="139.7" y="86.36" smashed="yes">
<attribute name="VALUE" x="137.16" y="83.82" size="1.778" layer="96"/>
</instance>
<instance part="IC1" gate="G$1" x="228.6" y="238.76" smashed="yes">
<attribute name="NAME" x="210.82" y="200.66" size="1.778" layer="95"/>
<attribute name="VALUE" x="223.52" y="284.48" size="1.778" layer="96"/>
<attribute name="OC_NEWARK" x="228.6" y="238.76" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="228.6" y="238.76" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="228.6" y="238.76" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C14" gate="G$1" x="88.9" y="314.96" smashed="yes">
<attribute name="NAME" x="86.61" y="316.21" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="91.2" y="316.21" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="88.9" y="314.96" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="88.9" y="314.96" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="88.9" y="314.96" size="1.778" layer="96" display="off"/>
</instance>
<instance part="+3V4" gate="G$1" x="66.04" y="330.2" smashed="yes" rot="MR0">
<attribute name="VALUE" x="68.58" y="325.12" size="1.778" layer="96" rot="MR90"/>
</instance>
<instance part="+3V5" gate="G$1" x="195.58" y="271.78" smashed="yes">
<attribute name="VALUE" x="193.04" y="266.7" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="+3V6" gate="G$1" x="198.12" y="254" smashed="yes" rot="MR0">
<attribute name="VALUE" x="200.66" y="248.92" size="1.778" layer="96" rot="MR90"/>
</instance>
<instance part="+3V7" gate="G$1" x="274.32" y="266.7" smashed="yes">
<attribute name="VALUE" x="274.32" y="266.7" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="U$1" gate="G$1" x="180.34" y="251.46" smashed="yes">
<attribute name="VALUE" x="178.816" y="252.476" size="1.27" layer="96"/>
</instance>
<instance part="U$3" gate="G$1" x="12.7" y="327.66" smashed="yes">
<attribute name="VALUE" x="11.176" y="328.676" size="1.27" layer="96"/>
</instance>
<instance part="U$8" gate="G$1" x="195.58" y="281.94" smashed="yes">
<attribute name="VALUE" x="194.056" y="282.956" size="1.27" layer="96"/>
</instance>
<instance part="U2" gate="G$1" x="45.72" y="322.58" smashed="yes">
<attribute name="NAME" x="38.1" y="328.676" size="1.27" layer="95"/>
<attribute name="VALUE" x="38.1" y="314.96" size="1.27" layer="95"/>
<attribute name="OC_NEWARK" x="45.72" y="322.58" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="45.72" y="322.58" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="45.72" y="322.58" size="1.778" layer="96" display="off"/>
</instance>
<instance part="D4" gate="G$1" x="20.32" y="332.74" smashed="yes" rot="R270">
<attribute name="NAME" x="22.86" y="332.74" size="1.27" layer="95" rot="R270" align="center"/>
<attribute name="VALUE" x="17.82" y="332.74" size="1.27" layer="96" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="20.32" y="332.74" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="20.32" y="332.74" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="20.32" y="332.74" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U3" gate="G$1" x="35.56" y="220.98" smashed="yes">
<attribute name="NAME" x="25.4" y="232.41" size="1.27" layer="95"/>
<attribute name="VALUE" x="25.4" y="208.28" size="1.27" layer="95"/>
<attribute name="OC_NEWARK" x="35.56" y="220.98" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="35.56" y="220.98" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="35.56" y="220.98" size="1.778" layer="96" display="off"/>
</instance>
<instance part="CHG" gate="G$1" x="10.16" y="218.44" smashed="yes">
<attribute name="NAME" x="8.89" y="222.885" size="1.27" layer="95" align="center"/>
<attribute name="VALUE" x="8.89" y="215.646" size="1.27" layer="96" align="center"/>
<attribute name="OC_NEWARK" x="10.16" y="218.44" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="10.16" y="218.44" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="10.16" y="218.44" size="1.778" layer="96" display="off"/>
</instance>
<instance part="R2" gate="G$1" x="17.78" y="218.44" smashed="yes">
<attribute name="NAME" x="17.78" y="220.98" size="1.27" layer="95" font="vector" align="center"/>
<attribute name="VALUE" x="17.78" y="218.44" size="1.016" layer="96" font="vector" ratio="15" align="center"/>
<attribute name="OC_NEWARK" x="17.78" y="218.44" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="17.78" y="218.44" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="17.78" y="218.44" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C3" gate="G$1" x="63.5" y="215.9" smashed="yes">
<attribute name="NAME" x="61.21" y="217.15" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="65.8" y="217.15" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="63.5" y="215.9" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="63.5" y="215.9" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="63.5" y="215.9" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$33" gate="G$1" x="63.5" y="208.28" smashed="yes">
<attribute name="VALUE" x="61.976" y="205.74" size="1.27" layer="96"/>
</instance>
<instance part="R8" gate="G$1" x="55.88" y="215.9" smashed="yes" rot="R270">
<attribute name="NAME" x="58.42" y="215.9" size="1.27" layer="95" font="vector" rot="R270" align="center"/>
<attribute name="VALUE" x="55.88" y="215.9" size="1.016" layer="96" font="vector" ratio="15" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="55.88" y="215.9" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="55.88" y="215.9" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="55.88" y="215.9" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$36" gate="G$1" x="55.88" y="208.28" smashed="yes">
<attribute name="VALUE" x="54.356" y="205.74" size="1.27" layer="96"/>
</instance>
<instance part="U$38" gate="G$1" x="5.08" y="231.14" smashed="yes" rot="MR0">
<attribute name="VALUE" x="6.604" y="232.156" size="1.27" layer="96" rot="MR0"/>
</instance>
<instance part="U$39" gate="G$1" x="63.5" y="231.14" smashed="yes">
<attribute name="VALUE" x="61.976" y="232.156" size="1.27" layer="96"/>
</instance>
<instance part="U$12" gate="G$1" x="96.52" y="78.74" smashed="yes">
<attribute name="VALUE" x="94.996" y="76.2" size="1.27" layer="96"/>
</instance>
<instance part="NETSTAT2" gate="G$1" x="38.1" y="68.58" smashed="yes" rot="R270">
<attribute name="NAME" x="42.545" y="69.85" size="1.27" layer="95" rot="R270" align="center"/>
<attribute name="VALUE" x="35.306" y="69.85" size="1.27" layer="96" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="38.1" y="68.58" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="38.1" y="68.58" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="38.1" y="68.58" size="1.778" layer="96" display="off"/>
</instance>
<instance part="NETSTAT1" gate="G$1" x="27.94" y="68.58" smashed="yes" rot="R270">
<attribute name="NAME" x="32.385" y="69.85" size="1.27" layer="95" rot="R270" align="center"/>
<attribute name="VALUE" x="25.146" y="69.85" size="1.27" layer="96" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="27.94" y="68.58" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="27.94" y="68.58" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="27.94" y="68.58" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$10" gate="G$1" x="38.1" y="60.96" smashed="yes">
<attribute name="VALUE" x="36.576" y="58.42" size="1.27" layer="96"/>
</instance>
<instance part="R1" gate="G$1" x="38.1" y="81.28" smashed="yes" rot="R90">
<attribute name="NAME" x="35.56" y="81.28" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="38.1" y="81.28" size="1.016" layer="96" font="vector" ratio="15" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="38.1" y="81.28" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="38.1" y="81.28" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="38.1" y="81.28" size="1.778" layer="96" display="off"/>
</instance>
<instance part="R3" gate="G$1" x="27.94" y="81.28" smashed="yes" rot="R90">
<attribute name="NAME" x="25.4" y="81.28" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="27.94" y="81.28" size="1.016" layer="96" font="vector" ratio="15" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="27.94" y="81.28" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="27.94" y="81.28" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="27.94" y="81.28" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$13" gate="G$1" x="27.94" y="60.96" smashed="yes">
<attribute name="VALUE" x="26.416" y="58.42" size="1.27" layer="96"/>
</instance>
<instance part="D5" gate="G$1" x="139.7" y="317.5" smashed="yes" rot="R90">
<attribute name="NAME" x="136.6774" y="314.96" size="1.27" layer="95" rot="R90"/>
<attribute name="VALUE" x="144.5514" y="309.88" size="1.27" layer="96" rot="R90"/>
<attribute name="OC_NEWARK" x="139.7" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="139.7" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="139.7" y="317.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$26" gate="G$1" x="124.46" y="304.8" smashed="yes">
<attribute name="VALUE" x="122.936" y="302.26" size="1.27" layer="96"/>
</instance>
<instance part="C5" gate="G$1" x="132.08" y="314.96" smashed="yes">
<attribute name="NAME" x="129.79" y="316.21" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="134.38" y="316.21" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="132.08" y="314.96" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="132.08" y="314.96" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="132.08" y="314.96" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C2" gate="G$1" x="124.46" y="314.96" smashed="yes">
<attribute name="NAME" x="122.17" y="316.21" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="126.76" y="316.21" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="124.46" y="314.96" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="124.46" y="314.96" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="124.46" y="314.96" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C4" gate="G$1" x="116.84" y="317.5" smashed="yes">
<attribute name="NAME" x="117.856" y="318.135" size="1.778" layer="95"/>
<attribute name="VALUE" x="117.856" y="313.309" size="1.778" layer="96"/>
<attribute name="OC_NEWARK" x="116.84" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="116.84" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="116.84" y="317.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$37" gate="G$1" x="124.46" y="327.66" smashed="yes">
<attribute name="VALUE" x="122.936" y="328.676" size="1.27" layer="96"/>
</instance>
<instance part="X4" gate="G$1" x="88.9" y="88.9" smashed="yes" rot="MR0">
<attribute name="NAME" x="91.44" y="92.202" size="1.27" layer="95" rot="MR0"/>
<attribute name="VALUE" x="91.44" y="78.74" size="1.27" layer="96" rot="MR0"/>
<attribute name="OC_NEWARK" x="88.9" y="88.9" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="88.9" y="88.9" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="88.9" y="88.9" size="1.778" layer="96" display="off"/>
</instance>
<instance part="R6" gate="G$1" x="27.94" y="317.5" smashed="yes" rot="R90">
<attribute name="NAME" x="25.4" y="317.5" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="27.94" y="317.5" size="1.016" layer="96" font="vector" ratio="15" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="27.94" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="27.94" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="27.94" y="317.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U4" gate="G$1" x="447.04" y="259.08" smashed="yes">
<attribute name="NAME" x="426.6897" y="299.7807" size="2.543790625" layer="95"/>
<attribute name="VALUE" x="426.6864" y="220.917" size="2.5442" layer="96"/>
<attribute name="OC_NEWARK" x="447.04" y="259.08" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="447.04" y="259.08" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U5" gate="G$1" x="441.96" y="182.88" smashed="yes">
<attribute name="NAME" x="429.5029" y="201.1844" size="1.271140625" layer="95"/>
<attribute name="VALUE" x="429.2451" y="160.5018" size="1.271490625" layer="96"/>
<attribute name="OC_NEWARK" x="441.96" y="182.88" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="441.96" y="182.88" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$6" gate="G$1" x="467.36" y="157.48" smashed="yes">
<attribute name="VALUE" x="465.836" y="154.94" size="1.27" layer="96"/>
</instance>
<instance part="U$4" gate="G$1" x="378.46" y="180.34" smashed="yes">
<attribute name="VALUE" x="376.936" y="177.8" size="1.27" layer="96"/>
</instance>
<instance part="R9" gate="G$1" x="401.32" y="210.82" smashed="yes" rot="R270">
<attribute name="NAME" x="403.86" y="210.82" size="1.27" layer="95" font="vector" rot="R270" align="center"/>
<attribute name="VALUE" x="398.78" y="210.82" size="1.016" layer="96" font="vector" ratio="15" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="401.32" y="210.82" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="401.32" y="210.82" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="401.32" y="210.82" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C1" gate="G$1" x="398.78" y="170.18" smashed="yes">
<attribute name="NAME" x="396.49" y="171.43" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="401.08" y="171.43" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="398.78" y="170.18" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="398.78" y="170.18" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="398.78" y="170.18" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C10" gate="G$1" x="406.4" y="167.64" smashed="yes">
<attribute name="NAME" x="404.11" y="168.89" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="408.7" y="168.89" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="406.4" y="167.64" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="406.4" y="167.64" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="406.4" y="167.64" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C11" gate="G$1" x="414.02" y="162.56" smashed="yes">
<attribute name="NAME" x="411.73" y="163.81" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="416.32" y="163.81" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="414.02" y="162.56" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="414.02" y="162.56" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="414.02" y="162.56" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C12" gate="G$1" x="421.64" y="162.56" smashed="yes">
<attribute name="NAME" x="419.35" y="163.81" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="423.94" y="163.81" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="421.64" y="162.56" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="421.64" y="162.56" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="421.64" y="162.56" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$7" gate="G$1" x="406.4" y="154.94" smashed="yes">
<attribute name="VALUE" x="404.876" y="152.4" size="1.27" layer="96"/>
</instance>
<instance part="R11" gate="G$1" x="500.38" y="195.58" smashed="yes" rot="R270">
<attribute name="NAME" x="502.92" y="195.58" size="1.27" layer="95" font="vector" rot="R270" align="center"/>
<attribute name="VALUE" x="497.84" y="195.58" size="1.016" layer="96" font="vector" ratio="15" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="500.38" y="195.58" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="500.38" y="195.58" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="500.38" y="195.58" size="1.778" layer="96" display="off"/>
</instance>
<instance part="R12" gate="G$1" x="378.46" y="208.28" smashed="yes" rot="R270">
<attribute name="NAME" x="381" y="208.28" size="1.27" layer="95" font="vector" rot="R270" align="center"/>
<attribute name="VALUE" x="375.92" y="208.28" size="1.016" layer="96" font="vector" ratio="15" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="378.46" y="208.28" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="378.46" y="208.28" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="378.46" y="208.28" size="1.778" layer="96" display="off"/>
</instance>
<instance part="R13" gate="G$1" x="508" y="195.58" smashed="yes" rot="R270">
<attribute name="NAME" x="510.54" y="195.58" size="1.27" layer="95" font="vector" rot="R270" align="center"/>
<attribute name="VALUE" x="505.46" y="195.58" size="1.016" layer="96" font="vector" ratio="15" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="508" y="195.58" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="508" y="195.58" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="508" y="195.58" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C13" gate="G$1" x="464.82" y="203.2" smashed="yes">
<attribute name="NAME" x="462.53" y="204.45" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="467.12" y="204.45" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="464.82" y="203.2" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="464.82" y="203.2" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="464.82" y="203.2" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C15" gate="G$1" x="472.44" y="203.2" smashed="yes">
<attribute name="NAME" x="470.15" y="204.45" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="474.74" y="204.45" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="472.44" y="203.2" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="472.44" y="203.2" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="472.44" y="203.2" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C16" gate="G$1" x="487.68" y="203.2" smashed="yes">
<attribute name="NAME" x="485.39" y="204.45" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="489.98" y="204.45" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="487.68" y="203.2" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="487.68" y="203.2" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="487.68" y="203.2" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$5" gate="G$1" x="464.82" y="198.12" smashed="yes">
<attribute name="VALUE" x="463.296" y="195.58" size="1.27" layer="96"/>
</instance>
<instance part="U$11" gate="G$1" x="472.44" y="198.12" smashed="yes">
<attribute name="VALUE" x="470.916" y="195.58" size="1.27" layer="96"/>
</instance>
<instance part="U$18" gate="G$1" x="487.68" y="198.12" smashed="yes">
<attribute name="VALUE" x="486.156" y="195.58" size="1.27" layer="96"/>
</instance>
<instance part="C17" gate="G$1" x="414.02" y="193.04" smashed="yes" rot="R90">
<attribute name="NAME" x="412.77" y="190.75" size="1.27" layer="95" font="vector" rot="R180" align="center"/>
<attribute name="VALUE" x="412.77" y="195.34" size="1.27" layer="96" font="vector" rot="R180" align="center"/>
<attribute name="OC_NEWARK" x="414.02" y="193.04" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="414.02" y="193.04" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="414.02" y="193.04" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C18" gate="G$1" x="419.1" y="190.5" smashed="yes" rot="R90">
<attribute name="NAME" x="417.85" y="188.21" size="1.27" layer="95" font="vector" rot="R180" align="center"/>
<attribute name="VALUE" x="417.85" y="192.8" size="1.27" layer="96" font="vector" rot="R180" align="center"/>
<attribute name="OC_NEWARK" x="419.1" y="190.5" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="419.1" y="190.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="419.1" y="190.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="R14" gate="G$1" x="368.3" y="182.88" smashed="yes" rot="R270">
<attribute name="NAME" x="370.84" y="182.88" size="1.27" layer="95" font="vector" rot="R270" align="center"/>
<attribute name="VALUE" x="365.76" y="182.88" size="1.016" layer="96" font="vector" ratio="15" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="368.3" y="182.88" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="368.3" y="182.88" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="368.3" y="182.88" size="1.778" layer="96" display="off"/>
</instance>
<instance part="JP2" gate="A" x="398.78" y="203.2" smashed="yes" rot="R90">
<attribute name="NAME" x="398.78" y="201.93" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="398.78" y="208.915" size="1.778" layer="96" rot="R180"/>
<attribute name="OC_NEWARK" x="398.78" y="203.2" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="398.78" y="203.2" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="398.78" y="203.2" size="1.778" layer="96" display="off"/>
</instance>
<instance part="JP4" gate="A" x="365.76" y="172.72" smashed="yes" rot="R90">
<attribute name="NAME" x="365.76" y="171.45" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="365.76" y="178.435" size="1.778" layer="96" rot="R180"/>
<attribute name="OC_NEWARK" x="365.76" y="172.72" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="365.76" y="172.72" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="365.76" y="172.72" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$23" gate="G$1" x="368.3" y="165.1" smashed="yes">
<attribute name="VALUE" x="366.776" y="162.56" size="1.27" layer="96"/>
</instance>
<instance part="JP5" gate="A" x="355.6" y="180.34" smashed="yes" rot="R90">
<attribute name="NAME" x="355.6" y="179.07" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="355.6" y="186.055" size="1.778" layer="96" rot="R180"/>
<attribute name="OC_NEWARK" x="355.6" y="180.34" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="355.6" y="180.34" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="355.6" y="180.34" size="1.778" layer="96" display="off"/>
</instance>
<instance part="S1" gate="G$1" x="25.4" y="190.5" smashed="yes">
<attribute name="NAME" x="20.31021875" y="195.58978125" size="1.27245" layer="95"/>
<attribute name="VALUE" x="20.31395" y="182.87093125" size="1.271509375" layer="96"/>
<attribute name="OC_NEWARK" x="25.4" y="190.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="25.4" y="190.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="D1" gate="G$1" x="96.52" y="213.36" smashed="yes">
<attribute name="NAME" x="96.52" y="218.44" size="1.778" layer="95" align="center"/>
<attribute name="VALUE" x="96.52" y="208.28" size="1.778" layer="95" align="center"/>
<attribute name="OC_NEWARK" x="96.52" y="213.36" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="96.52" y="213.36" size="1.778" layer="96" display="off"/>
</instance>
<instance part="D3" gate="G$1" x="129.54" y="213.36" smashed="yes">
<attribute name="NAME" x="129.54" y="218.44" size="1.778" layer="95" align="center"/>
<attribute name="VALUE" x="129.54" y="208.28" size="1.778" layer="95" align="center"/>
<attribute name="OC_NEWARK" x="129.54" y="213.36" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="129.54" y="213.36" size="1.778" layer="96" display="off"/>
</instance>
<instance part="D7" gate="G$1" x="96.52" y="195.58" smashed="yes">
<attribute name="NAME" x="96.52" y="200.66" size="1.778" layer="95" align="center"/>
<attribute name="VALUE" x="96.52" y="190.5" size="1.778" layer="95" align="center"/>
<attribute name="OC_NEWARK" x="96.52" y="195.58" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="96.52" y="195.58" size="1.778" layer="96" display="off"/>
</instance>
<instance part="D9" gate="G$1" x="129.54" y="195.58" smashed="yes">
<attribute name="NAME" x="129.54" y="200.66" size="1.778" layer="95" align="center"/>
<attribute name="VALUE" x="129.54" y="190.5" size="1.778" layer="95" align="center"/>
<attribute name="OC_NEWARK" x="129.54" y="195.58" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="129.54" y="195.58" size="1.778" layer="96" display="off"/>
</instance>
<instance part="D11" gate="G$1" x="96.52" y="177.8" smashed="yes">
<attribute name="NAME" x="96.52" y="182.88" size="1.778" layer="95" align="center"/>
<attribute name="VALUE" x="96.52" y="172.72" size="1.778" layer="95" align="center"/>
<attribute name="OC_NEWARK" x="96.52" y="177.8" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="96.52" y="177.8" size="1.778" layer="96" display="off"/>
</instance>
<instance part="D12" gate="G$1" x="129.54" y="177.8" smashed="yes">
<attribute name="NAME" x="129.54" y="182.88" size="1.778" layer="95" align="center"/>
<attribute name="VALUE" x="129.54" y="172.72" size="1.778" layer="95" align="center"/>
<attribute name="OC_NEWARK" x="129.54" y="177.8" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="129.54" y="177.8" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND4" gate="1" x="134.62" y="228.6" smashed="yes">
<attribute name="VALUE" x="132.08" y="226.06" size="1.778" layer="96"/>
</instance>
<instance part="LED1" gate="G$1" x="66.04" y="180.34" smashed="yes">
<attribute name="NAME" x="69.596" y="175.768" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="71.755" y="175.768" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="U$2" gate="G$1" x="66.04" y="170.18" smashed="yes">
<attribute name="VALUE" x="67.056" y="170.18" size="1.27" layer="96"/>
</instance>
<instance part="X1" gate="G$1" x="71.12" y="88.9" smashed="yes">
<attribute name="VALUE" x="68.58" y="83.82" size="1.778" layer="96"/>
<attribute name="NAME" x="68.58" y="92.202" size="1.778" layer="95"/>
</instance>
<instance part="U$25" gate="G$1" x="83.82" y="78.74" smashed="yes">
<attribute name="VALUE" x="82.296" y="76.2" size="1.27" layer="96"/>
</instance>
<instance part="+3V1" gate="G$1" x="363.22" y="330.2" smashed="yes" rot="MR0">
<attribute name="VALUE" x="365.76" y="325.12" size="1.778" layer="96" rot="MR90"/>
</instance>
<instance part="U$32" gate="G$1" x="360.68" y="279.4" smashed="yes">
<attribute name="VALUE" x="359.156" y="276.86" size="1.27" layer="96"/>
</instance>
<instance part="U$34" gate="G$1" x="414.02" y="251.46" smashed="yes">
<attribute name="VALUE" x="412.496" y="248.92" size="1.27" layer="96"/>
</instance>
<instance part="R15" gate="G$1" x="55.88" y="190.5" smashed="yes">
<attribute name="NAME" x="53.335559375" y="193.04148125" size="1.778" layer="95"/>
<attribute name="VALUE" x="48.25003125" y="195.573359375" size="1.778" layer="96"/>
<attribute name="OC_NEWARK" x="55.88" y="190.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="55.88" y="190.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="+3V8" gate="G$1" x="299.72" y="327.66" smashed="yes" rot="MR0">
<attribute name="VALUE" x="302.26" y="322.58" size="1.778" layer="96" rot="MR90"/>
</instance>
<instance part="U$19" gate="G$1" x="292.1" y="299.72" smashed="yes">
<attribute name="VALUE" x="290.576" y="297.18" size="1.27" layer="96"/>
</instance>
<instance part="U$20" gate="G$1" x="469.9" y="223.52" smashed="yes">
<attribute name="VALUE" x="468.376" y="220.98" size="1.27" layer="96"/>
</instance>
<instance part="C21" gate="G$1" x="378.46" y="317.5" smashed="yes">
<attribute name="NAME" x="376.17" y="318.75" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="380.76" y="318.75" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="378.46" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="378.46" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="378.46" y="317.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$22" gate="G$1" x="370.84" y="309.88" smashed="yes">
<attribute name="VALUE" x="369.316" y="307.34" size="1.27" layer="96"/>
</instance>
<instance part="U$24" gate="G$1" x="378.46" y="312.42" smashed="yes">
<attribute name="VALUE" x="376.936" y="309.88" size="1.27" layer="96"/>
</instance>
<instance part="C19" gate="G$1" x="370.84" y="314.96" smashed="yes">
<attribute name="NAME" x="368.55" y="316.21" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="373.14" y="316.21" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="370.84" y="314.96" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="370.84" y="314.96" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="370.84" y="314.96" size="1.778" layer="96" display="off"/>
</instance>
<instance part="Q5" gate="-2" x="461.01" y="346.71" smashed="yes">
<attribute name="NAME" x="463.55" y="346.71" size="1.778" layer="95"/>
<attribute name="OC_NEWARK" x="461.01" y="346.71" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="461.01" y="346.71" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="461.01" y="346.71" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND66" gate="1" x="461.01" y="339.09" smashed="yes">
<attribute name="VALUE" x="458.47" y="336.55" size="1.778" layer="96"/>
</instance>
<instance part="R7" gate="G$1" x="425.45" y="339.09" smashed="yes" rot="R90">
<attribute name="NAME" x="426.72" y="339.344" size="1.778" layer="95"/>
<attribute name="VALUE" x="426.72" y="338.836" size="1.778" layer="96" align="top-left"/>
<attribute name="OC_NEWARK" x="425.45" y="339.09" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="425.45" y="339.09" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="425.45" y="339.09" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND67" gate="1" x="425.45" y="334.01" smashed="yes">
<attribute name="VALUE" x="422.91" y="331.47" size="1.778" layer="96"/>
</instance>
<instance part="R16" gate="G$1" x="425.45" y="318.77" smashed="yes" rot="R90">
<attribute name="NAME" x="426.72" y="319.024" size="1.778" layer="95"/>
<attribute name="VALUE" x="426.72" y="318.516" size="1.778" layer="96" align="top-left"/>
<attribute name="OC_NEWARK" x="425.45" y="318.77" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="425.45" y="318.77" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="425.45" y="318.77" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND5" gate="1" x="425.45" y="313.69" smashed="yes">
<attribute name="VALUE" x="422.91" y="311.15" size="1.778" layer="96"/>
</instance>
<instance part="Q5" gate="-1" x="461.01" y="326.39" smashed="yes">
<attribute name="NAME" x="463.55" y="326.39" size="1.778" layer="95"/>
<attribute name="VALUE" x="463.55" y="323.85" size="1.778" layer="96"/>
</instance>
<instance part="GND47" gate="1" x="461.01" y="318.77" smashed="yes">
<attribute name="VALUE" x="458.47" y="316.23" size="1.778" layer="96"/>
</instance>
<instance part="JP1" gate="A" x="485.14" y="355.6" smashed="yes">
<attribute name="NAME" x="483.87" y="355.6" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="490.855" y="355.6" size="1.778" layer="96" rot="R90"/>
<attribute name="OC_NEWARK" x="485.14" y="355.6" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="485.14" y="355.6" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="485.14" y="355.6" size="1.778" layer="96" display="off"/>
</instance>
<instance part="JP3" gate="A" x="485.14" y="335.28" smashed="yes">
<attribute name="NAME" x="483.87" y="335.28" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="490.855" y="335.28" size="1.778" layer="96" rot="R90"/>
<attribute name="OC_NEWARK" x="485.14" y="335.28" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="485.14" y="335.28" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="485.14" y="335.28" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C25" gate="G$1" x="490.22" y="292.1" smashed="yes">
<attribute name="NAME" x="487.93" y="293.35" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="492.52" y="293.35" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="490.22" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="490.22" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="490.22" y="292.1" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C26" gate="G$1" x="497.84" y="292.1" smashed="yes">
<attribute name="NAME" x="495.55" y="293.35" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="500.14" y="293.35" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="497.84" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="497.84" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="497.84" y="292.1" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C27" gate="G$1" x="505.46" y="292.1" smashed="yes">
<attribute name="NAME" x="503.17" y="293.35" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="507.76" y="293.35" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="505.46" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="505.46" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="505.46" y="292.1" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C28" gate="G$1" x="513.08" y="292.1" smashed="yes">
<attribute name="NAME" x="510.79" y="293.35" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="515.38" y="293.35" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="513.08" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="513.08" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="513.08" y="292.1" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C29" gate="G$1" x="520.7" y="292.1" smashed="yes">
<attribute name="NAME" x="518.41" y="293.35" size="1.27" layer="95" font="vector" rot="R90" align="center"/>
<attribute name="VALUE" x="523" y="293.35" size="1.27" layer="96" font="vector" rot="R90" align="center"/>
<attribute name="OC_NEWARK" x="520.7" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="520.7" y="292.1" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="520.7" y="292.1" size="1.778" layer="96" display="off"/>
</instance>
<instance part="C31" gate="G$1" x="528.32" y="294.64" smashed="yes">
<attribute name="NAME" x="529.336" y="295.275" size="1.778" layer="95"/>
<attribute name="VALUE" x="529.336" y="290.449" size="1.778" layer="96"/>
<attribute name="OC_NEWARK" x="528.32" y="294.64" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="528.32" y="294.64" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="528.32" y="294.64" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$44" gate="G$1" x="528.32" y="284.48" smashed="yes">
<attribute name="VALUE" x="526.796" y="281.94" size="1.27" layer="96"/>
</instance>
<instance part="J1" gate="G$1" x="370.84" y="111.76" smashed="yes">
<attribute name="NAME" x="358.1325" y="132.092" size="2.5415" layer="95"/>
<attribute name="VALUE" x="358.1157" y="88.8562" size="2.544859375" layer="96"/>
<attribute name="OC_NEWARK" x="370.84" y="111.76" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="370.84" y="111.76" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="370.84" y="111.76" size="1.778" layer="96" display="off"/>
</instance>
<instance part="LS1" gate="G$1" x="424.18" y="144.78" smashed="yes">
<attribute name="NAME" x="427.977959375" y="146.07808125" size="1.78361875" layer="95"/>
<attribute name="VALUE" x="420.351290625" y="133.2939" size="1.78673125" layer="96"/>
<attribute name="OC_NEWARK" x="424.18" y="144.78" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="424.18" y="144.78" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="424.18" y="144.78" size="1.778" layer="96" display="off"/>
</instance>
<instance part="SV1" gate="G$1" x="431.8" y="119.38" smashed="yes" rot="R180">
<attribute name="VALUE" x="435.61" y="132.08" size="1.778" layer="96" rot="R180"/>
<attribute name="NAME" x="435.61" y="105.918" size="1.778" layer="95" rot="R180"/>
</instance>
<instance part="U$45" gate="G$1" x="462.28" y="111.76" smashed="yes">
<attribute name="VALUE" x="460.756" y="109.22" size="1.27" layer="96"/>
</instance>
<instance part="JP6" gate="A" x="353.06" y="190.5" smashed="yes" rot="R90">
<attribute name="NAME" x="353.06" y="189.23" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="353.06" y="196.215" size="1.778" layer="96" rot="R180"/>
<attribute name="OC_NEWARK" x="353.06" y="190.5" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="353.06" y="190.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="353.06" y="190.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="JP7" gate="A" x="480.06" y="182.88" smashed="yes" rot="R270">
<attribute name="NAME" x="485.14" y="181.61" size="1.778" layer="95"/>
<attribute name="VALUE" x="480.06" y="177.165" size="1.778" layer="96"/>
<attribute name="OC_NEWARK" x="480.06" y="182.88" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="480.06" y="182.88" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="480.06" y="182.88" size="1.778" layer="96" display="off"/>
</instance>
<instance part="S2" gate="G$1" x="132.08" y="96.52" smashed="yes" rot="R180">
<attribute name="NAME" x="137.16" y="93.218" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="137.16" y="101.6" size="1.778" layer="96" rot="R180"/>
<attribute name="OC_NEWARK" x="132.08" y="96.52" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="132.08" y="96.52" size="1.778" layer="96" display="off"/>
</instance>
<instance part="M2" gate="G$1" x="403.86" y="78.74" smashed="yes" rot="R180">
<attribute name="OC_NEWARK" x="403.86" y="78.74" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="403.86" y="78.74" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="403.86" y="78.74" size="1.778" layer="96" display="off"/>
</instance>
<instance part="FRAME2" gate="G$1" x="-10.16" y="-40.64" smashed="yes"/>
<instance part="FRAME2" gate="G$2" x="441.96" y="-40.64" smashed="yes">
<attribute name="LAST_DATE_TIME" x="454.66" y="-39.37" size="2.54" layer="94"/>
<attribute name="SHEET" x="528.32" y="-39.37" size="2.54" layer="94"/>
<attribute name="DRAWING_NAME" x="459.74" y="-21.59" size="2.54" layer="94"/>
</instance>
<instance part="U$46" gate="G$1" x="109.22" y="243.84" smashed="yes">
<attribute name="VALUE" x="107.696" y="244.856" size="1.27" layer="96"/>
</instance>
<instance part="X6" gate="G$1" x="101.6" y="317.5" smashed="yes" rot="R180">
<attribute name="NAME" x="107.95" y="311.785" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="107.95" y="322.58" size="1.778" layer="96" rot="R180"/>
<attribute name="OC_NEWARK" x="101.6" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="101.6" y="317.5" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="101.6" y="317.5" size="1.778" layer="96" display="off"/>
</instance>
<instance part="U$47" gate="G$1" x="2.54" y="193.04" smashed="yes">
<attribute name="VALUE" x="1.016" y="194.056" size="1.27" layer="96"/>
</instance>
<instance part="L" gate="G$1" x="48.26" y="68.58" smashed="yes" rot="R270">
<attribute name="NAME" x="52.705" y="69.85" size="1.27" layer="95" rot="R270" align="center"/>
<attribute name="VALUE" x="45.466" y="69.85" size="1.27" layer="96" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="48.26" y="68.58" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="48.26" y="68.58" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="48.26" y="68.58" size="1.778" layer="96" display="off"/>
</instance>
<instance part="R10" gate="G$1" x="48.26" y="81.28" smashed="yes" rot="R270">
<attribute name="NAME" x="50.8" y="81.28" size="1.27" layer="95" font="vector" rot="R270" align="center"/>
<attribute name="VALUE" x="48.26" y="81.28" size="1.016" layer="96" font="vector" ratio="15" rot="R270" align="center"/>
<attribute name="OC_NEWARK" x="48.26" y="81.28" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="48.26" y="81.28" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="48.26" y="81.28" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND10" gate="1" x="48.26" y="60.96" smashed="yes" rot="MR0">
<attribute name="VALUE" x="50.8" y="58.42" size="1.778" layer="96" rot="MR0"/>
</instance>
<instance part="J2" gate="G$0" x="231.14" y="147.32" smashed="yes" rot="R270">
<attribute name="NAME" x="228.6" y="147.32" size="2.54" layer="95" rot="R270" align="top-left"/>
<attribute name="OC_NEWARK" x="231.14" y="147.32" size="1.778" layer="96" display="off"/>
</instance>
<instance part="SIM2" gate="G$1" x="46.99" y="144.78" smashed="yes" rot="R90">
<attribute name="NAME" x="46.99" y="142.24" size="1.778" layer="95" font="vector" rot="R90"/>
<attribute name="OC_NEWARK" x="46.99" y="144.78" size="1.778" layer="96" display="off"/>
<attribute name="MF" x="46.99" y="144.78" size="1.778" layer="96" display="off"/>
<attribute name="MPN" x="46.99" y="144.78" size="1.778" layer="96" display="off"/>
</instance>
<instance part="GND8" gate="1" x="68.58" y="125.73" smashed="yes">
<attribute name="VALUE" x="66.04" y="123.19" size="1.778" layer="96"/>
</instance>
<instance part="X2" gate="-1" x="96.52" y="241.3" smashed="yes">
<attribute name="NAME" x="99.06" y="240.538" size="1.524" layer="95"/>
<attribute name="VALUE" x="95.758" y="242.697" size="1.778" layer="96"/>
</instance>
<instance part="X2" gate="-2" x="116.84" y="241.3" smashed="yes">
<attribute name="NAME" x="119.38" y="240.538" size="1.524" layer="95"/>
<attribute name="VALUE" x="116.078" y="242.697" size="1.778" layer="96"/>
</instance>
<instance part="X2" gate="-3" x="96.52" y="238.76" smashed="yes">
<attribute name="NAME" x="99.06" y="237.998" size="1.524" layer="95"/>
</instance>
<instance part="X2" gate="-4" x="116.84" y="238.76" smashed="yes">
<attribute name="NAME" x="119.38" y="237.998" size="1.524" layer="95"/>
</instance>
<instance part="X2" gate="-5" x="96.52" y="236.22" smashed="yes">
<attribute name="NAME" x="99.06" y="235.458" size="1.524" layer="95"/>
</instance>
<instance part="X2" gate="-6" x="116.84" y="236.22" smashed="yes">
<attribute name="NAME" x="119.38" y="235.458" size="1.524" layer="95"/>
</instance>
<instance part="+3V3" gate="G$1" x="462.28" y="124.46" smashed="yes" rot="MR0">
<attribute name="VALUE" x="464.82" y="119.38" size="1.778" layer="96" rot="MR90"/>
</instance>
<instance part="U6" gate="A" x="337.82" y="302.26" smashed="yes">
<attribute name="NAME" x="325.12" y="326.12" size="2.0828" layer="95" ratio="10" rot="SR0"/>
<attribute name="VALUE" x="325.12" y="275.4" size="2.0828" layer="96" ratio="10" rot="SR0"/>
</instance>
<instance part="U$9" gate="G$1" x="381" y="259.08" smashed="yes">
<attribute name="VALUE" x="379.476" y="256.54" size="1.27" layer="96"/>
</instance>
<instance part="C20" gate="G$1" x="144.78" y="147.32" smashed="yes">
<attribute name="NAME" x="144.78" y="147.32" size="1.778" layer="95"/>
<attribute name="VALUE" x="144.78" y="142.24" size="1.778" layer="96"/>
</instance>
<instance part="C22" gate="G$1" x="129.54" y="147.32" smashed="yes" rot="R270">
<attribute name="NAME" x="127" y="151.13093125" size="1.77843125" layer="95"/>
<attribute name="VALUE" x="127" y="126.99151875" size="0.6096" layer="96"/>
</instance>
<instance part="C23" gate="G$1" x="137.16" y="147.32" smashed="yes">
<attribute name="NAME" x="137.16" y="147.32" size="1.778" layer="95"/>
<attribute name="VALUE" x="137.16" y="139.7" size="1.778" layer="96"/>
</instance>
<instance part="C24" gate="G$1" x="116.84" y="144.78" smashed="yes">
<attribute name="NAME" x="116.84" y="144.78" size="1.778" layer="95"/>
<attribute name="VALUE" x="116.84" y="139.7" size="1.778" layer="96"/>
</instance>
<instance part="C30" gate="G$1" x="111.76" y="144.78" smashed="yes" rot="R270">
<attribute name="NAME" x="109.22" y="138.43093125" size="1.77843125" layer="95"/>
<attribute name="VALUE" x="109.22" y="126.99151875" size="0.6096" layer="96"/>
</instance>
<instance part="C32" gate="G$1" x="81.28" y="134.62" smashed="yes">
<attribute name="NAME" x="83.82" y="132.08" size="1.778" layer="95"/>
<attribute name="VALUE" x="83.82" y="134.62" size="1.778" layer="96"/>
</instance>
<instance part="C33" gate="G$1" x="76.2" y="134.62" smashed="yes" rot="R270">
<attribute name="NAME" x="68.58" y="133.35093125" size="1.77843125" layer="95"/>
<attribute name="VALUE" x="73.66" y="126.99151875" size="0.6096" layer="96"/>
</instance>
<instance part="C34" gate="G$1" x="99.06" y="142.24" smashed="yes">
<attribute name="NAME" x="99.06" y="142.24" size="1.778" layer="95"/>
<attribute name="VALUE" x="99.06" y="137.16" size="1.778" layer="96"/>
</instance>
<instance part="C35" gate="G$1" x="93.98" y="142.24" smashed="yes" rot="R270">
<attribute name="NAME" x="86.36" y="140.97093125" size="1.77843125" layer="95"/>
<attribute name="VALUE" x="91.44" y="126.99151875" size="0.6096" layer="96"/>
</instance>
<instance part="X3" gate="G$1" x="162.56" y="256.54" smashed="yes">
<attribute name="NAME" x="160.02" y="267.97" size="1.778" layer="95"/>
<attribute name="VALUE" x="160.02" y="254" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="Y1" gate="G$1" x="187.96" y="223.52" smashed="yes" rot="R270">
<attribute name="NAME" x="194.31" y="231.14" size="1.778" layer="95" rot="R270"/>
<attribute name="VALUE" x="181.61" y="222.25" size="1.778" layer="96" rot="MR270"/>
</instance>
<instance part="U$14" gate="G$1" x="472.44" y="111.76" smashed="yes" rot="MR0">
<attribute name="VALUE" x="473.964" y="112.776" size="1.27" layer="96" rot="MR0"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="GND" class="0">
<segment>
<pinref part="C7" gate="G$1" pin="2"/>
<pinref part="U$28" gate="G$1" pin="GND"/>
<wire x1="66.04" y1="309.88" x2="66.04" y2="307.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C6" gate="G$1" pin="2"/>
<pinref part="U$27" gate="G$1" pin="GND"/>
<wire x1="20.32" y1="309.88" x2="20.32" y2="307.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C8" gate="G$1" pin="2"/>
<pinref part="U$29" gate="G$1" pin="GND"/>
<wire x1="58.42" y1="309.88" x2="58.42" y2="307.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="GND1" gate="1" pin="GND"/>
<pinref part="X3" gate="G$1" pin="1"/>
<wire x1="175.26" y1="264.16" x2="172.72" y2="264.16" width="0.1524" layer="91"/>
<wire x1="175.26" y1="264.16" x2="175.26" y2="269.24" width="0.1524" layer="91"/>
<wire x1="175.26" y1="269.24" x2="180.34" y2="269.24" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="205.74" y1="220.98" x2="205.74" y2="215.9" width="0.1524" layer="91"/>
<wire x1="205.74" y1="215.9" x2="205.74" y2="213.36" width="0.1524" layer="91"/>
<wire x1="205.74" y1="213.36" x2="205.74" y2="210.82" width="0.1524" layer="91"/>
<junction x="205.74" y="215.9"/>
<junction x="205.74" y="213.36"/>
<junction x="205.74" y="210.82"/>
<junction x="205.74" y="210.82"/>
<pinref part="GND2" gate="1" pin="GND"/>
<pinref part="IC1" gate="G$1" pin="GND"/>
<pinref part="IC1" gate="G$1" pin="UGND"/>
<pinref part="IC1" gate="G$1" pin="GND1"/>
<pinref part="IC1" gate="G$1" pin="GND2"/>
<pinref part="IC1" gate="G$1" pin="GND3"/>
<wire x1="205.74" y1="210.82" x2="205.74" y2="208.28" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C9" gate="G$1" pin="2"/>
<pinref part="GND3" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="GND6" gate="1" pin="GND"/>
<pinref part="Y1" gate="G$1" pin="GND"/>
<wire x1="177.8" y1="223.52" x2="172.72" y2="223.52" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="GND12" gate="1" pin="GND"/>
<pinref part="C14" gate="G$1" pin="2"/>
<wire x1="88.9" y1="312.42" x2="88.9" y2="307.34" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="139.7" y1="96.52" x2="139.7" y2="88.9" width="0.1524" layer="91"/>
<pinref part="GND7" gate="1" pin="GND"/>
<pinref part="S2" gate="G$1" pin="1"/>
</segment>
<segment>
<pinref part="U2" gate="G$1" pin="GND"/>
<wire x1="35.56" y1="320.04" x2="35.56" y2="307.34" width="0.1524" layer="91"/>
<pinref part="U$30" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="C3" gate="G$1" pin="2"/>
<pinref part="U$33" gate="G$1" pin="GND"/>
<wire x1="63.5" y1="213.36" x2="63.5" y2="210.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R8" gate="G$1" pin="2"/>
<pinref part="U$36" gate="G$1" pin="GND"/>
<pinref part="U3" gate="G$1" pin="VSS"/>
<wire x1="48.26" y1="218.44" x2="50.8" y2="218.44" width="0.1524" layer="91"/>
<wire x1="50.8" y1="218.44" x2="50.8" y2="210.82" width="0.1524" layer="91"/>
<wire x1="50.8" y1="210.82" x2="55.88" y2="210.82" width="0.1524" layer="91"/>
<junction x="55.88" y="210.82"/>
</segment>
<segment>
<pinref part="U$12" gate="G$1" pin="GND"/>
<wire x1="96.52" y1="81.28" x2="96.52" y2="83.82" width="0.1524" layer="91"/>
<pinref part="X4" gate="G$1" pin="GND@1"/>
<wire x1="91.44" y1="81.28" x2="96.52" y2="81.28" width="0.1524" layer="91"/>
<junction x="96.52" y="81.28"/>
<pinref part="X4" gate="G$1" pin="GND@0"/>
<wire x1="91.44" y1="83.82" x2="96.52" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="NETSTAT2" gate="G$1" pin="C"/>
<pinref part="U$10" gate="G$1" pin="GND"/>
<wire x1="38.1" y1="63.5" x2="38.1" y2="66.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="NETSTAT1" gate="G$1" pin="C"/>
<wire x1="27.94" y1="66.04" x2="27.94" y2="63.5" width="0.1524" layer="91"/>
<pinref part="U$13" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="D5" gate="G$1" pin="A"/>
<wire x1="124.46" y1="309.88" x2="132.08" y2="309.88" width="0.1524" layer="91"/>
<wire x1="132.08" y1="309.88" x2="139.7" y2="309.88" width="0.1524" layer="91"/>
<wire x1="139.7" y1="309.88" x2="139.7" y2="314.96" width="0.1524" layer="91"/>
<pinref part="C2" gate="G$1" pin="2"/>
<wire x1="124.46" y1="312.42" x2="124.46" y2="309.88" width="0.1524" layer="91"/>
<junction x="124.46" y="309.88"/>
<pinref part="C5" gate="G$1" pin="2"/>
<wire x1="132.08" y1="312.42" x2="132.08" y2="309.88" width="0.1524" layer="91"/>
<junction x="132.08" y="309.88"/>
<pinref part="U$26" gate="G$1" pin="GND"/>
<wire x1="124.46" y1="307.34" x2="124.46" y2="309.88" width="0.1524" layer="91"/>
<pinref part="C4" gate="G$1" pin="2"/>
<wire x1="124.46" y1="309.88" x2="116.84" y2="309.88" width="0.1524" layer="91"/>
<wire x1="116.84" y1="309.88" x2="116.84" y2="312.42" width="0.1524" layer="91"/>
<wire x1="116.84" y1="309.88" x2="104.14" y2="309.88" width="0.1524" layer="91"/>
<junction x="116.84" y="309.88"/>
<pinref part="X6" gate="G$1" pin="1"/>
<wire x1="104.14" y1="309.88" x2="104.14" y2="314.96" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="MICGND"/>
<wire x1="457.2" y1="167.64" x2="467.36" y2="167.64" width="0.1524" layer="91"/>
<wire x1="467.36" y1="167.64" x2="467.36" y2="165.1" width="0.1524" layer="91"/>
<pinref part="U5" gate="G$1" pin="EP"/>
<wire x1="467.36" y1="165.1" x2="467.36" y2="160.02" width="0.1524" layer="91"/>
<wire x1="457.2" y1="165.1" x2="467.36" y2="165.1" width="0.1524" layer="91"/>
<junction x="467.36" y="165.1"/>
<pinref part="U5" gate="G$1" pin="AGND"/>
<wire x1="457.2" y1="170.18" x2="467.36" y2="170.18" width="0.1524" layer="91"/>
<wire x1="467.36" y1="170.18" x2="467.36" y2="167.64" width="0.1524" layer="91"/>
<junction x="467.36" y="167.64"/>
<pinref part="U5" gate="G$1" pin="DGND"/>
<wire x1="457.2" y1="172.72" x2="467.36" y2="172.72" width="0.1524" layer="91"/>
<wire x1="467.36" y1="172.72" x2="467.36" y2="170.18" width="0.1524" layer="91"/>
<junction x="467.36" y="170.18"/>
<pinref part="U$6" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="MICLP"/>
<pinref part="U$4" gate="G$1" pin="GND"/>
<wire x1="424.18" y1="187.96" x2="378.46" y2="187.96" width="0.1524" layer="91"/>
<wire x1="378.46" y1="187.96" x2="378.46" y2="185.42" width="0.1524" layer="91"/>
<pinref part="U5" gate="G$1" pin="MICLN"/>
<wire x1="378.46" y1="185.42" x2="378.46" y2="182.88" width="0.1524" layer="91"/>
<wire x1="424.18" y1="185.42" x2="378.46" y2="185.42" width="0.1524" layer="91"/>
<junction x="378.46" y="185.42"/>
</segment>
<segment>
<pinref part="C13" gate="G$1" pin="2"/>
<pinref part="U$5" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="C15" gate="G$1" pin="2"/>
<pinref part="U$11" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="C16" gate="G$1" pin="2"/>
<pinref part="U$18" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="JP4" gate="A" pin="1"/>
<pinref part="U$23" gate="G$1" pin="GND"/>
<wire x1="368.3" y1="172.72" x2="368.3" y2="167.64" width="0.1524" layer="91"/>
<wire x1="368.3" y1="167.64" x2="358.14" y2="167.64" width="0.1524" layer="91"/>
<junction x="368.3" y="167.64"/>
<pinref part="JP5" gate="A" pin="1"/>
<wire x1="358.14" y1="167.64" x2="358.14" y2="180.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="D3" gate="G$1" pin="A"/>
<wire x1="124.46" y1="213.36" x2="111.76" y2="213.36" width="0.1524" layer="91"/>
<wire x1="111.76" y1="213.36" x2="111.76" y2="231.14" width="0.1524" layer="91"/>
<wire x1="111.76" y1="231.14" x2="111.76" y2="238.76" width="0.1524" layer="91"/>
<wire x1="111.76" y1="238.76" x2="114.3" y2="238.76" width="0.1524" layer="91"/>
<wire x1="111.76" y1="213.36" x2="111.76" y2="195.58" width="0.1524" layer="91"/>
<junction x="111.76" y="213.36"/>
<pinref part="D9" gate="G$1" pin="A"/>
<wire x1="111.76" y1="195.58" x2="124.46" y2="195.58" width="0.1524" layer="91"/>
<pinref part="D12" gate="G$1" pin="A"/>
<wire x1="111.76" y1="195.58" x2="111.76" y2="177.8" width="0.1524" layer="91"/>
<wire x1="111.76" y1="177.8" x2="124.46" y2="177.8" width="0.1524" layer="91"/>
<junction x="111.76" y="195.58"/>
<pinref part="GND4" gate="1" pin="GND"/>
<wire x1="134.62" y1="231.14" x2="111.76" y2="231.14" width="0.1524" layer="91"/>
<junction x="111.76" y="231.14"/>
<pinref part="X2" gate="-4" pin="S"/>
</segment>
<segment>
<pinref part="LED1" gate="G$1" pin="C"/>
<pinref part="U$2" gate="G$1" pin="GND"/>
<wire x1="66.04" y1="175.26" x2="66.04" y2="172.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="X1" gate="G$1" pin="2"/>
<wire x1="73.66" y1="86.36" x2="83.82" y2="86.36" width="0.1524" layer="91"/>
<wire x1="83.82" y1="86.36" x2="83.82" y2="81.28" width="0.1524" layer="91"/>
<pinref part="U$25" gate="G$1" pin="GND"/>
</segment>
<segment>
<wire x1="355.6" y1="284.48" x2="360.68" y2="284.48" width="0.1524" layer="91"/>
<wire x1="360.68" y1="284.48" x2="360.68" y2="281.94" width="0.1524" layer="91"/>
<pinref part="U$32" gate="G$1" pin="GND"/>
<pinref part="U6" gate="A" pin="GND"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="VUSB_DET"/>
<wire x1="424.18" y1="254" x2="414.02" y2="254" width="0.1524" layer="91"/>
<pinref part="U$34" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="GND"/>
<pinref part="U$20" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="C21" gate="G$1" pin="2"/>
<pinref part="U$24" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="U$22" gate="G$1" pin="GND"/>
<pinref part="C19" gate="G$1" pin="2"/>
</segment>
<segment>
<pinref part="Q5" gate="-2" pin="S"/>
<pinref part="GND66" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="R7" gate="G$1" pin="1"/>
<pinref part="GND67" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="R16" gate="G$1" pin="1"/>
<pinref part="GND5" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="Q5" gate="-1" pin="S"/>
<pinref part="GND47" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C25" gate="G$1" pin="2"/>
<pinref part="C26" gate="G$1" pin="2"/>
<wire x1="490.22" y1="289.56" x2="497.84" y2="289.56" width="0.1524" layer="91"/>
<pinref part="C27" gate="G$1" pin="2"/>
<wire x1="497.84" y1="289.56" x2="505.46" y2="289.56" width="0.1524" layer="91"/>
<junction x="497.84" y="289.56"/>
<pinref part="C28" gate="G$1" pin="2"/>
<wire x1="505.46" y1="289.56" x2="513.08" y2="289.56" width="0.1524" layer="91"/>
<junction x="505.46" y="289.56"/>
<pinref part="C29" gate="G$1" pin="2"/>
<wire x1="513.08" y1="289.56" x2="520.7" y2="289.56" width="0.1524" layer="91"/>
<junction x="513.08" y="289.56"/>
<pinref part="C31" gate="G$1" pin="2"/>
<wire x1="520.7" y1="289.56" x2="528.32" y2="289.56" width="0.1524" layer="91"/>
<junction x="520.7" y="289.56"/>
<wire x1="528.32" y1="289.56" x2="528.32" y2="287.02" width="0.1524" layer="91"/>
<junction x="528.32" y="289.56"/>
<pinref part="U$44" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="C12" gate="G$1" pin="2"/>
<pinref part="C11" gate="G$1" pin="2"/>
<wire x1="406.4" y1="157.48" x2="414.02" y2="157.48" width="0.1524" layer="91"/>
<wire x1="414.02" y1="157.48" x2="421.64" y2="157.48" width="0.1524" layer="91"/>
<junction x="414.02" y="157.48"/>
<pinref part="C10" gate="G$1" pin="2"/>
<wire x1="406.4" y1="162.56" x2="406.4" y2="157.48" width="0.1524" layer="91"/>
<pinref part="U$7" gate="G$1" pin="GND"/>
<junction x="406.4" y="157.48"/>
<pinref part="C1" gate="G$1" pin="2"/>
<wire x1="398.78" y1="165.1" x2="398.78" y2="157.48" width="0.1524" layer="91"/>
<wire x1="398.78" y1="157.48" x2="406.4" y2="157.48" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SV1" gate="G$1" pin="12"/>
<pinref part="U$45" gate="G$1" pin="GND"/>
<wire x1="439.42" y1="114.3" x2="462.28" y2="114.3" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="L" gate="G$1" pin="C"/>
<pinref part="GND10" gate="1" pin="GND"/>
<wire x1="48.26" y1="66.04" x2="48.26" y2="63.5" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SIM2" gate="G$1" pin="GND"/>
<pinref part="GND8" gate="1" pin="GND"/>
<wire x1="68.58" y1="128.27" x2="68.58" y2="129.54" width="0.1524" layer="91"/>
<wire x1="68.58" y1="129.54" x2="68.58" y2="142.24" width="0.1524" layer="91"/>
<wire x1="68.58" y1="142.24" x2="64.77" y2="142.24" width="0.1524" layer="91"/>
<pinref part="C33" gate="G$1" pin="2"/>
<wire x1="68.58" y1="129.54" x2="76.2" y2="129.54" width="0.1524" layer="91"/>
<junction x="68.58" y="129.54"/>
<pinref part="C32" gate="G$1" pin="2"/>
<wire x1="76.2" y1="129.54" x2="81.28" y2="129.54" width="0.1524" layer="91"/>
<junction x="76.2" y="129.54"/>
<wire x1="81.28" y1="129.54" x2="93.98" y2="129.54" width="0.1524" layer="91"/>
<junction x="81.28" y="129.54"/>
<pinref part="C20" gate="G$1" pin="2"/>
<wire x1="93.98" y1="129.54" x2="99.06" y2="129.54" width="0.1524" layer="91"/>
<wire x1="99.06" y1="129.54" x2="111.76" y2="129.54" width="0.1524" layer="91"/>
<wire x1="111.76" y1="129.54" x2="116.84" y2="129.54" width="0.1524" layer="91"/>
<wire x1="116.84" y1="129.54" x2="129.54" y2="129.54" width="0.1524" layer="91"/>
<wire x1="129.54" y1="129.54" x2="137.16" y2="129.54" width="0.1524" layer="91"/>
<wire x1="137.16" y1="129.54" x2="144.78" y2="129.54" width="0.1524" layer="91"/>
<wire x1="144.78" y1="129.54" x2="144.78" y2="142.24" width="0.1524" layer="91"/>
<pinref part="C23" gate="G$1" pin="2"/>
<wire x1="137.16" y1="142.24" x2="137.16" y2="129.54" width="0.1524" layer="91"/>
<junction x="137.16" y="129.54"/>
<pinref part="C22" gate="G$1" pin="2"/>
<wire x1="129.54" y1="142.24" x2="129.54" y2="129.54" width="0.1524" layer="91"/>
<junction x="129.54" y="129.54"/>
<pinref part="C24" gate="G$1" pin="2"/>
<wire x1="116.84" y1="139.7" x2="116.84" y2="129.54" width="0.1524" layer="91"/>
<junction x="116.84" y="129.54"/>
<pinref part="C30" gate="G$1" pin="2"/>
<wire x1="111.76" y1="139.7" x2="111.76" y2="129.54" width="0.1524" layer="91"/>
<junction x="111.76" y="129.54"/>
<pinref part="C34" gate="G$1" pin="2"/>
<wire x1="99.06" y1="137.16" x2="99.06" y2="129.54" width="0.1524" layer="91"/>
<junction x="99.06" y="129.54"/>
<pinref part="C35" gate="G$1" pin="2"/>
<wire x1="93.98" y1="137.16" x2="93.98" y2="129.54" width="0.1524" layer="91"/>
<junction x="93.98" y="129.54"/>
</segment>
<segment>
<pinref part="U6" gate="A" pin="!OE"/>
<pinref part="U$19" gate="G$1" pin="GND"/>
<wire x1="320.04" y1="314.96" x2="292.1" y2="314.96" width="0.1524" layer="91"/>
<wire x1="292.1" y1="314.96" x2="292.1" y2="309.88" width="0.1524" layer="91"/>
<pinref part="U6" gate="A" pin="DIR2"/>
<wire x1="292.1" y1="309.88" x2="292.1" y2="304.8" width="0.1524" layer="91"/>
<wire x1="292.1" y1="304.8" x2="292.1" y2="302.26" width="0.1524" layer="91"/>
<wire x1="320.04" y1="309.88" x2="292.1" y2="309.88" width="0.1524" layer="91"/>
<junction x="292.1" y="309.88"/>
<pinref part="U6" gate="A" pin="DIR4"/>
<wire x1="320.04" y1="304.8" x2="292.1" y2="304.8" width="0.1524" layer="91"/>
<junction x="292.1" y="304.8"/>
</segment>
<segment>
<wire x1="381" y1="266.7" x2="381" y2="261.62" width="0.1524" layer="91"/>
<pinref part="U$9" gate="G$1" pin="GND"/>
<wire x1="424.18" y1="266.7" x2="381" y2="266.7" width="0.1524" layer="91"/>
<label x="408.94" y="266.7" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="DTR"/>
</segment>
</net>
<net name="D-" class="0">
<segment>
<wire x1="198.12" y1="259.08" x2="200.66" y2="259.08" width="0.1524" layer="91"/>
<wire x1="200.66" y1="259.08" x2="205.74" y2="254" width="0.1524" layer="91"/>
<pinref part="R4" gate="G$1" pin="2"/>
<pinref part="IC1" gate="G$1" pin="D-"/>
</segment>
</net>
<net name="D+" class="0">
<segment>
<wire x1="190.5" y1="256.54" x2="200.66" y2="256.54" width="0.1524" layer="91"/>
<wire x1="200.66" y1="256.54" x2="205.74" y2="251.46" width="0.1524" layer="91"/>
<pinref part="R5" gate="G$1" pin="2"/>
<pinref part="IC1" gate="G$1" pin="D+"/>
</segment>
</net>
<net name="MOSI" class="0">
<segment>
<wire x1="254" y1="236.22" x2="269.24" y2="236.22" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PB2(PDI/MOSI)"/>
<label x="256.54" y="236.22" size="1.778" layer="95"/>
</segment>
</net>
<net name="MISO" class="0">
<segment>
<wire x1="254" y1="238.76" x2="269.24" y2="238.76" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PB3(PDO/MISO)"/>
<label x="256.54" y="238.76" size="1.778" layer="95"/>
</segment>
</net>
<net name="SCK" class="0">
<segment>
<wire x1="254" y1="233.68" x2="269.24" y2="233.68" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PB1(SCK)"/>
<label x="256.54" y="233.68" size="1.778" layer="95"/>
</segment>
</net>
<net name="RST" class="0">
<segment>
<label x="200.66" y="281.94" size="1.778" layer="95"/>
<pinref part="IC1" gate="G$1" pin="/RESET"/>
<wire x1="205.74" y1="281.94" x2="200.66" y2="281.94" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="119.38" y1="86.36" x2="124.46" y2="86.36" width="0.1524" layer="91"/>
<label x="119.38" y="86.36" size="1.778" layer="95"/>
<pinref part="S2" gate="G$1" pin="2"/>
<wire x1="124.46" y1="86.36" x2="124.46" y2="96.52" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$11" class="0">
<segment>
<wire x1="198.12" y1="228.6" x2="205.74" y2="228.6" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="XTAL2"/>
<pinref part="Y1" gate="G$1" pin="OUT"/>
<wire x1="198.12" y1="228.6" x2="198.12" y2="210.82" width="0.1524" layer="91"/>
<wire x1="198.12" y1="210.82" x2="190.5" y2="210.82" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$12" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="XTAL1"/>
<pinref part="Y1" gate="G$1" pin="IN"/>
<wire x1="190.5" y1="236.22" x2="205.74" y2="236.22" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A5" class="0">
<segment>
<pinref part="J2" gate="G$0" pin="6"/>
<wire x1="215.9" y1="132.08" x2="208.28" y2="132.08" width="0.1524" layer="91"/>
<label x="208.28" y="132.08" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="276.86" x2="269.24" y2="276.86" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PF4(ADC4/TCK)"/>
<label x="256.54" y="276.86" size="1.778" layer="95"/>
</segment>
</net>
<net name="A4" class="0">
<segment>
<pinref part="J2" gate="G$0" pin="5"/>
<wire x1="215.9" y1="134.62" x2="208.28" y2="134.62" width="0.1524" layer="91"/>
<label x="208.28" y="134.62" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="274.32" x2="269.24" y2="274.32" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PF5(ADC5/TMS)"/>
<label x="256.54" y="274.32" size="1.778" layer="95"/>
</segment>
</net>
<net name="A3" class="0">
<segment>
<pinref part="J2" gate="G$0" pin="4"/>
<wire x1="215.9" y1="137.16" x2="208.28" y2="137.16" width="0.1524" layer="91"/>
<label x="208.28" y="137.16" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="271.78" x2="269.24" y2="271.78" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PF6(ADC6/TDO)"/>
<label x="256.54" y="271.78" size="1.778" layer="95"/>
</segment>
</net>
<net name="A2" class="0">
<segment>
<pinref part="J2" gate="G$0" pin="3"/>
<wire x1="215.9" y1="139.7" x2="208.28" y2="139.7" width="0.1524" layer="91"/>
<label x="208.28" y="139.7" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="269.24" x2="269.24" y2="269.24" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PF7(ADC7(TDI)"/>
<label x="256.54" y="269.24" size="1.778" layer="95"/>
</segment>
</net>
<net name="A1" class="0">
<segment>
<pinref part="J2" gate="G$0" pin="2"/>
<wire x1="215.9" y1="142.24" x2="208.28" y2="142.24" width="0.1524" layer="91"/>
<label x="208.28" y="142.24" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="256.54" x2="269.24" y2="256.54" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PC6(OC3A/!OC4A)"/>
<label x="256.54" y="256.54" size="1.778" layer="95"/>
</segment>
</net>
<net name="12" class="0">
<segment>
<wire x1="254" y1="223.52" x2="269.24" y2="223.52" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PD6(T1/ADC9/!OC4D)"/>
<label x="256.54" y="223.52" size="1.778" layer="95"/>
</segment>
</net>
<net name="2" class="0">
<segment>
<wire x1="254" y1="210.82" x2="269.24" y2="210.82" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PD1(INT1/SDA)"/>
<label x="256.54" y="210.82" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$15" class="0">
<segment>
<wire x1="172.72" y1="256.54" x2="180.34" y2="256.54" width="0.1524" layer="91"/>
<pinref part="R5" gate="G$1" pin="1"/>
<pinref part="X3" gate="G$1" pin="4"/>
</segment>
</net>
<net name="N$16" class="0">
<segment>
<wire x1="172.72" y1="259.08" x2="187.96" y2="259.08" width="0.1524" layer="91"/>
<pinref part="R4" gate="G$1" pin="1"/>
<pinref part="X3" gate="G$1" pin="3"/>
</segment>
</net>
<net name="AREF" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="AREF"/>
<wire x1="190.5" y1="241.3" x2="205.74" y2="241.3" width="0.1524" layer="91"/>
<label x="193.04" y="241.3" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C14" gate="G$1" pin="1"/>
<wire x1="88.9" y1="320.04" x2="88.9" y2="327.66" width="0.1524" layer="91"/>
<label x="88.9" y="320.04" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="MODEM_PWR_ON" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD3(INT3/TXD1)"/>
<wire x1="254" y1="215.9" x2="269.24" y2="215.9" width="0.1524" layer="91"/>
<label x="256.54" y="215.9" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="455.93" y1="323.85" x2="425.45" y2="323.85" width="0.1524" layer="91"/>
<wire x1="425.45" y1="323.85" x2="407.67" y2="323.85" width="0.1524" layer="91"/>
<pinref part="R16" gate="G$1" pin="2"/>
<wire x1="425.45" y1="323.85" x2="425.45" y2="321.31" width="0.1524" layer="91"/>
<junction x="425.45" y="323.85"/>
<pinref part="Q5" gate="-1" pin="G"/>
<label x="408.94" y="325.12" size="1.778" layer="95"/>
</segment>
</net>
<net name="0" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD2(INT2/RXD1)"/>
<wire x1="269.24" y1="213.36" x2="254" y2="213.36" width="0.1524" layer="91"/>
<label x="256.54" y="213.36" size="1.778" layer="95"/>
</segment>
</net>
<net name="+3V3" class="0">
<segment>
<wire x1="55.88" y1="325.12" x2="58.42" y2="325.12" width="0.1524" layer="91"/>
<wire x1="58.42" y1="325.12" x2="66.04" y2="325.12" width="0.1524" layer="91"/>
<wire x1="66.04" y1="325.12" x2="66.04" y2="327.66" width="0.1524" layer="91"/>
<pinref part="C7" gate="G$1" pin="1"/>
<wire x1="66.04" y1="325.12" x2="66.04" y2="317.5" width="0.1524" layer="91"/>
<junction x="66.04" y="325.12"/>
<pinref part="C8" gate="G$1" pin="1"/>
<wire x1="58.42" y1="317.5" x2="58.42" y2="325.12" width="0.1524" layer="91"/>
<junction x="58.42" y="325.12"/>
<pinref part="+3V4" gate="G$1" pin="+3V3"/>
<pinref part="U2" gate="G$1" pin="OUT"/>
</segment>
<segment>
<wire x1="205.74" y1="266.7" x2="205.74" y2="269.24" width="0.1524" layer="91"/>
<wire x1="195.58" y1="266.7" x2="205.74" y2="266.7" width="0.1524" layer="91"/>
<wire x1="205.74" y1="259.08" x2="205.74" y2="261.62" width="0.1524" layer="91"/>
<wire x1="205.74" y1="261.62" x2="195.58" y2="261.62" width="0.1524" layer="91"/>
<wire x1="195.58" y1="261.62" x2="195.58" y2="266.7" width="0.1524" layer="91"/>
<wire x1="195.58" y1="266.7" x2="195.58" y2="269.24" width="0.1524" layer="91"/>
<junction x="205.74" y="266.7"/>
<junction x="205.74" y="261.62"/>
<junction x="195.58" y="266.7"/>
<pinref part="IC1" gate="G$1" pin="VCC"/>
<pinref part="IC1" gate="G$1" pin="VCC1"/>
<pinref part="IC1" gate="G$1" pin="AVCC1"/>
<pinref part="IC1" gate="G$1" pin="AVCC"/>
<pinref part="+3V5" gate="G$1" pin="+3V3"/>
</segment>
<segment>
<wire x1="205.74" y1="246.38" x2="198.12" y2="246.38" width="0.1524" layer="91"/>
<wire x1="198.12" y1="246.38" x2="198.12" y2="251.46" width="0.1524" layer="91"/>
<wire x1="198.12" y1="251.46" x2="185.42" y2="251.46" width="0.1524" layer="91"/>
<pinref part="C9" gate="G$1" pin="1"/>
<pinref part="IC1" gate="G$1" pin="UCAP"/>
<pinref part="+3V6" gate="G$1" pin="+3V3"/>
<junction x="198.12" y="251.46"/>
</segment>
<segment>
<wire x1="254" y1="264.16" x2="274.32" y2="264.16" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PE2(!HWB)"/>
<pinref part="+3V7" gate="G$1" pin="+3V3"/>
</segment>
<segment>
<pinref part="+3V1" gate="G$1" pin="+3V3"/>
<wire x1="363.22" y1="322.58" x2="363.22" y2="327.66" width="0.1524" layer="91"/>
<wire x1="355.6" y1="322.58" x2="363.22" y2="322.58" width="0.1524" layer="91"/>
<pinref part="C21" gate="G$1" pin="1"/>
<junction x="363.22" y="322.58"/>
<pinref part="U6" gate="A" pin="VCCA"/>
<wire x1="378.46" y1="322.58" x2="363.22" y2="322.58" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SV1" gate="G$1" pin="8"/>
<wire x1="439.42" y1="119.38" x2="462.28" y2="119.38" width="0.1524" layer="91"/>
<wire x1="462.28" y1="119.38" x2="462.28" y2="121.92" width="0.1524" layer="91"/>
<pinref part="+3V3" gate="G$1" pin="+3V3"/>
</segment>
<segment>
<pinref part="+3V8" gate="G$1" pin="+3V3"/>
<wire x1="299.72" y1="307.34" x2="299.72" y2="312.42" width="0.1524" layer="91"/>
<pinref part="U6" gate="A" pin="DIR3"/>
<wire x1="299.72" y1="312.42" x2="299.72" y2="325.12" width="0.1524" layer="91"/>
<wire x1="299.72" y1="307.34" x2="320.04" y2="307.34" width="0.1524" layer="91"/>
<pinref part="U6" gate="A" pin="DIR1"/>
<wire x1="299.72" y1="312.42" x2="320.04" y2="312.42" width="0.1524" layer="91"/>
<junction x="299.72" y="312.42"/>
</segment>
</net>
<net name="VBUS" class="0">
<segment>
<pinref part="U$3" gate="G$1" pin="VBUS"/>
<junction x="20.32" y="325.12"/>
<pinref part="C6" gate="G$1" pin="1"/>
<wire x1="35.56" y1="325.12" x2="27.94" y2="325.12" width="0.1524" layer="91"/>
<wire x1="27.94" y1="325.12" x2="20.32" y2="325.12" width="0.1524" layer="91"/>
<wire x1="20.32" y1="325.12" x2="20.32" y2="317.5" width="0.1524" layer="91"/>
<wire x1="20.32" y1="330.2" x2="20.32" y2="325.12" width="0.1524" layer="91"/>
<pinref part="U2" gate="G$1" pin="IN"/>
<pinref part="D4" gate="G$1" pin="C"/>
<wire x1="12.7" y1="325.12" x2="20.32" y2="325.12" width="0.1524" layer="91"/>
<pinref part="R6" gate="G$1" pin="2"/>
<wire x1="27.94" y1="322.58" x2="27.94" y2="325.12" width="0.1524" layer="91"/>
<junction x="27.94" y="325.12"/>
</segment>
<segment>
<pinref part="U$1" gate="G$1" pin="VBUS"/>
<pinref part="X3" gate="G$1" pin="5"/>
<wire x1="177.8" y1="254" x2="172.72" y2="254" width="0.1524" layer="91"/>
<wire x1="177.8" y1="254" x2="177.8" y2="248.92" width="0.1524" layer="91"/>
<wire x1="177.8" y1="248.92" x2="180.34" y2="248.92" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="195.58" y1="276.86" x2="195.58" y2="279.4" width="0.1524" layer="91"/>
<wire x1="205.74" y1="276.86" x2="195.58" y2="276.86" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="VBUS"/>
<pinref part="U$8" gate="G$1" pin="VBUS"/>
</segment>
<segment>
<pinref part="U3" gate="G$1" pin="VDD"/>
<wire x1="5.08" y1="228.6" x2="5.08" y2="223.52" width="0.1524" layer="91"/>
<wire x1="5.08" y1="223.52" x2="22.86" y2="223.52" width="0.1524" layer="91"/>
<pinref part="CHG" gate="G$1" pin="A"/>
<wire x1="5.08" y1="218.44" x2="5.08" y2="223.52" width="0.1524" layer="91"/>
<junction x="5.08" y="223.52"/>
<pinref part="U$38" gate="G$1" pin="VBUS"/>
</segment>
<segment>
<pinref part="SV1" gate="G$1" pin="14"/>
<wire x1="439.42" y1="111.76" x2="454.66" y2="111.76" width="0.1524" layer="91"/>
<wire x1="454.66" y1="111.76" x2="454.66" y2="106.68" width="0.1524" layer="91"/>
<wire x1="454.66" y1="106.68" x2="472.44" y2="106.68" width="0.1524" layer="91"/>
<pinref part="U$14" gate="G$1" pin="VBUS"/>
<wire x1="472.44" y1="106.68" x2="472.44" y2="109.22" width="0.1524" layer="91"/>
</segment>
</net>
<net name="VBAT" class="0">
<segment>
<pinref part="U3" gate="G$1" pin="VBAT"/>
<pinref part="C3" gate="G$1" pin="1"/>
<wire x1="63.5" y1="223.52" x2="48.26" y2="223.52" width="0.1524" layer="91"/>
<wire x1="63.5" y1="220.98" x2="63.5" y2="223.52" width="0.1524" layer="91"/>
<junction x="63.5" y="223.52"/>
<pinref part="U$39" gate="G$1" pin="VBAT"/>
<wire x1="63.5" y1="228.6" x2="63.5" y2="223.52" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="D5" gate="G$1" pin="C"/>
<wire x1="116.84" y1="322.58" x2="124.46" y2="322.58" width="0.1524" layer="91"/>
<wire x1="124.46" y1="322.58" x2="132.08" y2="322.58" width="0.1524" layer="91"/>
<wire x1="132.08" y1="322.58" x2="139.7" y2="322.58" width="0.1524" layer="91"/>
<wire x1="139.7" y1="322.58" x2="139.7" y2="320.04" width="0.1524" layer="91"/>
<pinref part="C4" gate="G$1" pin="1"/>
<wire x1="116.84" y1="320.04" x2="116.84" y2="322.58" width="0.1524" layer="91"/>
<pinref part="C2" gate="G$1" pin="1"/>
<wire x1="124.46" y1="320.04" x2="124.46" y2="322.58" width="0.1524" layer="91"/>
<junction x="124.46" y="322.58"/>
<pinref part="C5" gate="G$1" pin="1"/>
<wire x1="132.08" y1="320.04" x2="132.08" y2="322.58" width="0.1524" layer="91"/>
<junction x="132.08" y="322.58"/>
<wire x1="124.46" y1="322.58" x2="124.46" y2="325.12" width="0.1524" layer="91"/>
<pinref part="U$37" gate="G$1" pin="VBAT"/>
<pinref part="X6" gate="G$1" pin="2"/>
<wire x1="104.14" y1="317.5" x2="104.14" y2="322.58" width="0.1524" layer="91"/>
<wire x1="104.14" y1="322.58" x2="116.84" y2="322.58" width="0.1524" layer="91"/>
<junction x="116.84" y="322.58"/>
</segment>
<segment>
<pinref part="D1" gate="G$1" pin="C"/>
<wire x1="101.6" y1="213.36" x2="109.22" y2="213.36" width="0.1524" layer="91"/>
<pinref part="D7" gate="G$1" pin="C"/>
<wire x1="101.6" y1="195.58" x2="109.22" y2="195.58" width="0.1524" layer="91"/>
<wire x1="109.22" y1="195.58" x2="109.22" y2="213.36" width="0.1524" layer="91"/>
<pinref part="D11" gate="G$1" pin="C"/>
<wire x1="101.6" y1="177.8" x2="109.22" y2="177.8" width="0.1524" layer="91"/>
<wire x1="109.22" y1="177.8" x2="109.22" y2="195.58" width="0.1524" layer="91"/>
<junction x="109.22" y="195.58"/>
<wire x1="109.22" y1="213.36" x2="109.22" y2="241.3" width="0.1524" layer="91"/>
<wire x1="109.22" y1="241.3" x2="114.3" y2="241.3" width="0.1524" layer="91"/>
<junction x="109.22" y="213.36"/>
<pinref part="U$46" gate="G$1" pin="VBAT"/>
<junction x="109.22" y="241.3"/>
<pinref part="X2" gate="-2" pin="S"/>
</segment>
<segment>
<pinref part="U$47" gate="G$1" pin="VBAT"/>
<pinref part="S1" gate="G$1" pin="3"/>
<wire x1="2.54" y1="190.5" x2="17.78" y2="190.5" width="0.1524" layer="91"/>
</segment>
</net>
<net name="13" class="0">
<segment>
<wire x1="254" y1="254" x2="269.24" y2="254" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PC7(ICP3/CLK0/OC4A)"/>
<label x="256.54" y="254" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="48.26" y1="86.36" x2="48.26" y2="99.06" width="0.1524" layer="91"/>
<label x="48.26" y="88.9" size="1.778" layer="95" rot="R90"/>
<pinref part="R10" gate="G$1" pin="1"/>
</segment>
</net>
<net name="A0" class="0">
<segment>
<pinref part="J2" gate="G$0" pin="1"/>
<wire x1="215.9" y1="144.78" x2="208.28" y2="144.78" width="0.1524" layer="91"/>
<label x="208.28" y="144.78" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="246.38" x2="269.24" y2="246.38" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PB6(OC1B/OC4B/ADC13)"/>
<label x="256.54" y="246.38" size="1.778" layer="95"/>
</segment>
</net>
<net name="3" class="0">
<segment>
<wire x1="254" y1="208.28" x2="269.24" y2="208.28" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PD0(INT0/OC0B/SCL)"/>
<label x="256.54" y="208.28" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<pinref part="CHG" gate="G$1" pin="C"/>
<pinref part="R2" gate="G$1" pin="1"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="R2" gate="G$1" pin="2"/>
<pinref part="U3" gate="G$1" pin="STAT"/>
</segment>
</net>
<net name="N$4" class="0">
<segment>
<pinref part="U3" gate="G$1" pin="PROG"/>
<pinref part="R8" gate="G$1" pin="1"/>
<wire x1="48.26" y1="220.98" x2="55.88" y2="220.98" width="0.1524" layer="91"/>
</segment>
</net>
<net name="NETSTAT1" class="0">
<segment>
<pinref part="R3" gate="G$1" pin="2"/>
<wire x1="27.94" y1="86.36" x2="27.94" y2="99.06" width="0.1524" layer="91"/>
<label x="27.94" y="86.36" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="GPIO1"/>
<wire x1="469.9" y1="243.84" x2="495.3" y2="243.84" width="0.1524" layer="91"/>
<label x="472.44" y="243.84" size="1.778" layer="95"/>
</segment>
</net>
<net name="NETSTAT2" class="0">
<segment>
<pinref part="R1" gate="G$1" pin="2"/>
<wire x1="38.1" y1="86.36" x2="38.1" y2="99.06" width="0.1524" layer="91"/>
<label x="38.1" y="86.36" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="GPIO2"/>
<wire x1="469.9" y1="241.3" x2="495.3" y2="241.3" width="0.1524" layer="91"/>
<label x="472.44" y="241.3" size="1.778" layer="95"/>
</segment>
</net>
<net name="SIMRST" class="0">
<segment>
<wire x1="485.14" y1="281.94" x2="469.9" y2="281.94" width="0.1524" layer="91"/>
<label x="472.44" y="281.94" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="SIM_RST"/>
</segment>
<segment>
<pinref part="SIM2" gate="G$1" pin="RST"/>
<label x="73.66" y="147.32" size="1.778" layer="95"/>
<pinref part="C24" gate="G$1" pin="1"/>
<pinref part="C30" gate="G$1" pin="1"/>
<wire x1="116.84" y1="147.32" x2="111.76" y2="147.32" width="0.1524" layer="91"/>
<wire x1="111.76" y1="147.32" x2="64.77" y2="147.32" width="0.1524" layer="91"/>
<junction x="111.76" y="147.32"/>
</segment>
</net>
<net name="SIMCLK" class="0">
<segment>
<wire x1="469.9" y1="284.48" x2="485.14" y2="284.48" width="0.1524" layer="91"/>
<label x="472.44" y="284.48" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="SIM_CLK"/>
</segment>
<segment>
<pinref part="SIM2" gate="G$1" pin="CLK"/>
<wire x1="64.77" y1="144.78" x2="93.98" y2="144.78" width="0.1524" layer="91"/>
<label x="73.66" y="144.78" size="1.778" layer="95"/>
<pinref part="C34" gate="G$1" pin="1"/>
<pinref part="C35" gate="G$1" pin="1"/>
<wire x1="99.06" y1="144.78" x2="93.98" y2="144.78" width="0.1524" layer="91"/>
<junction x="93.98" y="144.78"/>
</segment>
</net>
<net name="SIMDATA" class="0">
<segment>
<wire x1="485.14" y1="279.4" x2="469.9" y2="279.4" width="0.1524" layer="91"/>
<label x="472.44" y="279.4" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="SIM_IO"/>
</segment>
<segment>
<pinref part="SIM2" gate="G$1" pin="I/O"/>
<wire x1="64.77" y1="137.16" x2="76.2" y2="137.16" width="0.1524" layer="91"/>
<label x="73.66" y="137.16" size="1.778" layer="95"/>
<pinref part="C32" gate="G$1" pin="1"/>
<wire x1="76.2" y1="137.16" x2="81.28" y2="137.16" width="0.1524" layer="91"/>
<wire x1="81.28" y1="137.16" x2="83.82" y2="137.16" width="0.1524" layer="91"/>
<junction x="81.28" y="137.16"/>
<pinref part="C33" gate="G$1" pin="1"/>
<junction x="76.2" y="137.16"/>
</segment>
</net>
<net name="UART_RXD" class="0">
<segment>
<wire x1="424.18" y1="274.32" x2="408.94" y2="274.32" width="0.1524" layer="91"/>
<label x="408.94" y="274.32" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="RXD"/>
</segment>
<segment>
<label x="302.26" y="289.56" size="1.778" layer="95"/>
<pinref part="U6" gate="A" pin="B2"/>
<wire x1="302.26" y1="289.56" x2="320.04" y2="289.56" width="0.1524" layer="91"/>
</segment>
</net>
<net name="GSM_ANT" class="0">
<segment>
<label x="73.66" y="88.9" size="1.778" layer="95"/>
<pinref part="X4" gate="G$1" pin="SIGNAL"/>
<wire x1="73.66" y1="88.9" x2="83.82" y2="88.9" width="0.1524" layer="91"/>
<pinref part="X1" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="406.4" y1="287.02" x2="424.18" y2="287.02" width="0.1524" layer="91"/>
<pinref part="U4" gate="G$1" pin="ANT1"/>
<label x="406.4" y="287.02" size="1.778" layer="95"/>
</segment>
</net>
<net name="UART_RTS" class="0">
<segment>
<wire x1="408.94" y1="271.78" x2="424.18" y2="271.78" width="0.1524" layer="91"/>
<label x="408.94" y="271.78" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="RTS"/>
</segment>
<segment>
<label x="360.68" y="292.1" size="1.778" layer="95"/>
<pinref part="U6" gate="A" pin="B3"/>
<wire x1="355.6" y1="292.1" x2="375.92" y2="292.1" width="0.1524" layer="91"/>
</segment>
</net>
<net name="8_UART_TXD" class="0">
<segment>
<wire x1="254" y1="241.3" x2="269.24" y2="241.3" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PB4(ADC11)"/>
<label x="256.54" y="241.3" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="320.04" y1="299.72" x2="317.5" y2="299.72" width="0.1524" layer="91"/>
<label x="302.26" y="299.72" size="1.778" layer="95"/>
<pinref part="U6" gate="A" pin="A1"/>
</segment>
</net>
<net name="9_UART_RXD" class="0">
<segment>
<wire x1="254" y1="243.84" x2="269.24" y2="243.84" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PB5(OC1A/ADC12/!OC4B)"/>
<label x="256.54" y="243.84" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="320.04" y1="297.18" x2="317.5" y2="297.18" width="0.1524" layer="91"/>
<label x="302.26" y="297.18" size="1.778" layer="95"/>
<pinref part="U6" gate="A" pin="A2"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="R1" gate="G$1" pin="1"/>
<pinref part="NETSTAT2" gate="G$1" pin="A"/>
<wire x1="38.1" y1="76.2" x2="38.1" y2="73.66" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$9" class="0">
<segment>
<pinref part="R3" gate="G$1" pin="1"/>
<pinref part="NETSTAT1" gate="G$1" pin="A"/>
<wire x1="27.94" y1="76.2" x2="27.94" y2="73.66" width="0.1524" layer="91"/>
</segment>
</net>
<net name="EN" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="EN"/>
<wire x1="35.56" y1="322.58" x2="33.02" y2="322.58" width="0.1524" layer="91"/>
<wire x1="33.02" y1="322.58" x2="33.02" y2="312.42" width="0.1524" layer="91"/>
<pinref part="R6" gate="G$1" pin="1"/>
<wire x1="33.02" y1="312.42" x2="27.94" y2="312.42" width="0.1524" layer="91"/>
<label x="27.94" y="312.42" size="1.778" layer="95"/>
</segment>
</net>
<net name="6_UART_RTS" class="0">
<segment>
<wire x1="254" y1="248.92" x2="269.24" y2="248.92" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PB7(OC0A/OC1C/RTS)"/>
<label x="256.54" y="248.92" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U6" gate="A" pin="A3"/>
<wire x1="355.6" y1="299.72" x2="375.92" y2="299.72" width="0.1524" layer="91"/>
<label x="360.68" y="299.72" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_CLK" class="0">
<segment>
<pinref part="U4" gate="G$1" pin="I2S_CLK"/>
<wire x1="424.18" y1="238.76" x2="386.08" y2="238.76" width="0.1524" layer="91"/>
<label x="386.08" y="238.76" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="BCLK"/>
<wire x1="424.18" y1="177.8" x2="386.08" y2="177.8" width="0.1524" layer="91"/>
<label x="386.08" y="177.8" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_RXD" class="0">
<segment>
<wire x1="424.18" y1="243.84" x2="386.08" y2="243.84" width="0.1524" layer="91"/>
<label x="386.08" y="243.84" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="I2S_RXD"/>
</segment>
<segment>
<wire x1="469.9" y1="187.96" x2="457.2" y2="187.96" width="0.1524" layer="91"/>
<label x="459.74" y="187.96" size="1.778" layer="95"/>
<pinref part="U5" gate="G$1" pin="SDOUT"/>
</segment>
</net>
<net name="I2S_TXD" class="0">
<segment>
<wire x1="424.18" y1="241.3" x2="386.08" y2="241.3" width="0.1524" layer="91"/>
<label x="386.08" y="241.3" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="I2S_TXD"/>
</segment>
<segment>
<wire x1="424.18" y1="198.12" x2="386.08" y2="198.12" width="0.1524" layer="91"/>
<label x="386.08" y="198.12" size="1.778" layer="95"/>
<pinref part="U5" gate="G$1" pin="SDIN"/>
</segment>
</net>
<net name="I2S_WA" class="0">
<segment>
<wire x1="424.18" y1="236.22" x2="386.08" y2="236.22" width="0.1524" layer="91"/>
<label x="386.08" y="236.22" size="1.778" layer="95"/>
<pinref part="U4" gate="G$1" pin="I2S_WA"/>
</segment>
<segment>
<wire x1="424.18" y1="180.34" x2="386.08" y2="180.34" width="0.1524" layer="91"/>
<label x="386.08" y="180.34" size="1.778" layer="95"/>
<pinref part="U5" gate="G$1" pin="LRCLK"/>
</segment>
</net>
<net name="GPIO6_CODEC_CLK" class="0">
<segment>
<pinref part="U4" gate="G$1" pin="GPIO6"/>
<wire x1="469.9" y1="231.14" x2="495.3" y2="231.14" width="0.1524" layer="91"/>
<label x="472.44" y="231.14" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="398.78" y1="182.88" x2="424.18" y2="182.88" width="0.1524" layer="91"/>
<label x="401.32" y="182.88" size="1.778" layer="95"/>
<pinref part="U5" gate="G$1" pin="MCLK"/>
</segment>
</net>
<net name="VSIM" class="0">
<segment>
<pinref part="U4" gate="G$1" pin="VSIM"/>
<wire x1="469.9" y1="287.02" x2="485.14" y2="287.02" width="0.1524" layer="91"/>
<label x="472.44" y="287.02" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="SIM2" gate="G$1" pin="VCC"/>
<label x="73.66" y="149.86" size="1.778" layer="95"/>
<pinref part="C22" gate="G$1" pin="1"/>
<wire x1="64.77" y1="149.86" x2="129.54" y2="149.86" width="0.1524" layer="91"/>
<pinref part="C23" gate="G$1" pin="1"/>
<pinref part="C20" gate="G$1" pin="1"/>
<wire x1="137.16" y1="149.86" x2="144.78" y2="149.86" width="0.1524" layer="91"/>
<wire x1="137.16" y1="149.86" x2="129.54" y2="149.86" width="0.1524" layer="91"/>
<junction x="137.16" y="149.86"/>
<junction x="129.54" y="149.86"/>
</segment>
</net>
<net name="SCL" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="SCL"/>
<wire x1="424.18" y1="195.58" x2="378.46" y2="195.58" width="0.1524" layer="91"/>
<label x="386.08" y="195.58" size="1.778" layer="95"/>
<wire x1="378.46" y1="195.58" x2="378.46" y2="203.2" width="0.1524" layer="91"/>
<pinref part="R12" gate="G$1" pin="2"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="SCL"/>
<wire x1="469.9" y1="266.7" x2="485.14" y2="266.7" width="0.1524" layer="91"/>
<label x="472.44" y="266.7" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDA" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="SDA"/>
<label x="462.28" y="177.8" size="1.778" layer="95"/>
<wire x1="457.2" y1="177.8" x2="508" y2="177.8" width="0.1524" layer="91"/>
<wire x1="508" y1="177.8" x2="508" y2="190.5" width="0.1524" layer="91"/>
<pinref part="R13" gate="G$1" pin="2"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="SDA"/>
<wire x1="469.9" y1="264.16" x2="485.14" y2="264.16" width="0.1524" layer="91"/>
<label x="472.44" y="264.16" size="1.778" layer="95"/>
</segment>
</net>
<net name="CODEC_BIAS" class="0">
<segment>
<pinref part="R9" gate="G$1" pin="1"/>
<label x="411.48" y="215.9" size="1.778" layer="95"/>
<wire x1="411.48" y1="215.9" x2="401.32" y2="215.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="MICBIAS"/>
<pinref part="C1" gate="G$1" pin="1"/>
<wire x1="424.18" y1="172.72" x2="398.78" y2="172.72" width="0.1524" layer="91"/>
<label x="406.4" y="172.72" size="1.778" layer="95"/>
</segment>
</net>
<net name="MIC_P" class="0">
<segment>
<label x="386.08" y="193.04" size="1.778" layer="95"/>
<pinref part="C17" gate="G$1" pin="1"/>
<wire x1="411.48" y1="193.04" x2="401.32" y2="193.04" width="0.1524" layer="91"/>
<pinref part="JP6" gate="A" pin="2"/>
<pinref part="JP2" gate="A" pin="1"/>
<wire x1="401.32" y1="193.04" x2="355.6" y2="193.04" width="0.1524" layer="91"/>
<wire x1="401.32" y1="203.2" x2="401.32" y2="193.04" width="0.1524" layer="91"/>
<junction x="401.32" y="193.04"/>
</segment>
</net>
<net name="MIC_N" class="0">
<segment>
<label x="386.08" y="190.5" size="1.778" layer="95"/>
<pinref part="C18" gate="G$1" pin="1"/>
<pinref part="R14" gate="G$1" pin="1"/>
<wire x1="368.3" y1="190.5" x2="416.56" y2="190.5" width="0.1524" layer="91"/>
<wire x1="368.3" y1="187.96" x2="368.3" y2="190.5" width="0.1524" layer="91"/>
<pinref part="JP6" gate="A" pin="1"/>
<wire x1="368.3" y1="190.5" x2="358.14" y2="190.5" width="0.1524" layer="91"/>
<junction x="368.3" y="190.5"/>
<pinref part="JP5" gate="A" pin="2"/>
<wire x1="358.14" y1="190.5" x2="355.6" y2="190.5" width="0.1524" layer="91"/>
<wire x1="358.14" y1="182.88" x2="358.14" y2="190.5" width="0.1524" layer="91"/>
<junction x="358.14" y="190.5"/>
</segment>
</net>
<net name="N$10" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="REF"/>
<pinref part="C12" gate="G$1" pin="1"/>
<wire x1="424.18" y1="165.1" x2="421.64" y2="165.1" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$13" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="PREG"/>
<pinref part="C11" gate="G$1" pin="1"/>
<wire x1="414.02" y1="165.1" x2="414.02" y2="167.64" width="0.1524" layer="91"/>
<wire x1="414.02" y1="167.64" x2="424.18" y2="167.64" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$14" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="REG"/>
<pinref part="C10" gate="G$1" pin="1"/>
<wire x1="424.18" y1="170.18" x2="406.4" y2="170.18" width="0.1524" layer="91"/>
</segment>
</net>
<net name="SPK_P" class="0">
<segment>
<wire x1="457.2" y1="182.88" x2="477.52" y2="182.88" width="0.1524" layer="91"/>
<label x="459.74" y="182.88" size="1.778" layer="95"/>
<pinref part="U5" gate="G$1" pin="OUTP"/>
<pinref part="JP7" gate="A" pin="1"/>
</segment>
</net>
<net name="SPK_N" class="0">
<segment>
<label x="459.74" y="180.34" size="1.778" layer="95"/>
<pinref part="U5" gate="G$1" pin="OUTN"/>
<pinref part="JP7" gate="A" pin="2"/>
<wire x1="477.52" y1="180.34" x2="457.2" y2="180.34" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$18" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="!IRQ"/>
<wire x1="457.2" y1="185.42" x2="500.38" y2="185.42" width="0.1524" layer="91"/>
<pinref part="R11" gate="G$1" pin="2"/>
<wire x1="500.38" y1="185.42" x2="500.38" y2="190.5" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$8" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="MICRP"/>
<wire x1="424.18" y1="193.04" x2="419.1" y2="193.04" width="0.1524" layer="91"/>
<pinref part="C17" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$17" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="MICRN"/>
<pinref part="C18" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$20" class="0">
<segment>
<pinref part="R9" gate="G$1" pin="2"/>
<pinref part="JP2" gate="A" pin="2"/>
</segment>
</net>
<net name="N$21" class="0">
<segment>
<pinref part="R14" gate="G$1" pin="2"/>
<pinref part="JP4" gate="A" pin="2"/>
<wire x1="368.3" y1="177.8" x2="368.3" y2="175.26" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<wire x1="93.98" y1="241.3" x2="76.2" y2="241.3" width="0.1524" layer="91"/>
<wire x1="76.2" y1="241.3" x2="76.2" y2="185.42" width="0.1524" layer="91"/>
<pinref part="D11" gate="G$1" pin="A"/>
<wire x1="76.2" y1="185.42" x2="76.2" y2="177.8" width="0.1524" layer="91"/>
<wire x1="76.2" y1="177.8" x2="91.44" y2="177.8" width="0.1524" layer="91"/>
<wire x1="76.2" y1="185.42" x2="139.7" y2="185.42" width="0.1524" layer="91"/>
<junction x="76.2" y="185.42"/>
<pinref part="D12" gate="G$1" pin="C"/>
<wire x1="139.7" y1="185.42" x2="139.7" y2="177.8" width="0.1524" layer="91"/>
<wire x1="139.7" y1="177.8" x2="134.62" y2="177.8" width="0.1524" layer="91"/>
<pinref part="X2" gate="-1" pin="S"/>
</segment>
</net>
<net name="N$22" class="0">
<segment>
<wire x1="93.98" y1="238.76" x2="78.74" y2="238.76" width="0.1524" layer="91"/>
<pinref part="D7" gate="G$1" pin="A"/>
<wire x1="78.74" y1="238.76" x2="78.74" y2="203.2" width="0.1524" layer="91"/>
<wire x1="78.74" y1="203.2" x2="78.74" y2="195.58" width="0.1524" layer="91"/>
<wire x1="78.74" y1="195.58" x2="91.44" y2="195.58" width="0.1524" layer="91"/>
<pinref part="D9" gate="G$1" pin="C"/>
<wire x1="139.7" y1="203.2" x2="139.7" y2="195.58" width="0.1524" layer="91"/>
<wire x1="139.7" y1="195.58" x2="134.62" y2="195.58" width="0.1524" layer="91"/>
<wire x1="78.74" y1="203.2" x2="139.7" y2="203.2" width="0.1524" layer="91"/>
<junction x="78.74" y="203.2"/>
<pinref part="X2" gate="-3" pin="S"/>
</segment>
</net>
<net name="N$23" class="0">
<segment>
<wire x1="93.98" y1="236.22" x2="81.28" y2="236.22" width="0.1524" layer="91"/>
<pinref part="D1" gate="G$1" pin="A"/>
<wire x1="81.28" y1="236.22" x2="81.28" y2="220.98" width="0.1524" layer="91"/>
<wire x1="81.28" y1="220.98" x2="81.28" y2="213.36" width="0.1524" layer="91"/>
<wire x1="81.28" y1="213.36" x2="91.44" y2="213.36" width="0.1524" layer="91"/>
<wire x1="81.28" y1="220.98" x2="139.7" y2="220.98" width="0.1524" layer="91"/>
<wire x1="139.7" y1="220.98" x2="139.7" y2="213.36" width="0.1524" layer="91"/>
<junction x="81.28" y="220.98"/>
<pinref part="D3" gate="G$1" pin="C"/>
<wire x1="139.7" y1="213.36" x2="134.62" y2="213.36" width="0.1524" layer="91"/>
<pinref part="X2" gate="-5" pin="S"/>
</segment>
</net>
<net name="VLED" class="0">
<segment>
<pinref part="R15" gate="G$1" pin="1"/>
<wire x1="33.02" y1="193.04" x2="45.72" y2="193.04" width="0.1524" layer="91"/>
<pinref part="S1" gate="G$1" pin="1"/>
<wire x1="45.72" y1="190.5" x2="45.72" y2="193.04" width="0.1524" layer="91"/>
<label x="35.56" y="193.04" size="1.778" layer="95"/>
</segment>
</net>
<net name="V_INT" class="0">
<segment>
<pinref part="U4" gate="G$1" pin="V_INT"/>
<wire x1="469.9" y1="292.1" x2="477.52" y2="292.1" width="0.1524" layer="91"/>
<label x="472.44" y="292.1" size="1.778" layer="95"/>
<wire x1="482.6" y1="289.56" x2="477.52" y2="289.56" width="0.1524" layer="91"/>
<wire x1="477.52" y1="289.56" x2="477.52" y2="292.1" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C19" gate="G$1" pin="1"/>
<label x="360.68" y="320.04" size="1.778" layer="95"/>
<pinref part="U6" gate="A" pin="VCCB"/>
<wire x1="355.6" y1="320.04" x2="370.84" y2="320.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R12" gate="G$1" pin="1"/>
<wire x1="378.46" y1="213.36" x2="378.46" y2="215.9" width="0.1524" layer="91"/>
<wire x1="378.46" y1="215.9" x2="381" y2="215.9" width="0.1524" layer="91"/>
<label x="381" y="215.9" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="477.52" y1="208.28" x2="477.52" y2="210.82" width="0.1524" layer="91"/>
<wire x1="477.52" y1="210.82" x2="477.52" y2="213.36" width="0.1524" layer="91"/>
<wire x1="477.52" y1="213.36" x2="480.06" y2="213.36" width="0.1524" layer="91"/>
<label x="480.06" y="213.36" size="1.778" layer="95"/>
<pinref part="U5" gate="G$1" pin="DVDD"/>
<wire x1="457.2" y1="198.12" x2="457.2" y2="210.82" width="0.1524" layer="91"/>
<wire x1="457.2" y1="210.82" x2="477.52" y2="210.82" width="0.1524" layer="91"/>
<junction x="477.52" y="210.82"/>
<pinref part="U5" gate="G$1" pin="AVDD"/>
<wire x1="457.2" y1="195.58" x2="459.74" y2="195.58" width="0.1524" layer="91"/>
<wire x1="459.74" y1="195.58" x2="459.74" y2="208.28" width="0.1524" layer="91"/>
<wire x1="459.74" y1="208.28" x2="464.82" y2="208.28" width="0.1524" layer="91"/>
<pinref part="R13" gate="G$1" pin="1"/>
<wire x1="464.82" y1="208.28" x2="472.44" y2="208.28" width="0.1524" layer="91"/>
<wire x1="472.44" y1="208.28" x2="477.52" y2="208.28" width="0.1524" layer="91"/>
<wire x1="508" y1="200.66" x2="508" y2="210.82" width="0.1524" layer="91"/>
<wire x1="508" y1="210.82" x2="500.38" y2="210.82" width="0.1524" layer="91"/>
<pinref part="C13" gate="G$1" pin="1"/>
<junction x="464.82" y="208.28"/>
<pinref part="C15" gate="G$1" pin="1"/>
<junction x="472.44" y="208.28"/>
<pinref part="R11" gate="G$1" pin="1"/>
<wire x1="500.38" y1="210.82" x2="487.68" y2="210.82" width="0.1524" layer="91"/>
<wire x1="487.68" y1="210.82" x2="482.6" y2="210.82" width="0.1524" layer="91"/>
<wire x1="482.6" y1="210.82" x2="477.52" y2="210.82" width="0.1524" layer="91"/>
<wire x1="500.38" y1="200.66" x2="500.38" y2="210.82" width="0.1524" layer="91"/>
<junction x="500.38" y="210.82"/>
<pinref part="U5" gate="G$1" pin="DVDDIO"/>
<wire x1="457.2" y1="193.04" x2="482.6" y2="193.04" width="0.1524" layer="91"/>
<wire x1="482.6" y1="193.04" x2="482.6" y2="210.82" width="0.1524" layer="91"/>
<junction x="482.6" y="210.82"/>
<pinref part="C16" gate="G$1" pin="1"/>
<wire x1="487.68" y1="208.28" x2="487.68" y2="210.82" width="0.1524" layer="91"/>
<junction x="487.68" y="210.82"/>
</segment>
<segment>
<pinref part="SV1" gate="G$1" pin="10"/>
<wire x1="439.42" y1="116.84" x2="462.28" y2="116.84" width="0.1524" layer="91"/>
<label x="457.2" y="116.84" size="1.778" layer="95"/>
</segment>
</net>
<net name="UART_TXD" class="0">
<segment>
<pinref part="U4" gate="G$1" pin="TXD"/>
<wire x1="424.18" y1="276.86" x2="408.94" y2="276.86" width="0.1524" layer="91"/>
<label x="408.94" y="276.86" size="1.778" layer="95"/>
</segment>
<segment>
<label x="302.26" y="292.1" size="1.778" layer="95"/>
<pinref part="U6" gate="A" pin="B1"/>
<wire x1="302.26" y1="292.1" x2="320.04" y2="292.1" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$25" class="0">
<segment>
<pinref part="LED1" gate="G$1" pin="A"/>
<pinref part="R15" gate="G$1" pin="2"/>
<wire x1="66.04" y1="190.5" x2="66.04" y2="182.88" width="0.1524" layer="91"/>
</segment>
</net>
<net name="MODEM_RESET_N" class="0">
<segment>
<wire x1="455.93" y1="344.17" x2="425.45" y2="344.17" width="0.1524" layer="91"/>
<wire x1="425.45" y1="344.17" x2="407.67" y2="344.17" width="0.1524" layer="91"/>
<pinref part="Q5" gate="-2" pin="G"/>
<pinref part="R7" gate="G$1" pin="2"/>
<wire x1="425.45" y1="341.63" x2="425.45" y2="344.17" width="0.1524" layer="91"/>
<junction x="425.45" y="344.17"/>
<label x="408.94" y="345.44" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="218.44" x2="269.24" y2="218.44" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PD4(ICP1/ADC8)"/>
<label x="256.54" y="218.44" size="1.778" layer="95"/>
</segment>
</net>
<net name="M_RESET_N_PRE" class="0">
<segment>
<wire x1="485.14" y1="353.06" x2="461.01" y2="353.06" width="0.1524" layer="91"/>
<pinref part="Q5" gate="-2" pin="D"/>
<wire x1="461.01" y1="353.06" x2="461.01" y2="351.79" width="0.1524" layer="91"/>
<label x="461.01" y="353.06" size="1.778" layer="95"/>
<pinref part="JP1" gate="A" pin="1"/>
</segment>
</net>
<net name="A6" class="0">
<segment>
<pinref part="J2" gate="G$0" pin="7"/>
<wire x1="215.9" y1="129.54" x2="208.28" y2="129.54" width="0.1524" layer="91"/>
<label x="208.28" y="129.54" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="279.4" x2="269.24" y2="279.4" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PF1(ADC1)"/>
<label x="256.54" y="279.4" size="1.778" layer="95"/>
</segment>
</net>
<net name="A7" class="0">
<segment>
<pinref part="J2" gate="G$0" pin="8"/>
<wire x1="215.9" y1="127" x2="208.28" y2="127" width="0.1524" layer="91"/>
<label x="208.28" y="127" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="254" y1="281.94" x2="269.24" y2="281.94" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PF0(ADC0)"/>
<label x="256.54" y="281.94" size="1.778" layer="95"/>
</segment>
</net>
<net name="M_PWR_ON" class="0">
<segment>
<pinref part="JP3" gate="A" pin="2"/>
<label x="490.22" y="332.74" size="1.778" layer="95"/>
<wire x1="487.68" y1="332.74" x2="505.46" y2="332.74" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="PWR_ON"/>
<label x="406.4" y="297.18" size="1.778" layer="95"/>
<wire x1="424.18" y1="297.18" x2="406.4" y2="297.18" width="0.1524" layer="91"/>
</segment>
</net>
<net name="M_PWR_ON_PRE" class="0">
<segment>
<pinref part="Q5" gate="-1" pin="D"/>
<pinref part="JP3" gate="A" pin="1"/>
<wire x1="461.01" y1="331.47" x2="461.01" y2="332.74" width="0.1524" layer="91"/>
<wire x1="461.01" y1="332.74" x2="485.14" y2="332.74" width="0.1524" layer="91"/>
<label x="462.28" y="332.74" size="1.778" layer="95"/>
</segment>
</net>
<net name="M_RESET_N" class="0">
<segment>
<pinref part="JP1" gate="A" pin="2"/>
<label x="490.22" y="353.06" size="1.778" layer="95"/>
<wire x1="487.68" y1="353.06" x2="505.46" y2="353.06" width="0.1524" layer="91"/>
</segment>
<segment>
<label x="406.4" y="294.64" size="1.778" layer="95"/>
<wire x1="406.4" y1="294.64" x2="424.18" y2="294.64" width="0.1524" layer="91"/>
<pinref part="U4" gate="G$1" pin="RESET_N"/>
</segment>
</net>
<net name="N$24" class="0">
<segment>
<pinref part="J1" gate="G$1" pin="RING1_SWITCH"/>
<wire x1="388.62" y1="106.68" x2="406.4" y2="106.68" width="0.1524" layer="91"/>
<wire x1="406.4" y1="106.68" x2="406.4" y2="121.92" width="0.1524" layer="91"/>
<pinref part="SV1" gate="G$1" pin="5"/>
<wire x1="406.4" y1="121.92" x2="424.18" y2="121.92" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$26" class="0">
<segment>
<pinref part="J1" gate="G$1" pin="RING2_SWITCH"/>
<wire x1="388.62" y1="116.84" x2="401.32" y2="116.84" width="0.1524" layer="91"/>
<wire x1="401.32" y1="116.84" x2="401.32" y2="124.46" width="0.1524" layer="91"/>
<pinref part="SV1" gate="G$1" pin="3"/>
<wire x1="401.32" y1="124.46" x2="424.18" y2="124.46" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$27" class="0">
<segment>
<pinref part="J1" gate="G$1" pin="TIP"/>
<wire x1="388.62" y1="96.52" x2="408.94" y2="96.52" width="0.1524" layer="91"/>
<wire x1="408.94" y1="96.52" x2="408.94" y2="119.38" width="0.1524" layer="91"/>
<pinref part="SV1" gate="G$1" pin="7"/>
<wire x1="408.94" y1="119.38" x2="424.18" y2="119.38" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$28" class="0">
<segment>
<pinref part="J1" gate="G$1" pin="SLEEVE"/>
<wire x1="388.62" y1="127" x2="416.56" y2="127" width="0.1524" layer="91"/>
<wire x1="416.56" y1="127" x2="416.56" y2="116.84" width="0.1524" layer="91"/>
<pinref part="SV1" gate="G$1" pin="9"/>
<wire x1="416.56" y1="116.84" x2="424.18" y2="116.84" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$29" class="0">
<segment>
<pinref part="J1" gate="G$1" pin="RING2"/>
<wire x1="388.62" y1="121.92" x2="396.24" y2="121.92" width="0.1524" layer="91"/>
<wire x1="396.24" y1="121.92" x2="396.24" y2="114.3" width="0.1524" layer="91"/>
<pinref part="SV1" gate="G$1" pin="11"/>
<wire x1="396.24" y1="114.3" x2="424.18" y2="114.3" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$30" class="0">
<segment>
<pinref part="J1" gate="G$1" pin="RING1"/>
<pinref part="SV1" gate="G$1" pin="13"/>
<wire x1="388.62" y1="111.76" x2="424.18" y2="111.76" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$31" class="0">
<segment>
<pinref part="J1" gate="G$1" pin="TIP_SWITCH"/>
<wire x1="388.62" y1="101.6" x2="419.1" y2="101.6" width="0.1524" layer="91"/>
<wire x1="419.1" y1="101.6" x2="419.1" y2="109.22" width="0.1524" layer="91"/>
<pinref part="SV1" gate="G$1" pin="15"/>
<wire x1="419.1" y1="109.22" x2="424.18" y2="109.22" width="0.1524" layer="91"/>
</segment>
</net>
<net name="ONBRD_SPKP" class="0">
<segment>
<pinref part="LS1" gate="G$1" pin="P"/>
<wire x1="424.18" y1="149.86" x2="436.88" y2="149.86" width="0.1524" layer="91"/>
<label x="426.72" y="149.86" size="1.778" layer="95"/>
<wire x1="424.18" y1="149.86" x2="419.1" y2="149.86" width="0.1524" layer="91"/>
<wire x1="419.1" y1="149.86" x2="419.1" y2="127" width="0.1524" layer="91"/>
<junction x="424.18" y="149.86"/>
<pinref part="SV1" gate="G$1" pin="1"/>
<wire x1="419.1" y1="127" x2="424.18" y2="127" width="0.1524" layer="91"/>
</segment>
</net>
<net name="ONBRD_SPKN" class="0">
<segment>
<pinref part="LS1" gate="G$1" pin="M"/>
<wire x1="424.18" y1="139.7" x2="447.04" y2="139.7" width="0.1524" layer="91"/>
<label x="426.72" y="139.7" size="1.778" layer="95"/>
<wire x1="447.04" y1="139.7" x2="447.04" y2="127" width="0.1524" layer="91"/>
<pinref part="SV1" gate="G$1" pin="2"/>
<wire x1="447.04" y1="127" x2="439.42" y2="127" width="0.1524" layer="91"/>
</segment>
</net>
<net name="ONBRD_MICP" class="0">
<segment>
<wire x1="408.94" y1="81.28" x2="411.48" y2="81.28" width="0.1524" layer="91"/>
<label x="411.48" y="81.28" size="1.778" layer="95"/>
<pinref part="M2" gate="G$1" pin="2"/>
</segment>
</net>
<net name="ONBRD_MICN" class="0">
<segment>
<wire x1="408.94" y1="78.74" x2="411.48" y2="78.74" width="0.1524" layer="91"/>
<label x="411.48" y="78.74" size="1.778" layer="95"/>
<pinref part="M2" gate="G$1" pin="1"/>
</segment>
</net>
<net name="VBAT_ON" class="0">
<segment>
<pinref part="S1" gate="G$1" pin="4"/>
<wire x1="33.02" y1="187.96" x2="35.56" y2="187.96" width="0.1524" layer="91"/>
<wire x1="35.56" y1="187.96" x2="35.56" y2="185.42" width="0.1524" layer="91"/>
<wire x1="35.56" y1="185.42" x2="45.72" y2="185.42" width="0.1524" layer="91"/>
<label x="35.56" y="182.88" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="D4" gate="G$1" pin="A"/>
<wire x1="20.32" y1="335.28" x2="20.32" y2="337.82" width="0.1524" layer="91"/>
<wire x1="20.32" y1="337.82" x2="10.16" y2="337.82" width="0.1524" layer="91"/>
<label x="10.16" y="337.82" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="VCC"/>
<wire x1="469.9" y1="297.18" x2="482.6" y2="297.18" width="0.1524" layer="91"/>
<wire x1="482.6" y1="297.18" x2="482.6" y2="299.72" width="0.1524" layer="91"/>
<wire x1="490.22" y1="297.18" x2="482.6" y2="297.18" width="0.1524" layer="91"/>
<junction x="482.6" y="297.18"/>
<pinref part="C25" gate="G$1" pin="1"/>
<pinref part="C26" gate="G$1" pin="1"/>
<wire x1="490.22" y1="297.18" x2="497.84" y2="297.18" width="0.1524" layer="91"/>
<junction x="490.22" y="297.18"/>
<pinref part="C27" gate="G$1" pin="1"/>
<wire x1="497.84" y1="297.18" x2="505.46" y2="297.18" width="0.1524" layer="91"/>
<junction x="497.84" y="297.18"/>
<pinref part="C28" gate="G$1" pin="1"/>
<wire x1="505.46" y1="297.18" x2="513.08" y2="297.18" width="0.1524" layer="91"/>
<junction x="505.46" y="297.18"/>
<pinref part="C29" gate="G$1" pin="1"/>
<wire x1="513.08" y1="297.18" x2="520.7" y2="297.18" width="0.1524" layer="91"/>
<junction x="513.08" y="297.18"/>
<pinref part="C31" gate="G$1" pin="1"/>
<wire x1="520.7" y1="297.18" x2="528.32" y2="297.18" width="0.1524" layer="91"/>
<junction x="520.7" y="297.18"/>
<label x="482.6" y="299.72" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="L" gate="G$1" pin="A"/>
<pinref part="R10" gate="G$1" pin="2"/>
<wire x1="48.26" y1="76.2" x2="48.26" y2="73.66" width="0.1524" layer="91"/>
</segment>
</net>
<net name="UART_CTS" class="0">
<segment>
<pinref part="U4" gate="G$1" pin="CTS"/>
<wire x1="424.18" y1="269.24" x2="408.94" y2="269.24" width="0.1524" layer="91"/>
<label x="408.94" y="269.24" size="1.778" layer="95"/>
</segment>
<segment>
<label x="360.68" y="289.56" size="1.778" layer="95"/>
<pinref part="U6" gate="A" pin="B4"/>
<wire x1="355.6" y1="289.56" x2="375.92" y2="289.56" width="0.1524" layer="91"/>
</segment>
</net>
<net name="5_UART_CTS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PD5(XCK/CTS)"/>
<wire x1="254" y1="220.98" x2="269.24" y2="220.98" width="0.1524" layer="91"/>
<label x="256.54" y="220.98" size="1.778" layer="95"/>
</segment>
<segment>
<label x="360.68" y="297.18" size="1.778" layer="95"/>
<wire x1="375.92" y1="297.18" x2="355.6" y2="297.18" width="0.1524" layer="91"/>
<pinref part="U6" gate="A" pin="A4"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
<errors>
<approved hash="101,1,114.3,236.22,X2-6,S,,,,"/>
<approved hash="102,1,55.88,325.12,OUT,+3V3,,,,"/>
<approved hash="104,1,35.56,325.12,U2,IN,VBUS,,,"/>
<approved hash="104,1,22.86,223.52,U3,VDD,VBUS,,,"/>
<approved hash="104,1,48.26,218.44,U3,VSS,GND,,,"/>
<approved hash="104,1,469.9,297.18,U4,VCC,VBAT_ON,,,"/>
<approved hash="204,1,469.9,294.64,U4,V_BCKP,,,,"/>
<approved hash="202,1,424.18,284.48,U4,ANT2,,,,"/>
<approved hash="202,1,424.18,281.94,U4,ANT_DET,,,,"/>
<approved hash="104,1,457.2,170.18,U5,AGND,GND,,,"/>
<approved hash="104,1,457.2,195.58,U5,AVDD,V_INT,,,"/>
<approved hash="104,1,457.2,193.04,U5,DVDDIO,V_INT,,,"/>
<approved hash="104,1,457.2,172.72,U5,DGND,GND,,,"/>
<approved hash="104,1,457.2,198.12,U5,DVDD,V_INT,,,"/>
<approved hash="104,1,457.2,167.64,U5,MICGND,GND,,,"/>
<approved hash="104,1,457.2,165.1,U5,EP,GND,,,"/>
<approved hash="104,1,355.6,322.58,U6,VCCA,+3V3,,,"/>
<approved hash="104,1,355.6,320.04,U6,VCCB,V_INT,,,"/>
<approved hash="106,1,254,213.36,0,,,,,"/>
<approved hash="106,1,254,210.82,2,,,,,"/>
<approved hash="106,1,254,208.28,3,,,,,"/>
<approved hash="106,1,254,223.52,12,,,,,"/>
<approved hash="106,1,254,238.76,MISO,,,,,"/>
<approved hash="106,1,254,236.22,MOSI,,,,,"/>
<approved hash="106,1,408.94,78.74,ONBRD_MICN,,,,,"/>
<approved hash="106,1,408.94,81.28,ONBRD_MICP,,,,,"/>
<approved hash="106,1,254,233.68,SCK,,,,,"/>
<approved hash="113,1,399.721,203.495,JP2,,,,,"/>
<approved hash="113,1,366.701,173.015,JP4,,,,,"/>
<approved hash="113,1,356.541,180.635,JP5,,,,,"/>
<approved hash="113,1,485.435,354.659,JP1,,,,,"/>
<approved hash="113,1,485.435,334.339,JP3,,,,,"/>
<approved hash="113,1,431.8,116.55,SV1,,,,,"/>
<approved hash="113,1,354.001,190.795,JP6,,,,,"/>
<approved hash="113,1,481.659,181.61,JP7,,,,,"/>
<approved hash="113,1,269.136,175.156,FRAME2,,,,,"/>
</errors>
</schematic>
</drawing>
<compatibility>
<note version="6.3" minversion="6.2.2" severity="warning">
Since Version 6.2.2 text objects can contain more than one line,
which will not be processed correctly with this version.
</note>
<note version="8.2" severity="warning">
Since Version 8.2, EAGLE supports online libraries. The ids
of those online libraries will not be understood (or retained)
with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports URNs for individual library
assets (packages, symbols, and devices). The URNs of those assets
will not be understood (or retained) with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports the association of 3D packages
with devices in libraries, schematics, and board files. Those 3D
packages will not be understood (or retained) with this version.
</note>
<note version="8.4" severity="warning">
Since Version 8.4, EAGLE supports properties for SPICE simulation. 
Probes in schematics and SPICE mapping objects found in parts and library devices
will not be understood with this version. Update EAGLE to the latest version
for full support of SPICE simulation. 
</note>
</compatibility>
</eagle>
